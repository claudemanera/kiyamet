package com.kiyamet.ally;

import com.kiyamet.Kiyamet;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ModAllies {
    private static final class_5321<class_1299<?>> TURRET_KEY = class_5321.method_29179(class_7924.field_41266, Kiyamet.id("auto_turret"));
    public static final class_1299<TurretDrone> TURRET = class_2378.method_39197(class_7923.field_41177, TURRET_KEY,
            class_1299.class_1300.<TurretDrone>method_5903(TurretDrone::new, class_1311.field_17715).method_17687(0.9f, 1.1f).method_19947().method_27299(8).method_5905(TURRET_KEY));

    public static void init() {
        FabricDefaultAttributeRegistry.register(TURRET, class_1308.method_26828().method_26868(class_5134.field_23716, 60).method_26868(class_5134.field_23724, 14).method_26868(class_5134.field_23718, 1.0));
    }

    private ModAllies() {}
}
