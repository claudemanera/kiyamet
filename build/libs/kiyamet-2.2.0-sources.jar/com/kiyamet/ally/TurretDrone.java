package com.kiyamet.ally;

import com.kiyamet.defense.Power;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.Comparator;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_1569;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Auto Turret (1.6): a 3D tripod gun placed on the ground. Turns to the nearest walker, raider or masked one within
 * 22 blocks and fires on its own. Faster on generator power. Sneak + right-click to pack it back up.
 */
public class TurretDrone extends class_1314 implements GeoEntity {
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("misc.idle");
    private static final RawAnimation SHOOT = RawAnimation.begin().thenPlay("attack.swing");
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private int cooldown;
    public float bonus;

    public TurretDrone(class_1299<? extends class_1314> type, class_1937 level) {
        super(type, level);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar c) {
        c.add(new AnimationController<TurretDrone>("main", 0, t -> t.setAndContinue(IDLE)).triggerableAnim("shoot", SHOOT));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    @Override
    public boolean method_5747(double d, float m, class_1282 s) { return false; }

    @Override
    public boolean method_5810() { return false; }

    @Override
    public boolean method_5974(double d) { return false; }

    @Override
    protected net.minecraft.class_1269 method_5992(net.minecraft.class_1657 player, net.minecraft.class_1268 hand) {
        if (!player.method_5715()) return net.minecraft.class_1269.field_5811;
        if (method_73183() instanceof class_3218) {
            net.minecraft.class_1799 it = new net.minecraft.class_1799(com.kiyamet.registry.ModItems.get("auto_turret"));
            if (!player.method_31548().method_7394(it)) player.method_7328(it, false);
            method_5783(class_3417.field_14862.comp_349(), 1f, 0.8f);
            method_31472();
        }
        return net.minecraft.class_1269.field_5812;
    }

    static boolean hostile(class_1309 e) {
        if (e instanceof class_1569) return true;
        return e instanceof com.kiyamet.npc.HumanEntity h && (h.faction() == com.kiyamet.npc.Faction.RAIDER || h.faction() == com.kiyamet.npc.Faction.WHISPERER);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        method_18800(0, method_18798().field_1351, 0);
        if (!(method_73183() instanceof class_3218 level)) return;
        if (cooldown-- > 0) return;
        class_1309 target = level.method_8390(class_1309.class, method_5829().method_1014(22), e -> hostile(e) && e.method_5805() && method_6057(e))
                .stream().min(Comparator.comparingDouble(this::method_5858)).orElse(null);
        if (target == null) { cooldown = 10; return; }
        boolean powered = Power.isPowered(level, method_24515());
        cooldown = powered ? 5 : 9;
        double dx = target.method_23317() - method_23317(), dz = target.method_23321() - method_23321();
        float yaw = (float) (Math.atan2(dz, dx) * 180 / Math.PI) - 90f;
        method_36456(yaw); field_6283 = yaw; field_6241 = yaw;
        class_243 look = new class_243(dx, 0, dz).method_1029();
        class_243 from = method_73189().method_1031(0, 0.8, 0).method_1019(look.method_1021(0.8)), to = target.method_33571().method_1031(0, -0.3, 0);
        int n = (int) (from.method_1022(to) * 2);
        for (int i = 0; i < n; i++) { class_243 at = from.method_1019(to.method_1020(from).method_1021(i / (double) n)); level.method_65096(class_2398.field_11205, at.field_1352, at.field_1351, at.field_1350, 1, 0, 0, 0, 0); }
        level.method_65096(class_2398.field_11251, from.field_1352, from.field_1351, from.field_1350, 3, 0.05, 0.05, 0.05, 0.01);
        level.method_65096(class_2398.field_11240, from.field_1352, from.field_1351, from.field_1350, 1, 0, 0, 0, 0);
        target.method_64397(level, level.method_48963().method_48812(this), 5 + bonus * 2);
        level.method_8396(null, method_24515(), class_3417.field_14917, class_3419.field_15254, 0.7f, 1.4f);
        triggerAnim("main", "shoot");
        com.kiyamet.world.NoiseSystem.make(level, method_24515(), 18, 4);
    }
}
