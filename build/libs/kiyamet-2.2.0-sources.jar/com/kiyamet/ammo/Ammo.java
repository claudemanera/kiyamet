package com.kiyamet.ammo;

import com.kiyamet.registry.ModItems;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/** 1.5 bullet system: 6 ammo types, magazines that hold 32-256 rounds, every gun takes one ammo type. */
public final class Ammo {
    public enum Type {
        PISTOL("pistol_ammo", "9mm", class_124.field_1065), RIFLE("rifle_ammo", "7.62mm", class_124.field_1054),
        SHELL("shotgun_shell", "12 Gauge", class_124.field_1061), SNIPER("sniper_ammo", ".50 BMG", class_124.field_1075),
        ROCKET("rocket_ammo", "Rocket", class_124.field_1077), PLASMA("plasma_cell", "Plasma Cell", class_124.field_1076);
        public final String id, label; public final class_124 color;
        Type(String id, String label, class_124 color) { this.id = id; this.label = label; this.color = color; }
        public class_1792 item() { return ModItems.get(id); }
        public static Type byName(String n) { for (Type t : values()) if (t.name().equals(n)) return t; return null; }
        public static Type ofItem(class_1799 s) { for (Type t : values()) if (!s.method_7960() && s.method_31574(t.item())) return t; return null; }
    }

    public static final String[] AMMO = {"pistol_ammo", "rifle_ammo", "shotgun_shell", "sniper_ammo", "rocket_ammo", "plasma_cell"};
    public static final String[][] MAGS = {{"magazine_small", "32"}, {"magazine", "64"}, {"magazine_large", "128"}, {"magazine_drum", "256"}};

    public static Type typeFor(String gun) {
        return switch (gun) {
            case "arrow_pistol", "silenced_arrow_pistol", "service_pistol", "compact_pistol", "tactical_pistol", "hand_cannon", "revolver", "magnum_revolver",
                 "machine_pistol", "golden_pistol", "flare_pistol", "survivor_smg", "arrow_repeater" -> Type.PISTOL;
            case "arrow_shotgun", "double_arrow_rifle", "pump_shotgun", "sawed_off", "auto_shotgun", "ak_shotgun", "behemoth_shotgun" -> Type.SHELL;
            case "arrow_sniper", "bolt_sniper", "hunting_rifle", "marksman_rifle", "anti_materiel_rifle", "ghillie_sniper", "silent_sniper", "longshot_rifle", "harpoon_gun" -> Type.SNIPER;
            case "arrow_launcher", "apocalypse_cannon", "ak_grenadier" -> Type.ROCKET;
            case "tesla_arrow_gun", "arrow_railgun", "void_arrow_launcher", "homing_arrow_gun", "frost_arrow_gun", "toxic_arrow_rifle" -> Type.PLASMA;
            default -> Type.RIFLE;
        };
    }

    /** Loose rounds of a type in the inventory. */
    public static int loose(class_1661 inv, Type t) {
        int n = 0;
        for (int i = 0; i < inv.method_5439(); i++) { class_1799 s = inv.method_5438(i); if (s.method_31574(t.item())) n += s.method_7947(); }
        return n;
    }

    /** Rounds in loaded magazines of that type. */
    public static int loaded(class_1661 inv, Type t) {
        int n = 0;
        for (int i = 0; i < inv.method_5439(); i++) { class_1799 s = inv.method_5438(i); if (s.method_7909() instanceof MagazineItem && MagazineItem.type(s) == t) n += MagazineItem.rounds(s); }
        return n;
    }

    /** Takes n rounds: magazines first (offhand, then the fullest-first order of the inventory), then loose rounds. */
    public static boolean take(class_3222 p, Type t, int n) {
        if (p.method_68878()) return true;
        class_1661 inv = p.method_31548();
        if (loaded(inv, t) + loose(inv, t) < n) return false;
        class_1799 off = p.method_5998(class_1268.field_5810);
        if (off.method_7909() instanceof MagazineItem && MagazineItem.type(off) == t) n -= MagazineItem.drain(off, n);
        for (int i = 0; i < inv.method_5439() && n > 0; i++) {
            class_1799 s = inv.method_5438(i);
            if (s.method_7909() instanceof MagazineItem && MagazineItem.type(s) == t) n -= MagazineItem.drain(s, n);
        }
        for (int i = 0; i < inv.method_5439() && n > 0; i++) {
            class_1799 s = inv.method_5438(i);
            if (s.method_31574(t.item())) { int k = Math.min(n, s.method_7947()); s.method_7934(k); n -= k; }
        }
        return true;
    }

    public static class_2561 hud(class_3222 p, class_1799 gun, Type t) {
        class_1661 inv = p.method_31548();
        return class_2561.method_43473().method_10852(gun.method_7964().method_27661().method_27692(class_124.field_1068)).method_10852(class_2561.method_43470("  |  ").method_27692(class_124.field_1063))
                .method_10852(class_2561.method_43470(t.label + " ").method_27695(t.color, class_124.field_1067))
                .method_10852(class_2561.method_43470(loaded(inv, t) + " in mags").method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("  +" + loose(inv, t) + " loose").method_27692(class_124.field_1080));
    }

    private Ammo() {}
}
