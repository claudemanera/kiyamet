package com.kiyamet.ammo;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_9279;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

/** A magazine: right-click to load rounds from the inventory, sneak + right-click to empty it back. Guns draw from it first. */
public class MagazineItem extends class_1792 {
    public final int capacity;

    public MagazineItem(class_1793 p, int capacity) { super(p); this.capacity = capacity; }

    static class_2487 tag(class_1799 s) { return s.method_58695(class_9334.field_49628, class_9279.field_49302).method_57461(); }
    public static int rounds(class_1799 s) { return tag(s).method_68083("Rounds", 0); }
    public static Ammo.Type type(class_1799 s) { return Ammo.Type.byName(tag(s).method_68564("Ammo", "")); }

    static void set(class_1799 s, Ammo.Type t, int n) {
        class_2487 c = tag(s);
        if (n <= 0 || t == null) { c.method_10551("Rounds"); c.method_10551("Ammo"); } else { c.method_10569("Rounds", n); c.method_10582("Ammo", t.name()); }
        if (c.method_33133()) s.method_57381(class_9334.field_49628); else s.method_57379(class_9334.field_49628, class_9279.method_57456(c));
        int cap = s.method_7909() instanceof MagazineItem m ? m.capacity : 0;
        List<class_2561> lore = new ArrayList<>();
        if (n > 0 && t != null) lore.add(class_2561.method_43470(t.label + ": " + n + " / " + cap).method_27692(t.color));
        else lore.add(class_2561.method_43470("Empty - holds " + cap + " rounds").method_27692(class_124.field_1080));
        lore.add(class_2561.method_43470("Right-click: load · Sneak: empty").method_27692(class_124.field_1063));
        s.method_57379(class_9334.field_49632, new class_9290(lore));
    }

    /** Removes up to n rounds, returns how many were taken. */
    static int drain(class_1799 s, int n) {
        int have = rounds(s), k = Math.min(have, n);
        set(s, type(s), have - k);
        return k;
    }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 mag = player.method_5998(hand);
        if (!(player instanceof class_3222 p)) return class_1269.field_5812;
        class_1661 inv = p.method_31548();
        Ammo.Type t = type(mag);
        int have = rounds(mag);
        if (p.method_5715()) {   // empty it
            if (have <= 0 || t == null) return class_1269.field_5814;
            int left = have;
            while (left > 0) { int k = Math.min(left, t.item().method_7882()); class_1799 out = new class_1799(t.item(), k); if (!inv.method_7394(out)) p.method_7328(out, false); left -= k; }
            set(mag, null, 0);
            level.method_8396(null, p.method_24515(), class_3417.field_15191.comp_349(), class_3419.field_15248, 0.7f, 0.8f);
            p.method_7353(class_2561.method_43470("Magazine emptied: " + have + " " + t.label).method_27692(t.color), true);
            return class_1269.field_21466;
        }
        if (t == null) {   // pick the type: the gun in the other hand, else the first ammo found
            class_1799 other = p.method_5998(hand == class_1268.field_5808 ? class_1268.field_5810 : class_1268.field_5808);
            if (other.method_7909() instanceof com.kiyamet.item.GunItem) t = Ammo.typeFor(net.minecraft.class_7923.field_41178.method_10221(other.method_7909()).method_12832());
            if (t == null || Ammo.loose(inv, t) == 0)
                for (int i = 0; i < inv.method_5439() && (t == null || Ammo.loose(inv, t) == 0); i++) { Ammo.Type f = Ammo.Type.ofItem(inv.method_5438(i)); if (f != null) t = f; }
        }
        if (t == null || Ammo.loose(inv, t) == 0) { p.method_7353(class_2561.method_43470("No rounds to load.").method_27692(class_124.field_1061), true); return class_1269.field_5814; }
        int room = capacity - have;
        if (room <= 0) { p.method_7353(class_2561.method_43470("Magazine is full.").method_27692(class_124.field_1054), true); return class_1269.field_5814; }
        int added = 0;
        for (int i = 0; i < inv.method_5439() && added < room; i++) {
            class_1799 s = inv.method_5438(i);
            if (s.method_31574(t.item())) { int k = Math.min(room - added, s.method_7947()); s.method_7934(k); added += k; }
        }
        set(mag, t, have + added);
        level.method_8396(null, p.method_24515(), class_3417.field_14862.comp_349(), class_3419.field_15248, 0.8f, 1.3f);
        p.method_7353(class_2561.method_43470("Loaded " + added + " " + t.label + "  (" + (have + added) + "/" + capacity + ")").method_27692(t.color), true);
        p.method_7357().method_62835(mag, 10);
        return class_1269.field_21466;
    }

    @Override public boolean method_31567(class_1799 s) { return rounds(s) > 0; }
    @Override public int method_31569(class_1799 s) { return Math.round(13f * rounds(s) / capacity); }
    @Override public int method_31571(class_1799 s) { Ammo.Type t = type(s); Integer c = t == null ? null : t.color.method_532(); return c == null ? 0xFFFFFF : c; }
}
