package com.kiyamet.backpack;

import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/** Right-click: open it. Sneak + right-click: wear it on your back (its own slot, shown on your back). */
public class BackpackItem extends class_1792 {
    public final BackpackTier tier;

    public BackpackItem(class_1793 p, BackpackTier tier) {
        super(p);
        this.tier = tier;
    }

    @Override
    public class_1269 method_7884(net.minecraft.class_1838 ctx) {
        class_1269 r = com.kiyamet.furniture.BagBlock.place(ctx);
        return r != class_1269.field_5811 ? r : super.method_7884(ctx);
    }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        if (!(player instanceof class_3222 sp)) return class_1269.field_5812;
        class_1799 stack = sp.method_5998(hand);
        if (sp.method_5715()) {
            class_1799 worn = Backpacks.worn(sp);
            Backpacks.setWorn(sp, stack.method_7972());
            sp.method_6122(hand, worn);
            sp.method_51469().method_8396(null, sp.method_24515(), class_3417.field_14581.comp_349(), class_3419.field_15248, 1f, 1f);
            sp.method_7353(class_2561.method_43470("You put on the " + tier.title + ". Press U to open it.").method_27692(class_124.field_1065), true);
            return class_1269.field_21466;
        }
        BackpackMenu.openFromHand(sp, hand);
        return class_1269.field_21466;
    }
}
