package com.kiyamet.backpack;

import com.kiyamet.ui.Ui;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3917;
import net.minecraft.class_747;
import net.minecraft.class_9288;
import net.minecraft.class_9334;

/** Backpack contents. The last row is a toolbar (info, sort, pages, take off). Big packs (over 45 slots) have pages. */
public class BackpackMenu extends class_1707 {
    public static final int PAGE = 45;
    private final class_3222 player;
    private final class_1277 box;
    private final BackpackTier tier;
    private final int rows, cap;
    private final boolean worn;
    private final int handSlot;          // inventory index of the backpack when opened from the hand, else -1
    private final List<class_1799> data = new ArrayList<>();
    private int page;
    private class_1799 source;

    private static class_3917<class_1707> type(int rows) {
        return switch (rows) { case 1 -> class_3917.field_18664; case 2 -> class_3917.field_18665; case 3 -> class_3917.field_17326; case 4 -> class_3917.field_18666; case 5 -> class_3917.field_18667; default -> class_3917.field_17327; };
    }

    public static void openWorn(class_3222 p) {
        class_1799 s = Backpacks.worn(p);
        if (!(s.method_7909() instanceof BackpackItem b)) {
            p.method_7353(class_2561.method_43470("You aren't wearing a backpack. Sneak + right-click one to put it on.").method_27692(class_124.field_1080), true);
            return;
        }
        open(p, s, b.tier, true, -1);
    }

    public static void openFromHand(class_3222 p, class_1268 hand) {
        class_1799 s = p.method_5998(hand);
        if (!(s.method_7909() instanceof BackpackItem b)) return;
        int slot = hand == class_1268.field_5810 ? class_1661.field_30639 : p.method_31548().method_67532();
        open(p, s, b.tier, false, slot);
    }

    private static void open(class_3222 p, class_1799 s, BackpackTier t, boolean worn, int handSlot) {
        int rows = Math.min(6, t.rows() + 1);
        p.method_17355(new class_747((id, inv, pl) -> new BackpackMenu(id, inv, p, s, t, worn, handSlot, rows),
                class_2561.method_43470(t.title + "  (" + t.capacity + " slots)")));
        p.method_51469().method_8396(null, p.method_24515(), class_3417.field_34375, class_3419.field_15248, 0.6f, 1.2f);
    }

    private BackpackMenu(int id, class_1661 inv, class_3222 p, class_1799 source, BackpackTier t, boolean worn, int handSlot, int rows) {
        this(id, inv, p, source, t, worn, handSlot, rows, new class_1277(rows * 9));
    }

    private BackpackMenu(int id, class_1661 inv, class_3222 p, class_1799 source, BackpackTier t, boolean worn, int handSlot, int rows, class_1277 box) {
        super(type(rows), id, inv, box, rows);
        this.player = p; this.box = box; this.tier = t; this.rows = rows; this.cap = t.capacity; this.worn = worn; this.handSlot = handSlot; this.source = source;
        class_9288 contents = source.method_58695(class_9334.field_49622, class_9288.field_49334);
        List<class_1799> items = new ArrayList<>();
        contents.method_57489().forEach(items::add);
        for (int i = 0; i < cap; i++) data.add(i < items.size() ? items.get(i).method_7972() : class_1799.field_8037);
        show();
    }

    private int pages() { return (cap + PAGE - 1) / PAGE; }
    /** usable slots on this page */
    private int view() { return Math.min(PAGE, cap - page * PAGE); }
    private int toolbar() { return (rows - 1) * 9; }

    /** box -> data for the page on screen */
    private void pull() { for (int i = 0; i < view(); i++) data.set(page * PAGE + i, box.method_5438(i).method_7972()); }

    /** data -> box for the page on screen, plus chrome */
    private void show() {
        for (int i = 0; i < view(); i++) box.method_5447(i, data.get(page * PAGE + i).method_7972());
        drawChrome();
    }

    private void drawChrome() {
        int v = view();
        for (int i = v; i < toolbar(); i++) box.method_5447(i, Ui.icon(class_1802.field_8871, Ui.text(pages() > 1 ? "End of the backpack" : "Locked: upgrade the backpack", class_124.field_1063)));
        int tb = toolbar();
        for (int i = tb; i < tb + 9; i++) box.method_5447(i, Ui.dark());
        int used = 0;
        for (class_1799 s : data) if (!s.method_7960()) used++;
        BackpackTier next = BackpackTier.byIndex(tier.ordinal() + 1);
        box.method_5447(tb + 4, Ui.glint(Ui.icon(Backpacks.ITEMS.get(tier), Ui.text(tier.title, class_124.field_1065, class_124.field_1067),
                Ui.text("Used " + used + " / " + cap + " slots", class_124.field_1080), Ui.bar(used / (double) cap, 18),
                Ui.text(pages() > 1 ? "Page " + (page + 1) + " / " + pages() : "", class_124.field_1054),
                Ui.text(next == null ? "★ Biggest backpack" : "Upgrade: craft with 1 " + next.upgrade.substring(next.upgrade.indexOf(':') + 1).replace('_', ' ') + " → " + next.title + " (" + next.capacity + ")", class_124.field_1075)), true));
        box.method_5447(tb + 2, Ui.icon(class_1802.field_8239, Ui.text("Sort & stack", class_124.field_1054)));
        if (worn) box.method_5447(tb + 6, Ui.icon(class_1802.field_8745, Ui.text("Take off backpack", class_124.field_1061), Ui.text("Moves it into your inventory", class_124.field_1080)));
        if (page > 0) box.method_5447(tb, Ui.icon(class_1802.field_8107, Ui.text("◀ Page " + page, class_124.field_1054)));
        if (page + 1 < pages()) box.method_5447(tb + 8, Ui.icon(class_1802.field_8236, Ui.text("Page " + (page + 2) + " ▶", class_124.field_1054)));
    }

    private void save() {
        class_1799 target = worn ? Backpacks.worn(player) : handSlot >= 0 ? player.method_31548().method_5438(handSlot) : class_1799.field_8037;
        if (!(target.method_7909() instanceof BackpackItem)) return;
        List<class_1799> items = new ArrayList<>();
        for (class_1799 s : data) items.add(s.method_7972());
        target.method_57379(class_9334.field_49622, class_9288.method_57493(items));
        if (worn) Backpacks.setWorn(player, target);
    }

    private void sort() {
        List<class_1799> all = new ArrayList<>();
        for (class_1799 s : data) if (!s.method_7960()) all.add(s.method_7972());
        all.sort((a, b) -> a.method_7964().getString().compareTo(b.method_7964().getString()));
        class_1277 tmp = new class_1277(cap);
        for (class_1799 s : all) tmp.method_5491(s);
        for (int i = 0; i < cap; i++) data.set(i, tmp.method_5438(i));
    }

    @Override
    public void method_7593(int slot, int button, class_1713 type, class_1657 p) {
        int tb = toolbar();
        if (slot >= view() && slot < rows * 9) {
            pull();
            if (slot == tb + 2) { sort(); save(); show(); }
            else if (slot == tb && page > 0) { page--; show(); }
            else if (slot == tb + 8 && page + 1 < pages()) { page++; show(); }
            else if (slot == tb + 6 && worn) {
                save();
                class_1799 pack = Backpacks.worn(player);
                Backpacks.setWorn(player, class_1799.field_8037);
                player.method_7346();
                if (!player.method_31548().method_7394(pack)) player.method_7328(pack, false);
            }
            return;
        }
        if (slot >= rows * 9 && handSlot >= 0) {                     // never move the open backpack itself
            class_1735 s = slot < field_7761.size() ? field_7761.get(slot) : null;
            if (s != null && s.field_7871 == player.method_31548() && s.method_34266() == handSlot) return;
        }
        if (type == class_1713.field_7791 && (button == handSlot || button == 40 && handSlot == class_1661.field_30639)) return;
        class_1799 carried = method_34255();
        if (slot >= 0 && slot < view() && carried.method_7909() instanceof BackpackItem) return;   // no backpacks inside backpacks
        super.method_7593(slot, button, type, p);
        pull();
        save();
        drawChrome();
    }

    @Override
    public class_1799 method_7601(class_1657 p, int index) {
        class_1735 s = field_7761.get(index);
        if (!s.method_7681()) return class_1799.field_8037;
        class_1799 stack = s.method_7677();
        if (index < view()) {
            if (!method_7616(stack, rows * 9, field_7761.size(), true)) return class_1799.field_8037;
        } else if (index >= rows * 9) {
            if (stack.method_7909() instanceof BackpackItem) return class_1799.field_8037;
            if (!method_7616(stack, 0, view(), false)) return class_1799.field_8037;
        } else return class_1799.field_8037;
        if (stack.method_7960()) s.method_53512(class_1799.field_8037); else s.method_7668();
        pull();
        save();
        return class_1799.field_8037;
    }

    @Override
    public void method_7595(class_1657 p) {
        pull();
        save();
        for (int i = 0; i < rows * 9; i++) box.method_5447(i, class_1799.field_8037);          // contents live on the item, not in this temp box
        super.method_7595(p);
    }
}
