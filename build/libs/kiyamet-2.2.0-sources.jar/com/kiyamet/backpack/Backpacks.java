package com.kiyamet.backpack;

import com.kiyamet.Kiyamet;
import com.kiyamet.registry.ModItems;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_1542;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_3222;
import net.minecraft.class_9135;
import com.mojang.serialization.Codec;
import java.util.EnumMap;
import java.util.Map;

/** Back slot (extra equipment slot just for backpacks) + registration. */
public final class Backpacks {
    public static final Map<BackpackTier, class_1792> ITEMS = new EnumMap<>(BackpackTier.class);

    /** The backpack you wear (server only, saved with the player). */
    public static final AttachmentType<class_1799> WORN = AttachmentRegistry.create(Kiyamet.id("worn_backpack"),
            b -> b.initializer(() -> class_1799.field_8037).persistent(class_1799.field_49266));
    /** Which backpack to draw on your back (-1 = none), synced to every client. */
    public static final AttachmentType<Integer> WORN_TIER = AttachmentRegistry.create(Kiyamet.id("worn_backpack_tier"),
            b -> b.initializer(() -> -1).persistent(Codec.INT).syncWith(class_9135.field_48550, AttachmentSyncPredicate.all()));

    public static class_1799 worn(class_3222 p) { return p.getAttachedOrElse(WORN, class_1799.field_8037); }

    public static void setWorn(class_3222 p, class_1799 s) {
        p.setAttached(WORN, s);
        p.setAttached(WORN_TIER, s.method_7909() instanceof BackpackItem b ? b.tier.ordinal() : -1);
    }

    public static void init() {
        for (BackpackTier t : BackpackTier.values())
            ITEMS.put(t, ModItems.custom(t.id, p -> new BackpackItem(p.method_7889(1).method_7894(t.ordinal() >= 8 ? class_1814.field_8904 : t.ordinal() >= 5 ? class_1814.field_8903 : class_1814.field_8906), t)));
        // the worn backpack drops where you die (with everything inside)
        ServerLivingEntityEvents.AFTER_DEATH.register((e, src) -> {
            if (e instanceof class_3222 p && !worn(p).method_7960()) {
                p.method_51469().method_8649(new class_1542(p.method_51469(), p.method_23317(), p.method_23318() + 0.5, p.method_23321(), worn(p)));
                setWorn(p, class_1799.field_8037);
            }
        });
    }

    private Backpacks() {}
}
