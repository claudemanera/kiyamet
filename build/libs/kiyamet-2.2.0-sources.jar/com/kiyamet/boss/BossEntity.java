package com.kiyamet.boss;

import com.kiyamet.entity.KZombie;
import com.kiyamet.entity.ModEntities;
import com.kiyamet.entity.ZombieKind;
import com.kiyamet.robot.ModRobots;
import com.kiyamet.robot.RobotKind;
import com.kiyamet.world.Infection;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.animation.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;
import net.minecraft.class_1259;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1366;
import net.minecraft.class_1376;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1538;
import net.minecraft.class_1542;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3213;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_7923;

/** One class for all 15 bosses. Each uses the three abilities of its {@link BossKind}; below 50% HP it enters phase 2. */
public class BossEntity extends class_1588 implements GeoEntity {
    public static final RawAnimation IDLE = RawAnimation.begin().thenLoop("misc.idle");
    public static final RawAnimation WALK = RawAnimation.begin().thenLoop("move.walk");
    public static final RawAnimation ATTACK = RawAnimation.begin().thenPlay("attack.swing");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    public final BossKind kind;
    private final class_3213 bar;
    private final int[] cooldowns;
    private boolean phase2;

    public BossEntity(class_1299<? extends class_1588> type, class_1937 level, BossKind kind) {
        super(type, level);
        this.kind = kind;
        this.cooldowns = new int[kind.abilities.length];
        for (int i = 0; i < cooldowns.length; i++) cooldowns[i] = 60 + i * 50;
        this.bar = new class_3213(class_2561.method_43470(kind.title), kind.color, class_1259.class_1261.field_5791);
        this.field_6194 = 200;
        method_5971();
    }

    @Override
    protected void method_5959() {
        field_6201.method_6277(0, new class_1347(this));
        field_6201.method_6277(2, new class_1366(this, 1.0, true));
        field_6201.method_6277(6, new class_1394(this, 0.6));
        field_6201.method_6277(7, new class_1361(this, class_1657.class, 24f));
        field_6201.method_6277(8, new class_1376(this));
        field_6185.method_6277(1, new class_1399(this));
        field_6185.method_6277(2, new class_1400<>(this, class_1657.class, true));
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<BossEntity>("main", 4, test -> test.setAndContinue(test.isMoving() ? WALK : IDLE)));
        controllers.add(new AnimationController<BossEntity>("attack", 0, test -> PlayState.STOP).triggerableAnim("attack", ATTACK));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    @Override
    public boolean method_5974(double distance) { return false; }

    @Override
    public void method_5837(class_3222 player) {
        super.method_5837(player);
        bar.method_14088(player);
    }

    @Override
    public void method_5742(class_3222 player) {
        super.method_5742(player);
        bar.method_14089(player);
    }

    @Override
    public boolean method_6121(class_3218 level, class_1297 target) {
        boolean hit = super.method_6121(level, target);
        if (hit) triggerAnim("attack", "attack");
        return hit;
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (!(method_73183() instanceof class_3218 level)) return;
        bar.method_5408(method_6032() / method_6063());
        if (!phase2 && method_6032() < method_6063() / 2) {
            phase2 = true;
            bar.method_5413(class_2561.method_43470(kind.title + " - Enraged"));
            method_6092(new class_1293(class_1294.field_5904, 999999, 0, false, false));
            method_6092(new class_1293(class_1294.field_5910, 999999, 0, false, false));
            level.method_8396(null, method_24515(), class_3417.field_14733, class_3419.field_15251, 3f, 0.6f);
        }
        class_1309 target = method_5968();
        for (int i = 0; i < cooldowns.length; i++) {
            Ability a = kind.abilities[i];
            if (a == Ability.SHADOW_CLOAK) { shadowCloak(level); continue; }
            if (cooldowns[i] > 0) { cooldowns[i] -= phase2 ? 2 : 1; continue; }
            if (target == null || !target.method_5805() || method_5739(target) > 32) continue;
            if (use(level, a, target)) cooldowns[i] = a.cooldown;
        }
    }

    private List<class_1657> playersNear(class_3218 level, double r) {
        return level.method_8390(class_1657.class, method_5829().method_1014(r), p -> p.method_5805() && !p.method_68878() && !p.method_7325());
    }

    private void burst(class_3218 level, class_2394 p, int n, double spread) {
        level.method_65096(p, method_23317(), method_23318() + method_17682() / 2, method_23321(), n, spread, method_17682() / 3, spread, 0.05);
    }

    private void line(class_3218 level, class_2394 p, class_243 from, class_243 to) {
        int n = (int) (from.method_1022(to) * 3);
        for (int i = 0; i < n; i++) { class_243 at = from.method_1019(to.method_1020(from).method_1021(i / (double) n)); level.method_65096(p, at.field_1352, at.field_1351, at.field_1350, 1, 0, 0, 0, 0); }
    }

    private float dmg(float mult) { return (float) (kind.damage * mult * (phase2 ? 1.3 : 1.0)); }

    private class_1282 src(class_3218 level) { return level.method_48963().method_48812(this); }

    /** @return true if the ability fired (cooldown starts). */
    private boolean use(class_3218 level, Ability a, class_1309 target) {
        double dist = method_5739(target);
        switch (a) {
            case INFECT_AURA -> {
                burst(level, class_2398.field_28803, 120, 5);
                for (class_1657 p : playersNear(level, 7)) {
                    p.method_6092(new class_1293(class_1294.field_5899, 100, 1));
                    if (p instanceof class_3222 sp) Infection.onZombieHit(sp, ZombieKind.TOXIC);
                }
            }
            case TOXIC_BURST -> {
                burst(level, class_2398.field_11246, 150, 4);
                for (class_1657 p : playersNear(level, 6)) { p.method_64397(level, src(level), dmg(0.6f)); p.method_6092(new class_1293(class_1294.field_5899, 120, 2)); p.method_6092(new class_1293(class_1294.field_5916, 160, 0)); }
            }
            case SUMMON_DOCTORS -> summonZombies(level, ZombieKind.DOCTOR, 3);
            case SUMMON_CRAWLERS -> summonZombies(level, ZombieKind.CRAWLER, 4);
            case SUMMON_TOXIC -> summonZombies(level, ZombieKind.TOXIC, 3);
            case SUMMON_GUARDS -> summonZombies(level, ZombieKind.ARMORED, 3);
            case SUMMON_SOLDIERS -> { summonZombies(level, ZombieKind.ARMORED, 2); summonZombies(level, ZombieKind.POLICE, 2); }
            case SUMMON_ROBOTS -> {
                for (int i = 0; i < 3; i++) {
                    RobotKind rk = i == 2 ? RobotKind.SCOUT_DRONE : RobotKind.ROBOT_TROOPER;
                    class_1308 m = ModRobots.TYPES.get(rk).method_5883(level, class_3730.field_16471);
                    if (m != null) { m.method_5814(method_23317() + field_5974.method_43048(7) - 3, method_23318() + (rk == RobotKind.SCOUT_DRONE ? 3 : 0), method_23321() + field_5974.method_43048(7) - 3); m.method_5980(target); level.method_8649(m); }
                }
                burst(level, class_2398.field_29644, 80, 2);
            }
            case CHARGE -> {
                if (dist < 4 || dist > 18) return false;
                class_243 d = target.method_73189().method_1020(method_73189()).method_1029();
                method_18800(d.field_1352 * 2.2, 0.3, d.field_1350 * 2.2);
                level.method_8396(null, method_24515(), class_3417.field_14733, class_3419.field_15251, 2f, 1f);
            }
            case BLEED -> {
                if (dist > 5) return false;
                target.method_64397(level, src(level), dmg(0.8f));
                target.method_6092(new class_1293(class_1294.field_5920, 100, 1));
                level.method_65096(class_2398.field_11209, target.method_23317(), target.method_23318() + 1, target.method_23321(), 20, 0.3, 0.5, 0.3, 0.1);
            }
            case SLAM -> {
                if (dist > 7) return false;
                slam(level, 6, 1.0f);
            }
            case LEAP_SLAM -> {
                if (!method_24828() || dist < 5) return false;
                class_243 d = target.method_73189().method_1020(method_73189());
                method_18800(d.field_1352 * 0.15, 1.0, d.field_1350 * 0.15);
                slamPending = 12;
            }
            case REGEN -> {
                if (method_6032() > method_6063() * 0.7f) return false;
                method_6025(method_6063() * 0.08f);
                burst(level, class_2398.field_11201, 20, 1.5);
            }
            case SOUL_DRAIN -> {
                for (class_1657 p : playersNear(level, 10)) { p.method_64397(level, level.method_48963().method_48831(), dmg(0.4f)); method_6025(dmg(0.4f)); line(level, class_2398.field_23114, p.method_33571(), method_33571()); }
            }
            case DARKNESS -> {
                for (class_1657 p : playersNear(level, 20)) p.method_6092(new class_1293(class_1294.field_38092, 200, 0));
                level.method_8396(null, method_24515(), class_3417.field_38075, class_3419.field_15251, 2f, 1.2f);
            }
            case SPIT, FIREBALL, BEAM -> {
                if (!method_6057(target)) return false;
                class_2394 p = a == Ability.SPIT ? class_2398.field_11228 : a == Ability.FIREBALL ? class_2398.field_11240 : class_2398.field_11207;
                line(level, p, method_33571(), target.method_33571());
                target.method_64397(level, a == Ability.BEAM ? level.method_48963().method_48831() : src(level), dmg(a == Ability.BEAM ? 0.7f : 0.5f));
                if (a == Ability.FIREBALL) target.method_5639(5);
                if (a == Ability.SPIT) target.method_6092(new class_1293(class_1294.field_5899, 80, 1));
            }
            case FIRE_RING -> {
                burst(level, class_2398.field_11240, 300, 6);
                for (class_1657 p : playersNear(level, 7)) { p.method_5639(6); p.method_64397(level, level.method_48963().method_48794(), dmg(0.5f)); }
                level.method_8396(null, method_24515(), class_3417.field_14970, class_3419.field_15251, 2f, 0.5f);
            }
            case TIME_SLOW -> {
                for (class_1657 p : playersNear(level, 16)) { p.method_6092(new class_1293(class_1294.field_5909, 120, 3)); p.method_6092(new class_1293(class_1294.field_5901, 120, 2)); }
                burst(level, class_2398.field_11215, 300, 8);
                level.method_8396(null, method_24515(), class_3417.field_19167, class_3419.field_15251, 3f, 0.5f);
            }
            case TELEPORT_BEHIND -> {
                if (dist < 4) return false;
                class_243 back = target.method_73189().method_1020(target.method_5720().method_18805(1, 0, 1).method_1029().method_1021(2.5));
                burst(level, class_2398.field_11214, 60, 1);
                method_5859(back.field_1352, target.method_23318(), back.field_1350);
                burst(level, class_2398.field_11214, 60, 1);
                level.method_8396(null, method_24515(), class_3417.field_14879, class_3419.field_15251, 2f, 0.7f);
            }
            case SHOCKWAVE -> {
                level.method_65096(class_2398.field_38908, method_23317(), method_23318() + 1, method_23321(), 12, 4, 0.5, 4, 0);
                level.method_8396(null, method_24515(), class_3417.field_38830, class_3419.field_15251, 3f, 1f);
                for (class_1657 p : playersNear(level, 10)) { p.method_64397(level, level.method_48963().method_48821(this), dmg(0.6f)); push(p, 1.6, 0.5); }
            }
            case LEVITATE -> {
                for (class_1657 p : playersNear(level, 14)) p.method_6092(new class_1293(class_1294.field_5902, 50, 1));
            }
            case LIGHTNING -> {
                for (class_1657 p : playersNear(level, 24)) {
                    class_1538 bolt = class_1299.field_6112.method_5883(level, class_3730.field_16461);
                    if (bolt != null) { bolt.method_5814(p.method_23317(), p.method_23318(), p.method_23321()); bolt.method_29498(true); level.method_8649(bolt); }
                    p.method_64397(level, level.method_48963().method_48809(), dmg(0.6f));
                }
            }
            case CURSE -> {
                for (class_1657 p : playersNear(level, 12)) { p.method_6092(new class_1293(class_1294.field_5911, 200, 1)); p.method_6092(new class_1293(class_1294.field_5909, 100, 1)); p.method_6092(new class_1293(class_1294.field_5899, 100, 0)); }
                burst(level, class_2398.field_11249, 120, 5);
                level.method_8396(null, method_24515(), class_3417.field_19153, class_3419.field_15251, 2f, 0.6f);
            }
            case ARROW_BARRAGE -> {
                for (class_1657 p : playersNear(level, 24)) {
                    if (!method_6057(p)) continue;
                    for (int i = 0; i < 4; i++) line(level, class_2398.field_11205, method_33571().method_1031(field_5974.method_43059(), 0, field_5974.method_43059()), p.method_33571());
                    p.method_64397(level, src(level), dmg(0.45f));
                }
                level.method_8396(null, method_24515(), class_3417.field_15187, class_3419.field_15251, 2f, 0.8f);
            }
            case PULL -> {
                if (dist < 4 || dist > 20) return false;
                class_243 d = method_73189().method_1020(target.method_73189()).method_1029();
                target.method_18800(d.field_1352 * 1.8, 0.5, d.field_1350 * 1.8);
                target.field_6037 = true;
                target.method_6092(new class_1293(class_1294.field_5901, 200, 2));
                line(level, class_2398.field_11233, method_33571(), target.method_33571());
            }
            case FREEZE -> {
                for (class_1657 p : playersNear(level, 10)) { p.method_32317(p.method_32315() + 120); p.method_6092(new class_1293(class_1294.field_5909, 100, 2)); p.method_64397(level, level.method_48963().method_48836(), dmg(0.4f)); }
                burst(level, class_2398.field_28013, 300, 6);
                level.method_8396(null, method_24515(), class_3417.field_15081, class_3419.field_15251, 3f, 0.5f);
            }
            default -> { return false; }
        }
        return true;
    }

    private int slamPending;

    @Override
    public void method_6007() {
        super.method_6007();
        if (slamPending > 0 && method_73183() instanceof class_3218 level) {
            slamPending--;
            if (method_24828() && slamPending < 10) { slamPending = 0; slam(level, 8, 1.3f); }
        }
    }

    private void slam(class_3218 level, double radius, float mult) {
        level.method_65096(class_2398.field_11236, method_23317(), method_23318() + 0.2, method_23321(), 8, radius / 2, 0.1, radius / 2, 0);
        level.method_8396(null, method_24515(), class_3417.field_15152.comp_349(), class_3419.field_15251, 2f, 0.6f);
        for (class_1657 p : playersNear(level, radius)) { p.method_64397(level, src(level), dmg(mult)); push(p, 1.2, 0.6); }
    }

    private void push(class_1309 e, double strength, double up) {
        class_243 d = e.method_73189().method_1020(method_73189()).method_18805(1, 0, 1).method_1029();
        e.method_18800(d.field_1352 * strength, up, d.field_1350 * strength);
        e.field_6037 = true;
    }

    private void summonZombies(class_3218 level, ZombieKind zk, int n) {
        for (int i = 0; i < n; i++) {
            KZombie z = ModEntities.ZOMBIES.get(zk).method_5883(level, class_3730.field_16471);
            if (z == null) continue;
            z.method_5814(method_23317() + field_5974.method_43048(9) - 4, method_23318(), method_23321() + field_5974.method_43048(9) - 4);
            z.method_5943(level, level.method_8404(method_24515()), class_3730.field_16471, null);
            z.method_5980(method_5968());
            level.method_8649(z);
        }
        burst(level, class_2398.field_11237, 60, 3);
        level.method_8396(null, method_24515(), class_3417.field_14905, class_3419.field_15251, 2f, 0.5f);
    }

    private void shadowCloak(class_3218 level) {
        if (field_6012 % 20 != 0) return;
        if (level.method_22339(method_24515()) < 8) method_6092(new class_1293(class_1294.field_5905, 30, 0, false, false));
        else method_6016(class_1294.field_5905);
    }

    @Override
    public void method_6078(class_1282 source) {
        super.method_6078(source);
        if (!(method_73183() instanceof class_3218 level)) return;
        for (String part : kind.drops.split(",")) {
            String[] kv = part.split(":");
            class_1792 item = class_7923.field_41178.method_63535(com.kiyamet.Kiyamet.id(kv[0]));
            int n = Integer.parseInt(kv[1]);
            level.method_8649(new class_1542(level, method_23317(), method_23318() + 1, method_23321(), new class_1799(item, n)));
        }
        BossRewards.onBossKilled(level, this);
        bar.method_14094();
    }
}
