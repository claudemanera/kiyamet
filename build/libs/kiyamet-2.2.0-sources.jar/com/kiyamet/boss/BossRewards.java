package com.kiyamet.boss;

import com.kiyamet.Kiyamet;
import com.kiyamet.skill.Skill;
import com.kiyamet.skill.SkillManager;
import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.ArrayList;
import java.util.List;

/** Big XP on each player's first kill of a boss, small XP afterwards. */
public final class BossRewards {
    public static final AttachmentType<List<String>> KILLED = AttachmentRegistry.create(Kiyamet.id("bosses_killed"),
            b -> b.initializer(List::of).persistent(Codec.STRING.listOf()).copyOnDeath());

    private static final Skill[] COMBAT = {Skill.SWORDS, Skill.ARCHERY, Skill.DEFENSE, Skill.HEAVY_WEAPONS, Skill.SURVIVAL};

    public static void onBossKilled(class_3218 level, BossEntity boss) {
        for (class_3222 p : level.method_18467(class_3222.class, boss.method_5829().method_1014(48))) {
            List<String> done = p.getAttachedOrElse(KILLED, List.of());
            boolean first = !done.contains(boss.kind.id);
            if (first) {
                List<String> next = new ArrayList<>(done);
                next.add(boss.kind.id);
                p.setAttached(KILLED, List.copyOf(next));
                for (Skill s : COMBAT) SkillManager.addXp(p, s, boss.kind.firstKillXp() / (double) COMBAT.length);
                p.method_64398(class_2561.method_43470("BOSS DEFEATED: " + boss.kind.title + " (first kill! " + next.size() + "/" + BossKind.values().length + ")")
                        .method_27695(class_124.field_1065, class_124.field_1067));
            } else {
                for (Skill s : COMBAT) SkillManager.addXp(p, s, 150);
                p.method_64398(class_2561.method_43470("Boss defeated: " + boss.kind.title).method_27692(class_124.field_1054));
            }
        }
    }

    public static void init() {}

    private BossRewards() {}
}
