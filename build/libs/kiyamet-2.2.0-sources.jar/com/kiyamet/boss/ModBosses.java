package com.kiyamet.boss;

import com.kiyamet.Kiyamet;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1588;
import net.minecraft.class_2378;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.EnumMap;
import java.util.Map;

public final class ModBosses {
    public static final Map<BossKind, class_1299<BossEntity>> TYPES = new EnumMap<>(BossKind.class);

    static {
        for (BossKind k : BossKind.values()) {
            class_5321<class_1299<?>> key = class_5321.method_29179(class_7924.field_41266, Kiyamet.id(k.id));
            class_1299.class_1300<BossEntity> b = class_1299.class_1300.<BossEntity>method_5903((t, l) -> new BossEntity(t, l, k), class_1311.field_6302)
                    .method_17687(k.width, k.height).method_55687(k.height * 0.88f).method_27299(10);
            if (k.fireImmune) b = b.method_19947();
            TYPES.put(k, class_2378.method_39197(class_7923.field_41177, key, b.method_5905(key)));
        }
    }

    public static void init() {
        TYPES.forEach((k, type) -> FabricDefaultAttributeRegistry.register(type, class_1588.method_26918()
                .method_26868(class_5134.field_23716, k.health)
                .method_26868(class_5134.field_23721, k.damage)
                .method_26868(class_5134.field_23724, k.armor)
                .method_26868(class_5134.field_23725, k.armor / 2)
                .method_26868(class_5134.field_23719, k.speed)
                .method_26868(class_5134.field_23717, 40)
                .method_26868(class_5134.field_23718, 0.9)
                .method_26868(class_5134.field_47761, 1.5)
                .method_26868(class_5134.field_47760, 1.0)));
        BossRewards.init();
    }

    private ModBosses() {}
}
