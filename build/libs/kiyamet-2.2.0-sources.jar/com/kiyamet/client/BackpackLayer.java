package com.kiyamet.client;

import com.kiyamet.Kiyamet;
import com.kiyamet.backpack.BackpackTier;
import com.kiyamet.backpack.Backpacks;
import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_12249;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_591;
import net.minecraft.class_630;

/** Draws the worn backpack on the player's back (each of the 10 backpacks has its own colours). */
public class BackpackLayer extends class_3887<class_10055, class_591> {
    private static final class_630 PACK;
    private static final class_2960[] TEX = new class_2960[BackpackTier.values().length];
    /** 2.2: a baby wrapped in white, riding beside the backpack (or on the back when there is none) */
    private static final class_630 BABY_SIDE, BABY_BACK;
    private static final class_2960 BABY_TEX = Kiyamet.id("textures/entity/baby_bundle.png");

    static {
        class_5609 mesh = new class_5609();
        mesh.method_32111().method_32117("pack", class_5606.method_32108().method_32101(0, 0).method_32097(-4f, 1f, 2f, 8, 10, 4), class_5603.field_27701);
        PACK = class_5607.method_32110(mesh, 32, 32).method_32109().method_32086("pack");
        class_5609 bm = new class_5609();
        bm.method_32111().method_32117("side", class_5606.method_32108().method_32101(0, 0).method_32097(4.4f, 2f, 3f, 3, 8, 3)
                .method_32101(0, 12).method_32097(4.65f, -0.6f, 3.3f, 2.5f, 2.6f, 2.6f).method_32101(12, 12).method_32097(4.3f, -1.2f, 2.9f, 3.2f, 2f, 2.7f), class_5603.method_32092(0f, 0f, -0.12f));
        bm.method_32111().method_32117("back", class_5606.method_32108().method_32101(0, 0).method_32097(-1.5f, 3f, 2.2f, 3, 8, 3)
                .method_32101(0, 12).method_32097(-1.25f, 0.4f, 2.5f, 2.5f, 2.6f, 2.6f).method_32101(12, 12).method_32097(-1.6f, -0.2f, 2.1f, 3.2f, 2f, 2.7f), class_5603.field_27701);
        class_630 broot = class_5607.method_32110(bm, 32, 32).method_32109();
        BABY_SIDE = broot.method_32086("side"); BABY_BACK = broot.method_32086("back");
        for (BackpackTier t : BackpackTier.values()) TEX[t.ordinal()] = Kiyamet.id("textures/entity/backpack/" + t.id + ".png");
    }

    public BackpackLayer(class_3883<class_10055, class_591> parent) {
        super(parent);
    }

    @Override
    public void submit(class_4587 pose, class_11659 collector, int light, class_10055 state, float yRot, float xRot) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) return;
        class_1297 e = mc.field_1687.method_8469(state.field_53528);
        if (e == null || e.method_5767()) return;
        int tier = e.getAttachedOrElse(Backpacks.WORN_TIER, -1);
        boolean pack = tier >= 0 && tier < TEX.length;
        boolean baby = e.getAttachedOrElse(com.kiyamet.settle.Family.CARRIED, 0) > 0;
        if (!pack && !baby) return;
        pose.method_22903();
        method_17165().field_3391.method_22703(pose);
        if (pack) collector.method_73491(PACK, pose, class_12249.method_75990(TEX[tier]), light, class_4608.field_21444, null);
        if (baby) collector.method_73491(pack ? BABY_SIDE : BABY_BACK, pose, class_12249.method_75990(BABY_TEX), light, class_4608.field_21444, null);
        pose.method_22909();
    }
}
