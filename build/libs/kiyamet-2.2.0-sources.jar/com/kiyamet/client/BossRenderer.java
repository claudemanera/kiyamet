package com.kiyamet.client;

import com.kiyamet.Kiyamet;
import com.kiyamet.boss.BossEntity;
import com.kiyamet.boss.BossKind;
import net.minecraft.class_10042;
import net.minecraft.class_5617;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.base.GeoRenderState;

public class BossRenderer<R extends class_10042 & GeoRenderState> extends GeoEntityRenderer<BossEntity, R> {
    public BossRenderer(class_5617.class_5618 ctx, BossKind kind) {
        super(ctx, new DefaultedEntityGeoModel<>(Kiyamet.id(kind.id)));
        withScale(kind.scale);
        this.field_4673 = 0.7f * kind.scale;
    }
}
