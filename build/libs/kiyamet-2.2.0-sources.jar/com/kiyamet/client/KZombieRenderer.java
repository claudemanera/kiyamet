package com.kiyamet.client;

import com.kiyamet.Kiyamet;
import com.kiyamet.entity.KZombie;
import com.kiyamet.entity.ZombieKind;
import net.minecraft.class_10042;
import net.minecraft.class_5617;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.base.GeoRenderState;

public class KZombieRenderer<R extends class_10042 & GeoRenderState> extends GeoEntityRenderer<KZombie, R> {
    public KZombieRenderer(class_5617.class_5618 ctx, ZombieKind kind) {
        super(ctx, new DefaultedEntityGeoModel<>(Kiyamet.id(kind.id)));
        withScale(kind.scale);
        this.field_4673 = 0.5f * kind.scale;
    }
}
