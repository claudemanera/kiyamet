package com.kiyamet.client;

import com.kiyamet.registry.ModBlocks;
import com.kiyamet.entity.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_11515;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;

public class KiyametClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.putBlocks(class_11515.field_60925, ModBlocks.STEEL_GRATE, ModBlocks.STEEL_GATE, ModBlocks.BARBED_WIRE,
                ModBlocks.RAZOR_WIRE, ModBlocks.ELECTRIC_FENCE, ModBlocks.SPIKE_TRAP);
        BlockRenderLayerMap.putBlock(ModBlocks.ENERGY_WALL, class_11515.field_60926);
        BlockRenderLayerMap.putBlocks(class_11515.field_60926, ModBlocks.WISDOM_GLASS);
        BlockRenderLayerMap.putBlocks(class_11515.field_60925, ModBlocks.CREATION_TABLE, ModBlocks.CREATION_ALTAR);
        com.kiyamet.farm.ModFarm.CUTOUT.forEach(b -> BlockRenderLayerMap.putBlock(b, class_11515.field_60925));
        ModEntities.ZOMBIES.forEach((kind, type) -> EntityRendererRegistry.register(type, ctx -> new KZombieRenderer<>(ctx, kind)));
        com.kiyamet.boss.ModBosses.TYPES.forEach((kind, type) -> EntityRendererRegistry.register(type, ctx -> new BossRenderer<>(ctx, kind)));
        com.kiyamet.vehicle.ModVehicles.TYPES.forEach((k, t) -> EntityRendererRegistry.register(t, ctx -> new SimpleGeoRenderer<>(ctx, k.id, k.scale)));
        EntityRendererRegistry.register(com.kiyamet.twd.ModTwd.SHELTER_CORE, ctx -> new SimpleGeoRenderer<>(ctx, "shelter_core", 1.0f));
        EntityRendererRegistry.register(com.kiyamet.twd.ModTwd.MISSION_BOARD, ctx -> new SimpleGeoRenderer<>(ctx, "mission_board", 1.0f));
        EntityRendererRegistry.register(com.kiyamet.ally.ModAllies.TURRET, ctx -> new SimpleGeoRenderer<>(ctx, "auto_turret", 1.0f));
        EntityRendererRegistry.register(com.kiyamet.item.BombProjectile.TYPE, net.minecraft.class_953::new);
        EntityRendererRegistry.register(com.kiyamet.furniture.Furniture.SEAT, net.minecraft.class_6344::new);
        com.kiyamet.wild.ModWild.TYPES.forEach((k, t) -> EntityRendererRegistry.register(t, ctx -> new SimpleGeoRenderer<>(ctx, k.id, 1.0f)));
        com.kiyamet.element.ElementMobs.GUARDIANS.forEach((e, t) -> EntityRendererRegistry.register(t, ctx -> new SimpleGeoRenderer<>(ctx, e.guardian(), 1.0f)));
        EntityRendererRegistry.register(com.kiyamet.end.EndMobs.ZOMBIE_ENDERMAN, ctx -> new SimpleGeoRenderer<>(ctx, "zombie_enderman", 1.0f));
        com.kiyamet.element.ElementMobs.SAGES.forEach((e, t) -> EntityRendererRegistry.register(t, ctx -> new SimpleGeoRenderer<>(ctx, e.sage(), 1.0f)));
        ModKeys.init();
        Tooltips.init();
        ThirstHud.init();
        net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type, renderer, helper, ctx) -> {
            if (renderer instanceof net.minecraft.class_1007<?> ar)
                helper.register(new BackpackLayer((net.minecraft.class_3883<net.minecraft.class_10055, net.minecraft.class_591>) (Object) ar));
        });
        EntityRendererRegistry.register(com.kiyamet.npc.ModHumans.HUMAN, ctx -> new com.kiyamet.client.human.HumanRenderer<>(ctx));
        com.kiyamet.robot.ModRobots.TYPES.forEach((kind, type) -> EntityRendererRegistry.register(type, ctx -> new RobotRenderer<>(ctx, kind)));
    }
}
