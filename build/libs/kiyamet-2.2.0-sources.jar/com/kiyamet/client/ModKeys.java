package com.kiyamet.client;

import com.kiyamet.Kiyamet;
import com.kiyamet.net.KeyAction;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/** Key bindings, changeable in Options > Controls > Key Binds > The Walking Dead. */
public final class ModKeys {
    private static final class_304.class_11900 CATEGORY = class_304.class_11900.method_74698(Kiyamet.id("twd"));
    private static final String[] NAMES = {"skills", "powers", "companions", "gauntlet_use", "gauntlet_cycle", "camouflage", "night_vision", "shadow_step", "backpack", "squad"};
    private static final int[] KEYS = {GLFW.GLFW_KEY_K, GLFW.GLFW_KEY_P, GLFW.GLFW_KEY_H, GLFW.GLFW_KEY_R, GLFW.GLFW_KEY_V, GLFW.GLFW_KEY_B, GLFW.GLFW_KEY_N, GLFW.GLFW_KEY_J, GLFW.GLFW_KEY_U, GLFW.GLFW_KEY_G};
    private static final class_304[] MAPPINGS = new class_304[NAMES.length];
    private static class_304 AUTOPILOT;
    /** 2.2: one key per power of the Creation Axe (numpad by default, change them freely) */
    private static final int[] CREATION_KEYS = {GLFW.GLFW_KEY_KP_1, GLFW.GLFW_KEY_KP_2, GLFW.GLFW_KEY_KP_3, GLFW.GLFW_KEY_KP_4, GLFW.GLFW_KEY_KP_5, GLFW.GLFW_KEY_KP_6, GLFW.GLFW_KEY_KP_7,
            GLFW.GLFW_KEY_KP_8, GLFW.GLFW_KEY_KP_9, GLFW.GLFW_KEY_KP_0, GLFW.GLFW_KEY_KP_DIVIDE, GLFW.GLFW_KEY_KP_MULTIPLY, GLFW.GLFW_KEY_KP_SUBTRACT, GLFW.GLFW_KEY_KP_ADD};
    private static final class_304[] CREATION = new class_304[14];

    public static void init() {
        for (int i = 0; i < NAMES.length; i++)
            MAPPINGS[i] = KeyBindingHelper.registerKeyBinding(new class_304("key.kiyamet." + NAMES[i], class_3675.class_307.field_1668, KEYS[i], CATEGORY));
        // left-click with the Stone Gauntlet in hand opens its panel
        ClientTickEvents.START_CLIENT_TICK.register(mc -> {
            if (mc.field_1724 == null || mc.field_1755 != null || !(mc.field_1724.method_6047().method_7909() instanceof com.kiyamet.stone.GauntletItem)) return;
            boolean any = false;
            while (mc.field_1690.field_1886.method_1436()) any = true;
            if (any) ClientPlayNetworking.send(new KeyAction(KeyAction.GAUNTLET_MENU));
        });
        // 2.2: wearing a backpack, E opens the backpack together with your inventory (sneak + E: the normal inventory)
        ClientTickEvents.START_CLIENT_TICK.register(mc -> {
            if (mc.field_1724 == null || mc.field_1755 != null || mc.field_1724.method_5715()) return;
            if (mc.field_1724.getAttachedOrElse(com.kiyamet.backpack.Backpacks.WORN_TIER, -1) < 0) return;
            boolean any = false;
            while (mc.field_1690.field_1822.method_1436()) any = true;
            if (any) ClientPlayNetworking.send(new KeyAction(KeyAction.BACKPACK));
        });
        AUTOPILOT = KeyBindingHelper.registerKeyBinding(new class_304("key.kiyamet.autopilot", class_3675.class_307.field_1668, GLFW.GLFW_KEY_Y, CATEGORY));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.field_1724 == null) return;
            while (AUTOPILOT.method_1436()) {
                Object[] w = XaeroWaypoints.newest(mc);
                ClientPlayNetworking.send(w == null ? new com.kiyamet.vehicle.Autopilot.Drive(0, 0, "?") : new com.kiyamet.vehicle.Autopilot.Drive((Integer) w[0], (Integer) w[1], (String) w[2]));
            }
        });
        com.kiyamet.element.Element[] els = com.kiyamet.element.Element.values();
        for (int i = 0; i < els.length; i++)
            CREATION[i] = KeyBindingHelper.registerKeyBinding(new class_304("key.kiyamet.creation_" + els[i].id, class_3675.class_307.field_1668, CREATION_KEYS[i], CATEGORY));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.field_1724 == null) return;
            for (int i = 0; i < CREATION.length; i++)
                while (CREATION[i].method_1436()) ClientPlayNetworking.send(new KeyAction(KeyAction.CREATION + i));
        });
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.field_1724 == null) return;
            for (int i = 0; i < MAPPINGS.length; i++)
                while (MAPPINGS[i].method_1436()) ClientPlayNetworking.send(new KeyAction(i));
        });
    }

    private ModKeys() {}
}
