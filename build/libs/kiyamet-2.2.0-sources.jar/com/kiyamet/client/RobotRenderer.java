package com.kiyamet.client;

import com.kiyamet.Kiyamet;
import com.kiyamet.robot.RobotEntity;
import com.kiyamet.robot.RobotKind;
import net.minecraft.class_10042;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import software.bernie.geckolib.constant.dataticket.DataTicket;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.base.GeoRenderState;

/** Enemy robots wear red; your own robot companions are painted blue. */
public class RobotRenderer<R extends class_10042 & GeoRenderState> extends GeoEntityRenderer<RobotEntity, R> {
    static final DataTicket<Boolean> ALLY = DataTicket.create("kiyamet_robot_ally", Boolean.class);

    static class Model extends DefaultedEntityGeoModel<RobotEntity> {
        private final class_2960 allyTex;

        Model(RobotKind kind) {
            super(Kiyamet.id(kind.id));
            this.allyTex = buildFormattedTexturePath(Kiyamet.id(kind.id + "_ally"));
        }

        @Override
        public void addAdditionalStateData(RobotEntity animatable, Object related, GeoRenderState state) {
            super.addAdditionalStateData(animatable, related, state);
            state.addGeckolibData(ALLY, animatable.isAlly());
        }

        @Override
        public class_2960 getTextureResource(GeoRenderState state) {
            return state.getOrDefaultGeckolibData(ALLY, false) ? allyTex : super.getTextureResource(state);
        }
    }

    public RobotRenderer(class_5617.class_5618 ctx, RobotKind kind) {
        super(ctx, new Model(kind));
        withScale(kind.scale);
        this.field_4673 = 0.5f * kind.scale;
    }
}
