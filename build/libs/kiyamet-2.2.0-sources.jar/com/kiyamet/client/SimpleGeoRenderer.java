package com.kiyamet.client;

import com.kiyamet.Kiyamet;
import net.minecraft.class_10042;
import net.minecraft.class_1309;
import net.minecraft.class_5617;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.base.GeoRenderState;

/** Renders any GeckoLib living entity with the model/texture/animation named {@code asset}. */
public class SimpleGeoRenderer<T extends class_1309 & GeoEntity, R extends class_10042 & GeoRenderState> extends GeoEntityRenderer<T, R> {
    public SimpleGeoRenderer(class_5617.class_5618 ctx, String asset, float scale) {
        super(ctx, new DefaultedEntityGeoModel<>(Kiyamet.id(asset)));
        withScale(scale);
        this.field_4673 = 0.5f * scale;
    }
}
