package com.kiyamet.client;

import com.kiyamet.Kiyamet;
import com.kiyamet.water.Thirst;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudStatusBarHeightRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/** Water bar (10 droplets) above the hunger bar. */
public final class ThirstHud {
    static final class_2960 ID = Kiyamet.id("thirst_bar");
    static final class_2960 FULL = Kiyamet.id("hud/water_full"), HALF = Kiyamet.id("hud/water_half"), EMPTY = Kiyamet.id("hud/water_empty");

    static boolean shown(net.minecraft.class_1657 p) { return p != null && !p.method_68878() && !p.method_7325(); }

    public static void init() {
        HudStatusBarHeightRegistry.addRight(ID, p -> shown(p) ? 10 : 0);
        HudElementRegistry.attachElementAfter(VanillaHudElements.FOOD_BAR, ID, (g, delta) -> {
            class_310 mc = class_310.method_1551();
            if (!shown(mc.field_1724) || mc.field_1690.field_1842) return;
            float w = mc.field_1724.getAttachedOrElse(Thirst.WATER, 20f);
            int right = g.method_51421() / 2 + 91, y = g.method_51443() - HudStatusBarHeightRegistry.getHeight(ID);
            boolean shake = w <= 4 && mc.field_1724.field_6012 % 8 < 4;
            for (int i = 0; i < 10; i++) {
                int x = right - i * 8 - 9, yy = y + (shake && i % 2 == 0 ? 1 : 0);
                g.method_52706(class_10799.field_56883, EMPTY, x, yy, 9, 9);
                float v = w - i * 2;
                if (v >= 2) g.method_52706(class_10799.field_56883, FULL, x, yy, 9, 9);
                else if (v >= 1) g.method_52706(class_10799.field_56883, HALF, x, yy, 9, 9);
            }
        });
    }

    private ThirstHud() {}
}
