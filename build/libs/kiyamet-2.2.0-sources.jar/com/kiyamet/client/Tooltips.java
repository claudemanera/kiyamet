package com.kiyamet.client;

import com.kiyamet.ammo.Ammo;
import com.kiyamet.item.GunItem;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.class_1074;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Info text under every TWD item (tooltip.kiyamet.<id> in the lang file; guns show their live stats). */
public final class Tooltips {
    public static void init() {
        ItemTooltipCallback.EVENT.register((stack, ctx, flag, lines) -> {
            // food: best-before date (any food, vanilla too)
            var mc = net.minecraft.class_310.method_1551();
            if (mc.field_1687 != null && com.kiyamet.food.Spoilage.spoils(stack)) {
                long e = com.kiyamet.food.Spoilage.expires(stack);
                if (e < 0) lines.add(Math.min(lines.size(), 1), class_2561.method_43470("Fresh · keeps " + com.kiyamet.food.Spoilage.life(stack) + " days").method_27692(class_124.field_1060));
                else {
                    long days = (e - mc.field_1687.method_75260()) / 24000;
                    var date = com.kiyamet.season.Calendar.dateAt(mc.field_1687, e);
                    lines.add(Math.min(lines.size(), 1), class_2561.method_43470("Best before " + com.kiyamet.season.Calendar.shortFormat(date) + (days <= 0 ? " · spoils today!" : " · " + days + " days left"))
                            .method_27692(days <= 0 ? class_124.field_1061 : days <= 2 ? class_124.field_1065 : class_124.field_1060));
                }
            }
            class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());
            if (!id.method_12836().equals("kiyamet")) return;
            String path = id.method_12832();
            int at = Math.min(lines.size(), 1);
            if (stack.method_7909() instanceof GunItem) {
                GunItem.Stats s = GunItem.statsFor(path);
                Ammo.Type t = Ammo.typeFor(path);
                String mode = switch (s.mode()) {
                    case SINGLE -> "single shot"; case DOUBLE -> "double shot"; case SHOTGUN -> "5 pellets"; case BURST3 -> "3-round burst"; case PIERCE -> "pierces through";
                    case EXPLODE -> "explosive"; case VOID -> "void pull"; case HARPOON -> "harpoon"; case TESLA -> "chain lightning"; case HOMING -> "homing"; case CANNON -> "cannon";
                };
                lines.add(at++, class_2561.method_43470("Damage " + fmt(s.damage()) + " · " + fmt(s.cooldown() / 20f) + " s between shots").method_27692(class_124.field_1080));
                lines.add(at++, class_2561.method_43470(mode.substring(0, 1).toUpperCase() + mode.substring(1) + " · " + (s.noise() == 0 ? "silent" : "heard " + s.noise() + " blocks away")).method_27692(class_124.field_1080));
                lines.add(at++, class_2561.method_43470("Ammo: " + t.label).method_27692(t.color));
                String eff = switch (s.effect()) { case 1 -> "Poisons"; case 2 -> "Freezes"; case 3 -> "Burns"; case 4 -> "Heavy: slows you while firing"; default -> null; };
                if (eff != null) lines.add(at++, class_2561.method_43470(eff).method_27692(class_124.field_1062));
                lines.add(at++, class_2561.method_43470("Clip " + com.kiyamet.gunsmith.GunHandling.clip(stack) + "/" + com.kiyamet.gunsmith.GunHandling.clipSize(stack) + " · R reloads / clears jams"
                        + (com.kiyamet.gunsmith.GunHandling.jammed(stack) ? " · JAMMED" : "")).method_27692(com.kiyamet.gunsmith.GunHandling.jammed(stack) ? class_124.field_1061 : class_124.field_1054));
                return;
            }
            if (path.equals("electric_drill") || path.equals("chainsaw")) lines.add(at++, class_2561.method_43470("Battery " + com.kiyamet.power.Renewables.charge(stack) + "/" + com.kiyamet.power.Renewables.MAX_CHARGE).method_27692(class_124.field_1075));
            String key = "tooltip.kiyamet." + path;
            com.kiyamet.food.Recipes.Meal meal = com.kiyamet.food.Recipes.meal(path);
            if (meal != null) lines.add(at++, class_2561.method_43470("Hearty meal: fills " + meal.food() + " hunger + Well Fed " + meal.fedMinutes() + " min").method_27692(class_124.field_1065));
            if (!class_1074.method_4663(key)) return;
            for (String l : class_1074.method_4662(key).split("\\|")) lines.add(at++, class_2561.method_43470(l).method_27692(class_124.field_1080));
        });
    }

    static String fmt(float f) { return f == (int) f ? String.valueOf((int) f) : String.format("%.1f", f); }

    private Tooltips() {}
}
