package com.kiyamet.client.human;

import com.kiyamet.npc.HumanEntity;
import net.minecraft.class_10042;
import net.minecraft.class_5617;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.base.GeoRenderState;
import software.bernie.geckolib.renderer.layer.builtin.ItemInHandGeoLayer;

public class HumanRenderer<R extends class_10042 & GeoRenderState> extends GeoEntityRenderer<HumanEntity, R> {
    public HumanRenderer(class_5617.class_5618 ctx) {
        super(ctx, new HumanModel());
        withRenderLayer(new ItemInHandGeoLayer<>(this, "item_l", "item_r"));
        this.field_4673 = 0.5f;
    }
}
