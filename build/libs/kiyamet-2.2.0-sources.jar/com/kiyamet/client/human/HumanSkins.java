package com.kiyamet.client.human;

import com.kiyamet.Kiyamet;
import com.kiyamet.npc.Appearance;
import com.kiyamet.npc.Gear;
import com.kiyamet.npc.SkinPainter;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/** Uploads the skin painted by {@link SkinPainter} for each look (appearance + gear) and caches it. */
public final class HumanSkins {
    private static final Map<Long, class_2960> CACHE = new HashMap<>();

    public static class_2960 texture(int code, int gear) {
        long key = (code & 0xFFFFFFFFL) | (long) gear << 32;
        return CACHE.computeIfAbsent(key, k -> {
            int[] px = SkinPainter.paint(Appearance.unpack(code), Gear.unpack(gear), code * 31L + 7);
            class_1011 img = new class_1011(64, 64, true);
            for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) img.method_61941(x, y, px[y * 64 + x]);
            class_2960 id = Kiyamet.id("dynamic/human_" + Long.toHexString(k));
            class_310.method_1551().method_1531().method_4616(id, new class_1043(() -> "kiyamet human " + k, img));
            return id;
        });
    }

    private HumanSkins() {}
}
