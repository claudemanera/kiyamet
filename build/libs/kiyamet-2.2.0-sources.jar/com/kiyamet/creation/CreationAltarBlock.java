package com.kiyamet.creation;

import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3726;
import net.minecraft.class_3965;

/** The heart of a Sage of Creation's own temple. Build the temple around it however you like. */
public class CreationAltarBlock extends class_2248 {
    static final class_265 SHAPE = class_2248.method_9541(1, 0, 1, 15, 16, 15);

    public CreationAltarBlock(class_2251 p) { super(p); }

    @Override
    protected class_265 method_9530(class_2680 s, class_1922 l, class_2338 pos, class_3726 c) { return SHAPE; }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, class_1309 by, class_1799 stack) {
        super.method_9567(level, pos, state, by, stack);
        if (by instanceof class_3222 p) CreationSage.founded(p, pos);
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (player instanceof class_3222 p) CreationSage.useAltar(p, pos);
        return class_1269.field_5812;
    }
}
