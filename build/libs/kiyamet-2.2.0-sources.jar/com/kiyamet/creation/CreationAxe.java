package com.kiyamet.creation;

import com.kiyamet.element.Element;
import com.kiyamet.element.ElementPowers;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_9279;
import net.minecraft.class_9280;
import net.minecraft.class_9334;

/**
 * TWD 2.2: the Creation Axe, a double-bladed battle axe that holds all fourteen element powers.
 * Every power has its own key (Options > Controls > The Walking Dead), right-click switches the selected power,
 * sneak + right-click picks the next power. Powers that fight over the same thing (time, flight) replace each other.
 */
public class CreationAxe extends class_1792 {
    public CreationAxe(class_1793 p) { super(p); }

    static class_2487 tag(class_1799 s) { return s.method_58695(class_9334.field_49628, class_9279.field_49302).method_57461(); }
    public static int mask(class_1799 s) { return tag(s).method_68083("On", 0); }
    public static int selected(class_1799 s) { return Math.floorMod(tag(s).method_68083("Sel", 0), Element.values().length); }

    static void write(class_1799 s, int mask, int sel) {
        class_2487 t = tag(s);
        t.method_10569("On", mask);
        t.method_10569("Sel", sel);
        s.method_57379(class_9334.field_49628, class_9279.method_57456(t));
        s.method_57379(class_9334.field_49637, new class_9280(List.of(), List.of(mask != 0), List.of(), List.of()));
    }

    public static boolean isOn(class_1799 s, Element e) { return (mask(s) & (1 << e.ordinal())) != 0; }

    /** switch one power of the axe in this player's main hand */
    public static void toggle(class_3222 p, class_1799 s, Element e) {
        int m = mask(s);
        boolean on = (m & (1 << e.ordinal())) == 0;
        if (on) {
            for (Element o : Element.values())                                          // the clock and the flight have one owner
                if (o != e && (m & (1 << o.ordinal())) != 0 && clash(o, e)) { m &= ~(1 << o.ordinal()); ElementPowers.stop(p, o); }
            m |= 1 << e.ordinal();
            ElementPowers.start(p, e);
        } else {
            m &= ~(1 << e.ordinal());
            ElementPowers.stop(p, e);
        }
        write(s, m, e.ordinal());
        p.method_7353(class_2561.method_43470("✦ CREATION · ").method_27695(class_124.field_1068, class_124.field_1067)
                .method_10852(class_2561.method_43470(e.title.toUpperCase() + (on ? " ON" : " OFF")).method_27695(e.fmt, class_124.field_1067))
                .method_10852(class_2561.method_43470("   (" + Integer.bitCount(m) + " active)").method_27692(class_124.field_1080)), true);
        p.method_51469().method_8396(null, p.method_24515(), on ? class_3417.field_43154 : class_3417.field_26979, class_3419.field_15248, 1f, on ? 1.4f : 0.8f);
    }

    static boolean clash(Element a, Element b) {
        boolean ca = a == Element.ICE || a == Element.THUNDER || a == Element.WIND, cb = b == Element.ICE || b == Element.THUNDER || b == Element.WIND;
        boolean fa = a == Element.SPIRIT || a == Element.AIR, fb = b == Element.SPIRIT || b == Element.AIR;
        return ca && cb || fa && fb;
    }

    public static void allOff(class_3222 p, class_1799 s) {
        int m = mask(s);
        for (Element e : Element.values()) if ((m & (1 << e.ordinal())) != 0) ElementPowers.stop(p, e);
        write(s, 0, selected(s));
    }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 s = player.method_5998(hand);
        if (player instanceof class_3222 sp) {
            if (sp.method_5715()) {
                int sel = (selected(s) + 1) % Element.values().length;
                write(s, mask(s), sel);
                Element e = Element.values()[sel];
                sp.method_7353(class_2561.method_43470("✦ Selected power: ").method_27692(class_124.field_1068)
                        .method_10852(class_2561.method_43470(e.title + " - " + e.power).method_27692(e.fmt)), true);
                sp.method_51469().method_8396(null, sp.method_24515(), class_3417.field_15015.comp_349(), class_3419.field_15248, 0.5f, 1.6f);
            } else toggle(sp, s, Element.values()[selected(s)]);
        }
        return class_1269.field_5812;
    }

    @Override
    public void method_7888(class_1799 s, class_3218 level, class_1297 ent, class_1304 slot) {
        if (!(ent instanceof class_3222 p)) return;
        boolean held = p.method_6047() == s || p.method_6079() == s;
        int m = mask(s);
        if (!held) { if (m != 0) allOff(p, s); return; }
        // the axe shines white: a slow ring of light around you, brighter when powers are on
        int t = p.field_6012;
        double a = t * 0.18;
        for (int k = 0; k < 2; k++) {
            double ang = a + k * Math.PI;
            level.method_65096(class_2398.field_11207, p.method_23317() + Math.cos(ang) * 0.9, p.method_23318() + 0.4 + (t % 40) / 40.0 * 1.6, p.method_23321() + Math.sin(ang) * 0.9, 1, 0, 0, 0, 0);
        }
        if (t % 3 == 0) level.method_65096(new class_2390(0xFFFFFF, 1.4f), p.method_23317(), p.method_23318() + 1.1, p.method_23321(), 1, 0.4, 0.5, 0.4, 0);
        if (m == 0) return;
        if (t % 10 == 0) level.method_65096(class_2398.field_23956, p.method_23317(), p.method_23318() + 1, p.method_23321(), 6, 0.6, 0.8, 0.6, 0.02);
        for (Element e : Element.values()) if ((m & (1 << e.ordinal())) != 0) ElementPowers.tick(p, e, s);
    }

    @Override
    public void method_7873(class_1799 s, class_1309 target, class_1309 attacker) {
        super.method_7873(s, target, attacker);
        int m = mask(s);
        if (target.method_73183() instanceof class_3218 l) {
            l.method_65096(net.minecraft.class_9381.method_58256(class_2398.field_17909, 0xFFFFFFFF), target.method_23317(), target.method_23318() + 1, target.method_23321(), 1, 0, 0, 0, 0);
            l.method_65096(class_2398.field_11207, target.method_23317(), target.method_23318() + 1, target.method_23321(), 12, 0.3, 0.5, 0.3, 0.15);
            target.method_64397(l, l.method_48963().method_48831(), 6f);                          // creation itself cuts
        }
        if (m == 0) { ElementPowers.onHit(Element.values()[attacker.method_59922().method_43048(14)], target, attacker); return; }
        for (Element e : Element.values()) if ((m & (1 << e.ordinal())) != 0) ElementPowers.onHit(e, target, attacker);
    }
}
