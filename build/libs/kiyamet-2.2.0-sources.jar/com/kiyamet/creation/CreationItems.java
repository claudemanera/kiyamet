package com.kiyamet.creation;

import com.kiyamet.registry.ModItems;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_2199;
import net.minecraft.class_2338;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3902;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_9334;
import net.minecraft.class_9886;

/** TWD 2.2: the Creation Element, the Creation Rod and the Creation Axe, and forging the axe on an anvil. */
public final class CreationItems {
    public static class_1792 CORE, ROD, AXE;

    public static void init() {
        CORE = ModItems.custom("creation_core", p -> new class_1792(p.method_7889(1).method_24359().method_7894(class_1814.field_8904).method_57349(class_9334.field_49641, true)));
        ROD = ModItems.custom("creation_rod", p -> new class_1792(p.method_66333(class_9886.field_52590, 6f, -2.4f).method_24359().method_7894(class_1814.field_8904)
                .method_57349(class_9334.field_49630, class_3902.field_17274).method_57349(class_9334.field_49641, true)));
        AXE = ModItems.custom("creation_axe", p -> new CreationAxe(p.method_67190(class_9886.field_52590, 17f, -2.8f).method_24359().method_7894(class_1814.field_8904)
                .method_57349(class_9334.field_49630, class_3902.field_17274).method_57349(class_9334.field_49641, true)));

        // hold the Creation Element, carry the Creation Rod, right-click an anvil
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (hand != class_1268.field_5808 || !(player instanceof class_3222 p) || !(level instanceof class_3218 l)) return class_1269.field_5811;
            class_2338 pos = hit.method_17777();
            if (!(l.method_8320(pos).method_26204() instanceof class_2199) || !p.method_6047().method_31574(CORE)) return class_1269.field_5811;
            int rod = -1;
            for (int i = 0; i < p.method_31548().method_5439(); i++) if (p.method_31548().method_5438(i).method_31574(ROD)) { rod = i; break; }
            if (rod < 0) { p.method_7353(class_2561.method_43470("You need the Creation Rod in your inventory.").method_27692(class_124.field_1061), true); return class_1269.field_5814; }
            p.method_31548().method_5438(rod).method_7934(1);
            p.method_6047().method_7934(1);
            class_1799 axe = new class_1799(AXE);
            if (!p.method_31548().method_7394(axe)) p.method_7328(axe, false);
            for (int i = 0; i < 7; i++) l.method_8396(null, pos, class_3417.field_14559, class_3419.field_15245, 1f, 0.5f + i * 0.15f);
            l.method_8396(null, pos, class_3417.field_14981, class_3419.field_15245, 1f, 1.2f);
            l.method_8396(null, pos, class_3417.field_14931, class_3419.field_15245, 1f, 1.4f);
            l.method_65096(new class_2390(0xFFFFFF, 2.5f), pos.method_10263() + 0.5, pos.method_10264() + 1.2, pos.method_10260() + 0.5, 200, 0.8, 1.2, 0.8, 0.1);
            l.method_65096(class_2398.field_11207, pos.method_10263() + 0.5, pos.method_10264() + 1.2, pos.method_10260() + 0.5, 120, 0.4, 2, 0.4, 0.2);
            l.method_65096(net.minecraft.class_9381.method_58256(class_2398.field_17909, 0xFFFFFFFF), pos.method_10263() + 0.5, pos.method_10264() + 1.2, pos.method_10260() + 0.5, 3, 0, 0, 0, 0);
            p.field_13987.method_14364(new class_5904(class_2561.method_43470("CREATION").method_27695(class_124.field_1068, class_124.field_1067)));
            p.field_13987.method_14364(new class_5903(class_2561.method_43470("All fourteen powers answer to you now").method_27692(class_124.field_1080)));
            com.kiyamet.skill.SkillManager.addXp(p, com.kiyamet.skill.Skill.ENCHANTING, 20000);
            l.method_8503().method_3760().method_43514(class_2561.method_43470("✦ " + p.method_5477().getString() + " forged the CREATION AXE!").method_27695(class_124.field_1068, class_124.field_1067), false);
            return class_1269.field_5812;
        });
    }

    private CreationItems() {}
}
