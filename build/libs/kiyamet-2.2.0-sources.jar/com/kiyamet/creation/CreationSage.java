package com.kiyamet.creation;

import com.kiyamet.Kiyamet;
import com.kiyamet.element.Sage;
import com.kiyamet.npc.HumanEntity;
import com.kiyamet.registry.ModBlocks;
import com.kiyamet.skill.Skill;
import com.kiyamet.skill.SkillData;
import com.kiyamet.skill.SkillManager;
import com.mojang.serialization.Codec;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5903;
import net.minecraft.class_5904;

/**
 * TWD 2.2: the sages were always you, further down the road. When every one of your twenty skills reaches 999 you
 * become the Sage of Creation: you get the Altar of Creation, you build your own temple around it, and the companions
 * you choose become its guardians - they never die and never leave it.
 */
public final class CreationSage {
    public static final String TAG = "creation_sage", GUARD = "creation_guardian";
    /** where this player's altar stands (BlockPos as long), dimension id */
    public static final AttachmentType<Long> ALTAR = AttachmentRegistry.create(Kiyamet.id("creation_altar"), b -> b.persistent(Codec.LONG).copyOnDeath());
    public static final AttachmentType<String> ALTAR_DIM = AttachmentRegistry.create(Kiyamet.id("creation_altar_dim"), b -> b.persistent(Codec.STRING).copyOnDeath());

    public static boolean isSage(class_3222 p) { return p.method_5752().contains(TAG); }

    public static boolean ready(SkillData d) {
        for (Skill s : Skill.values()) if (d.level(s) < Skill.MAX_LEVEL) return false;
        return true;
    }

    static final String[] STORY = {
            "The fourteen sages you met were never strangers.",
            "Each of them was you - the you that walked one element to its end.",
            "Fire, ice, thunder, shadow... every road you finished, a sage was waiting at the end of it.",
            "Now every road is finished. What is left is the element that made all the others:",
            "CREATION. You are its sage. There is no temple for you yet - you must build it yourself.",
            "Place the Altar of Creation where your temple will stand. Bring the companions you trust:",
            "sneak + right-click the altar, and they will guard it forever."};

    public static void ascend(class_3222 p) {
        if (isSage(p)) return;
        p.method_5780(TAG);
        class_3218 l = p.method_51469();
        p.field_13987.method_14364(new class_5904(class_2561.method_43470("SAGE OF CREATION").method_27695(class_124.field_1068, class_124.field_1067)));
        p.field_13987.method_14364(new class_5903(class_2561.method_43470("every element answers to you").method_27692(class_124.field_1080)));
        l.method_8396(null, p.method_24515(), class_3417.field_15195, class_3419.field_15248, 1f, 1f);
        l.method_8396(null, p.method_24515(), class_3417.field_14981, class_3419.field_15248, 1f, 1.3f);
        l.method_65096(class_2398.field_11207, p.method_23317(), p.method_23318() + 1, p.method_23321(), 400, 2, 3, 2, 0.15);
        l.method_65096(net.minecraft.class_9381.method_58256(class_2398.field_17909, 0xFFFFFFFF), p.method_23317(), p.method_23318() + 1, p.method_23321(), 4, 0, 0, 0, 0);
        for (String s : STORY) p.method_64398(class_2561.method_43470("✦ " + s).method_27692(class_124.field_1068));
        class_1799 altar = new class_1799(ModBlocks.CREATION_ALTAR.method_8389());
        if (!p.method_31548().method_7394(altar)) p.method_7328(altar, false);
        l.method_8503().method_3760().method_43514(class_2561.method_43470("✦ " + p.method_5477().getString() + " has become the SAGE OF CREATION.").method_27695(class_124.field_1068, class_124.field_1067), false);
    }

    static void founded(class_3222 p, class_2338 pos) {
        Long old = p.getAttached(ALTAR);
        p.setAttached(ALTAR, pos.method_10063());
        p.setAttached(ALTAR_DIM, p.method_51469().method_27983().method_29177().toString());
        p.method_64398(class_2561.method_43470("✦ Your Temple of Creation will stand here. Build it as you wish." + (old != null ? " (Your old altar is no longer your temple's heart.)" : "")).method_27692(class_124.field_1068));
        p.method_64398(class_2561.method_43470("   Right-click the altar: your temple · sneak + right-click: nearby companions become its guardians (again, with none near: release them).").method_27692(class_124.field_1080));
        p.method_51469().method_65096(class_2398.field_11207, pos.method_10263() + 0.5, pos.method_10264() + 1, pos.method_10260() + 0.5, 80, 0.5, 2, 0.5, 0.1);
    }

    static boolean mine(class_3222 p, class_2338 pos) {
        Long at = p.getAttached(ALTAR);
        return at != null && at == pos.method_10063() && p.method_51469().method_27983().method_29177().toString().equals(p.getAttachedOrElse(ALTAR_DIM, ""));
    }

    static List<class_1309> guardians(class_3218 l, class_3222 p, class_2338 pos, double r) {
        return l.method_8390(class_1309.class, new class_238(pos).method_1014(r), e -> e.method_5752().contains(GUARD) && owned(e, p));
    }

    static boolean owned(class_1309 e, class_3222 p) {
        return e instanceof HumanEntity h && h.isOwnedBy(p) || e instanceof Sage s && s.isOwnedBy(p);
    }

    static void useAltar(class_3222 p, class_2338 pos) {
        class_3218 l = p.method_51469();
        if (!isSage(p) && !mine(p, pos)) { p.method_7353(class_2561.method_43470("Only the Sage of Creation can wake this altar.").method_27692(class_124.field_1080), true); return; }
        if (!mine(p, pos)) founded(p, pos);
        class_2338 stand = pos.method_10084();
        if (!p.method_5715()) {
            List<class_1309> g = guardians(l, p, pos, 64);
            p.method_64398(class_2561.method_43470("✦ TEMPLE OF CREATION  ·  guardians: " + g.size()).method_27695(class_124.field_1068, class_124.field_1067));
            for (class_1309 e : g) p.method_64398(class_2561.method_43470("   · " + e.method_5477().getString()).method_27692(class_124.field_1075));
            if (g.isEmpty()) p.method_64398(class_2561.method_43470("   Bring your companions here and sneak + right-click the altar.").method_27692(class_124.field_1080));
            l.method_65096(class_2398.field_11207, pos.method_10263() + 0.5, pos.method_10264() + 1.2, pos.method_10260() + 0.5, 30, 0.3, 0.8, 0.3, 0.05);
            return;
        }
        List<class_1309> near = l.method_8390(class_1309.class, new class_238(pos).method_1014(24), e -> owned(e, p) && !e.method_5752().contains(GUARD));
        if (near.isEmpty()) {
            List<class_1309> g = guardians(l, p, pos, 64);
            for (class_1309 e : g) {
                e.method_5738(GUARD);
                e.method_6016(class_1294.field_5910); e.method_6016(class_1294.field_5907);
                if (e instanceof HumanEntity h) h.setOrder(HumanEntity.Order.FOLLOW);
                if (e instanceof Sage s) s.release();
            }
            p.method_64398(class_2561.method_43470(g.isEmpty() ? "No companions nearby to make guardians." : "✦ Released " + g.size() + " guardian(s). They follow you again.").method_27692(class_124.field_1080));
            return;
        }
        int i = 0;
        for (class_1309 e : near) {
            e.method_5780(GUARD);
            e.method_6092(new class_1293(class_1294.field_5910, -1, 1, true, false));
            e.method_6092(new class_1293(class_1294.field_5907, -1, 1, true, false));
            e.method_6033(e.method_6063());
            double a = Math.toRadians(i++ * (360.0 / near.size()));
            class_2338 post = stand.method_10069((int) Math.round(Math.cos(a) * 4), 0, (int) Math.round(Math.sin(a) * 4));
            if (e instanceof HumanEntity h) { h.setOrder(HumanEntity.Order.GUARD); h.setHome(post); }
            if (e instanceof Sage s) s.guardTemple(post);
            l.method_65096(new class_2390(0xFFFFFF, 2f), e.method_23317(), e.method_23318() + 1, e.method_23321(), 40, 0.4, 0.8, 0.4, 0.05);
            p.method_64398(class_2561.method_43470("✦ " + e.method_5477().getString() + " is now a guardian of your Temple of Creation. They will never fall.").method_27692(class_124.field_1068));
        }
        l.method_8396(null, pos, class_3417.field_14891, class_3419.field_15245, 1f, 1.1f);
    }

    public static void init() {
        // guardians of a Temple of Creation cannot die: they drop to half health and keep standing
        ServerLivingEntityEvents.ALLOW_DEATH.register((e, src, amount) -> {
            if (!e.method_5752().contains(GUARD)) return true;
            e.method_6033(e.method_6063() * 0.5f);
            if (e.method_73183() instanceof class_3218 l) l.method_65096(class_2398.field_11220, e.method_23317(), e.method_23318() + 1, e.method_23321(), 30, 0.4, 0.8, 0.4, 0.3);
            return false;
        });
        ServerLivingEntityEvents.AFTER_DAMAGE.register((e, src, base, taken, blocked) -> {
            if (e.method_5752().contains(GUARD)) e.method_6092(new class_1293(class_1294.field_5924, 100, 2, true, false));
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.method_3780() % 100 != 0) return;
            for (class_3222 p : server.method_3760().method_14571()) {
                if (!isSage(p)) { if (ready(SkillManager.get(p))) ascend(p); continue; }
                // the Sage of Creation: strength, regeneration and a quiet white light
                p.method_6092(new class_1293(class_1294.field_5924, 140, 0, true, false));
                p.method_6092(new class_1293(class_1294.field_5910, 140, 0, true, false));
                p.method_6092(new class_1293(class_1294.field_5907, 140, 0, true, false));
                p.method_51469().method_65096(class_2398.field_11207, p.method_23317(), p.method_23318() + 1, p.method_23321(), 8, 0.4, 0.8, 0.4, 0.02);
            }
        });
        // testing helper: /twd ascend (creative or console)
        CommandRegistrationCallback.EVENT.register((d, ctx, env) -> d.register(class_2170.method_9247("twd").then(class_2170.method_9247("ascend")
                .executes(c -> {
                    if (c.getSource().method_44023() != null && !c.getSource().method_44023().method_68878()) return 0;
                    int n = 0;
                    for (class_3222 p : c.getSource().method_9211().method_3760().method_14571()) if (c.getSource().method_44023() == null || c.getSource().method_44023() == p) { ascend(p); n++; }
                    int fn = n;
                    c.getSource().method_9226(() -> class_2561.method_43470("Ascended " + fn + " player(s)."), true);
                    return 1;
                }))));
    }

    private CreationSage() {}
}
