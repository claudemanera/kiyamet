package com.kiyamet.creation;

import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3726;
import net.minecraft.class_3965;

/** The Table of Creation: it stands in the Temple of Wisdom in the End. It cannot be broken or taken. */
public class CreationTableBlock extends class_2248 {
    static final class_265 SHAPE = class_2248.method_9541(0, 0, 0, 16, 14, 16);

    public CreationTableBlock(class_2251 p) { super(p); }

    @Override
    protected class_265 method_9530(class_2680 s, class_1922 l, class_2338 pos, class_3726 c) { return SHAPE; }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (player instanceof class_3222 p) {
            if (level.method_27983() != class_1937.field_25181) p.method_7353(class_2561.method_43470("The Table of Creation only answers in the Temple of Wisdom, in the End.").method_27692(class_124.field_1080), true);
            else CreationTableMenu.open(p);
        }
        return class_1269.field_5812;
    }
}
