package com.kiyamet.creation;

import com.kiyamet.element.Element;
import com.kiyamet.element.ElementItems;
import com.kiyamet.stone.StoneItem;
import com.kiyamet.stone.StoneKind;
import com.kiyamet.ui.Ui;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_124;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3917;
import net.minecraft.class_747;

/** Twelve stones become the Creation Element. Fourteen element weapons become the Creation Rod. */
public class CreationTableMenu extends class_1707 {
    private final class_1277 shown;
    private final class_3222 player;

    public static void open(class_3222 p) {
        p.method_17355(new class_747((id, inv, pl) -> new CreationTableMenu(id, inv, p), class_2561.method_43470("Table of Creation")));
    }

    private CreationTableMenu(int id, class_1661 inv, class_3222 p) { this(id, inv, new class_1277(27), p); }

    private CreationTableMenu(int id, class_1661 inv, class_1277 c, class_3222 p) {
        super(class_3917.field_17326, id, inv, c, 3);
        this.shown = c;
        this.player = p;
        refresh();
    }

    static Set<StoneKind> stones(class_1657 p) {
        Set<StoneKind> s = EnumSet.noneOf(StoneKind.class);
        for (int i = 0; i < p.method_31548().method_5439(); i++) if (p.method_31548().method_5438(i).method_7909() instanceof StoneItem si) s.add(si.kind);
        return s;
    }

    static Set<Element> weapons(class_1657 p) {
        Set<Element> s = EnumSet.noneOf(Element.class);
        for (int i = 0; i < p.method_31548().method_5439(); i++)
            for (Element e : Element.values()) if (p.method_31548().method_5438(i).method_31574(ElementItems.WEAPONS.get(e))) s.add(e);
        return s;
    }

    private void refresh() {
        shown.method_5448();
        for (int i = 0; i < 27; i++) shown.method_5447(i, Ui.pane(class_1802.field_8736));
        Set<StoneKind> have = stones(player);
        List<class_2561> sl = new ArrayList<>();
        sl.add(Ui.text("Needs all 12 stones (loose, not in the gauntlet):", class_124.field_1080));
        for (StoneKind k : StoneKind.values())
            sl.add(class_2561.method_43470(have.contains(k) ? " ✔ " : " ✘ ").method_27692(have.contains(k) ? class_124.field_1060 : class_124.field_1061).method_10852(class_2561.method_43471("item.kiyamet." + k.id).method_27692(class_124.field_1068)));
        sl.add(Ui.bar(have.size() / 12.0, 20));
        sl.add(Ui.text(have.size() == 12 ? "Click to create!" : have.size() + " / 12", have.size() == 12 ? class_124.field_1054 : class_124.field_1080));
        shown.method_5447(11, Ui.glint(Ui.lore(Ui.icon(CreationItems.CORE, Ui.text("Creation Element", class_124.field_1068, class_124.field_1067)), sl), have.size() == 12));

        Set<Element> w = weapons(player);
        List<class_2561> wl = new ArrayList<>();
        wl.add(Ui.text("Needs all 14 element weapons:", class_124.field_1080));
        for (Element e : Element.values())
            wl.add(class_2561.method_43470(w.contains(e) ? " ✔ " : " ✘ ").method_27692(w.contains(e) ? class_124.field_1060 : class_124.field_1061).method_10852(class_2561.method_43470(e.weaponTitle).method_27692(e.fmt)));
        wl.add(Ui.bar(w.size() / 14.0, 20));
        wl.add(Ui.text(w.size() == 14 ? "Click to create!" : w.size() + " / 14", w.size() == 14 ? class_124.field_1054 : class_124.field_1080));
        shown.method_5447(15, Ui.glint(Ui.lore(Ui.icon(CreationItems.ROD, Ui.text("Creation Rod", class_124.field_1068, class_124.field_1067)), wl), w.size() == 14));

        shown.method_5447(13, Ui.glint(Ui.icon(CreationItems.AXE, Ui.text("Creation Axe", class_124.field_1068, class_124.field_1067),
                Ui.text("Hold the Creation Element and right-click an anvil", class_124.field_1080),
                Ui.text("with the Creation Rod in your inventory.", class_124.field_1080),
                Ui.text("It carries all fourteen powers.", class_124.field_1075)), true));
        shown.method_5447(22, Ui.icon(class_1802.field_8077, Ui.text("Close", class_124.field_1061)));
    }

    private void done(String what) {
        var l = player.method_51469();
        l.method_8396(null, player.method_24515(), class_3417.field_14981, class_3419.field_15248, 0.8f, 1.5f);
        l.method_8396(null, player.method_24515(), class_3417.field_14891, class_3419.field_15248, 1f, 1.2f);
        l.method_65096(class_2398.field_11207, player.method_23317(), player.method_23318() + 1.5, player.method_23321(), 120, 1.2, 1.2, 1.2, 0.2);
        l.method_65096(net.minecraft.class_9381.method_58256(class_2398.field_17909, 0xFFFFFFFF), player.method_23317(), player.method_23318() + 1.5, player.method_23321(), 2, 0, 0, 0, 0);
        l.method_8503().method_3760().method_43514(class_2561.method_43470("✦ " + player.method_5477().getString() + " has made the " + what + "!").method_27695(class_124.field_1068, class_124.field_1067), false);
        com.kiyamet.skill.SkillManager.addXp(player, com.kiyamet.skill.Skill.ENCHANTING, 8000);
    }

    private void give(class_1799 s) { if (!player.method_31548().method_7394(s)) player.method_7328(s, false); }

    @Override
    public void method_7593(int slot, int button, class_1713 type, class_1657 p) {
        if (slot < 0 || slot >= 27) { if (type != class_1713.field_7794) super.method_7593(slot, button, type, p); return; }
        if (slot == 22) { player.method_7346(); return; }
        if (slot == 11 && stones(player).size() == StoneKind.values().length) {
            Set<StoneKind> need = EnumSet.allOf(StoneKind.class);
            for (int i = 0; i < player.method_31548().method_5439() && !need.isEmpty(); i++)
                if (player.method_31548().method_5438(i).method_7909() instanceof StoneItem si && need.remove(si.kind)) player.method_31548().method_5438(i).method_7934(1);
            give(new class_1799(CreationItems.CORE));
            done("Creation Element");
        } else if (slot == 15 && weapons(player).size() == Element.values().length) {
            Set<Element> need = EnumSet.allOf(Element.class);
            for (int i = 0; i < player.method_31548().method_5439() && !need.isEmpty(); i++)
                for (Element e : Element.values())
                    if (need.contains(e) && player.method_31548().method_5438(i).method_31574(ElementItems.WEAPONS.get(e))) {
                        com.kiyamet.element.ElementPowers.stop(player, e);
                        player.method_31548().method_5438(i).method_7934(1); need.remove(e); break;
                    }
            give(new class_1799(CreationItems.ROD));
            done("Creation Rod");
        }
        refresh();
    }

    @Override public class_1799 method_7601(class_1657 p, int index) { return class_1799.field_8037; }
    @Override public boolean method_7597(class_1657 p) { return true; }
}
