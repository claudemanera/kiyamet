package com.kiyamet.defense;

import com.kiyamet.registry.ModBlocks;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5321;

/** Zombies chip away "durability points" of the blocks in their way. Damage slowly heals if left alone. */
public final class BlockDurability {
    private record Hit(float damage, long lastTick) {}
    private static final Map<class_5321<class_1937>, Map<Long, Hit>> DAMAGE = new HashMap<>();
    private static final Map<class_2248, Float> HP = new HashMap<>();

    static {
        HP.put(ModBlocks.REINFORCED_PLANKS, 60f);
        HP.put(ModBlocks.STEEL_BLOCK, 150f);
        HP.put(ModBlocks.STEEL_GRATE, 120f);
        HP.put(ModBlocks.RUBY_BLOCK, 260f);
        HP.put(ModBlocks.TITANIUM_BLOCK, 400f);
        HP.put(ModBlocks.ENERGY_WALL, 300f);
        HP.put(ModBlocks.STEEL_GATE, 220f);
        HP.put(class_2246.field_10540, 500f);
        HP.put(class_2246.field_10085, 120f);
        HP.put(class_2246.field_9973, 80f);
        HP.put(class_2246.field_10576, 60f);
    }

    public static float maxHp(class_2680 state) {
        Float hp = HP.get(state.method_26204());
        if (hp != null) return hp;
        float hardness = state.method_26204().method_36555();
        if (hardness < 0) return -1;                 // unbreakable
        return Math.max(4f, hardness * 14f);
    }

    public static boolean breakable(class_3218 level, class_2338 pos, class_2680 state) {
        return !state.method_26215() && !state.method_26220(level, pos).method_1110() && maxHp(state) > 0;
    }

    /** Applies damage; returns true if the block broke. */
    public static boolean hit(class_3218 level, class_2338 pos, float amount, class_1297 breaker) {
        class_2680 state = level.method_8320(pos);
        if (!breakable(level, pos, state)) return false;
        if (state.method_27852(ModBlocks.ENERGY_WALL) && Power.isPowered(level, pos)) return false;   // powered energy walls hold
        float max = maxHp(state);
        Map<Long, Hit> map = DAMAGE.computeIfAbsent(level.method_27983(), k -> new HashMap<>());
        long key = pos.method_10063();
        long now = level.method_75260();
        Hit old = map.get(key);
        float dmg = (old == null ? 0 : healed(old, now)) + amount;
        if (dmg >= max) {
            map.remove(key);
            level.method_8517(breaker.method_5628(), pos, -1);
            level.method_8651(pos, false, breaker);
            return true;
        }
        map.put(key, new Hit(dmg, now));
        level.method_8517(breaker.method_5628(), pos, Math.min(9, (int) (dmg / max * 10)));
        return false;
    }

    private static float healed(Hit h, long now) {
        long idle = now - h.lastTick;
        return idle > 1200 ? Math.max(0, h.damage - (idle - 1200) / 200f) : h.damage;   // after 1 min, 1 point per 10 s
    }

    public static float damage(class_3218 level, class_2338 pos) {
        Hit h = DAMAGE.getOrDefault(level.method_27983(), Map.of()).get(pos.method_10063());
        return h == null ? 0 : healed(h, level.method_75260());
    }

    /** Repairs a fraction (0..1) of the block's max durability. Returns false if there was nothing to repair. */
    public static boolean repair(class_3218 level, class_2338 pos, float fraction) {
        Map<Long, Hit> map = DAMAGE.get(level.method_27983());
        if (map == null) return false;
        Hit h = map.get(pos.method_10063());
        if (h == null) return false;
        float left = h.damage - maxHp(level.method_8320(pos)) * fraction;
        if (left <= 0) map.remove(pos.method_10063());
        else map.put(pos.method_10063(), new Hit(left, h.lastTick));
        for (int i = 0; i < 1; i++) level.method_8517(pos.hashCode(), pos, -1);
        return true;
    }

    /** Damaged blocks within r blocks of a point. */
    public static java.util.List<class_2338> damagedNear(class_3218 level, class_2338 c, int r) {
        java.util.List<class_2338> out = new java.util.ArrayList<>();
        for (long l : DAMAGE.getOrDefault(level.method_27983(), Map.of()).keySet()) {
            class_2338 p = class_2338.method_10092(l);
            if (p.method_10262(c) <= r * r) out.add(p);
        }
        return out;
    }

    private BlockDurability() {}
}
