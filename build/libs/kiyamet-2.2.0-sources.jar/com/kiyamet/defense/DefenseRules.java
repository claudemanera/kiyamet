package com.kiyamet.defense;

import com.kiyamet.entity.KZombie;
import com.kiyamet.entity.ZombieKind;
import com.kiyamet.registry.ModBlocks;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5321;

/** Traps that hurt zombies, and zombies breaking through walls. Called from {@link KZombie#method_5773()}. */
public final class DefenseRules {
    private static final Map<class_5321<class_1937>, Map<Long, Integer>> WEAR = new HashMap<>();

    public static void tickZombie(class_3218 level, KZombie z) {
        if (z.field_6012 % 20 == 0) traps(level, z);
        if (z.field_6012 % 20 == 10) breakWalls(level, z);
    }

    /** Raiders on a base raid: traps hurt them too, and when a wall blocks the way they smash through. */
    public static void tickRaider(class_3218 level, net.minecraft.class_1308 m) {
        if (m.field_6012 % 20 == 0) traps(level, m);
        if (m.field_6012 % 20 == 10) breakWalls(level, m);
    }

    private static void traps(class_3218 level, net.minecraft.class_1308 z) {
        class_2338 pos = z.method_24515();
        for (class_2338 p : new class_2338[]{pos, pos.method_10084()}) {
            class_2680 s = level.method_8320(p);
            class_2248 b = s.method_26204();
            if (b == ModBlocks.BARBED_WIRE) { hurt(level, z, 2); wear(level, p, 60); }
            else if (b == ModBlocks.RAZOR_WIRE) { hurt(level, z, 3); z.method_6092(new class_1293(class_1294.field_5920, 40, 0)); wear(level, p, 90); }
            else if (b == ModBlocks.SPIKE_TRAP) { hurt(level, z, 10); wear(level, p, 20); }
            else if (b == ModBlocks.ELECTRIC_FENCE && Power.isPowered(level, p)) {
                hurt(level, z, 6);
                z.method_6092(new class_1293(class_1294.field_5909, 40, 5));
                level.method_65096(class_2398.field_29644, z.method_23317(), z.method_23318() + 1, z.method_23321(), 15, 0.3, 0.5, 0.3, 0.2);
                level.method_8396(null, p, class_3417.field_20606, class_3419.field_15245, 0.8f, 0.5f);
            }
        }
    }

    private static void hurt(class_3218 level, class_1309 e, float amount) {
        e.method_64397(level, level.method_48963().method_48826(), amount);
    }

    private static void wear(class_3218 level, class_2338 p, int uses) {
        Map<Long, Integer> m = WEAR.computeIfAbsent(level.method_27983(), k -> new HashMap<>());
        int n = m.merge(p.method_10063(), 1, Integer::sum);
        if (n >= uses) { m.remove(p.method_10063()); level.method_22352(p, false); }
    }

    private static void breakWalls(class_3218 level, net.minecraft.class_1308 z) {
        class_1309 target = z.method_5968();
        if (!z.field_5976) return;
        class_243 goal;
        if (target != null && z.method_5739(target) <= 32) goal = target.method_73189();
        else if (z.method_5942().method_6355() != null) goal = class_243.method_24953(z.method_5942().method_6355());
        else return;
        class_243 dir = goal.method_1020(z.method_73189()).method_18805(1, 0, 1);
        if (dir.method_1027() < 0.01) return;
        dir = dir.method_1029();
        class_2338 front = class_2338.method_49637(z.method_23317() + dir.field_1352 * (z.method_17681() / 2 + 0.6), z.method_23318() + 0.5, z.method_23321() + dir.field_1350 * (z.method_17681() / 2 + 0.6));
        for (class_2338 p : new class_2338[]{front, front.method_10084()}) {
            class_2680 s = level.method_8320(p);
            if (!BlockDurability.breakable(level, p, s)) continue;
            if (s.method_27852(ModBlocks.ENERGY_WALL) && Power.isPowered(level, p)) {
                z.method_6005(1.0, dir.field_1352, dir.field_1350);
                z.method_64397(level, level.method_48963().method_48809(), 2);
                level.method_65096(class_2398.field_29644, p.method_10263() + 0.5, p.method_10264() + 0.5, p.method_10260() + 0.5, 20, 0.4, 0.4, 0.4, 0.3);
                return;
            }
            float mult = !(z instanceof KZombie kz) ? 1.5f : switch (kz.kind) {
                case TANK, ALPHA, MUTANT -> 3f;
                case EXPLODER -> s.method_27852(ModBlocks.TITANIUM_BLOCK) ? 1f : 5f;
                default -> 1f;
            };
            float dmg = (float) (Math.max(3, z.method_45325(net.minecraft.class_5134.field_23721)) * mult * 0.5);
            z.method_6104(net.minecraft.class_1268.field_5808);
            if (z instanceof KZombie kz) kz.triggerAnim("attack", "attack");
            level.method_8396(null, p, s.method_26231().method_10596(), class_3419.field_15251, 1f, 0.7f);
            BlockDurability.hit(level, p, dmg, z);
            return;
        }
    }

    private DefenseRules() {}
}
