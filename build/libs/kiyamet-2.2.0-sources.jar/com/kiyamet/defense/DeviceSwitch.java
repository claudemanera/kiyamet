package com.kiyamet.defense;

import com.kiyamet.Kiyamet;
import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_2338;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import java.util.ArrayList;
import java.util.List;

/** Remembers which powered devices were switched off in a generator's panel (stored on the chunk). */
public final class DeviceSwitch {
    public static final AttachmentType<List<Long>> OFF = AttachmentRegistry.create(Kiyamet.id("devices_off"),
            b -> b.initializer(List::of).persistent(Codec.LONG.listOf()));

    public static boolean isOff(class_3218 level, class_2338 pos) {
        class_2818 c = level.method_8500(pos);
        List<Long> l = c.getAttachedOrElse(OFF, List.of());
        return !l.isEmpty() && l.contains(pos.method_10063());
    }

    public static void set(class_3218 level, class_2338 pos, boolean on) {
        class_2818 c = level.method_8500(pos);
        List<Long> l = new ArrayList<>(c.getAttachedOrElse(OFF, List.of()));
        boolean changed = on ? l.remove((Long) pos.method_10063()) : !l.contains(pos.method_10063()) && l.add(pos.method_10063());
        if (changed) c.setAttached(OFF, List.copyOf(l));
    }

    public static void init() {}

    private DeviceSwitch() {}
}
