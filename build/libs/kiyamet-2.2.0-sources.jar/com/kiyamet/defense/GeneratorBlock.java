package com.kiyamet.defense;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_5819;

/** Burns fuel (fuel canister = 4 min, coal = 1 min) and powers energy walls, electric fences and turrets within 8 blocks. */
public class GeneratorBlock extends class_2248 {
    public static final class_2746 LIT = class_2741.field_12548;
    public static final class_2758 FUEL = class_2758.method_11867("fuel", 0, 15);
    /** Master switch from the panel: when off the generator keeps its fuel and powers nothing. */
    public static final class_2746 ON = class_2746.method_11825("on");
    private static final int MINUTE = 1200;

    public GeneratorBlock(class_2251 p) {
        super(p);
        method_9590(field_10647.method_11664().method_11657(LIT, false).method_11657(FUEL, 0).method_11657(ON, true));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> b) {
        b.method_11667(LIT, FUEL, ON);
    }

    public static int fuelValue(class_1799 s) {
        if (s.method_31574(class_1802.field_8713) || s.method_31574(class_1802.field_8665)) return 1;
        if (s.method_31574(class_1802.field_8797)) return 9;
        if (s.method_31574(class_1802.field_8187)) return 10;
        if (s.method_7909() == net.minecraft.class_7923.field_41178.method_63535(com.kiyamet.Kiyamet.id("fuel_canister"))) return 4;
        return 0;
    }

    @Override
    protected class_1269 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        int v = fuelValue(stack);
        if (v == 0) return class_1269.field_52423;
        int fuel = state.method_11654(FUEL);
        if (fuel >= 15) return class_1269.field_5814;
        if (!level.method_8608()) {
            if (!player.method_68878()) {
                if (stack.method_31574(class_1802.field_8187)) player.method_6122(hand, new class_1799(class_1802.field_8550));
                else stack.method_7934(1);
            }
            boolean wasLit = state.method_11654(LIT);
            level.method_8652(pos, state.method_11657(FUEL, Math.min(15, fuel + v)).method_11657(LIT, true), 3);
            if (!wasLit) level.method_64310(pos, this, MINUTE);
            if (level instanceof class_3218 sl0) Power.track(sl0, pos);
            Power.invalidate();
            level.method_8396(null, pos, class_3417.field_15006, class_3419.field_15245, 1f, 0.8f);
        }
        return class_1269.field_5812;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (level instanceof class_3218 sl) GeneratorMenu.open(player, sl, pos);
        return class_1269.field_5812;
    }

    /** Adds fuel from the panel; returns the number of items used (0 or 1). */
    public static boolean addFuel(class_3218 level, class_2338 pos, class_1799 stack) {
        class_2680 state = level.method_8320(pos);
        if (!(state.method_26204() instanceof GeneratorBlock g)) return false;
        int v = fuelValue(stack), fuel = state.method_11654(FUEL);
        if (v == 0 || fuel >= 15) return false;
        boolean wasLit = state.method_11654(LIT);
        level.method_8652(pos, state.method_11657(FUEL, Math.min(15, fuel + v)).method_11657(LIT, true), 3);
        if (!wasLit) level.method_64310(pos, g, MINUTE);
        Power.track(level, pos);
        Power.invalidate();
        level.method_8396(null, pos, class_3417.field_15006, class_3419.field_15245, 1f, 0.8f);
        return true;
    }


    @Override
    protected void method_9588(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        Power.track(level, pos);
        if (!state.method_11654(ON)) { if (state.method_11654(LIT)) level.method_64310(pos, this, MINUTE); return; }
        // clusters burn slower: each extra running generator stretches every unit of fuel by 3% (up to 2.5x)
        int n = Power.runningInCluster(level, pos);
        if (n > 1 && random.method_43057() < Math.min(0.6f, (n - 1) * 0.03f / (1 + (n - 1) * 0.03f))) { level.method_64310(pos, this, MINUTE); return; }
        int fuel = state.method_11654(FUEL) - 1;
        if (fuel <= 0) {
            level.method_8652(pos, state.method_11657(FUEL, 0).method_11657(LIT, false), 3);
            Power.invalidate();
            level.method_8396(null, pos, class_3417.field_15102, class_3419.field_15245, 1f, 1f);
        } else {
            level.method_8652(pos, state.method_11657(FUEL, fuel), 3);
            level.method_64310(pos, this, MINUTE);
        }
    }

    @Override
    protected void method_9615(class_2680 state, class_1937 level, class_2338 pos, class_2680 old, boolean moved) {
        super.method_9615(state, level, pos, old, moved);
        if (level instanceof class_3218 sl) { Power.track(sl, pos); Power.invalidate(); }
    }

    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
        if (state.method_11654(LIT) && state.method_11654(ON) && random.method_43048(3) == 0)
            level.method_8406(class_2398.field_11251, pos.method_10263() + 0.5, pos.method_10264() + 1.05, pos.method_10260() + 0.5, 0, 0.05, 0);
    }
}
