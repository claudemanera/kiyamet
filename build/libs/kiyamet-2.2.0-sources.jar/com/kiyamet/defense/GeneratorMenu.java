package com.kiyamet.defense;

import com.kiyamet.registry.ModBlocks;
import com.kiyamet.ui.Ui;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_124;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3917;
import net.minecraft.class_747;

/**
 * Generator control panel. Shows fuel, a master switch and every powered device group (connected electric fences /
 * energy walls) within range; click a group to switch it on or off.
 */
public class GeneratorMenu extends class_1707 {
    private static final int DEVICE_START = 9, DEVICE_SLOTS = 27;
    private static final int FUEL = 2, STATUS = 4, MASTER = 6, ALL_ON = 47, ALL_OFF = 51, FEED = 49;

    record Group(class_2248 block, List<class_2338> blocks) {
        class_2338 anchor() { return blocks.get(0); }
    }

    private final class_1277 shown;
    private final class_3218 level;
    private final class_2338 pos;
    private List<Group> groups = List.of();

    public static void open(class_1657 player, class_3218 level, class_2338 pos) {
        player.method_17355(new class_747((id, inv, p) -> new GeneratorMenu(id, inv, level, pos), class_2561.method_43470("Generator Control Panel")));
    }

    private GeneratorMenu(int id, class_1661 inv, class_3218 level, class_2338 pos) {
        this(id, inv, new class_1277(54), level, pos);
    }

    private GeneratorMenu(int id, class_1661 inv, class_1277 c, class_3218 level, class_2338 pos) {
        super(class_3917.field_17327, id, inv, c, 6);
        this.shown = c;
        this.level = level;
        this.pos = pos;
        scan();
        refresh();
    }

    private static boolean powered(class_2248 b) { return b == ModBlocks.ELECTRIC_FENCE || b == ModBlocks.ENERGY_WALL; }

    private void scan() {
        Set<class_2338> seen = new HashSet<>();
        List<Group> out = new ArrayList<>();
        int r = Math.min(40, Power.range(level, pos));
        for (class_2338 p0 : class_2338.method_10097(pos.method_10069(-r, -r, -r), pos.method_10069(r, r, r))) {
            class_2248 b = level.method_8320(p0).method_26204();
            if (!powered(b) || seen.contains(p0)) continue;
            List<class_2338> blocks = new ArrayList<>();
            ArrayDeque<class_2338> q = new ArrayDeque<>();
            q.add(p0.method_10062());
            seen.add(p0.method_10062());
            while (!q.isEmpty()) {
                class_2338 c = q.poll();
                blocks.add(c);
                for (class_2338 n : class_2338.method_10097(c.method_10069(-1, -1, -1), c.method_10069(1, 1, 1))) {
                    if (Math.abs(n.method_10263() - pos.method_10263()) > r || Math.abs(n.method_10264() - pos.method_10264()) > r || Math.abs(n.method_10260() - pos.method_10260()) > r) continue;
                    if (!seen.contains(n) && level.method_8320(n).method_26204() == b) { class_2338 im = n.method_10062(); seen.add(im); q.add(im); }
                }
            }
            out.add(new Group(b, blocks));
            if (out.size() >= DEVICE_SLOTS) break;
        }
        groups = out;
    }

    private boolean isOn(Group g) { return !DeviceSwitch.isOff(level, g.anchor()); }

    private void refresh() {
        shown.method_5448();
        for (int i = 0; i < 54; i++) shown.method_5447(i, i < 9 || i >= 45 ? Ui.dark() : class_1799.field_8037);
        class_2680 st = level.method_8320(pos);
        if (!(st.method_26204() instanceof GeneratorBlock)) return;
        int fuel = st.method_11654(GeneratorBlock.FUEL);
        boolean lit = st.method_11654(GeneratorBlock.LIT), on = st.method_11654(GeneratorBlock.ON);

        class_1799 gauge = Ui.icon(class_1802.field_8713, Ui.text("Fuel: " + fuel + " / 15 min", class_124.field_1065),
                Ui.bar(fuel / 15.0, 15), Ui.text("Fuel canister = 4 min, coal = 1 min", class_124.field_1080),
                Ui.text("Coal block = 9 min, lava bucket = 10 min", class_124.field_1080));
        gauge.method_7939(Math.max(1, fuel));
        shown.method_5447(FUEL, gauge);
        shown.method_5447(STATUS, Ui.glint(Ui.icon(lit && on ? class_1802.field_16306 : class_1802.field_8732,
                Ui.text("Generator", class_124.field_1075, class_124.field_1067),
                Ui.text(lit && on ? "● Running" : on ? "● Out of fuel" : "● Paused", lit && on ? class_124.field_1060 : class_124.field_1061),
                Ui.text("Range: " + Power.range(level, pos) + " blocks", class_124.field_1080),
                Ui.text("Cluster: " + Power.cluster(level, pos).size() + " generators (" + Power.runningInCluster(level, pos) + " running, max " + Power.MAX_CLUSTER + ")", class_124.field_1080),
                Ui.text("Place generators touching each other: +" + Power.PER_EXTRA + " range each, slower fuel use", class_124.field_1063),
                Ui.text("Devices in range: " + groups.size() + " groups", class_124.field_1080)), lit && on));
        shown.method_5447(MASTER, Ui.icon(on ? class_1802.field_8131 : class_1802.field_8264,
                Ui.text(on ? "Master switch: ON" : "Master switch: OFF", on ? class_124.field_1060 : class_124.field_1061, class_124.field_1067),
                Ui.text("Click to " + (on ? "pause (keeps fuel)" : "resume"), class_124.field_1080)));

        if (groups.isEmpty()) {
            shown.method_5447(22, Ui.icon(class_1802.field_8077, Ui.text("No devices in range", class_124.field_1061),
                    Ui.text("Place electric fences or energy walls", class_124.field_1080), Ui.text("within " + Power.RANGE + " blocks of the generator.", class_124.field_1080)));
        }
        int fence = 0, wall = 0;
        for (int i = 0; i < groups.size(); i++) {
            Group g = groups.get(i);
            boolean gOn = isOn(g);
            boolean isFence = g.block() == ModBlocks.ELECTRIC_FENCE;
            String name = (isFence ? "Electric Fence #" + (++fence) : "Energy Wall #" + (++wall));
            class_2338 a = g.anchor();
            class_1799 s = Ui.icon(g.block().method_8389(), Ui.text(name, gOn ? class_124.field_1060 : class_124.field_1061, class_124.field_1067),
                    Ui.text(gOn ? "● Active" : "● Switched off", gOn ? class_124.field_1060 : class_124.field_1079),
                    Ui.text(g.blocks().size() + " blocks", class_124.field_1080),
                    Ui.text("At " + a.method_10263() + ", " + a.method_10264() + ", " + a.method_10260() + "  (" + (int) Math.sqrt(a.method_10262(pos)) + " m)", class_124.field_1063),
                    Ui.text(isFence ? "Shocks zombies: 6 dmg + stun" : "Unbreakable while powered, knocks zombies back", class_124.field_1080),
                    Ui.text("Click to switch " + (gOn ? "off" : "on"), class_124.field_1054));
            s.method_7939(Math.min(64, g.blocks().size()));
            shown.method_5447(DEVICE_START + i, Ui.glint(s, gOn && lit && on));
        }
        shown.method_5447(ALL_ON, Ui.icon(class_1802.field_8839, Ui.text("Switch all ON", class_124.field_1060)));
        shown.method_5447(FEED, Ui.icon(class_1802.field_8239, Ui.text("Add fuel", class_124.field_1065),
                Ui.text("Click here holding fuel on the cursor", class_124.field_1080)));
        shown.method_5447(ALL_OFF, Ui.icon(class_1802.field_8333, Ui.text("Switch all OFF", class_124.field_1061)));
    }

    private void setGroup(Group g, boolean on) {
        for (class_2338 p : g.blocks()) DeviceSwitch.set(level, p, on);
    }

    @Override
    public void method_7593(int slot, int button, class_1713 type, class_1657 player) {
        if (slot < 0 || slot >= 54) { if (type != class_1713.field_7794) super.method_7593(slot, button, type, player); return; }
        if (!(player instanceof class_3222 sp)) return;
        class_2680 st = level.method_8320(pos);
        if (!(st.method_26204() instanceof GeneratorBlock)) { sp.method_7346(); return; }
        boolean changed = true;
        if (slot == MASTER) {
            boolean on = !st.method_11654(GeneratorBlock.ON);
            level.method_8652(pos, st.method_11657(GeneratorBlock.ON, on), 3);
            if (on && st.method_11654(GeneratorBlock.LIT)) level.method_64310(pos, st.method_26204(), 1200);
        } else if (slot == FEED || slot == FUEL) {
            class_1799 carried = method_34255();
            changed = !carried.method_7960() && GeneratorBlock.addFuel(level, pos, carried);
            if (changed && !sp.method_68878()) carried.method_7934(1);
        } else if (slot == ALL_ON || slot == ALL_OFF) {
            for (Group g : groups) setGroup(g, slot == ALL_ON);
        } else if (slot >= DEVICE_START && slot < DEVICE_START + groups.size()) {
            Group g = groups.get(slot - DEVICE_START);
            setGroup(g, !isOn(g));
        } else changed = false;
        if (changed) {
            Power.invalidate();
            level.method_8396(null, sp.method_24515(), class_3417.field_14962, class_3419.field_15245, 0.7f, 1.3f);
            refresh();
        }
    }

    @Override
    public class_1799 method_7601(class_1657 player, int index) { return class_1799.field_8037; }

    @Override
    public void method_7595(class_1657 player) {
        shown.method_5448();
        super.method_7595(player);
    }

    @Override
    public boolean method_7597(class_1657 player) { return player.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5) < 64; }
}
