package com.kiyamet.defense;

import java.util.*;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_5321;

/**
 * Generators power blocks around them. Generators placed touching each other (side by side or stacked)
 * form a cluster of up to 65: every extra running generator adds +1 block of range (8 alone, 72 with 65)
 * and the whole cluster burns fuel more slowly. Results are cached for 5 seconds.
 */
public final class Power {
    public static final int RANGE = 8, PER_EXTRA = 1, MAX_CLUSTER = 65;
    private record Cached(boolean on, long until) {}
    private static final Map<Long, Cached> CACHE = new HashMap<>();
    /** Known generator positions per dimension (filled as generators are placed, fuelled and tick). */
    private static final Map<class_5321<class_1937>, Set<Long>> GENS = new HashMap<>();
    private static final Map<Long, Integer> CLUSTER = new HashMap<>();

    public static void track(class_3218 level, class_2338 pos) { GENS.computeIfAbsent(level.method_27983(), k -> new HashSet<>()).add(pos.method_10063()); }

    static boolean running(class_2680 s) { return s.method_26204() instanceof GeneratorBlock && s.method_11654(class_2741.field_12548) && s.method_11654(GeneratorBlock.ON); }

    /** Generators connected to this one (touching faces), counting running ones, max 20. */
    public static List<class_2338> cluster(class_3218 level, class_2338 start) {
        List<class_2338> out = new ArrayList<>();
        Set<Long> seen = new HashSet<>();
        ArrayDeque<class_2338> q = new ArrayDeque<>();
        q.add(start.method_10062()); seen.add(start.method_10063());
        while (!q.isEmpty() && out.size() < 128) {
            class_2338 c = q.poll();
            if (!(level.method_8320(c).method_26204() instanceof GeneratorBlock)) continue;
            out.add(c);
            for (class_2350 d : class_2350.values()) {
                class_2338 n = c.method_10093(d);
                if (seen.add(n.method_10063()) && level.method_8320(n).method_26204() instanceof GeneratorBlock) q.add(n);
            }
        }
        return out;
    }

    public static int runningInCluster(class_3218 level, class_2338 pos) {
        Integer c = CLUSTER.get(pos.method_10063());
        if (c != null) return c;
        int n = 0;
        for (class_2338 p : cluster(level, pos)) if (running(level.method_8320(p))) n++;
        n = Math.min(MAX_CLUSTER, n);
        CLUSTER.put(pos.method_10063(), n);
        return n;
    }

    public static int range(class_3218 level, class_2338 gen) {
        int n = runningInCluster(level, gen);
        return RANGE + PER_EXTRA * Math.max(0, n - 1);
    }

    public static boolean isPowered(class_3218 level, class_2338 pos) {
        long now = level.method_75260();
        Cached c = CACHE.get(pos.method_10063());
        if (c != null && c.until > now) return c.on;
        if (DeviceSwitch.isOff(level, pos)) { CACHE.put(pos.method_10063(), new Cached(false, now + 100)); return false; }
        boolean on = false;
        // nearby generators (also finds ones not tracked yet, e.g. right after a restart)
        for (class_2338 p : class_2338.method_10097(pos.method_10069(-RANGE, -RANGE, -RANGE), pos.method_10069(RANGE, RANGE, RANGE))) {
            class_2680 s = level.method_8320(p);
            if (s.method_26204() instanceof GeneratorBlock) { track(level, p); if (running(s)) { on = true; break; } }
        }
        if (!on) on = com.kiyamet.power.Renewables.near(level, pos, RANGE);   // 1.9 solar panels and wind turbines
        if (!on) {
            Set<Long> gens = GENS.getOrDefault(level.method_27983(), Set.of());
            for (Iterator<Long> it = gens.iterator(); it.hasNext(); ) {
                class_2338 g = class_2338.method_10092(it.next());
                int max = RANGE + PER_EXTRA * (MAX_CLUSTER - 1);
                if (Math.abs(g.method_10263() - pos.method_10263()) > max || Math.abs(g.method_10264() - pos.method_10264()) > max || Math.abs(g.method_10260() - pos.method_10260()) > max) continue;
                if (!level.method_8477(g)) continue;
                class_2680 s = level.method_8320(g);
                if (!(s.method_26204() instanceof GeneratorBlock)) { it.remove(); continue; }
                if (!running(s)) continue;
                int r = range(level, g);
                if (Math.abs(g.method_10263() - pos.method_10263()) <= r && Math.abs(g.method_10264() - pos.method_10264()) <= r && Math.abs(g.method_10260() - pos.method_10260()) <= r) { on = true; break; }
            }
        }
        if (CACHE.size() > 20000) CACHE.clear();
        CACHE.put(pos.method_10063(), new Cached(on, now + 100));
        return on;
    }

    public static void invalidate() { CACHE.clear(); CLUSTER.clear(); }

    private Power() {}
}
