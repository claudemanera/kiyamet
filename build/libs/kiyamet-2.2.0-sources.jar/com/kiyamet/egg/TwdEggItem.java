package com.kiyamet.egg;

import com.kiyamet.npc.Faction;
import com.kiyamet.npc.HumanEntity;
import com.kiyamet.npc.ModHumans;
import com.kiyamet.npc.Role;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;

/** TWD spawn eggs (and car kits): use on a block to spawn the thing. */
public class TwdEggItem extends class_1792 {
    final String what;   // "entity:<id>", "human:<FACTION>:<ROLE>", "vehicle:<KIND>"

    public TwdEggItem(class_1793 p, String what) { super(p); this.what = what; }

    @Override
    public class_1269 method_7884(class_1838 ctx) {
        if (!(ctx.method_8045() instanceof class_3218 level)) return class_1269.field_5812;
        class_2338 pos = ctx.method_8037().method_10093(ctx.method_8038());
        String[] w = what.split(":");
        class_1297 made = null;
        switch (w[0]) {
            case "entity" -> {
                class_1299<?> t = net.minecraft.class_7923.field_41177.method_63535(com.kiyamet.Kiyamet.id(w[1]));
                class_1297 e = t.method_5883(level, class_3730.field_16465);
                if (e == null) return class_1269.field_5814;
                e.method_24203(pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5); e.method_36456(level.field_9229.method_43057() * 360);
                if (e instanceof class_1308 m) m.method_5943(level, level.method_8404(pos), class_3730.field_16465, null);
                level.method_8649(e);
                made = e;
            }
            case "human" -> {
                Faction f = Faction.valueOf(w[1]);
                int lv = 20 + level.field_9229.method_43048(60);
                HumanEntity h = ModHumans.spawn(level, pos, f == Faction.COMPANION ? Faction.SURVIVOR : f, Role.valueOf(w[2]), lv, f == Faction.COMMUNITY ? "Alexandria" : "");
                if (h != null && f == Faction.COMPANION && ctx.method_8036() instanceof class_3222 sp) h.setOwner(sp);
                made = h;
            }
            case "vehicle" -> {
                float yaw = ctx.method_8036() == null ? 0 : ctx.method_8036().method_36454();
                made = com.kiyamet.vehicle.ModVehicles.spawn(level, com.kiyamet.vehicle.VehicleKind.valueOf(w[1]), pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5, yaw, 1f, 1f);
            }
        }
        if (made == null) return class_1269.field_5814;
        level.method_8396(null, pos, w[0].equals("vehicle") ? class_3417.field_14785 : class_3417.field_15219, class_3419.field_15248, 0.7f, 1f);
        if (ctx.method_8036() == null || !ctx.method_8036().method_68878()) ctx.method_8041().method_7934(1);
        return class_1269.field_21466;
    }
}
