package com.kiyamet.element;

import com.kiyamet.registry.ModItems;
import java.util.EnumMap;
import java.util.Map;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_2199;
import net.minecraft.class_2338;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_9334;
import net.minecraft.class_9886;

/** Weapons, element cores, the ancient rod; and forging: core + rod on an anvil. */
public final class ElementItems {
    public static final Map<Element, class_1792> WEAPONS = new EnumMap<>(Element.class), CORES = new EnumMap<>(Element.class);
    public static class_1792 ROD, SAGE_MAP;

    public static void init() {
        for (Element e : Element.values()) {
            WEAPONS.put(e, ModItems.custom(e.weapon, p -> new ElementWeapon(p.method_66333(class_9886.field_52590, e.damage - 5f, e.speed).method_24359().method_7894(class_1814.field_8904)
                    .method_57349(class_9334.field_49630, net.minecraft.class_3902.field_17274), e)));
            CORES.put(e, ModItems.custom(e.core(), p -> new class_1792(p.method_7889(1).method_24359().method_7894(class_1814.field_8904).method_57349(class_9334.field_49641, true))));
        }
        ROD = ModItems.custom("ancient_rod", p -> new class_1792(p.method_66333(class_9886.field_52587, 4f, -2.4f).method_24359().method_7894(class_1814.field_8903).method_57349(class_9334.field_49630, net.minecraft.class_3902.field_17274)));
        SAGE_MAP = ModItems.custom("sage_map", p -> new SageMapItem(p.method_7889(1).method_7894(class_1814.field_8907)));

        // walkers felled with a sage's rod count for that sage's quest
        net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents.AFTER_DEATH.register((dead, src) -> {
            if (!(src.method_5529() instanceof class_3222 p) || !(dead instanceof net.minecraft.class_1569)) return;
            Element e = Sage.rodElement(p.method_6047());
            if (e != null) Sage.addKill(p, e);
        });
        // forging: hold the element core, have an ancient rod in your inventory, right-click an anvil
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (hand != class_1268.field_5808 || !(player instanceof class_3222 p) || !(level instanceof class_3218 l)) return class_1269.field_5811;
            class_2338 pos = hit.method_17777();
            if (!(l.method_8320(pos).method_26204() instanceof class_2199)) return class_1269.field_5811;
            class_1799 held = p.method_6047();
            Element e = null;
            for (var en : CORES.entrySet()) if (held.method_31574(en.getValue())) e = en.getKey();
            if (e == null) return class_1269.field_5811;
            int rod = -1;
            for (int i = 0; i < p.method_31548().method_5439(); i++) if (p.method_31548().method_5438(i).method_31574(ROD)) { rod = i; break; }
            if (rod < 0) { p.method_7353(class_2561.method_43470("You need an Ancient Rod to forge the " + e.weaponTitle + ".").method_27692(class_124.field_1061), true); return class_1269.field_5814; }
            p.method_31548().method_5438(rod).method_7934(1);
            held.method_7934(1);
            class_1799 w = new class_1799(WEAPONS.get(e));
            if (!p.method_31548().method_7394(w)) p.method_7328(w, false);
            for (int i = 0; i < 5; i++) l.method_8396(null, pos, class_3417.field_14559, class_3419.field_15245, 1f, 0.6f + i * 0.15f);
            l.method_8396(null, pos, class_3417.field_14981, class_3419.field_15245, 0.6f, 1.6f);
            l.method_65096(new class_2390(e.color, 2f), pos.method_10263() + 0.5, pos.method_10264() + 1.2, pos.method_10260() + 0.5, 80, 0.6, 0.6, 0.6, 0.1);
            l.method_65096(class_2398.field_11207, pos.method_10263() + 0.5, pos.method_10264() + 1.2, pos.method_10260() + 0.5, 30, 0.3, 1, 0.3, 0.1);
com.kiyamet.skill.SkillManager.addXp(p, com.kiyamet.skill.Skill.ENCHANTING, 4000);
            l.method_8503().method_3760().method_43514(class_2561.method_43470("⚔ " + p.method_5477().getString() + " forged the " + e.weaponTitle + "!").method_27695(e.fmt, class_124.field_1067), false);
            return class_1269.field_5812;
        });
    }

    private ElementItems() {}
}
