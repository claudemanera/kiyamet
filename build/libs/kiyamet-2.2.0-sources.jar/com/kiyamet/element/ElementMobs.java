package com.kiyamet.element;

import com.kiyamet.Kiyamet;
import java.util.EnumMap;
import java.util.Map;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1314;
import net.minecraft.class_1588;
import net.minecraft.class_2378;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/** Registers the 14 temple guardians and the 14 sages. */
public final class ElementMobs {
    public static final Map<Element, class_1299<TempleGuardian>> GUARDIANS = new EnumMap<>(Element.class);
    public static final Map<Element, class_1299<Sage>> SAGES = new EnumMap<>(Element.class);

    static {
        for (Element e : Element.values()) {
            class_5321<class_1299<?>> gk = class_5321.method_29179(class_7924.field_41266, Kiyamet.id(e.guardian()));
            class_1299.class_1300<TempleGuardian> gb = class_1299.class_1300.<TempleGuardian>method_5903((t, l) -> new TempleGuardian(t, l, e), class_1311.field_6302).method_17687(0.7f, 2.2f).method_55687(1.9f).method_27299(10);
            if (e == Element.FLAME || e == Element.FIRE) gb = gb.method_19947();
            GUARDIANS.put(e, class_2378.method_39197(class_7923.field_41177, gk, gb.method_5905(gk)));
            class_5321<class_1299<?>> sk = class_5321.method_29179(class_7924.field_41266, Kiyamet.id(e.sage()));
            SAGES.put(e, class_2378.method_39197(class_7923.field_41177, sk, class_1299.class_1300.<Sage>method_5903((t, l) -> new Sage(t, l, e), class_1311.field_17715).method_17687(0.6f, 1.95f).method_27299(10).method_5905(sk)));
        }
    }

    public static void init() {
        GUARDIANS.forEach((e, t) -> FabricDefaultAttributeRegistry.register(t, class_1588.method_26918().method_26868(class_5134.field_23716, 110).method_26868(class_5134.field_23721, 13)
                .method_26868(class_5134.field_23724, 14).method_26868(class_5134.field_23725, 6).method_26868(class_5134.field_23719, 0.29).method_26868(class_5134.field_23717, 28).method_26868(class_5134.field_23718, 0.6)));
        SAGES.forEach((e, t) -> FabricDefaultAttributeRegistry.register(t, class_1314.method_26828().method_26868(class_5134.field_23716, 80).method_26868(class_5134.field_23719, 0.3)
                .method_26868(class_5134.field_23721, 8).method_26868(class_5134.field_23724, 10).method_26868(class_5134.field_23717, 24)));
    }

    private ElementMobs() {}
}
