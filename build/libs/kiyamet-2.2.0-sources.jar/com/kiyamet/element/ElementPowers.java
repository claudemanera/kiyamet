package com.kiyamet.element;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1538;
import net.minecraft.class_1657;
import net.minecraft.class_1674;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.server.MinecraftServer;

/** What each element does while its power is on - and how it is switched off cleanly. */
public final class ElementPowers {
    static final Map<UUID, java.util.EnumSet<Element>> ON = new HashMap<>();
    static final java.util.EnumSet<Element> CLOCK = java.util.EnumSet.of(Element.ICE, Element.THUNDER, Element.WIND), FLIGHT = java.util.EnumSet.of(Element.SPIRIT, Element.AIR);

    public static boolean on(class_3222 p, Element e) { var s = ON.get(p.method_5667()); return s != null && s.contains(e); }
    /** whoever froze / sped / slowed time last owns the clock */
    static UUID clockOwner;

    public static void init() {
        // metal: no damage at all
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((e, src, amount) -> !(e instanceof class_3222 p && on(p, Element.METAL)));
        ServerPlayConnectionEvents.DISCONNECT.register((h, server) -> { var set = ON.remove(h.field_14140.method_5667()); if (set != null) for (Element e : java.util.EnumSet.copyOf(set)) stop(h.field_14140, e); });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            // safety: a power whose holder vanished gives the clock back
            if (clockOwner != null && server.method_3760().method_14602(clockOwner) == null) resetClock(server);
        });
    }

    static class_243 look(class_3222 p, double range, boolean entities) {
        class_243 eye = p.method_33571(), end = eye.method_1019(p.method_5720().method_1021(range));
        class_3965 bh = p.method_51469().method_17742(new class_3959(eye, end, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, p));
        class_243 hit = bh.method_17783() == class_239.class_240.field_1333 ? end : bh.method_17784();
        if (entities) {
            class_3966 eh = net.minecraft.class_1675.method_37226(p.method_51469(), p, eye, hit, p.method_5829().method_18804(p.method_5720().method_1021(range)).method_1014(1), e -> e instanceof class_1309 && e != p, 0.3f);
            if (eh != null) return eh.method_17784();
        }
        return hit;
    }

    static boolean friend(class_3222 p, class_1297 e) {
        if (e == p || e instanceof class_1657) return true;
        if (e instanceof class_1321 t && t.method_6171(p)) return true;
        if (e instanceof com.kiyamet.npc.HumanEntity h && h.isOwnedBy(p)) return true;
        return false;
    }

    static void resetClock(MinecraftServer s) {
        s.method_54833().method_54675(false);
        s.method_54833().method_54671(20f);
        clockOwner = null;
    }

    public static void start(class_3222 p, Element e) {
        var set = ON.computeIfAbsent(p.method_5667(), k -> java.util.EnumSet.noneOf(Element.class));
        // powers that fight over the same thing (the clock, the flight) replace each other
        for (Element o : java.util.EnumSet.copyOf(set)) if (o != e && (CLOCK.contains(o) && CLOCK.contains(e) || FLIGHT.contains(o) && FLIGHT.contains(e))) stop(p, o);
        set.add(e);
        class_3218 l = p.method_51469();
        MinecraftServer s = l.method_8503();
        l.method_8396(null, p.method_24515(), class_3417.field_14703, class_3419.field_15248, 1f, 1.6f);
        burst(l, p, e, 40);
        switch (e) {
            case SPIRIT -> { p.method_31549().field_7478 = true; p.method_31549().field_7479 = true; p.method_31549().method_7248(0.2f); p.method_7355(); }
            case AIR -> { p.method_31549().field_7478 = true; p.method_31549().method_7248(0.05f); p.method_7355(); p.method_6092(new class_1293(class_1294.field_5902, 30, 4, false, false)); }
            case ICE -> { s.method_54833().method_54675(true); clockOwner = p.method_5667(); }
            case THUNDER -> { s.method_54833().method_54671(10f); clockOwner = p.method_5667(); }
            case WIND -> { s.method_54833().method_54671(40f); clockOwner = p.method_5667(); }
            default -> {}
        }
    }

    public static void stop(class_3222 p, Element e) {
        var set = ON.get(p.method_5667());
        if (set != null) { set.remove(e); if (set.isEmpty()) ON.remove(p.method_5667()); }
        class_3218 l = p.method_51469();
        switch (e) {
            case SPIRIT, AIR -> {
                boolean keep = p.method_68878() || p.method_7325();
                p.method_31549().method_7248(0.05f);
                if (!keep) { p.method_31549().field_7478 = false; p.method_31549().field_7479 = false; p.method_6092(new class_1293(class_1294.field_5906, 200, 0, false, false)); }
                p.method_7355();
            }
            case ICE, THUNDER, WIND -> { if (p.method_5667().equals(clockOwner)) resetClock(l.method_8503()); }
            case SHADOW -> p.method_6016(class_1294.field_5905);
            default -> {}
        }
        if (e == Element.THUNDER) { p.method_6016(class_1294.field_5904); p.method_6016(class_1294.field_5917); }
        if (e == Element.WATER) { p.method_6016(class_1294.field_5913); p.method_6016(class_1294.field_5900); }
        l.method_8396(null, p.method_24515(), class_3417.field_19344, class_3419.field_15248, 1f, 1.4f);
    }

    static void burst(class_3218 l, class_3222 p, Element e, int n) {
        int c = e.color;
        l.method_65096(new class_2390(c, 1.6f), p.method_23317(), p.method_23318() + 1, p.method_23321(), n, 0.6, 0.9, 0.6, 0.02);
    }

    static class_1293 fx(net.minecraft.class_6880<net.minecraft.class_1291> m, int ticks, int amp) { return new class_1293(m, ticks, amp, false, false, true); }

    public static void tick(class_3222 p, Element e, class_1799 weapon) {
        class_3218 l = p.method_51469();
        int t = p.field_6012;
        ON.computeIfAbsent(p.method_5667(), k -> java.util.EnumSet.noneOf(Element.class)).add(e);
        if (t % 100 == 0) com.kiyamet.skill.SkillManager.addXp(p, switch (e) {            // using a power trains the body
            case SPIRIT, AIR -> com.kiyamet.skill.Skill.ACROBATICS; case SHADOW, SMOKE -> com.kiyamet.skill.Skill.STEALTH; case WATER -> com.kiyamet.skill.Skill.SWIMMING;
            case THUNDER, WIND -> com.kiyamet.skill.Skill.ATHLETICS; case METAL -> com.kiyamet.skill.Skill.DEFENSE; case EARTH -> com.kiyamet.skill.Skill.MINING;
            default -> com.kiyamet.skill.Skill.ENCHANTING; }, 15);
        if (t % 4 == 0) l.method_65096(new class_2390(e.color, 1.1f), p.method_23317(), p.method_23318() + 0.9, p.method_23321(), 3, 0.45, 0.7, 0.45, 0.01);
        switch (e) {
            case FLAME -> {                    // a cone of flame in front of you
                if (t % 2 != 0) break;
                class_243 dir = p.method_5720(), eye = p.method_33571().method_1031(0, -0.2, 0);
                for (int i = 1; i <= 9; i++) {
                    class_243 at = eye.method_1019(dir.method_1021(i * 0.9));
                    l.method_65096(class_2398.field_11240, at.field_1352, at.field_1351, at.field_1350, 3, 0.12 * i / 3, 0.12 * i / 3, 0.12 * i / 3, 0.02);
                }
                if (t % 6 == 0) l.method_8396(null, p.method_24515(), class_3417.field_15013, class_3419.field_15248, 0.4f, 1.6f);
                for (class_1309 v : l.method_8390(class_1309.class, p.method_5829().method_18804(dir.method_1021(9)).method_1014(1.5), v -> !friend(p, v))) {
                    class_243 to = v.method_73189().method_1031(0, v.method_17682() / 2, 0).method_1020(eye);
                    if (to.method_1033() < 10 && to.method_1029().method_1026(dir) > 0.8) { v.method_5639(5); v.method_64397(l, l.method_48963().method_48813(), 3f); }
                }
            }
            case FIRE -> {                     // fireballs
                if (t % 16 != 0) break;
                class_243 dir = p.method_5720();
                class_1674 f = new class_1674(l, p, dir, 2);
                f.method_5814(p.method_23317() + dir.field_1352 * 1.5, p.method_23320() + dir.field_1351 * 1.5 - 0.2, p.method_23321() + dir.field_1350 * 1.5);
                l.method_8649(f);
                l.method_8396(null, p.method_24515(), class_3417.field_15231, class_3419.field_15248, 0.8f, 1.2f);
            }
            case LIGHTNING -> {                // lightning where you look
                if (t % 20 != 0) break;
                class_243 at = look(p, 48, true);
                class_1538 b = class_1299.field_6112.method_5883(l, class_3730.field_16461);
                if (b != null) { b.method_5808(at.field_1352, at.field_1351, at.field_1350, 0, 0); b.method_6961(p); l.method_8649(b); }
            }
            case ELECTRIC -> {                 // exploding lightning
                if (t % 24 != 0) break;
                class_243 at = look(p, 48, true);
                class_1538 b = class_1299.field_6112.method_5883(l, class_3730.field_16461);
                if (b != null) { b.method_5808(at.field_1352, at.field_1351, at.field_1350, 0, 0); b.method_6961(p); l.method_8649(b); }
                if (at.method_1022(p.method_73189()) > 4) l.method_8437(p, at.field_1352, at.field_1351, at.field_1350, 3.2f, class_1937.class_7867.field_40891);
            }
            case EARTH -> {                    // shatter a 6x6 area
                if (t % 20 != 0) break;
                class_243 at = look(p, 32, false);
                if (at.method_1022(p.method_33571()) > 31) break;
                class_2338 c = class_2338.method_49638(at.method_1019(p.method_5720().method_1021(0.5)));
                int broke = 0;
                for (class_2338 q : class_2338.method_10097(c.method_10069(-3, -3, -3), c.method_10069(2, 2, 2))) {
                    class_2680 s = l.method_8320(q);
                    if (s.method_26215() || s.method_26214(l, q) < 0 || s.method_26214(l, q) > 50 || q.method_19771(p.method_24515(), 2)) continue;
                    l.method_8651(q, p.method_59922().method_43048(4) == 0, p); broke++;
                }
                if (broke > 0) { l.method_8396(null, c, class_3417.field_15152.comp_349(), class_3419.field_15248, 0.7f, 0.6f); l.method_65096(class_2398.field_11236, c.method_10263(), c.method_10264(), c.method_10260(), 4, 2, 2, 2, 0); }
                for (class_1309 v : l.method_8390(class_1309.class, new class_238(c).method_1014(3), v -> !friend(p, v))) v.method_64397(l, l.method_48963().method_48802(p), 10f);
            }
            case SHADOW -> {
                p.method_6092(fx(class_1294.field_5905, 40, 0));
                if (t % 10 == 0) for (class_1308 m : l.method_8390(class_1308.class, p.method_5829().method_1014(32), m -> m.method_5968() == p)) m.method_5980(null);
            }
            case SMOKE -> {                    // choking cloud
                l.method_65096(class_2398.field_11237, p.method_23317(), p.method_23318() + 1, p.method_23321(), 6, 3.5, 1.2, 3.5, 0.01);
                l.method_65096(class_2398.field_17431, p.method_23317(), p.method_23318() + 1, p.method_23321(), 1, 3, 0.5, 3, 0.01);
                if (t % 10 == 0) for (class_1309 v : l.method_8390(class_1309.class, p.method_5829().method_1014(8), v -> !friend(p, v))) {
                    v.method_5855(Math.max(-20, v.method_5669() - 60));
                    v.method_64397(l, l.method_48963().method_48824(), 4f);
                    v.method_6092(fx(class_1294.field_5919, 40, 0));
                }
            }
            case SPIRIT -> {
                if (!p.method_31549().field_7478 || p.method_31549().method_7252() != 0.2f) { p.method_31549().field_7478 = true; p.method_31549().method_7248(0.2f); p.method_7355(); }
                if (t % 3 == 0) l.method_65096(class_2398.field_22246, p.method_23317(), p.method_23318() + 0.3, p.method_23321(), 2, 0.3, 0.1, 0.3, 0.01);
            }
            case AIR -> {
                if (!p.method_31549().field_7478) { p.method_31549().field_7478 = true; p.method_7355(); }
                if (t % 3 == 0) l.method_65096(class_2398.field_11204, p.method_23317(), p.method_23318(), p.method_23321(), 2, 0.3, 0.05, 0.3, 0.01);
            }
            case THUNDER -> {
                p.method_6092(fx(class_1294.field_5904, 40, 7)); p.method_6092(fx(class_1294.field_5917, 40, 3));
                if (t % 2 == 0) l.method_65096(class_2398.field_29644, p.method_23317(), p.method_23318() + 0.5, p.method_23321(), 4, 0.3, 0.5, 0.3, 0.1);
            }
            case ICE -> {
                if (t % 5 == 0) l.method_65096(class_2398.field_28013, p.method_23317(), p.method_23318() + 1, p.method_23321(), 10, 6, 3, 6, 0);
                if (!l.method_8503().method_54833().method_54754()) { l.method_8503().method_54833().method_54675(true); clockOwner = p.method_5667(); }
            }
            case WATER -> {
                p.method_6092(fx(class_1294.field_5913, 40, 6)); p.method_6092(fx(class_1294.field_5900, 40, 2)); p.method_6092(fx(class_1294.field_5923, 40, 0));
                p.field_6017 = 0;
                if (p.method_5799()) { p.method_6092(fx(class_1294.field_5904, 40, 3)); }
            }
            case WIND -> {
                if (t % 3 == 0) l.method_65096(class_2398.field_47494, p.method_23317(), p.method_23318() + 1, p.method_23321(), 1, 1.5, 0.5, 1.5, 0);
            }
            case METAL -> {
                if (t % 6 == 0) l.method_65096(class_2398.field_29643, p.method_23317(), p.method_23318() + 1, p.method_23321(), 4, 0.4, 0.8, 0.4, 0.05);
                p.method_5646();
            }
        }
    }

    /** every hit carries the element */
    public static void onHit(Element e, class_1309 v, class_1309 a) {
        if (!(v.method_73183() instanceof class_3218 l)) return;
        switch (e) {
            case FLAME, FIRE -> v.method_5639(6);
            case LIGHTNING, THUNDER, ELECTRIC -> { v.method_6092(fx(class_1294.field_5909, 40, 3)); l.method_65096(class_2398.field_29644, v.method_23317(), v.method_23318() + 1, v.method_23321(), 12, 0.3, 0.5, 0.3, 0.3); }
            case EARTH -> { v.method_6005(1.4, a.method_23317() - v.method_23317(), a.method_23321() - v.method_23321()); v.method_6092(fx(class_1294.field_5909, 40, 1)); }
            case SHADOW -> { v.method_6092(fx(class_1294.field_38092, 80, 0)); v.method_6092(fx(class_1294.field_5920, 60, 1)); }
            case SMOKE -> v.method_6092(fx(class_1294.field_5919, 60, 0));
            case SPIRIT -> { a.method_6025(2f); v.method_6092(fx(class_1294.field_5912, 100, 0)); }
            case ICE -> { v.method_32317(200); v.method_6092(fx(class_1294.field_5909, 80, 4)); }
            case WATER -> { v.method_6092(fx(class_1294.field_5901, 80, 1)); v.method_5646(); }
            case AIR -> v.method_18799(v.method_18798().method_1031(0, 0.8, 0));
            case WIND -> v.method_6005(2.2, a.method_23317() - v.method_23317(), a.method_23321() - v.method_23321());
            case METAL -> v.method_6092(fx(class_1294.field_5911, 80, 1));
        }
    }

    private ElementPowers() {}
}
