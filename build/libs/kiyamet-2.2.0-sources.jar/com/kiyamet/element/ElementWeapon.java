package com.kiyamet.element;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_9280;
import net.minecraft.class_9334;

/**
 * An ancient elemental weapon. Left click: attack (every hit carries the element). Right click: switch the element's
 * power on, right click again: off. No cooldown. The power only works while the weapon is in your hand.
 */
public class ElementWeapon extends class_1792 {
    public final Element element;

    public ElementWeapon(class_1793 p, Element e) { super(p); this.element = e; }

    public static boolean active(class_1799 s) {
        class_9280 d = s.method_58694(class_9334.field_49637);
        return d != null && !d.comp_3355().isEmpty() && d.comp_3355().get(0);
    }

    public static void setActive(class_1799 s, boolean on) {
        s.method_57379(class_9334.field_49637, new class_9280(List.of(), List.of(on), List.of(), List.of()));
        s.method_57379(class_9334.field_49641, on);
    }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 s = player.method_5998(hand);
        if (player instanceof class_3222 sp) {
            boolean on = !active(s);
            setActive(s, on);
            if (on) ElementPowers.start(sp, element); else ElementPowers.stop(sp, element);
            sp.method_7353(class_2561.method_43470(element.title.toUpperCase() + (on ? " POWER: ON" : " POWER: OFF")).method_27695(element.fmt, class_124.field_1067), true);
        }
        return class_1269.field_5812;
    }

    @Override
    public void method_7888(class_1799 s, class_3218 level, class_1297 e, class_1304 slot) {
        if (!(e instanceof class_3222 p) || !active(s)) return;
        boolean held = p.method_6047() == s || p.method_6079() == s;
        if (!held) { setActive(s, false); ElementPowers.stop(p, element); return; }
        ElementPowers.tick(p, element, s);
    }

    @Override
    public void method_7873(class_1799 s, class_1309 target, class_1309 attacker) {
        super.method_7873(s, target, attacker);
        ElementPowers.onHit(element, target, attacker);
    }
}
