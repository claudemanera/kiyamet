package com.kiyamet.element;

import com.kiyamet.Kiyamet;
import com.kiyamet.npc.Shop;
import com.kiyamet.skill.SkillManager;
import com.kiyamet.ui.Ui;
import com.mojang.serialization.Codec;
import java.util.*;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_1347;
import net.minecraft.class_1352;
import net.minecraft.class_1361;
import net.minecraft.class_1366;
import net.minecraft.class_1376;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1538;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_1677;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.goal.*;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * A sage (2.1). Each has a name and tells their element's story. On your first visit the sage entrusts you with an
 * Ancient Rod - fight with it while you gather what they ask (items + walkers felled with that rod). Fulfil it and they
 * give you the temple's map. Sages cannot die: they can be hurt, never killed, and never turn. At very high levels
 * (total skill power 3000) a sage you helped will join you - and can carry their element's weapon.
 */
public class Sage extends class_1314 implements GeoEntity {
    static final RawAnimation IDLE = RawAnimation.begin().thenLoop("misc.idle"), WALK = RawAnimation.begin().thenLoop("move.walk"), ATTACK = RawAnimation.begin().thenPlay("attack.swing");
    public static final int ROD_KILLS = 20, COMPANION_POWER = 3000;
    /** walkers felled with each sage's rod, per player: "flame" -> 12 */
    public static final AttachmentType<Map<String, Integer>> KILLS = AttachmentRegistry.create(Kiyamet.id("rod_kills"),
            b -> b.initializer(Map::of).persistent(Codec.unboundedMap(Codec.STRING, Codec.INT)).copyOnDeath());
    public final Element element;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final List<String> helped = new ArrayList<>(), given = new ArrayList<>();
    private final Map<String, Integer> talks = new HashMap<>();
    UUID owner;
    boolean stay;
    int powerCd;

    public Sage(class_1299<? extends class_1314> t, class_1937 l, Element e) { super(t, l); this.element = e; method_5971(); }

    public static String[] wants(Element e) {
        return switch (e) {
            case FLAME -> new String[]{"minecraft:coal", "32", "minecraft:magma_block", "8", "minecraft:flint_and_steel", "1"};
            case LIGHTNING -> new String[]{"minecraft:copper_ingot", "32", "minecraft:lightning_rod", "4", "minecraft:glowstone_dust", "16"};
            case EARTH -> new String[]{"minecraft:mossy_cobblestone", "32", "minecraft:emerald", "4", "minecraft:oak_sapling", "8"};
            case SHADOW -> new String[]{"minecraft:obsidian", "8", "minecraft:ink_sac", "16", "minecraft:ender_pearl", "4"};
            case SMOKE -> new String[]{"minecraft:campfire", "4", "minecraft:charcoal", "32", "minecraft:gunpowder", "16"};
            case SPIRIT -> new String[]{"minecraft:rotten_flesh", "64", "minecraft:bone", "32", "minecraft:soul_sand", "16"};
            case ELECTRIC -> new String[]{"minecraft:redstone", "64", "minecraft:copper_ingot", "32", "kiyamet:circuit", "2"};
            case THUNDER -> new String[]{"minecraft:iron_ingot", "32", "minecraft:lightning_rod", "8", "minecraft:gold_ingot", "8"};
            case ICE -> new String[]{"minecraft:packed_ice", "32", "minecraft:snowball", "32", "minecraft:blue_ice", "4"};
            case FIRE -> new String[]{"minecraft:coal_block", "8", "minecraft:fire_charge", "8", "minecraft:netherrack", "32"};
            case WATER -> new String[]{"minecraft:prismarine_shard", "16", "minecraft:cod", "16", "minecraft:kelp", "32"};
            case AIR -> new String[]{"minecraft:feather", "32", "minecraft:phantom_membrane", "4", "minecraft:string", "32"};
            case WIND -> new String[]{"minecraft:feather", "32", "minecraft:white_wool", "16", "minecraft:wind_charge", "8"};
            case METAL -> new String[]{"minecraft:iron_block", "8", "minecraft:chain", "16", "minecraft:anvil", "1"};
        };
    }

    public static int kills(class_3222 p, Element e) { return p.getAttachedOrElse(KILLS, Map.of()).getOrDefault(e.id, 0); }
    public static void addKill(class_3222 p, Element e) {
        Map<String, Integer> m = new HashMap<>(p.getAttachedOrElse(KILLS, Map.of()));
        m.merge(e.id, 1, Integer::sum);
        p.setAttached(KILLS, Map.copyOf(m));
        int k = m.get(e.id);
        if (k <= ROD_KILLS) p.method_7353(class_2561.method_43470("Ancient Rod (" + e.title + "): " + k + " / " + ROD_KILLS + " walkers").method_27692(e.fmt), true);
    }

    /** the rod a sage entrusts to you, marked with their element */
    public static class_1799 rod(Element e) {
        class_1799 s = new class_1799(ElementItems.ROD);
        class_2487 t = new class_2487(); t.method_10582("Sage", e.id);
        s.method_57379(class_9334.field_49628, class_9279.method_57456(t));
        s.method_57379(class_9334.field_49631, class_2561.method_43470("Ancient Rod of " + SageLore.name(e)).method_27692(e.fmt).method_27694(st -> st.method_10978(false)));
        return s;
    }

    public static Element rodElement(class_1799 s) {
        if (!s.method_31574(ElementItems.ROD)) return null;
        return Element.of(s.method_58695(class_9334.field_49628, class_9279.field_49302).method_57461().method_68564("Sage", ""));
    }

    class_3222 ownerPlayer() { return owner == null || !(method_73183() instanceof class_3218 sl) ? null : sl.method_8503().method_3760().method_14602(owner); }
    public boolean isCompanion() { return owner != null; }
    public boolean isOwnedBy(class_1657 p) { return owner != null && owner.equals(p.method_5667()); }
    /** 2.2: a companion sage made guardian of its owner's Temple of Creation stands watch there */
    public void guardTemple(net.minecraft.class_2338 at) { stay = true; method_5942().method_6340(); method_5808(at.method_10263() + 0.5, at.method_10264(), at.method_10260() + 0.5, method_36454(), 0); }
    public void release() { stay = false; }

    @Override
    protected void method_5959() {
        field_6201.method_6277(0, new class_1347(this));
        field_6201.method_6277(2, new class_1366(this, 1.2, true) { @Override public boolean method_6264() { return isCompanion() && super.method_6264(); } });
        field_6201.method_6277(3, new class_1352() {                    // follow the owner
            { method_6265(EnumSet.of(Flag.field_18405)); }
            @Override public boolean method_6264() { class_3222 o = ownerPlayer(); return o != null && !stay && o.method_51469() == method_73183() && method_5858(o) > 36; }
            @Override public void method_6268() {
                class_3222 o = ownerPlayer(); if (o == null) return;
                method_5988().method_6226(o, 30, 30);
                if (method_5858(o) > 24 * 24 && o.method_24828()) { method_5808(o.method_23317(), o.method_23318(), o.method_23321(), method_36454(), 0); method_5942().method_6340(); }
                else method_5942().method_6335(o, 1.25);
            }
        });
        field_6201.method_6277(7, new class_1361(this, class_1657.class, 10f));
        field_6201.method_6277(8, new class_1376(this));
        field_6185.method_6277(1, new class_1399(this) { @Override public boolean method_6264() { return isCompanion() && super.method_6264() && !(method_6065() instanceof class_1657); } });
        field_6185.method_6277(2, new class_1400<>(this, class_1308.class, 5, true, false, (e, l) -> isCompanion() && e instanceof class_1569));
    }

    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        if (!(player instanceof class_3222 p) || hand != class_1268.field_5808 || element == null) return class_1269.field_5812;
        class_3218 l = (class_3218) method_73183();
        String who = p.method_5667().toString();
        int talk = talks.merge(who, 1, Integer::sum);
        // --- my companion
        if (p.method_5667().equals(owner)) {
            class_1799 held = p.method_6047();
            if (p.method_5715()) {
                if (held.method_7909() instanceof ElementWeapon && method_6047().method_7960()) {
                    method_5673(class_1304.field_6173, held.method_7971(1)); method_5946(class_1304.field_6173, 0f);
                    say(p, "Ahh. " + ((ElementWeapon) method_6047().method_7909()).element.weaponTitle + ". I know this one. Let them come.");
                } else if (!method_6047().method_7960()) {
                    class_1799 w = method_6047().method_7972(); method_5673(class_1304.field_6173, class_1799.field_8037);
                    if (!p.method_31548().method_7394(w)) p.method_7328(w, false);
                    say(p, "Take it back, then. My staff will do.");
                } else say(p, "Give me an element weapon (sneak + right-click) and I will fight with it.");
                return class_1269.field_5812;
            }
            stay = !stay; method_5942().method_6340();
            say(p, stay ? "I'll wait here." : "Lead the way.");
            return class_1269.field_5812;
        }
        // --- first meeting: name, greeting, the rod
        if (!given.contains(who)) {
            given.add(who);
            com.kiyamet.skill.SkillManager.addXp(p, com.kiyamet.skill.Skill.EXPLORATION, 600);
            say(p, "I am " + SageLore.name(element) + ". " + SageLore.greeting(element));
            say(p, "Take this Ancient Rod. Carry it, fight with it. Fell " + ROD_KILLS + " walkers with it, and bring me what I ask - then I will show you the way to the " + element.title + " Temple.");
            class_1799 r = rod(element);
            if (!p.method_31548().method_7394(r)) p.method_7328(r, false);
            l.method_8396(null, method_24515(), class_3417.field_15119, class_3419.field_15254, 1f, 0.8f);
            needs(p);
            return class_1269.field_5812;
        }
        String[] lore = SageLore.story(element);
        // --- helped already: stories, and at high levels - an offer
        if (helped.contains(who)) {
            if (owner == null && SkillManager.get(p).totalPower() >= COMPANION_POWER) {
                owner = p.method_5667(); stay = false;
                say(p, SageLore.companion(element));
                p.method_64398(class_2561.method_43470("★ " + SageLore.name(element) + " joined you! Right-click: follow / wait · sneak + right-click: give or take an element weapon.").method_27695(element.fmt, class_124.field_1067));
                l.method_65096(new class_2390(element.color, 2f), method_23317(), method_23318() + 1.5, method_23321(), 60, 0.6, 1, 0.6, 0.05);
                return class_1269.field_5812;
            }
            say(p, lore[talk % lore.length]);
            if (owner == null && talk % 3 == 0) say(p, "When you are much stronger (total skill power " + COMPANION_POWER + "), come back. I could walk with you. You have " + SkillManager.get(p).totalPower() + ".");
            if (talk % 4 == 0) give(p);
            return class_1269.field_5812;
        }
        // --- the quest
        String[] w = wants(element);
        boolean all = kills(p, element) >= ROD_KILLS;
        for (int i = 0; i < w.length; i += 2) if (Shop.count(p, w[i]) < Integer.parseInt(w[i + 1])) all = false;
        if (!all && !p.method_68878()) {
            say(p, lore[(talk - 1) % lore.length]);
            needs(p);
            return class_1269.field_5812;
        }
        if (!p.method_68878()) for (int i = 0; i < w.length; i += 2) Shop.take(p, w[i], Integer.parseInt(w[i + 1]));
        helped.add(who);
        com.kiyamet.skill.SkillManager.addXp(p, com.kiyamet.skill.Skill.EXPLORATION, 2000);
        l.method_8396(null, method_24515(), class_3417.field_14709, class_3419.field_15254, 1f, 0.8f);
        l.method_65096(new class_2390(element.color, 1.8f), method_23317(), method_23318() + 1.6, method_23321(), 50, 0.6, 0.8, 0.6, 0.05);
        say(p, "You kept your word. Here is the true map of the " + element.title + " Temple. Keep the rod - at the bottom of the temple lies the core. Join them on an anvil.");
        give(p);
        return class_1269.field_5812;
    }

    void needs(class_3222 p) {
        String[] w = wants(element);
        StringBuilder b = new StringBuilder("I need: ");
        for (int i = 0; i < w.length; i += 2)
            b.append(w[i + 1]).append("× ").append(new class_1799(Ui.item(w[i])).method_7964().getString()).append(" (").append(Math.min(Shop.count(p, w[i]), Integer.parseInt(w[i + 1]))).append("), ");
        b.append("and ").append(ROD_KILLS).append(" walkers felled with my rod (").append(Math.min(kills(p, element), ROD_KILLS)).append(").");
        say(p, b.toString());
    }

    void give(class_3222 p) {
        class_1799 map = Temples.templeMap(p.method_51469(), element);
        if (!p.method_31548().method_7394(map)) p.method_7328(map, false);
    }

    void say(class_3222 p, String text) {
        p.method_64398(class_2561.method_43470("[" + SageLore.name(element) + "] ").method_27695(element.fmt, class_124.field_1067).method_10852(class_2561.method_43470(text).method_27692(class_124.field_1068)));
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (!(method_73183() instanceof class_3218 sl) || element == null) return;
        if (!isCompanion() || stay) method_18800(0, method_18798().field_1351, 0);
        if (field_6012 % 100 == 1 && (method_5797() == null || !method_5797().getString().equals(SageLore.name(element)))) {
            method_5665(class_2561.method_43470(SageLore.name(element)).method_27692(element.fmt)); method_5880(true);
        }
        if (field_6012 % 20 == 0 && method_6032() < method_6063()) method_6025(isCompanion() ? 2 : 4);
        if (field_6012 % 8 == 0) sl.method_65096(new class_2390(element.color, 0.9f), method_23317(), method_23318() + 2.1, method_23321(), 2, 0.25, 0.1, 0.25, 0);
        if (field_6012 % 40 == 0) sl.method_65096(class_2398.field_11215, method_23317(), method_23318() + 1.5, method_23321(), 12, 0.6, 0.6, 0.6, 0.5);
        // a companion sage uses their element at range
        class_1309 t = method_5968();
        if (isCompanion() && t != null && t.method_5805() && --powerCd <= 0 && method_5739(t) < 20 && method_6057(t)) {
            powerCd = 50;
            Element use = method_6047().method_7909() instanceof ElementWeapon w ? w.element : element;
            float dmg = method_6047().method_7909() instanceof ElementWeapon ? 10f : 5f;
            switch (use) {
                case FLAME, FIRE -> { class_243 d = t.method_73189().method_1031(0, t.method_17682() / 2, 0).method_1020(method_33571()).method_1029();
                    class_1677 f = new class_1677(sl, this, d); f.method_5814(method_23317() + d.field_1352, method_23320() + d.field_1351, method_23321() + d.field_1350); sl.method_8649(f); }
                case LIGHTNING, ELECTRIC, THUNDER -> { class_1538 b = class_1299.field_6112.method_5883(sl, class_3730.field_16461);
                    if (b != null) { b.method_5808(t.method_23317(), t.method_23318(), t.method_23321(), 0, 0); b.method_29498(true); sl.method_8649(b); } t.method_64397(sl, method_48923().method_48812(this), dmg); }
                default -> { t.method_64397(sl, method_48923().method_48815(this, this), dmg);
                    sl.method_65096(new class_2390(use.color, 1.6f), t.method_23317(), t.method_23318() + 1, t.method_23321(), 30, 0.4, 0.6, 0.4, 0.05); }
            }
            ElementPowers.onHit(use, t, this);
            triggerAnim("main", "attack");
            sl.method_8396(null, method_24515(), class_3417.field_14858, class_3419.field_15254, 0.8f, 1.2f);
        }
    }

    @Override
    public boolean method_6121(class_3218 level, class_1297 target) {
        boolean hit = super.method_6121(level, target);
        if (hit && target instanceof class_1309 le) {
            ElementPowers.onHit(method_6047().method_7909() instanceof ElementWeapon w ? w.element : element, le, this);
            triggerAnim("main", "attack");
        }
        return hit;
    }

    /** sages can be hurt, never killed */
    @Override
    public boolean method_64397(class_3218 l, class_1282 src, float amount) {
        if (src.method_5529() instanceof class_1657 p && p.method_5667().equals(owner)) return false;
        float cap = Math.max(0, method_6032() - 1f);
        if (amount >= cap) {
            method_6033(1f);
            l.method_65096(new class_2390(element == null ? 0xFFFFFF : element.color, 1.5f), method_23317(), method_23318() + 1, method_23321(), 20, 0.4, 0.6, 0.4, 0.02);
            return super.method_64397(l, src, 0.001f);
        }
        return super.method_64397(l, src, amount);
    }
    @Override public void method_6078(class_1282 src) { method_6033(1f); }
    @Override public boolean method_5810() { return isCompanion(); }
    @Override public boolean method_5974(double d) { return false; }

    @Override
    protected void method_5652(class_11372 out) {
        super.method_5652(out);
        out.method_71469("Helped", String.join(",", helped));
        out.method_71469("Given", String.join(",", given));
        if (owner != null) out.method_71469("Owner", owner.toString());
        out.method_71472("Stay", stay);
    }
    @Override
    protected void method_5749(class_11368 in) {
        super.method_5749(in);
        helped.clear(); given.clear();
        for (String s : in.method_71428("Helped", "").split(",")) if (!s.isEmpty()) helped.add(s);
        for (String s : in.method_71428("Given", "").split(",")) if (!s.isEmpty()) given.add(s);
        given.addAll(helped);
        String o = in.method_71428("Owner", "");
        owner = o.isEmpty() ? null : UUID.fromString(o);
        stay = in.method_71433("Stay", false);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar c) {
        c.add(new AnimationController<Sage>("main", 4, t -> t.setAndContinue(t.isMoving() ? WALK : IDLE)).triggerableAnim("attack", ATTACK));
    }
    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
