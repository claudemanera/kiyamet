package com.kiyamet.element;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/** A torn map piece from a city. Unfold it: it shows where one of the sages lives. */
public class SageMapItem extends class_1792 {
    public SageMapItem(class_1793 p) { super(p); }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        if (!(player instanceof class_3222 p)) return class_1269.field_5812;
        List<String> got = Temples.mapped(p);
        List<Element> left = new ArrayList<>();
        for (Element e : Element.values()) if (!got.contains(e.id)) left.add(e);
        if (left.isEmpty()) left.addAll(List.of(Element.values()));
        Element e = left.get(p.method_59922().method_43048(left.size()));
        Temples.markMapped(p, e);
        class_1799 map = Temples.sageMap(p.method_51469(), e);
        player.method_5998(hand).method_7934(1);
        if (!p.method_31548().method_7394(map)) p.method_7328(map, false);
        level.method_8396(null, p.method_24515(), class_3417.field_17481, class_3419.field_15248, 1f, 0.8f);
        p.method_64398(class_2561.method_43470("The torn map shows the way to the " + e.title + " Sage.").method_27695(e.fmt, class_124.field_1067));
        return class_1269.field_5812;
    }
}
