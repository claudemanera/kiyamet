package com.kiyamet.element;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1366;
import net.minecraft.class_1376;
import net.minecraft.class_1379;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2390;
import net.minecraft.class_3218;
import net.minecraft.world.entity.ai.goal.*;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/** Armoured temple guardian: carries its element in every blow, never leaves its temple. */
public class TempleGuardian extends class_1588 implements GeoEntity {
    static final RawAnimation IDLE = RawAnimation.begin().thenLoop("misc.idle"), WALK = RawAnimation.begin().thenLoop("move.walk"), ATTACK = RawAnimation.begin().thenPlay("attack.swing");
    public final Element element;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public TempleGuardian(class_1299<? extends class_1588> t, class_1937 l, Element e) { super(t, l); this.element = e; field_6194 = 40; method_5971(); }

    @Override
    protected void method_5959() {
        field_6201.method_6277(0, new class_1347(this));
        field_6201.method_6277(2, new class_1366(this, 1.15, true));
        field_6201.method_6277(6, new class_1379(this, 0.6, 120));
        field_6201.method_6277(7, new class_1361(this, class_1657.class, 16f));
        field_6201.method_6277(8, new class_1376(this));
        field_6185.method_6277(1, new class_1399(this));
        field_6185.method_6277(2, new class_1400<>(this, class_1657.class, true));
        field_6185.method_6277(3, new class_1400<>(this, com.kiyamet.npc.HumanEntity.class, true));
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (method_73183() instanceof class_3218 sl && element != null && field_6012 % 10 == 0)
            sl.method_65096(new class_2390(element.color, 1.0f), method_23317(), method_23318() + 1.2, method_23321(), 2, 0.3, 0.6, 0.3, 0);
    }

    @Override
    public boolean method_6121(class_3218 level, class_1297 target) {
        boolean hit = super.method_6121(level, target);
        if (hit && target instanceof class_1309 le && element != null) { ElementPowers.onHit(element, le, this); triggerAnim("main", "attack"); }
        return hit;
    }

    @Override public boolean method_5974(double d) { return false; }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar c) {
        c.add(new AnimationController<TempleGuardian>("main", 4, t -> t.setAndContinue(t.isMoving() ? WALK : IDLE)).triggerableAnim("attack", ATTACK));
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
