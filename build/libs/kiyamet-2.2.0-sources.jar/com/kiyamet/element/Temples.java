package com.kiyamet.element;

import com.kiyamet.Kiyamet;
import com.kiyamet.boss.BossEntity;
import com.kiyamet.boss.BossKind;
import com.kiyamet.boss.ModBosses;
import com.mojang.serialization.Codec;
import java.util.*;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1806;
import net.minecraft.class_21;
import net.minecraft.class_2170;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

/**
 * One temple per element, somewhere within 50,000 blocks; one sage per element, closer in.
 * Both are built the first time a player comes near. The world remembers what it already built.
 */
public final class Temples {
    public static final AttachmentType<List<String>> BUILT = AttachmentRegistry.create(Kiyamet.id("temples_built"), b -> b.initializer(List::of).persistent(Codec.STRING.listOf()));
    public static final AttachmentType<List<String>> MAPPED = AttachmentRegistry.create(Kiyamet.id("sage_maps"), b -> b.initializer(List::of).persistent(Codec.STRING.listOf()).copyOnDeath());
    static final List<Job> JOBS = new ArrayList<>();

    static long seed(class_3218 l) { return l.method_8412(); }

    public static class_2338 templePos(class_3218 l, Element e) {
        Random r = new Random(seed(l) * 31 + e.ordinal() * 7919L);
        double a = Math.toRadians(e.ordinal() * (360.0 / 14) + r.nextDouble() * 18);
        int d = 4000 + ((e.ordinal() * 5 + 3) % 14) * 2900 + r.nextInt(1200);     // 4k .. ~43k
        return new class_2338((int) (Math.cos(a) * d), 0, (int) (Math.sin(a) * d));
    }

    public static class_2338 sagePos(class_3218 l, Element e) {
        Random r = new Random(seed(l) * 17 + e.ordinal() * 104729L);
        double a = Math.toRadians(e.ordinal() * (360.0 / 14) + 40 + r.nextDouble() * 30);
        int d = 900 + ((e.ordinal() * 3) % 14) * 450 + r.nextInt(400);           // 0.9k .. 7.5k
        return new class_2338((int) (Math.cos(a) * d), 0, (int) (Math.sin(a) * d));
    }

    public static List<String> mapped(class_3222 p) { return p.getAttachedOrElse(MAPPED, List.of()); }
    public static void markMapped(class_3222 p, Element e) {
        List<String> m = new ArrayList<>(mapped(p));
        if (!m.contains(e.id)) m.add(e.id);
        p.setAttached(MAPPED, List.copyOf(m));
    }

    static class_1799 map(class_3218 l, class_2338 at, String title, class_124 color, net.minecraft.class_6880<net.minecraft.class_9428> mark, byte scale) {
        class_1799 s = class_1806.method_8005(l, at.method_10263(), at.method_10260(), scale, true, true);
        class_1806.method_8002(l, s);
        net.minecraft.class_22.method_110(s, at, "+", mark);
        s.method_57379(class_9334.field_50239, class_2561.method_43470(title).method_27695(color, class_124.field_1067));
        s.method_57379(class_9334.field_49632, new class_9290(List.of(class_2561.method_43470("X: " + at.method_10263() + "   Z: " + at.method_10260()).method_27692(class_124.field_1080))));
        return s;
    }

    public static class_1799 sageMap(class_3218 l, Element e) { return map(l, sagePos(l, e), "Map to the " + e.title + " Sage", e.fmt, class_21.field_84, (byte) 1); }
    public static class_1799 templeMap(class_3218 l, Element e) { return map(l, templePos(l, e), "Map of the " + e.title + " Temple", e.fmt, class_21.field_110, (byte) 2); }

    static boolean built(class_3218 l, String key) { return l.getAttachedOrElse(BUILT, List.of()).contains(key); }
    static void markBuilt(class_3218 l, String key) { List<String> b = new ArrayList<>(l.getAttachedOrElse(BUILT, List.of())); b.add(key); l.setAttached(BUILT, List.copyOf(b)); }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            class_3218 ow = server.method_30002();
            // run queued building work (spread over ticks)
            if (!JOBS.isEmpty()) {
                Job j = JOBS.get(0);
                if (j.step(ow, 30000)) JOBS.remove(0);
            }
            if (server.method_3780() % 40 != 0) return;
            for (class_3222 p : server.method_3760().method_14571()) {
                if (p.method_51469() != ow) continue;
                for (Element e : Element.values()) {
                    class_2338 sp = sagePos(ow, e), tp = templePos(ow, e);
                    if (!built(ow, "sage:" + e.id) && horiz(p.method_24515(), sp) < 72 * 72) { markBuilt(ow, "sage:" + e.id); buildCamp(ow, e, sp); }
                    if (!built(ow, "temple:" + e.id) && horiz(p.method_24515(), tp) < 140 * 140) { markBuilt(ow, "temple:" + e.id); JOBS.add(new TempleBuilder(ow, e, tp).job()); }
                    if (built(ow, "temple:" + e.id) && horiz(p.method_24515(), tp) < 30 * 30 && !p.method_5752().contains("temple_" + e.id)) {
                        p.method_5780("temple_" + e.id);
                        com.kiyamet.skill.SkillManager.addXp(p, com.kiyamet.skill.Skill.EXPLORATION, 2500);
                        p.field_13987.method_14364(new class_5904(class_2561.method_43470("TEMPLE OF " + e.title.toUpperCase()).method_27695(e.fmt, class_124.field_1067)));
                        p.field_13987.method_14364(new class_5903(class_2561.method_43470("Its lord waits at the very bottom").method_27692(class_124.field_1080)));
                        ow.method_8396(null, p.method_24515(), class_3417.field_15203, class_3419.field_15251, 0.6f, 0.7f);
                    }
                }
            }
        });
        // creative helpers: /twd temple <element> (teleport), /twd sage <element>
        CommandRegistrationCallback.EVENT.register((d, ctx, env) -> {
            var temple = class_2170.method_9247("temple");
            var sage = class_2170.method_9247("sage");
            var build = class_2170.method_9247("buildtemple");
            for (Element e : Element.values()) {
                temple.then(class_2170.method_9247(e.id).executes(c -> tp(c.getSource().method_9207(), templePos(c.getSource().method_9225(), e), 30)));
                sage.then(class_2170.method_9247(e.id).executes(c -> tp(c.getSource().method_9207(), sagePos(c.getSource().method_9225(), e), 6)));
                build.then(class_2170.method_9247(e.id).executes(c -> {        // testing: build this temple right here (console or creative)
                    if (c.getSource().method_44023() != null && !c.getSource().method_44023().method_68878()) return 0;
                    JOBS.add(new TempleBuilder(c.getSource().method_9225(), e, class_2338.method_49638(c.getSource().method_9222())).job());
                    c.getSource().method_9226(() -> class_2561.method_43470("Building the " + e.title + " Temple..."), true);
                    return 1;
                }));
            }
            d.register(class_2170.method_9247("twd").then(temple).then(sage).then(build));
        });
    }

    static int tp(class_3222 p, class_2338 at, int back) {
        if (!p.method_68878()) { p.method_64398(class_2561.method_43470("Creative mode only - follow the maps!").method_27692(class_124.field_1061)); return 0; }
        class_3218 l = p.method_51469();
        l.method_8497(at.method_10263() >> 4, (at.method_10260() + back) >> 4);
        int y = l.method_8624(class_2902.class_2903.field_13203, at.method_10263(), at.method_10260() + back);
        p.method_48105(l, at.method_10263() + 0.5, y + 1, at.method_10260() + back + 0.5, java.util.Set.of(), 180, 0, true);
        return 1;
    }

    static long horiz(class_2338 a, class_2338 b) { long dx = a.method_10263() - b.method_10263(), dz = a.method_10260() - b.method_10260(); return dx * dx + dz * dz; }

    /** the sage's little camp: a tent in the element's colour, a campfire, a lantern */
    static void buildCamp(class_3218 l, Element e, class_2338 at) {
        l.method_8497(at.method_10263() >> 4, at.method_10260() >> 4);
        int y = l.method_8624(class_2902.class_2903.field_13203, at.method_10263(), at.method_10260());
        class_2338 o = new class_2338(at.method_10263(), y, at.method_10260());
        class_2680 wool = TempleBuilder.wool(e);
        for (int x = -5; x <= 5; x++) for (int z = -5; z <= 5; z++) {
            for (int h = 0; h < 6; h++) l.method_8652(o.method_10069(x, h, z), class_2246.field_10124.method_9564(), 2);
            l.method_8652(o.method_10069(x, -1, z), (Math.abs(x) + Math.abs(z)) % 5 == 0 ? class_2246.field_10253.method_9564() : class_2246.field_10520.method_9564(), 2);
        }
        for (int z = -3; z <= 0; z++) for (int x = -3; x <= 3; x++) {
            int h = 3 - Math.abs(x);
            if (h >= 0) l.method_8652(o.method_10069(x, h, z), wool, 2);
            if (z == -3 && h >= 0) for (int k = 0; k < h; k++) l.method_8652(o.method_10069(x, k, z), wool, 2);
        }
        for (int k = 0; k < 4; k++) { l.method_8652(o.method_10069(-4, k, 1), class_2246.field_10620.method_9564(), 2); l.method_8652(o.method_10069(4, k, 1), class_2246.field_10620.method_9564(), 2); }
        l.method_8652(o.method_10069(-4, 4, 1), class_2246.field_16541.method_9564(), 3);
        l.method_8652(o.method_10069(4, 4, 1), class_2246.field_16541.method_9564(), 3);
        l.method_8652(o.method_10069(0, 0, 3), class_2246.field_17350.method_9564(), 3);
        l.method_8652(o.method_10069(2, 0, -2), class_2246.field_16328.method_9564(), 3);
        l.method_8652(o.method_10069(-2, 0, -2), class_2246.field_16330.method_9564(), 3);
        for (int x : new int[]{-2, 2}) l.method_8652(o.method_10069(x, 0, 4), class_2246.field_10431.method_9564(), 3);
        Sage s = ElementMobs.SAGES.get(e).method_5883(l, class_3730.field_16474);
        if (s != null) {
            s.method_5808(o.method_10263() + 0.5, o.method_10264(), o.method_10260() + 1.5, 180, 0);
            s.method_5665(class_2561.method_43470(e.title + " Sage").method_27692(e.fmt));
            s.method_5880(true);
            l.method_8649(s);
        }
    }

    /** a long job done a slice per tick */
    public interface Job { boolean step(class_3218 l, int budget); }

    private Temples() {}
}
