package com.kiyamet.enchant;

import com.kiyamet.registry.ModItems;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

/** Enchanted weapons found out in the world: raider drops, bosses, car trunks, story rewards. Stronger with your power. */
public final class EnchantLoot {
    private static final String[] NAMES = {"Old Faithful", "Widowmaker", "Lucille's Cousin", "Last Word", "Walker Bane", "The Persuader", "Grave Digger",
            "Mercy", "Bad News", "Sunday Best", "Rusty", "Peacemaker", "Silent Night", "Home Run", "No Return"};

    public static class_1799 weapon(class_3218 level, int power) {
        class_5819 r = level.field_9229;
        class_1792[] base = power >= 2000 ? new class_1792[]{class_1802.field_8802, class_1802.field_8556, class_1802.field_22022, class_1802.field_8102, class_1802.field_8399, class_1802.field_8547}
                : new class_1792[]{class_1802.field_8371, class_1802.field_8475, class_1802.field_8802, class_1802.field_8102, class_1802.field_8399, class_1802.field_8528};
        class_1799 s;
        if (r.method_43057() < 0.3f) s = new class_1799(ModItems.get(ModItems.WEAPONS[r.method_43048(Math.min(ModItems.WEAPONS.length, 6 + power / 400))]));
        else s = new class_1799(base[r.method_43048(base.length)]);
        List<class_6880<class_1887>> ok = new ArrayList<>();
        level.method_30349().method_30530(class_7924.field_41265).method_42017().forEach(h -> { if (h.comp_349().method_8192(s)) ok.add(h); });
        int n = 1 + r.method_43048(2 + Math.min(2, power / 1500));
        for (int i = 0; i < n && !ok.isEmpty(); i++) {
            class_6880<class_1887> h = ok.get(r.method_43048(ok.size()));
            if (!class_1890.method_8201(s.method_58657().method_57534(), h)) continue;
            int max = Math.min(Enchants.maxCap(Enchants.id(h)), h.comp_349().method_8183() + power / 1500);
            s.method_7978(h, 1 + r.method_43048(Math.max(1, max)));
        }
        if (r.method_43057() < 0.35f) s.method_57379(net.minecraft.class_9334.field_49631,
                class_2561.method_43470(NAMES[r.method_43048(NAMES.length)]).method_27694(st -> st.method_10978(false).method_10977(net.minecraft.class_124.field_1065)));
        return s;
    }

    private EnchantLoot() {}
}
