package com.kiyamet.enchant;

import com.kiyamet.npc.Shop;
import com.kiyamet.skill.Skill;
import com.kiyamet.skill.SkillData;
import com.kiyamet.skill.SkillManager;
import com.kiyamet.ui.PanelMenu;
import com.kiyamet.ui.Ui;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_6880;
import net.minecraft.class_747;
import net.minecraft.class_7924;
import net.minecraft.class_9304;

/**
 * Enchantment Forge: hold an item, sneak + right-click an enchanting table. Add or raise any enchantment the item can take,
 * up to the level your Enchanting skill has unlocked (gun enchantments: Firearms, and a blue tome to learn each one).
 * Costs XP levels and lapis.
 */
public class ForgeMenu extends PanelMenu {
    private final List<class_6880<class_1887>> shown = new ArrayList<>();

    public static void open(class_3222 p) {
        p.method_17355(new class_747((id, inv, pl) -> new ForgeMenu(id, inv, p), class_2561.method_43470("Enchantment Forge")));
    }

    private ForgeMenu(int id, class_1661 inv, class_3222 p) { super(id, inv, p); redraw(); }

    record Offer(class_6880<class_1887> h, String id, int cur, int next, int cap, int max, int xp, int lapis, String block) {}

    Offer offer(class_6880<class_1887> h, class_1799 stack, SkillData d) {
        String id = Enchants.id(h);
        class_9304 en = stack.method_58657();
        int cur = en.method_57536(h), max = Enchants.maxCap(id), next = cur + 1;
        int cap = Enchants.cap(id, d.level(Skill.ENCHANTING), d.level(Skill.ARCHERY));
        int vmax = h.comp_349().method_8183();
        int xp = 3 + 2 * next + (next > vmax ? 4 * (next - vmax) : 0);
        int lapis = Math.min(64, next * 2);
        String block = null;
        if (cur >= max) block = "MAX";
        else if (next > cap) {
            int at = Enchants.nextUnlock(id, cur);
            block = Enchants.isGun(id) ? (at > 0 ? "Unlocks at Firearms " + at : "Locked") : (at > 0 ? "Unlocks at Enchanting " + at : "Locked");
        } else if (cur == 0 && !class_1890.method_8201(en.method_57534(), h)) block = "Conflicts with an enchantment on this item";
        else if (cur == 0 && Enchants.isGun(id) && !hasTome(id)) block = "Needs a blue Gunsmith Tome: " + Enchants.gunTitle(id);
        return new Offer(h, id, cur, next, cap, max, xp, lapis, block);
    }

    boolean hasTome(String id) {
        for (int i = 0; i < player.method_31548().method_5439(); i++) {
            class_1799 s = player.method_31548().method_5438(i);
            if (s.method_31574(ModEnchant.GUN_TOME) && GunTomeItem.ench(s).equals(id)) return true;
        }
        return false;
    }

    boolean takeTome(String id) {
        for (int i = 0; i < player.method_31548().method_5439(); i++) {
            class_1799 s = player.method_31548().method_5438(i);
            if (s.method_31574(ModEnchant.GUN_TOME) && GunTomeItem.ench(s).equals(id)) { s.method_7934(1); return true; }
        }
        return false;
    }

    @Override
    protected void draw() {
        class_1799 stack = player.method_6047();
        SkillData d = SkillManager.get(player);
        shown.clear();
        c.method_5447(4, stack.method_7960() ? Ui.icon(class_1802.field_8077, Ui.text("Hold the item you want to enchant", class_124.field_1061)) : stack.method_7972());
        c.method_5447(0, Ui.icon(class_1802.field_8287, Ui.text("Your XP levels: " + player.field_7520, class_124.field_1060),
                Ui.text("Lapis: " + Shop.count(player, "minecraft:lapis_lazuli"), class_124.field_1078),
                Ui.text("Enchanting " + d.level(Skill.ENCHANTING) + " · Firearms " + d.level(Skill.ARCHERY), class_124.field_1080)));
        c.method_5447(8, Ui.icon(class_1802.field_8529, Ui.text("How it works", class_124.field_1065),
                Ui.text("Each click raises one enchantment by one level.", class_124.field_1080),
                Ui.text("Higher levels unlock along the Enchanting road.", class_124.field_1080),
                Ui.text("Gun enchantments: Firearms road + blue tomes.", class_124.field_1075)));
        if (stack.method_7960()) return;
        List<class_6880<class_1887>> all = new ArrayList<>();
        player.method_51469().method_30349().method_30530(class_7924.field_41265).method_42017().forEach(h -> { if (h.comp_349().method_8192(stack) || stack.method_58657().method_57536(h) > 0) all.add(h); });
        all.sort(Comparator.comparing((class_6880<class_1887> h) -> stack.method_58657().method_57536(h) > 0 ? 0 : 1).thenComparing(Enchants::id));
        int slot = 9;
        for (class_6880<class_1887> h : all) {
            if (slot >= 45) break;
            Offer o = offer(h, stack, d);
            boolean gun = Enchants.isGun(o.id);
            boolean ok = o.block == null && player.field_7520 >= o.xp && Shop.count(player, "minecraft:lapis_lazuli") >= o.lapis;
            String name = Enchants.title(o.id);
            class_1799 icon = gun ? GunTomeItem.of(o.id) : new class_1799(o.cur > 0 ? class_1802.field_8598 : class_1802.field_8529);
            List<class_2561> lore = new ArrayList<>();
            lore.add(Ui.text(o.cur > 0 ? "Now: " + name + " " + Enchants.roman(o.cur) : "Not on this item", class_124.field_1080));
            if (o.block == null) {
                lore.add(Ui.text("Cost: " + o.xp + " XP levels + " + o.lapis + " lapis" + (o.cur == 0 && gun ? " + the tome" : ""), ok ? class_124.field_1060 : class_124.field_1061));
                lore.add(Ui.text(ok ? "Click to enchant!" : "Not enough XP or lapis", ok ? class_124.field_1054 : class_124.field_1061));
            } else lore.add(Ui.text(o.block, o.block.equals("MAX") ? class_124.field_1076 : class_124.field_1061));
            lore.add(Ui.text("Unlocked up to " + Enchants.roman(Math.max(1, o.cap)) + " · max " + Enchants.roman(o.max), class_124.field_1062));
            String title = o.cur >= o.max ? name + " " + Enchants.roman(o.cur) + " (MAX)" : name + " " + (o.cur > 0 ? Enchants.roman(o.cur) + " → " : "") + Enchants.roman(o.next);
            icon.method_57379(net.minecraft.class_9334.field_49631, Ui.text(title, gun ? class_124.field_1075 : ok ? class_124.field_1060 : class_124.field_1068, class_124.field_1067));
            Ui.lore(icon, lore);
            c.method_5447(slot, Ui.glint(icon, ok));
            shown.add(h);
            slot++;
        }
        c.method_5447(49, Ui.icon(class_1802.field_8077, Ui.text("Close", class_124.field_1061)));
    }

    @Override
    protected boolean click(int slot, class_1713 type) {
        if (slot == 49) { player.method_7346(); return false; }
        int i = slot - 9;
        if (i < 0 || i >= shown.size()) return false;
        class_1799 stack = player.method_6047();
        if (stack.method_7960()) return false;
        Offer o = offer(shown.get(i), stack, SkillManager.get(player));
        if (o.block != null) { player.method_7353(class_2561.method_43470(o.block).method_27692(class_124.field_1061), true); return false; }
        if (player.field_7520 < o.xp && !player.method_68878()) { player.method_7353(class_2561.method_43470("You need " + o.xp + " XP levels.").method_27692(class_124.field_1061), true); return false; }
        if (!player.method_68878() && !Shop.take(player, "minecraft:lapis_lazuli", o.lapis)) { player.method_7353(class_2561.method_43470("You need " + o.lapis + " lapis.").method_27692(class_124.field_1061), true); return false; }
        if (o.cur == 0 && Enchants.isGun(o.id) && !player.method_68878() && !takeTome(o.id)) return false;
        if (!player.method_68878()) player.method_7316(-o.xp);
        stack.method_7978(o.h, o.next);
        SkillManager.addXp(player, Skill.ENCHANTING, 25 * o.next);
        player.method_51469().method_8396(null, player.method_24515(), class_3417.field_15119, class_3419.field_15248, 1f, 1f);
        player.method_7353(class_2561.method_43470(Enchants.title(o.id) + " " + Enchants.roman(o.next) + "!").method_27695(class_124.field_1076, class_124.field_1067), true);
        return true;
    }
}
