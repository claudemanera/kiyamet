package com.kiyamet.enchant;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_5819;
import net.minecraft.class_9279;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

/** Blue gunsmith tomes: each teaches one gun enchantment. Used at the Enchantment Forge (sneak + right-click an enchanting table). */
public class GunTomeItem extends class_1792 {
    public GunTomeItem(class_1793 p) { super(p); }

    public static class_1799 of(String id) {
        class_1799 s = new class_1799(ModEnchant.GUN_TOME);
        class_2487 t = new class_2487();
        t.method_10582("Ench", id);
        s.method_57379(class_9334.field_49628, class_9279.method_57456(t));
        s.method_57379(class_9334.field_49631, class_2561.method_43470("Gunsmith Tome: " + Enchants.gunTitle(id)).method_27694(st -> st.method_10978(false).method_10977(class_124.field_1075)));
        String what = "";
        for (String[] g : Enchants.GUN) if (("kiyamet:" + g[0]).equals(id)) what = g[3] + " (max " + Enchants.roman(Integer.parseInt(g[2])) + ")";
        s.method_57379(class_9334.field_49632, new class_9290(List.of(
                class_2561.method_43470(what).method_27694(st -> st.method_10978(false).method_10977(class_124.field_1080)),
                class_2561.method_43470("Guns only · needs Firearms 100+").method_27694(st -> st.method_10978(false).method_10977(class_124.field_1062)),
                class_2561.method_43470("Hold your gun, sneak + right-click an enchanting table").method_27694(st -> st.method_10978(false).method_10977(class_124.field_1063)))));
        s.method_57379(class_9334.field_49641, true);
        return s;
    }

    public static class_1799 random(class_5819 r) { return of("kiyamet:" + Enchants.GUN[r.method_43048(Enchants.GUN.length)][0]); }

    public static String ench(class_1799 s) {
        return s.method_58695(class_9334.field_49628, class_9279.field_49302).method_57461().method_68564("Ench", "");
    }
}
