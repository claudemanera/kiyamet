package com.kiyamet.enchant;

import com.kiyamet.registry.ModItems;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_3222;

public final class ModEnchant {
    public static final class_1792 GUN_TOME = ModItems.custom("gun_tome", p -> new GunTomeItem(p.method_7889(1).method_7894(net.minecraft.class_1814.field_8903)));

    public static void init() {
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (!(player instanceof class_3222 sp) || !player.method_5715() || !level.method_8320(hit.method_17777()).method_27852(class_2246.field_10485)) return class_1269.field_5811;
            if (player.method_6047().method_7960()) return class_1269.field_5811;
            ForgeMenu.open(sp);
            return class_1269.field_5812;
        });
    }

    private ModEnchant() {}
}
