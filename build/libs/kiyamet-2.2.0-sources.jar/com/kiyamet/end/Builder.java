package com.kiyamet.end;

import com.kiyamet.boss.BossEntity;
import com.kiyamet.boss.BossKind;
import com.kiyamet.boss.ModBosses;
import com.kiyamet.element.Temples;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2595;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/** Plans a big structure as a list of block changes, then places it a slice per tick. Coordinates are relative to the origin. */
public class Builder {
    public final class_3218 l;
    public final class_2338 o;
    public final Random r;
    final List<long[]> ops = new ArrayList<>();
    final List<class_2680> states = new ArrayList<>();
    final List<Runnable> after = new ArrayList<>();
    public static final class_2680 AIR = class_2246.field_10124.method_9564();

    public Builder(class_3218 l, class_2338 origin, long seed) { this.l = l; this.o = origin; this.r = new Random(seed); }

    public static class_2680 b(String id) { return class_7923.field_41175.method_63535(class_2960.method_60654(id)).method_9564(); }

    public void set(int x, int y, int z, class_2680 s) { ops.add(new long[]{o.method_10263() + x, o.method_10264() + y, o.method_10260() + z}); states.add(s); }

    public void fill(int x0, int y0, int z0, int x1, int y1, int z1, class_2680 s) {
        for (int y = Math.min(y0, y1); y <= Math.max(y0, y1); y++)
            for (int x = Math.min(x0, x1); x <= Math.max(x0, x1); x++)
                for (int z = Math.min(z0, z1); z <= Math.max(z0, z1); z++) set(x, y, z, s);
    }

    /** a hollow box: walls only */
    public void walls(int x0, int y0, int z0, int x1, int y1, int z1, class_2680 s) {
        for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) for (int z = z0; z <= z1; z++)
            if (x == x0 || x == x1 || z == z0 || z == z1) set(x, y, z, s);
    }

    public void disc(int cx, int y, int cz, double rad, class_2680 s) {
        int R = (int) Math.ceil(rad);
        for (int x = -R; x <= R; x++) for (int z = -R; z <= R; z++) if (x * x + z * z <= rad * rad) set(cx + x, y, cz + z, s);
    }

    public void ring(int cx, int y, int cz, double rOut, double rIn, class_2680 s) {
        int R = (int) Math.ceil(rOut);
        for (int x = -R; x <= R; x++) for (int z = -R; z <= R; z++) { double d = x * x + z * z; if (d <= rOut * rOut && d >= rIn * rIn) set(cx + x, y, cz + z, s); }
    }

    /** a cylinder; hollow keeps only a 1-thick wall */
    public void cyl(int cx, int y0, int cz, double rad, int h, class_2680 s, boolean hollow) {
        for (int y = y0; y < y0 + h; y++) { if (hollow) ring(cx, y, cz, rad, rad - 1.2, s); else disc(cx, y, cz, rad, s); }
    }

    /** sphere; shell > 0 makes it hollow with that wall thickness, air inside */
    public void sphere(int cx, int cy, int cz, double rad, class_2680 s, double shell) {
        int R = (int) Math.ceil(rad);
        for (int x = -R; x <= R; x++) for (int y = -R; y <= R; y++) for (int z = -R; z <= R; z++) {
            double d = Math.sqrt(x * x + y * y + z * z);
            if (d > rad) continue;
            if (shell > 0 && d < rad - shell) set(cx + x, cy + y, cz + z, AIR);
            else set(cx + x, cy + y, cz + z, s);
        }
    }

    /** a floating rock: flat top at y, an uneven point hanging down */
    public void island(int cx, int y, int cz, double rad, int depth, class_2680 top, class_2680 under) {
        int R = (int) Math.ceil(rad);
        for (int x = -R; x <= R; x++) for (int z = -R; z <= R; z++) {
            double d = Math.sqrt(x * x + z * z);
            if (d > rad) continue;
            double k = 1 - d / rad;
            int dn = (int) Math.round(depth * Math.pow(k, 0.8) + Math.sin(x * 0.7 + z * 0.4) * 1.5 + Math.cos(z * 0.9) * 1.2);
            set(cx + x, y, cz + z, top);
            for (int dy = 1; dy <= Math.max(1, dn); dy++) set(cx + x, y - dy, cz + z, under);
        }
    }

    public void chest(int x, int y, int z, String loot) {
        set(x, y, z, class_2246.field_10034.method_9564());
        long seed = r.nextLong();
        after.add(() -> {
            if (l.method_8321(new class_2338(o.method_10263() + x, o.method_10264() + y, o.method_10260() + z)) instanceof class_2595 ch)
                ch.method_54867(class_5321.method_29179(class_7924.field_50079, class_2960.method_60654(loot)), seed);
        });
    }

    public void mob(int x, int y, int z, class_1299<? extends class_1308> type) {
        float yaw = r.nextFloat() * 360;
        after.add(() -> {
            class_1308 m = type.method_5883(l, class_3730.field_16474);
            if (m == null) return;
            m.method_5808(o.method_10263() + x + 0.5, o.method_10264() + y, o.method_10260() + z + 0.5, yaw, 0);
            m.method_5971();
            l.method_8649(m);
        });
    }

    public void boss(int x, int y, int z, BossKind k) {
        after.add(() -> {
            BossEntity boss = ModBosses.TYPES.get(k).method_5883(l, class_3730.field_16474);
            if (boss == null) return;
            boss.method_5808(o.method_10263() + x + 0.5, o.method_10264() + y, o.method_10260() + z + 0.5, 0, 0);
            boss.method_5971();
            l.method_8649(boss);
        });
    }

    public int size() { return ops.size(); }

    public Temples.Job job() {
        return new Temples.Job() {
            int at = 0;
            @Override
            public boolean step(class_3218 ignored, int budget) {            // always builds in its own level
                int end = Math.min(ops.size(), at + budget);
                class_2338.class_2339 m = new class_2338.class_2339();
                for (; at < end; at++) {
                    long[] q = ops.get(at);
                    m.method_10103((int) q[0], (int) q[1], (int) q[2]);
                    if (!l.method_24794(m)) continue;
                    l.method_8652(m, states.get(at), 2 | 16);
                }
                if (at < ops.size()) return false;
                for (Runnable a : after) a.run();
                return true;
            }
        };
    }

    /** load every chunk the structure touches before building */
    public void loadChunks(int radius) {
        for (int dx = -radius; dx <= radius; dx += 16) for (int dz = -radius; dz <= radius; dz += 16) l.method_8497((o.method_10263() + dx) >> 4, (o.method_10260() + dz) >> 4);
        l.method_8497((o.method_10263() + radius) >> 4, (o.method_10260() + radius) >> 4);
    }
}
