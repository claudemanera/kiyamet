package com.kiyamet.end;

import com.kiyamet.Kiyamet;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1560;
import net.minecraft.class_2378;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/** TWD 2.2: the zombie enderman. */
public final class EndMobs {
    public static final class_5321<class_1299<?>> ZE_KEY = class_5321.method_29179(class_7924.field_41266, Kiyamet.id("zombie_enderman"));
    public static final class_1299<ZombieEnderman> ZOMBIE_ENDERMAN = class_2378.method_39197(class_7923.field_41177, ZE_KEY,
            class_1299.class_1300.<ZombieEnderman>method_5903(ZombieEnderman::new, class_1311.field_6302).method_17687(0.6f, 2.9f).method_55687(2.55f).method_27299(8).method_5905(ZE_KEY));

    public static void init() {
        FabricDefaultAttributeRegistry.register(ZOMBIE_ENDERMAN, class_1560.method_26910().method_26868(class_5134.field_23716, 60).method_26868(class_5134.field_23721, 10)
                .method_26868(class_5134.field_23719, 0.32).method_26868(class_5134.field_23717, 48).method_26868(class_5134.field_23724, 4));
        net.minecraft.class_1317.method_20637(ZOMBIE_ENDERMAN, net.minecraft.class_9169.field_48745, net.minecraft.class_2902.class_2903.field_13203, net.minecraft.class_1588::method_20680);
        BiomeModifications.addSpawn(BiomeSelectors.foundInTheEnd(), class_1311.field_6302, ZOMBIE_ENDERMAN, 8, 1, 3);
    }

    private EndMobs() {}
}
