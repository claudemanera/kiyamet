package com.kiyamet.end;

import com.kiyamet.Kiyamet;
import com.kiyamet.element.Temples;
import com.mojang.serialization.Codec;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1937;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5903;
import net.minecraft.class_5904;

/**
 * TWD 2.2: five great structures float in the outer End, over and over: the Void Citadel, the Sky Spire, the Fallen Sky
 * Ship, the Ender Hive and the Starfall Observatory. Each is built the first time a player comes near. The Temple of
 * Wisdom stands alone, just south of the dragon's island.
 */
public final class EndStructures {
    public enum Type {
        VOID_CITADEL("void_citadel", "The Void Citadel", "A fortress the plague took. Its tyrant waits in the keep.", 60),
        SKY_SPIRE("sky_spire", "The Sky Spire", "Climb. The herald waits at the crown.", 40),
        FALLEN_SKYSHIP("fallen_skyship", "The Fallen Sky Ship", "Its dead captain never left the cabin.", 48),
        ENDER_HIVE("ender_hive", "The Ender Hive", "Something breeds inside. Mind the eggs.", 32),
        STARFALL_OBSERVATORY("starfall_observatory", "The Starfall Observatory", "Where the stars fell, a warden still keeps watch.", 40);

        public final String id, title, hint;
        public final int radius;
        Type(String id, String title, String hint, int radius) { this.id = id; this.title = title; this.hint = hint; this.radius = radius; }
        public static Type of(String id) { for (Type t : values()) if (t.id.equals(id)) return t; return null; }
    }

    public static final AttachmentType<List<String>> BUILT = AttachmentRegistry.create(Kiyamet.id("end_built"), b -> b.initializer(List::of).persistent(Codec.STRING.listOf()));
    static final List<Temples.Job> JOBS = new ArrayList<>();
    static final int CELL = 576;
    public static final class_2338 WISDOM = new class_2338(0, 72, 150);

    public record Site(int cx, int cz, class_2338 pos, Type type) { String key() { return cx + "," + cz; } }

    /** the structure of one region of the outer End, or null */
    public static Site site(long seed, int cx, int cz) {
        Random r = new Random(seed ^ (cx * 341873128712L) ^ (cz * 132897987541L));
        if (r.nextFloat() < 0.12f) return null;
        int x = cx * CELL + 100 + r.nextInt(CELL - 200), z = cz * CELL + 100 + r.nextInt(CELL - 200);
        if ((long) x * x + (long) z * z < 1150L * 1150L) return null;                       // the outer islands only
        int y = 140 + r.nextInt(30);                                                       // high above the End islands
        Type t = Type.values()[Math.floorMod(cx + 2 * cz + (int) (seed & 0xff), 5)];
        return new Site(cx, cz, new class_2338(x, y, z), t);
    }

    static boolean built(class_3218 l, String key) { return l.getAttachedOrElse(BUILT, List.of()).contains(key); }
    static void markBuilt(class_3218 l, String key) { List<String> b = new ArrayList<>(l.getAttachedOrElse(BUILT, List.of())); b.add(key); l.setAttached(BUILT, List.copyOf(b)); }

    public static Builder plan(class_3218 l, Type t, class_2338 at) {
        Builder b = new Builder(l, at, at.method_10063() * 31 + t.ordinal());
        b.loadChunks(t.radius + 20);
        EndDesigns.plan(b, t);
        return b;
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            class_3218 end = server.method_3847(class_1937.field_25181);
            if (end == null) return;
            if (!JOBS.isEmpty() && JOBS.get(0).step(end, 20000)) JOBS.remove(0);
            if (server.method_3780() % 40 != 0) return;
            for (class_3222 p : server.method_3760().method_14571()) {
                if (p.method_51469() != end) continue;
                if (!built(end, "wisdom")) { markBuilt(end, "wisdom"); JOBS.add(0, WisdomTemple.plan(end, WISDOM).job()); }
                if (!p.method_5752().contains("twd_wisdom_told")) {
                    p.method_5780("twd_wisdom_told");
                    p.method_64398(class_2561.method_43470("✦ Somewhere close, something white is glowing. The Temple of Wisdom stands at X " + WISDOM.method_10263() + "  Z " + WISDOM.method_10260()
                            + " - follow the white bridge south of this island.").method_27692(class_124.field_1068));
                }
                int pcx = Math.floorDiv(p.method_31477(), CELL), pcz = Math.floorDiv(p.method_31479(), CELL);
                for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
                    Site s = site(end.method_8412(), pcx + dx, pcz + dz);
                    if (s == null) continue;
                    long ddx = p.method_31477() - s.pos().method_10263(), ddz = p.method_31479() - s.pos().method_10260(), d2 = ddx * ddx + ddz * ddz;
                    if (!built(end, s.key()) && d2 < 230L * 230L) { markBuilt(end, s.key()); JOBS.add(plan(end, s.type(), s.pos()).job()); }
                    String tag = "end_" + s.key();
                    if (built(end, s.key()) && d2 < 60L * 60L && !p.method_5752().contains(tag)) {
                        p.method_5780(tag);
                        com.kiyamet.skill.SkillManager.addXp(p, com.kiyamet.skill.Skill.EXPLORATION, 1500);
                        p.field_13987.method_14364(new class_5904(class_2561.method_43470(s.type().title.toUpperCase()).method_27695(class_124.field_1076, class_124.field_1067)));
                        p.field_13987.method_14364(new class_5903(class_2561.method_43470(s.type().hint).method_27692(class_124.field_1080)));
                        end.method_8396(null, p.method_24515(), class_3417.field_14967, class_3419.field_15251, 0.8f, 0.6f);
                    }
                }
            }
        });
        CommandRegistrationCallback.EVENT.register((d, ctx, env) -> {
            var build = class_2170.method_9247("endbuild");
            var find = class_2170.method_9247("endfind");
            for (Type t : Type.values()) {
                // testing: build this structure right here (console or creative)
                build.then(class_2170.method_9247(t.id).executes(c -> {
                    if (c.getSource().method_44023() != null && !c.getSource().method_44023().method_68878()) return 0;
                    class_2338 at = class_2338.method_49638(c.getSource().method_9222());
                    JOBS.add(plan(c.getSource().method_9225(), t, at).job());
                    c.getSource().method_9226(() -> class_2561.method_43470("Building " + t.title + " at " + at.method_23854()), true);
                    return 1;
                }));
                // creative: teleport to the nearest one of this kind in the End
                find.then(class_2170.method_9247(t.id).executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    if (!p.method_68878()) return 0;
                    class_3218 end = c.getSource().method_9211().method_3847(class_1937.field_25181);
                    if (end == null) return 0;
                    Site best = null; long bd = Long.MAX_VALUE;
                    int pcx = Math.floorDiv(p.method_31477(), CELL), pcz = Math.floorDiv(p.method_31479(), CELL);
                    for (int dx = -6; dx <= 6; dx++) for (int dz = -6; dz <= 6; dz++) {
                        Site s = site(end.method_8412(), pcx + dx, pcz + dz);
                        if (s == null || s.type() != t) continue;
                        long ex = s.pos().method_10263() - p.method_31477(), ez = s.pos().method_10260() - p.method_31479();
                        if (ex * ex + ez * ez < bd) { bd = ex * ex + ez * ez; best = s; }
                    }
                    if (best == null) return 0;
                    p.method_48105(end, best.pos().method_10263() + 0.5, best.pos().method_10264() + 30, best.pos().method_10260() + 0.5, java.util.Set.of(), 0, 0, true);
                    return 1;
                }));
            }
            d.register(class_2170.method_9247("twd").then(build).then(find)
                    .then(class_2170.method_9247("buildwisdom").executes(c -> {
                        if (c.getSource().method_44023() != null && !c.getSource().method_44023().method_68878()) return 0;
                        class_2338 at = class_2338.method_49638(c.getSource().method_9222());
                        JOBS.add(0, WisdomTemple.plan(c.getSource().method_9225(), at).job());
                        c.getSource().method_9226(() -> class_2561.method_43470("Building the Temple of Wisdom at " + at.method_23854()), true);
                        return 1;
                    })));
        });
    }

    private EndStructures() {}
}
