package com.kiyamet.end;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1400;
import net.minecraft.class_1560;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/** TWD 2.2: an enderman the plague reached. It does not wait to be looked at - it hunts on sight, blinks behind you and bites. */
public class ZombieEnderman extends class_1560 implements GeoEntity {
    static final RawAnimation IDLE = RawAnimation.begin().thenLoop("misc.idle"), WALK = RawAnimation.begin().thenLoop("move.walk"), ATTACK = RawAnimation.begin().thenPlay("attack.swing");
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private int blink;

    public ZombieEnderman(class_1299<? extends class_1560> t, class_1937 l) { super(t, l); field_6194 = 12; }

    @Override
    protected void method_5959() {
        super.method_5959();
        field_6185.method_6277(1, new class_1400<>(this, class_1657.class, false));
        field_6185.method_6277(2, new class_1400<>(this, com.kiyamet.npc.HumanEntity.class, false));
    }

    @Override
    public void method_6007() {
        super.method_6007();
        if (!(method_73183() instanceof class_3218 sl)) return;
        if (field_6012 % 12 == 0) sl.method_65096(class_2398.field_11214, method_23317(), method_23318() + 1.6, method_23321(), 2, 0.3, 0.8, 0.3, 0.2);
        class_1309 t = method_5968();
        // blink: every few seconds it vanishes and comes out right behind its prey
        if (t != null && t.method_5805() && --blink <= 0 && method_5858(t) > 9) {
            blink = 80 + field_5974.method_43048(80);
            double yaw = Math.toRadians(t.method_36454());
            double x = t.method_23317() + Math.sin(yaw) * 2.0, z = t.method_23321() - Math.cos(yaw) * 2.0;     // two steps behind its back
            sl.method_65096(class_2398.field_23190, method_23317(), method_23318() + 1.5, method_23321(), 30, 0.3, 1, 0.3, 0.1);
            if (method_6082(x, t.method_23318(), z, true)) sl.method_65096(class_2398.field_23190, method_23317(), method_23318() + 1.5, method_23321(), 30, 0.3, 1, 0.3, 0.1);
        }
    }

    @Override
    public boolean method_6121(class_3218 level, class_1297 target) {
        boolean hit = super.method_6121(level, target);
        if (hit) {
            triggerAnim("main", "attack");
            if (target instanceof class_1309 le) le.method_6092(new class_1293(class_1294.field_5916, 80, 0));
            if (target instanceof class_3222 p) com.kiyamet.world.Infection.onZombieHit(p, com.kiyamet.entity.ZombieKind.TOXIC);
        }
        return hit;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar c) {
        c.add(new AnimationController<ZombieEnderman>("main", 4, s -> s.setAndContinue(s.isMoving() ? WALK : IDLE)).triggerableAnim("attack", ATTACK));
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
