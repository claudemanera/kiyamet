package com.kiyamet.entity;

import com.kiyamet.skill.SkillManager;
import com.kiyamet.world.Difficulty;
import com.kiyamet.world.Infection;
import com.kiyamet.world.NoiseSystem;
import net.minecraft.class_1266;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1315;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1642;
import net.minecraft.class_1657;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import net.minecraft.class_5134;
import net.minecraft.class_5425;
import net.minecraft.class_5819;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.animation.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/** One class for all 14 zombie kinds; behaviour switches on {@link #kind}. Never burns in daylight. */
public class KZombie extends class_1642 implements GeoEntity {
    private static final class_2960 SCALE_MOD = com.kiyamet.Kiyamet.id("power_scale");
    public static final RawAnimation IDLE = RawAnimation.begin().thenLoop("misc.idle");
    public static final RawAnimation WALK = RawAnimation.begin().thenLoop("move.walk");
    public static final RawAnimation ATTACK = RawAnimation.begin().thenPlay("attack.swing");
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    public final ZombieKind kind;
    /** Prisoner state (see Captives) and who this walker used to be. */
    public final com.kiyamet.npc.Captives.Data captives = new com.kiyamet.npc.Captives.Data();
    public String formerName;
    /** A walker that only exists in a broken mind (Mind): vanishes when hit or at this game time. */
    public long hallucination;
    public java.util.UUID formerOwner;
    private int screamCooldown, leapCooldown, noiseCheck;

    public KZombie(class_1299<? extends class_1642> type, class_1937 level, ZombieKind kind) {
        super(type, level);
        this.kind = kind;
        this.field_6194 = 5 + (int) (kind.health / 6);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<KZombie>("main", 4, test -> test.setAndContinue(test.isMoving() ? WALK : IDLE)));
        controllers.add(new AnimationController<KZombie>("attack", 0, test -> PlayState.STOP).triggerableAnim("attack", ATTACK));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    @Override
    protected boolean method_7216() { return false; }

    /** Walkers stay walkers underwater (no turning into vanilla Drowned). */
    @Override
    protected boolean method_7209() { return false; }

    @Override
    public boolean method_6109() { return false; }

    @Override
    public class_1315 method_5943(class_5425 level, class_1266 difficulty, class_3730 reason, class_1315 data) {
        class_1315 result = super.method_5943(level, difficulty, reason, data);
        double mult = Difficulty.multiplierNear(level.method_8410(), method_24515());
        apply(class_5134.field_23716, mult);
        apply(class_5134.field_23721, mult);
        method_6033(method_6063());
        method_7201(true);
        return result;
    }

    private void apply(net.minecraft.class_6880<net.minecraft.class_1320> attr, double mult) {
        class_1324 inst = method_5996(attr);
        if (inst == null || mult <= 1.0) return;
        inst.method_6200(SCALE_MOD);
        inst.method_26837(new class_1322(SCALE_MOD, mult - 1.0, class_1322.class_1323.field_6331));
    }

    @Override
    public boolean method_6121(class_3218 level, class_1297 target) {
        if (captives.captive) return false;
        if (hallucination > 0) { poof(level); return false; }
        boolean hit = super.method_6121(level, target);
        if (hit) triggerAnim("attack", "attack");
        if (hit && target instanceof class_1309 living) {
            switch (kind) {
                case TOXIC -> living.method_6092(new class_1293(class_1294.field_5899, 100, 1));
                case LISTENER -> living.method_6092(new class_1293(class_1294.field_5909, 60, 1));
                case MUTANT, TANK -> living.method_6005(1.2, method_23317() - living.method_23317(), method_23321() - living.method_23321());
                default -> {}
            }
            if (target instanceof class_3222 p) Infection.onZombieHit(p, kind);
        }
        return hit;
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (!(method_73183() instanceof class_3218 server)) return;
        if (hallucination > 0 && server.method_75260() > hallucination) { poof(server); return; }
        if (field_6012 % 40 == 0 && com.kiyamet.season.Seasons.season(server) == com.kiyamet.season.Seasons.Season.WINTER && server.method_8311(method_24515().method_10084()))
            method_6092(new class_1293(class_1294.field_5909, 60, 0, true, false));   // the cold slows the dead
        com.kiyamet.npc.Captives.tick(server, this, captives);
        if (captives.captive) return;
        com.kiyamet.defense.DefenseRules.tickZombie(server, this);
        class_1309 target = method_5968();
        if (target != null && com.kiyamet.twd.Camouflage.hides(target, this)) { method_5980(null); target = null; }
        if (screamCooldown > 0) screamCooldown--;
        if (leapCooldown > 0) leapCooldown--;

        if (kind == ZombieKind.SCREAMER && target instanceof class_1657 && screamCooldown == 0 && method_5739(target) < 16) {
            screamCooldown = 400;
            method_5783(net.minecraft.class_3417.field_14905, 2.5f, 0.5f);
            NoiseSystem.make(server, method_24515(), 48, 3);
            for (KZombie z : server.method_18467(KZombie.class, method_5829().method_1014(40))) if (z != this) z.method_5980(target);
        }
        if (kind == ZombieKind.HUNTER && target != null && leapCooldown == 0 && method_24828() && method_5739(target) > 3 && method_5739(target) < 9) {
            leapCooldown = 80;
            class_243 d = target.method_73189().method_1020(method_73189()).method_1029();
            method_18800(d.field_1352 * 1.1, 0.55, d.field_1350 * 1.1);
        }
        if (kind == ZombieKind.ALPHA && field_6012 % 40 == 0) {
            for (KZombie z : server.method_18467(KZombie.class, method_5829().method_1014(12)))
                if (z != this) z.method_6092(new class_1293(class_1294.field_5910, 60, 0));
        }
        if (target == null && ++noiseCheck >= 20) {
            noiseCheck = 0;
            class_2338 heard = NoiseSystem.loudestNear(server, method_24515(), kind == ZombieKind.LISTENER ? 2.0 : 1.0);
            if (heard != null) method_5942().method_6337(heard.method_10263() + 0.5, heard.method_10264(), heard.method_10260() + 0.5, 1.1);
        }
    }

    @Override
    protected void method_7208() {
        super.method_7208();
        field_6185.method_6277(3, new net.minecraft.class_1400<>(this, com.kiyamet.npc.HumanEntity.class, 10, true, false,
                (t, l) -> t instanceof com.kiyamet.npc.HumanEntity h && !h.isWhisperer() && !h.raiding && !h.captives.captive && !com.kiyamet.twd.Camouflage.hides(t, this)));
        field_6185.method_6277(4, new net.minecraft.class_1400<>(this, com.kiyamet.robot.RobotEntity.class, 10, true, false,
                (t, l) -> t instanceof com.kiyamet.robot.RobotEntity r && r.isAlly()));
    }

    @Override
    public boolean method_64397(class_3218 level, class_1282 source, float amount) {
        if (hallucination > 0) { poof(level); return false; }
        return super.method_64397(level, source, amount * com.kiyamet.twd.Headshot.multiplier(level, this, source));
    }

    @Override
    public void method_6078(class_1282 source) {
        if (method_73183() instanceof class_3218 sl && field_5974.method_43057() < 0.35f)
            method_5775(sl, new net.minecraft.class_1799(net.minecraft.class_7923.field_41178.method_63535(com.kiyamet.Kiyamet.id("walker_guts"))));
        if (method_73183() instanceof class_3218 sl3 && field_5974.method_43057() < 0.03f) method_5775(sl3, new net.minecraft.class_1799(com.kiyamet.twd.ModTwd.LOST_NOTE));
        if (kind == ZombieKind.EXPLODER && method_73183() instanceof class_3218 server)
            server.method_8437(this, method_23317(), method_23318(), method_23321(), 2.5f, class_1937.class_7867.field_40890);
        super.method_6078(source);
    }

    void poof(class_3218 level) {
        level.method_65096(net.minecraft.class_2398.field_11237, method_23317(), method_23318() + 1, method_23321(), 12, 0.3, 0.6, 0.3, 0.01);
        method_31472();
    }

    @Override
    public boolean method_5931() { return com.kiyamet.npc.Captives.canCapture(this); }

    @Override
    protected net.minecraft.class_1269 method_5992(class_1657 player, net.minecraft.class_1268 hand) {
        if (captives.captive && hand == net.minecraft.class_1268.field_5808 && !player.method_5998(hand).method_31574(net.minecraft.class_1802.field_8719)) {
            if (player instanceof class_3222 sp) com.kiyamet.npc.Captives.walker(sp, this);
            return net.minecraft.class_1269.field_5812;
        }
        return super.method_5992(player, hand);
    }

    @Override
    protected void method_5652(net.minecraft.class_11372 out) {
        super.method_5652(out);
        com.kiyamet.npc.Captives.save(out, captives);
        if (formerName != null) out.method_71469("FormerName", formerName);
        if (formerOwner != null) out.method_71469("FormerOwner", formerOwner.toString());
    }

    @Override
    protected void method_5749(net.minecraft.class_11368 in) {
        super.method_5749(in);
        com.kiyamet.npc.Captives.load(in, captives);
        String n = in.method_71428("FormerName", "");
        formerName = n.isEmpty() ? null : n;
        String o = in.method_71428("FormerOwner", "");
        try { formerOwner = o.isEmpty() ? null : java.util.UUID.fromString(o); } catch (IllegalArgumentException e) { formerOwner = null; }
    }

    /** Apocalypse zombies spawn day and night on any solid ground, never in water. */
    @Override
    public boolean method_5979(class_1936 level, class_3730 reason) {
        if (reason != class_3730.field_16459 && reason != class_3730.field_16472) return true;
        class_2338 below = method_24515().method_10074();
        if (!level.method_8320(below).method_51367() || !level.method_8316(method_24515()).method_15769()) return false;
        if (level instanceof class_3218 sl && com.kiyamet.world.ModStructures.inSanctuary(sl, method_24515())) return false;
        if (level instanceof class_3218 sl2 && com.kiyamet.twd.ShelterCore.protects(sl2, method_24515())) return false;
        int power = level instanceof class_3218 s ? Difficulty.nearestPower(s, method_24515()) : 0;
        if (power < kind.minPower) return false;
        boolean day = level instanceof class_3218 s && s.method_8530();
        return !day || field_5974.method_43057() < 0.35f;
    }

    public static boolean noisy(class_5819 r) { return r.method_43057() < 0.5f; }
}
