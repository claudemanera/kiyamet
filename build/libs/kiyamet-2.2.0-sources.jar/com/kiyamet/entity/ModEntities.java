package com.kiyamet.entity;

import com.kiyamet.Kiyamet;
import java.util.EnumMap;
import java.util.Map;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1642;
import net.minecraft.class_2378;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ModEntities {
    public static final Map<ZombieKind, class_1299<KZombie>> ZOMBIES = new EnumMap<>(ZombieKind.class);

    static {
        for (ZombieKind k : ZombieKind.values()) {
            class_5321<class_1299<?>> key = class_5321.method_29179(class_7924.field_41266, Kiyamet.id(k.id));
            class_1299<KZombie> type = class_1299.class_1300.<KZombie>method_5903((t, l) -> new KZombie(t, l, k), class_1311.field_6302)
                    .method_17687(k.width, k.height).method_55687(k.height * 0.88f).method_27299(8).method_5905(key);
            ZOMBIES.put(k, class_2378.method_39197(class_7923.field_41177, key, type));
        }
    }

    public static void init() {
        ZOMBIES.forEach((k, type) -> {
            FabricDefaultAttributeRegistry.register(type, class_1642.method_26940()
                    .method_26868(class_5134.field_23716, k.health)
                    .method_26868(class_5134.field_23719, k.speed)
                    .method_26868(class_5134.field_23721, k.damage)
                    .method_26868(class_5134.field_23724, k.armor)
                    .method_26868(class_5134.field_23717, k == ZombieKind.LISTENER ? 48 : 40)
                    .method_26868(class_5134.field_23718, k.scale > 1.2f ? 0.8 : 0.1));
            BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), class_1311.field_6302, type, k.weight, 1, k.scale > 1.2f ? 1 : 4);
        });
    }

    private ModEntities() {}
}
