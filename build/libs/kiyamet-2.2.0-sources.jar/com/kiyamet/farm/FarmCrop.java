package com.kiyamet.farm;

import net.minecraft.class_1935;
import net.minecraft.class_2302;

/** A 1.6 crop: 8 growth stages, drops its produce (and seeds) via its loot table. */
public class FarmCrop extends class_2302 {
    final String seeds;
    public FarmCrop(class_2251 p, String seeds) { super(p); this.seeds = seeds; }
    @Override protected class_1935 method_9832() { return com.kiyamet.registry.ModItems.get(seeds); }
}
