package com.kiyamet.farm;

import com.kiyamet.season.Seasons;
import net.minecraft.class_1269;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_5819;

/**
 * Fruit tree leaves: fruit 0 = bare, 1 = blossom / green fruit, 2 = ripe. Ripe fruit falls to the ground by itself now and then,
 * or you pick it with right-click. Nothing grows in winter; autumn and summer are the harvest.
 */
public class FruitLeaves extends class_2248 {
    public static final class_2758 FRUIT = class_2758.method_11867("fruit", 0, 2);
    final String fruit;

    public FruitLeaves(class_2251 p, String fruit) {
        super(p);
        this.fruit = fruit;
        method_9590(field_10647.method_11664().method_11657(FRUIT, 0));
    }

    @Override protected void method_9515(class_2689.class_2690<class_2248, class_2680> b) { b.method_11667(FRUIT); }
    @Override protected boolean method_9542(class_2680 s) { return true; }

    @Override
    protected void method_9514(class_2680 s, class_3218 level, class_2338 pos, class_5819 r) {
        Seasons.Season season = Seasons.season(level);
        int f = s.method_11654(FRUIT);
        if (season == Seasons.Season.WINTER) { if (f > 0 && r.method_43048(3) == 0) level.method_8652(pos, s.method_11657(FRUIT, f - 1), 2); return; }
        float grow = season == Seasons.Season.SPRING ? 0.12f : season == Seasons.Season.SUMMER ? 0.2f : 0.25f;
        if (f < 2) { if (r.method_43057() < grow) level.method_8652(pos, s.method_11657(FRUIT, f + 1), 2); return; }
        // ripe: drops on its own
        if (r.method_43057() < 0.18f && level.method_8320(pos.method_10074()).method_26215()) {
            class_1542 it = new class_1542(level, pos.method_10263() + 0.5, pos.method_10264() - 0.3, pos.method_10260() + 0.5, new class_1799(com.kiyamet.registry.ModItems.get(fruit)));
            it.method_18800(0, -0.05, 0);
            level.method_8649(it);
            level.method_8652(pos, s.method_11657(FRUIT, 0), 2);
        }
    }

    @Override
    protected class_1269 method_55766(class_2680 s, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (s.method_11654(FRUIT) < 2) return class_1269.field_5811;
        if (level instanceof class_3218 sl) {
            int n = 1 + sl.field_9229.method_43048(2);
            class_2248.method_9577(level, pos, new class_1799(com.kiyamet.registry.ModItems.get(fruit), n));
            level.method_8396(null, pos, class_3417.field_17617, class_3419.field_15245, 1f, 1.1f);
            level.method_8652(pos, s.method_11657(FRUIT, 0), 2);
        }
        return class_1269.field_5812;
    }
}
