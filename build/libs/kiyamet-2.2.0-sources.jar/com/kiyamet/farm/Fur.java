package com.kiyamet.farm;

import com.kiyamet.Kiyamet;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_10191;
import net.minecraft.class_10192;
import net.minecraft.class_10394;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5321;
import net.minecraft.class_9279;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

/**
 * TWD 1.6 fur pelts: worn OVER armor. Right-click a pelt to line the next piece of armor you wear; the armor keeps
 * its look and gets a fur layer on top (an extra equipment-asset layer), and keeps you warm in the cold.
 * Sneak + right-click with shears takes the fur off again.
 */
public final class Fur {
    public enum Kind {
        WOLF("wolf_pelt", "Wolf Fur", 4f), FOX("fox_pelt", "Fox Fur", 4.5f), POLAR("polar_pelt", "Polar Bear Fur", 6f), SHEEP("sheepskin", "Sheepskin", 3.5f),
        LION("lion_pelt", "Lion Fur", 5f), TIGER("tiger_pelt", "Tiger Fur", 5.5f), BEAR("bear_pelt", "Bear Fur", 7f), ICE_BEAR("ice_bear_pelt", "Ice Bear Fur", 9f);
        public final String item, title; public final float warmth;
        Kind(String item, String title, float warmth) { this.item = item; this.title = title; this.warmth = warmth; }
        public String id() { return name().toLowerCase(); }
        static Kind byName(String n) { for (Kind k : values()) if (k.name().equals(n)) return k; return null; }
    }

    /** Vanilla armor looks we can put fur on (the equipment/fur_*_<base>.json files exist for these). */
    public static final String[] BASES = {"leather", "chainmail", "iron", "gold", "diamond", "netherite", "copper", "turtle_scute", "armadillo_scute"};

    public static class PeltItem extends class_1792 {
        final Kind kind;
        public PeltItem(class_1793 p, Kind kind) { super(p); this.kind = kind; }

        @Override
        public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
            if (!(player instanceof class_3222 p)) return class_1269.field_5812;
            for (class_1304 slot : new class_1304[]{class_1304.field_6174, class_1304.field_6169, class_1304.field_6172, class_1304.field_6166}) {
                class_1799 armor = p.method_6118(slot);
                if (armor.method_7960() || kind(armor) != null) continue;
                String r = apply(armor, kind);
                if (r != null) { p.method_7353(class_2561.method_43470(r).method_27692(class_124.field_1061), true); continue; }
                if (!p.method_68878()) player.method_5998(hand).method_7934(1);
                level.method_8396(null, p.method_24515(), class_3417.field_14581.comp_349(), class_3419.field_15248, 1f, 0.8f);
                p.method_7353(class_2561.method_43470(armor.method_7964().getString() + " lined with " + kind.title + " (+" + fmt(kind.warmth) + "°C in the cold)").method_27692(class_124.field_1075), true);
                return class_1269.field_21466;
            }
            p.method_7353(class_2561.method_43470("Wear armor first - the fur goes on top of it (helmet, chestplate, leggings or boots).").method_27692(class_124.field_1054), true);
            return class_1269.field_5814;
        }
    }

    static String fmt(float f) { return f == (int) f ? String.valueOf((int) f) : String.valueOf(f); }

    static class_2487 tag(class_1799 s) { return s.method_58695(class_9334.field_49628, class_9279.field_49302).method_57461(); }

    public static Kind kind(class_1799 s) { return Kind.byName(tag(s).method_68564("Fur", "")); }

    /** Lines the armor with fur. Returns an error message, or null when it worked. */
    static String apply(class_1799 armor, Kind k) {
        class_10192 eq = armor.method_58694(class_9334.field_54196);
        if (eq == null || eq.comp_3176().isEmpty()) return "This can't take fur.";
        class_5321<class_10394> base = eq.comp_3176().get();
        String path = base.method_29177().method_12832();
        boolean known = base.method_29177().method_12836().equals("minecraft") && java.util.Arrays.asList(BASES).contains(path);
        if (!known) return "Fur doesn't fit on " + armor.method_7964().getString() + ".";
        class_2487 t = tag(armor);
        t.method_10582("Fur", k.name());
        t.method_10582("FurBase", base.method_29177().toString());
        armor.method_57379(class_9334.field_49628, class_9279.method_57456(t));
        armor.method_57379(class_9334.field_54196, with(eq, class_5321.method_29179(class_10191.field_55214, Kiyamet.id("fur_" + k.id() + "_" + path))));
        List<class_2561> lore = new ArrayList<>(armor.method_58695(class_9334.field_49632, class_9290.field_49340).comp_2400());
        lore.add(class_2561.method_43470("❄ Lined with " + k.title + " (+" + fmt(k.warmth) + "°C in the cold)").method_27694(st -> st.method_10978(false).method_10977(class_124.field_1075)));
        armor.method_57379(class_9334.field_49632, new class_9290(lore));
        return null;
    }

    /** Takes the fur off and gives the pelt back. */
    static boolean strip(class_1799 armor, class_1657 p) {
        Kind k = kind(armor);
        if (k == null) return false;
        class_2487 t = tag(armor);
        String base = t.method_68564("FurBase", "minecraft:iron");
        t.method_10551("Fur"); t.method_10551("FurBase");
        if (t.method_33133()) armor.method_57381(class_9334.field_49628); else armor.method_57379(class_9334.field_49628, class_9279.method_57456(t));
        class_10192 eq = armor.method_58694(class_9334.field_54196);
        if (eq != null) armor.method_57379(class_9334.field_54196, with(eq, class_5321.method_29179(class_10191.field_55214, net.minecraft.class_2960.method_60654(base))));
        List<class_2561> lore = new ArrayList<>();
        for (class_2561 c : armor.method_58695(class_9334.field_49632, class_9290.field_49340).comp_2400()) if (!c.getString().startsWith("❄ Lined with")) lore.add(c);
        if (lore.isEmpty()) armor.method_57381(class_9334.field_49632); else armor.method_57379(class_9334.field_49632, new class_9290(lore));
        class_1799 pelt = new class_1799(com.kiyamet.registry.ModItems.get(k.item));
        if (!p.method_31548().method_7394(pelt)) p.method_7328(pelt, false);
        return true;
    }

    static class_10192 with(class_10192 e, class_5321<class_10394> asset) {
        return new class_10192(e.comp_3174(), e.comp_3175(), Optional.of(asset), e.comp_3306(), e.comp_3177(), e.comp_3178(), e.comp_3213(),
                e.comp_3214(), e.comp_3523(), e.comp_4362(), e.comp_4363());
    }

    /** Extra warmth from fur-lined armor (used by Seasons). */
    public static float warmth(class_1309 p) {
        float w = 0;
        for (class_1304 es : new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166}) {
            Kind k = kind(p.method_6118(es));
            if (k != null) w += k.warmth * (es == class_1304.field_6174 ? 1.25f : 1f);
        }
        return w;
    }

    public static int pieces(class_1309 p) {
        int n = 0;
        for (class_1304 es : new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166}) if (kind(p.method_6118(es)) != null) n++;
        return n;
    }

    public static void init() {
        // shears: sneak + right-click takes all fur off your armor
        UseItemCallback.EVENT.register((player, level, hand) -> {
            class_1799 s = player.method_5998(hand);
            if (level.method_8608() || !s.method_31574(class_1802.field_8868) || !player.method_5715()) return class_1269.field_5811;
            boolean any = false;
            for (class_1304 es : new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166}) any |= strip(player.method_6118(es), player);
            if (!any) return class_1269.field_5811;
            level.method_8396(null, player.method_24515(), class_3417.field_14975, class_3419.field_15248, 1f, 1f);
            ((class_3222) player).method_7353(class_2561.method_43470("You took the fur off your armor.").method_27692(class_124.field_1080), true);
            return class_1269.field_5812;
        });
        // pelts from animals
        ServerLivingEntityEvents.AFTER_DEATH.register((e, src) -> {
            if (!(e.method_73183() instanceof class_3218 level) || !(src.method_5529() instanceof class_1657)) return;
            class_1299<?> t = e.method_5864();
            Kind k = t == class_1299.field_6055 ? Kind.WOLF : t == class_1299.field_17943 ? Kind.FOX : t == class_1299.field_6042 ? Kind.POLAR : t == class_1299.field_6115 ? Kind.SHEEP : null;
            if (k == null) return;
            float chance = k == Kind.SHEEP ? 0.35f : 0.75f;
            if (level.field_9229.method_43057() < chance) e.method_5775(level, new class_1799(com.kiyamet.registry.ModItems.get(k.item), k == Kind.POLAR ? 2 : 1));
        });
    }

    private Fur() {}
}
