package com.kiyamet.farm;

import com.kiyamet.Kiyamet;
import com.kiyamet.registry.ModItems;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1972;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2465;
import net.minecraft.class_2473;
import net.minecraft.class_2893;
import net.minecraft.class_4174;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8813;

/** TWD 1.6 farming: 8 crops, 2 fruit trees (orange, peach), 4 fur pelts. */
public final class ModFarm {
    /** crop id, produce food (nutrition, saturation) */
    public static final Object[][] CROPS = {{"tomato", 3, 0.4f}, {"corn", 4, 0.5f}, {"cucumber", 2, 0.4f}, {"eggplant", 3, 0.45f},
            {"bell_pepper", 3, 0.4f}, {"onion", 2, 0.3f}, {"cabbage", 3, 0.5f}, {"strawberry", 2, 0.35f}};
    public static final Object[][] TREES = {{"orange", 4, 0.4f}, {"peach", 4, 0.5f}};
    public static final List<class_2248> CROP_BLOCKS = new ArrayList<>(), CUTOUT = new ArrayList<>();
    public static final List<String> SEEDS = new ArrayList<>(), PRODUCE = new ArrayList<>();

    static class_2248 block(String name, Function<class_4970.class_2251, class_2248> f, class_4970.class_2251 p) {
        class_5321<class_2248> key = class_5321.method_29179(class_7924.field_41254, Kiyamet.id(name));
        return class_2378.method_39197(class_7923.field_41175, key, f.apply(p.method_63500(key)));
    }

    static void blockItem(String name, class_2248 b) {
        ModItems.custom(name, p -> new class_1747(b, p.method_63685()));
    }

    static void food(String name, int n, float sat) {
        ModItems.custom(name, p -> new class_1792(p.method_19265(new class_4174(n, sat, false))));
        PRODUCE.add(name);
    }

    public static void init() {
        for (Object[] c : CROPS) {
            String id = (String) c[0];
            class_2248 crop = block(id + "_crop", p -> new FarmCrop(p, id + "_seeds"), class_4970.class_2251.method_9630(class_2246.field_10293));
            CROP_BLOCKS.add(crop); CUTOUT.add(crop);
            ModItems.custom(id + "_seeds", p -> new class_1747(crop, p));
            SEEDS.add(id + "_seeds");
            food(id, (Integer) c[1], (Float) c[2]);
        }
        for (Object[] t : TREES) {
            String id = (String) t[0];
            class_2248 log = block(id + "_log", class_2465::new, class_4970.class_2251.method_9630(class_2246.field_10431));
            blockItem(id + "_log", log);
            class_2248 leaves = block(id + "_leaves", p -> new FruitLeaves(p, id), class_4970.class_2251.method_9630(class_2246.field_10503).method_22488().method_9640());
            blockItem(id + "_leaves", leaves); CUTOUT.add(leaves);
            class_8813 grower = new class_8813(Kiyamet.MOD_ID + "_" + id, Optional.empty(),
                    Optional.of(class_5321.method_29179(class_7924.field_41239, Kiyamet.id(id + "_tree"))), Optional.empty());
            class_2248 sapling = block(id + "_sapling", p -> new class_2473(grower, p), class_4970.class_2251.method_9630(class_2246.field_10394));
            blockItem(id + "_sapling", sapling); CUTOUT.add(sapling);
            food(id, (Integer) t[1], (Float) t[2]);
        }
        for (Fur.Kind k : Fur.Kind.values()) ModItems.custom(k.item, p -> new Fur.PeltItem(p.method_7889(16), k));
        Fur.init();

        // wild fruit trees
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(class_1972.field_9449, class_1972.field_9430, class_1972.field_9451, class_1972.field_35118, class_1972.field_9455),
                class_2893.class_2895.field_13178, class_5321.method_29179(class_7924.field_41245, Kiyamet.id("orange_tree_wild")));
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(class_1972.field_9451, class_1972.field_34470, class_1972.field_9409, class_1972.field_9414, class_1972.field_9412, class_1972.field_42720),
                class_2893.class_2895.field_13178, class_5321.method_29179(class_7924.field_41245, Kiyamet.id("peach_tree_wild")));

        // seeds from grass
        PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, be) -> {
            if (level.method_8608() || player.method_68878()) return;
            if (!(state.method_27852(class_2246.field_10479) || state.method_27852(class_2246.field_10214) || state.method_27852(class_2246.field_10112))) return;
            if (level.field_9229.method_43057() < 0.07f)
                class_2248.method_9577(level, pos, new class_1799(ModItems.get(SEEDS.get(level.field_9229.method_43048(SEEDS.size())))));
        });
    }

    private ModFarm() {}
}
