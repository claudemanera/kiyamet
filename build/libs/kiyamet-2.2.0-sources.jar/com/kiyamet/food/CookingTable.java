package com.kiyamet.food;

import com.kiyamet.Kiyamet;
import com.kiyamet.npc.Shop;
import com.kiyamet.registry.ModItems;
import com.kiyamet.ui.PanelMenu;
import com.kiyamet.ui.Ui;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_747;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/** 1.9 Cooking Table: every meal is cooked here. Pick a dish, and if you carry the ingredients it's made on the spot. */
public class CookingTable extends class_2248 {
    public static class_2248 BLOCK;
    static final class_265 SHAPE = class_2248.method_9541(0, 0, 0, 16, 14, 16);

    public CookingTable(class_2251 p) { super(p); }

    public static void init() {
        class_5321<class_2248> key = class_5321.method_29179(class_7924.field_41254, Kiyamet.id("cooking_table"));
        BLOCK = class_2378.method_39197(class_7923.field_41175, key, new CookingTable(class_4970.class_2251.method_9630(class_2246.field_9980).method_9632(2.5f).method_22488().method_63500(key)));
        ModItems.custom("cooking_table", ip -> new class_1747(BLOCK, ip.method_63685()));
    }

    @Override
    protected class_265 method_9530(class_2680 s, class_1922 l, class_2338 p, class_3726 c) { return SHAPE; }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (player instanceof class_3222 sp) Menu.open(sp, pos);
        return class_1269.field_5812;
    }

    static Map<String, Integer> need(CookList.Cook c) {
        Map<String, Integer> m = new LinkedHashMap<>();
        for (String i : c.ingredients()) m.merge(i, 1, Integer::sum);
        return m;
    }

    static boolean has(class_3222 p, CookList.Cook c) {
        if (p.method_68878()) return true;
        for (var e : need(c).entrySet()) if (Shop.count(p, e.getKey()) < e.getValue()) return false;
        return true;
    }

    public static class Menu extends PanelMenu {
        static final int[] SLOTS = new int[36];
        static { for (int i = 0; i < 36; i++) SLOTS[i] = 9 + i; }
        final class_2338 pos;

        static void open(class_3222 p, class_2338 pos) { p.method_17355(new class_747((id, inv, pl) -> new Menu(id, inv, p, pos), class_2561.method_43470("Cooking Table"))); }

        private Menu(int id, class_1661 inv, class_3222 p, class_2338 pos) { super(id, inv, p); this.pos = pos; redraw(); }

        @Override
        protected void draw() {
            c.method_5447(4, Ui.icon(BLOCK.method_8389(), Ui.text("Cooking Table", class_124.field_1065, class_124.field_1067), Ui.text("Click a dish to cook it (shift-click: cook as many as you can)", class_124.field_1080)));
            List<CookList.Cook> all = CookList.ALL;
            for (int i = 0; i < all.size() && i < SLOTS.length; i++) {
                CookList.Cook ck = all.get(i);
                boolean ok = has(player, ck);
                Recipes.Meal m = Recipes.meal(ck.meal());
                List<class_2561> lore = new ArrayList<>();
                if (m != null) lore.add(Ui.text("Hunger +" + m.food() + "  ·  Well Fed " + m.fedMinutes() + " min  ·  keeps " + m.days() + " days", class_124.field_1075));
                for (var e : need(ck).entrySet()) {
                    int have = Shop.count(player, e.getKey());
                    lore.add(class_2561.method_43470((have >= e.getValue() ? "✔ " : "✘ ") + e.getValue() + "× ").method_10852(new class_1799(Ui.item(e.getKey())).method_7964())
                            .method_27692(have >= e.getValue() ? class_124.field_1060 : class_124.field_1080));
                }
                lore.add(Ui.text(ok ? "Click to cook (makes " + ck.count() + ")" : "Missing ingredients", ok ? class_124.field_1054 : class_124.field_1063));
                class_1799 icon = new class_1799(ModItems.get(ck.meal()), ck.count());
                c.method_5447(SLOTS[i], Ui.glint(Ui.lore(icon, lore), ok));
            }
            c.method_5447(49, Ui.icon(class_1802.field_8077, Ui.text("Close", class_124.field_1061)));
        }

        @Override
        protected boolean click(int slot, class_1713 type) {
            if (slot == 49) { player.method_7346(); return false; }
            List<CookList.Cook> all = CookList.ALL;
            for (int i = 0; i < all.size() && i < SLOTS.length; i++) {
                if (SLOTS[i] != slot) continue;
                CookList.Cook ck = all.get(i);
                int times = 0;
                do {
                    if (!has(player, ck)) break;
                    if (!player.method_68878()) for (var e : need(ck).entrySet()) {
                        Shop.take(player, e.getKey(), e.getValue());
                        if (e.getKey().equals("minecraft:milk_bucket")) Shop.give(player, new class_1799(class_1802.field_8550, e.getValue()));
                        if (e.getKey().equals("minecraft:honey_bottle")) Shop.give(player, new class_1799(class_1802.field_8469, e.getValue()));
                    }
                    Shop.give(player, new class_1799(ModItems.get(ck.meal()), ck.count()));
                    times++;
                } while (type == class_1713.field_7794 && times < 16);
                if (times == 0) return false;
                com.kiyamet.skill.SkillManager.addXp(player, com.kiyamet.skill.Skill.SURVIVAL, 10 * times);
                player.method_51469().method_8396(null, pos, class_3417.field_17483, class_3419.field_15245, 1f, 1f);
                player.method_51469().method_8396(null, pos, class_3417.field_20614.comp_349(), class_3419.field_15245, 0.4f, 1.4f);
                player.method_51469().method_65096(class_2398.field_17430, pos.method_10263() + 0.3, pos.method_10264() + 1.2, pos.method_10260() + 0.3, 3, 0.05, 0.1, 0.05, 0.01);
                return true;
            }
            return false;
        }
    }
}
