package com.kiyamet.food;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3730;
import net.minecraft.class_3965;
import net.minecraft.class_4590;
import net.minecraft.class_811;
import net.minecraft.class_8113;
import net.minecraft.class_9334;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * A plate: works like an item frame laid on the table. Right-click with food: the food goes on the plate.
 * Right-click with an empty hand: take it back. Sneak + right-click with an empty hand: eat it from the plate.
 */
public class PlateBlock extends class_2248 {
    static final class_265 SHAPE = class_2248.method_9541(2, 0, 2, 14, 1.5, 14);
    static final String TAG = "kiyamet_plate";

    public PlateBlock(class_2251 p) { super(p); }

    @Override
    protected class_265 method_9530(class_2680 s, class_1922 l, class_2338 pos, class_3726 c) { return SHAPE; }

    static class_8113.class_8122 food(class_1937 l, class_2338 pos) {
        List<class_8113.class_8122> d = l.method_8390(class_8113.class_8122.class, new class_238(pos), e -> e.method_5752().contains(TAG));
        return d.isEmpty() ? null : d.get(0);
    }

    @Override
    protected class_1269 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!stack.method_57826(class_9334.field_50075)) return class_1269.field_52423;
        if (!(level instanceof class_3218 l)) return class_1269.field_5812;
        if (food(l, pos) != null) return class_1269.field_52423;
        class_8113.class_8122 d = class_1299.field_42456.method_5883(l, class_3730.field_16461);
        if (d == null) return class_1269.field_5811;
        d.method_48897(stack.method_46651(1));
        d.method_48896(class_811.field_4319);
        float yaw = (float) Math.toRadians(-player.method_36454() + 180);
        d.method_48849(new class_4590(new Vector3f(0, 0, 0), new Quaternionf().rotateY(yaw).rotateX((float) Math.toRadians(-90)), new Vector3f(0.5f, 0.5f, 0.5f), new Quaternionf()));
        d.method_5814(pos.method_10263() + 0.5, pos.method_10264() + 0.11, pos.method_10260() + 0.5);
        d.method_5780(TAG);
        l.method_8649(d);
        if (!player.method_68878()) stack.method_7934(1);
        l.method_8396(null, pos, class_3417.field_46649, class_3419.field_15245, 0.8f, 1.2f);
        return class_1269.field_5812;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!(level instanceof class_3218 l) || !(player instanceof class_3222 p)) return class_1269.field_5812;
        class_8113.class_8122 d = food(l, pos);
        if (d == null) return class_1269.field_5811;
        class_1799 s = d.method_48900().method_7972();
        d.method_31472();
        if (p.method_5715() && p.method_7344().method_7587() || p.method_5715() && p.method_68878()) {
            class_1799 rest = s.method_7910(l, p);                       // eat it right off the plate
            l.method_8396(null, pos, class_3417.field_20614.comp_349(), class_3419.field_15248, 1f, 1f);
            if (!rest.method_7960() && !p.method_31548().method_7394(rest)) p.method_7328(rest, false);
        } else {
            if (!p.method_31548().method_7394(s)) p.method_7328(s, false);
            l.method_8396(null, pos, class_3417.field_15197, class_3419.field_15245, 0.6f, 1.2f);
        }
        return class_1269.field_5812;
    }

    @Override
    protected void method_66388(class_2680 state, class_3218 l, class_2338 pos, boolean moved) {
        super.method_66388(state, l, pos, moved);
        class_8113.class_8122 d = food(l, pos);
        if (d != null) { l.method_8649(new class_1542(l, pos.method_10263() + 0.5, pos.method_10264() + 0.3, pos.method_10260() + 0.5, d.method_48900().method_7972())); d.method_31472(); }
    }
}
