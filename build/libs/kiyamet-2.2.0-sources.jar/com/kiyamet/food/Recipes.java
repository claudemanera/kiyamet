package com.kiyamet.food;

import com.kiyamet.registry.ModItems;
import java.util.List;
import net.minecraft.class_10124;
import net.minecraft.class_10128;
import net.minecraft.class_10132;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1802;
import net.minecraft.class_4174;

/** 1.7: 10 hearty meals from the new crops - they fill you up for a long time and keep for weeks. */
public final class Recipes {
    /** id, title, nutrition, saturation modifier, keeps (days), well-fed minutes */
    public record Meal(String id, String title, int food, float sat, int days, int fedMinutes, boolean bowl) {}

    public static final List<Meal> MEALS = List.of(
            new Meal("vegetable_stew", "Vegetable Stew", 12, 1.2f, 10, 6, true),
            new Meal("tomato_soup", "Tomato Soup", 10, 1.1f, 10, 5, true),
            new Meal("stuffed_peppers", "Stuffed Peppers", 12, 1.3f, 12, 6, false),
            new Meal("ratatouille", "Baked Vegetables", 14, 1.3f, 12, 8, true),
            new Meal("cabbage_rolls", "Cabbage Rolls", 12, 1.2f, 14, 6, false),
            new Meal("cornbread", "Cornbread", 10, 1.2f, 20, 4, false),
            new Meal("fruit_salad", "Fruit Salad", 9, 1.0f, 7, 4, true),
            new Meal("peach_pie", "Peach Pie", 12, 1.2f, 15, 6, false),
            new Meal("strawberry_jam", "Strawberry Jam", 8, 1.0f, 120, 4, false),
            new Meal("survivor_ration", "Survivor's Ration", 16, 1.5f, 365, 10, false),
            new Meal("hunters_breakfast", "Hunter's Breakfast", 14, 1.3f, 6, 7, false),
            new Meal("fish_and_chips", "Fish and Chips", 12, 1.2f, 5, 5, false),
            new Meal("mushroom_risotto", "Chicken and Mushroom Rice", 12, 1.3f, 6, 6, true),
            new Meal("honey_glazed_ham", "Honey Glazed Ham", 14, 1.4f, 9, 8, false),
            new Meal("berry_pancakes", "Berry Pancakes", 10, 1.2f, 6, 5, false),
            new Meal("fish_sandwich", "Fish Sandwich", 11, 1.2f, 4, 5, false),
            new Meal("chicken_soup", "Chicken Soup", 12, 1.3f, 6, 6, true),
            new Meal("burger", "Burger", 14, 1.3f, 4, 7, false),
            new Meal("cabbage_salad", "Cabbage Salad", 8, 1.0f, 5, 4, true),
            new Meal("omelette", "Omelette", 10, 1.2f, 3, 5, false),
            new Meal("venison_stew", "Venison Stew", 14, 1.4f, 6, 8, true),
            new Meal("bear_steak", "Bear Steak and Potatoes", 16, 1.5f, 5, 9, false),
            new Meal("boar_sausages", "Boar Sausages", 12, 1.3f, 10, 6, false),
            new Meal("moose_roast", "Moose Roast", 18, 1.5f, 6, 10, false),
            new Meal("meat_skewers", "Meat Skewers", 12, 1.3f, 4, 6, false),
            new Meal("croc_wrap", "Crocodile Wrap", 12, 1.3f, 4, 6, false),
            new Meal("hunters_pie", "Hunter's Pie", 16, 1.4f, 8, 9, false),
            new Meal("bear_chili", "Bear Chili", 14, 1.4f, 6, 8, true),
            new Meal("jerky", "Jerky", 8, 1.1f, 120, 4, false),
            new Meal("meatballs", "Meatballs in Tomato Sauce", 14, 1.4f, 5, 8, true));

    public static Meal meal(String id) { for (Meal m : MEALS) if (m.id().equals(id)) return m; return null; }

    public static void init() {
        for (Meal m : MEALS) {
            class_10124 c = class_10128.method_62858().method_62854(new class_10132(List.of(
                    new class_1293(class_1294.field_5922, 30, 0, true, false), new class_1293(class_1294.field_5924, 20 * 20, 0, true, true),
                    new class_1293(com.kiyamet.food.Recipes.WELL_FED, m.fedMinutes() * 1200, 0, true, true)))).method_62851();
            ModItems.custom(m.id(), p -> {
                var pp = p.method_62833(new class_4174(m.food(), m.sat(), false), c).method_7889(16);
                if (m.bowl()) pp = pp.method_62834(class_1802.field_8428);
                return new net.minecraft.class_1792(pp);
            });
        }
        ModItems.custom("spoiled_food", p -> new net.minecraft.class_1792(p.method_62833(new class_4174(1, 0.1f, false),
                class_10128.method_62858().method_62854(new class_10132(new class_1293(class_1294.field_5903, 600, 1), 0.8f)).method_62851())));
    }

    /** Well Fed: hunger slowly refills while it lasts - you stay full for minutes. */
    public static class WellFed extends net.minecraft.class_1291 {
        public WellFed() { super(net.minecraft.class_4081.field_18271, 0xE8A040); }
        @Override public boolean method_5552(int duration, int amp) { return duration % 160 == 0; }
        @Override public boolean method_5572(net.minecraft.class_3218 level, net.minecraft.class_1309 e, int amp) {
            if (e instanceof net.minecraft.class_1657 p) p.method_7344().method_7585(1, 0.4f);
            return true;
        }
    }
    public static final net.minecraft.class_6880<net.minecraft.class_1291> WELL_FED =
            net.minecraft.class_2378.method_47985(net.minecraft.class_7923.field_41174, com.kiyamet.Kiyamet.id("well_fed"), new WellFed());

    private Recipes() {}
}
