package com.kiyamet.food;

import com.kiyamet.registry.ModItems;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

/**
 * 1.7 food spoilage. Food gets a "best before" date the first time you carry it; when the date passes it turns into
 * Spoiled Food. The Fridge slows it down 4x, the freezer stops it. Recipes and canned food keep much longer.
 */
public final class Spoilage {
    public static final long DAY = 24000;

    /** Days a food keeps (0 = never spoils). */
    public static int life(class_1799 s) {
        String id = class_7923.field_41178.method_10221(s.method_7909()).toString();
        return switch (id) {
            case "minecraft:beef", "minecraft:porkchop", "minecraft:chicken", "minecraft:mutton", "minecraft:rabbit", "minecraft:cod", "minecraft:salmon", "minecraft:tropical_fish" -> 3;
            case "minecraft:cooked_beef", "minecraft:cooked_porkchop", "minecraft:cooked_chicken", "minecraft:cooked_mutton", "minecraft:cooked_rabbit", "minecraft:cooked_cod", "minecraft:cooked_salmon" -> 6;
            case "minecraft:bread", "minecraft:cookie", "minecraft:pumpkin_pie", "minecraft:cake" -> 7;
            case "minecraft:mushroom_stew", "minecraft:rabbit_stew", "minecraft:beetroot_soup", "minecraft:suspicious_stew" -> 5;
            case "minecraft:sweet_berries", "minecraft:glow_berries", "kiyamet:strawberry", "minecraft:melon_slice" -> 4;
            case "minecraft:apple", "kiyamet:orange", "kiyamet:peach", "kiyamet:tomato", "kiyamet:cucumber", "kiyamet:eggplant", "kiyamet:bell_pepper", "kiyamet:cabbage" -> 8;
            case "minecraft:carrot", "minecraft:potato", "minecraft:beetroot", "kiyamet:corn", "kiyamet:onion", "minecraft:baked_potato" -> 12;
            case "minecraft:rotten_flesh", "minecraft:spider_eye", "minecraft:poisonous_potato", "minecraft:golden_apple", "minecraft:enchanted_golden_apple", "minecraft:golden_carrot",
                 "minecraft:honey_bottle", "minecraft:dried_kelp", "minecraft:chorus_fruit", "kiyamet:spoiled_food" -> 0;
            default -> {
                Recipes.Meal m = Recipes.meal(class_7923.field_41178.method_10221(s.method_7909()).method_12832());
                yield m != null ? m.days() : 7;
            }
        };
    }

    public static boolean spoils(class_1799 s) { return s.method_57826(class_9334.field_50075) && life(s) > 0; }

    static class_2487 tag(class_1799 s) { return s.method_58695(class_9334.field_49628, class_9279.field_49302).method_57461(); }

    public static long expires(class_1799 s) { return tag(s).method_68080("Expires", -1L); }

    /** Gives fresh food its date (rounded to whole days so stacks still merge). */
    public static void stamp(class_1937 level, class_1799 s) {
        if (expires(s) >= 0) return;
        long now = level.method_75260();
        class_2487 t = tag(s);
        t.method_10544("Expires", (now / DAY + life(s)) * DAY + DAY / 2);
        s.method_57379(class_9334.field_49628, class_9279.method_57456(t));
    }

    public static void delay(class_1799 s, long ticks) {
        long e = expires(s);
        if (e < 0) return;
        class_2487 t = tag(s);
        t.method_10544("Expires", e + ticks);
        s.method_57379(class_9334.field_49628, class_9279.method_57456(t));
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.method_3780() % 100 != 13) return;
            for (class_3222 p : server.method_3760().method_14571()) {
                if (p.method_68878()) continue;
                class_1661 inv = p.method_31548();
                long now = p.method_51469().method_75260();
                for (int i = 0; i < inv.method_5439(); i++) {
                    class_1799 s = inv.method_5438(i);
                    if (s.method_7960() || !spoils(s)) continue;
                    stamp(p.method_51469(), s);
                    if (now >= expires(s)) {
                        inv.method_5447(i, new class_1799(ModItems.get("spoiled_food"), s.method_7947()));
                        p.method_7353(net.minecraft.class_2561.method_43470(s.method_7964().getString() + " went bad.").method_27692(net.minecraft.class_124.field_1077), true);
                    }
                }
            }
        });
    }

    private Spoilage() {}
}
