package com.kiyamet.furniture;

import com.kiyamet.Kiyamet;
import com.kiyamet.registry.ModItems;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2464;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2754;
import net.minecraft.class_2758;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * Backpacks and money bags put down on the ground (sneak + right-click a block). Each is half a block tall, two fit in one
 * block on top of each other. Right-click picks the top one up again - contents and money stay inside.
 */
public class BagBlock extends class_2237 {
    /** 1-10 backpacks (by tier), 11 money bag, 12 gold money bag */
    public static final String[] IDS = {"", "canvas_satchel", "scout_pack", "hiker_pack", "survivor_pack", "ranger_pack", "medic_pack", "tactical_pack",
            "military_rucksack", "expedition_pack", "apocalypse_pack", "money_bag", "gold_money_bag"};
    public static final class_2758 LOWER = class_2758.method_11867("lower", 0, 12), UPPER = class_2758.method_11867("upper", 0, 12);
    public static final class_2754<class_2350> FACING = net.minecraft.class_2383.field_11177;
    public static class_2248 BLOCK;
    static final class_265 HALF = class_2248.method_9541(2, 0, 2, 14, 8, 14), FULL = class_2248.method_9541(2, 0, 2, 14, 16, 14);

    public BagBlock(class_4970.class_2251 p) {
        super(p);
        method_9590(field_10647.method_11664().method_11657(LOWER, 1).method_11657(UPPER, 0).method_11657(FACING, class_2350.field_11043));
    }

    static void register() {
        class_5321<class_2248> key = class_5321.method_29179(class_7924.field_41254, Kiyamet.id("placed_bag"));
        BLOCK = class_2378.method_39197(class_7923.field_41175, key, new BagBlock(class_4970.class_2251.method_9630(class_2246.field_10446).method_9632(0.5f).method_22488().method_9626(class_2498.field_11543).method_63500(key)));
    }

    public static int index(class_1792 it) {
        String id = class_7923.field_41178.method_10221(it).method_12832();
        for (int i = 1; i < IDS.length; i++) if (IDS[i].equals(id)) return i;
        return 0;
    }

    @Override protected MapCodec<? extends class_2237> method_53969() { return method_54094(BagBlock::new); }
    @Override protected void method_9515(class_2689.class_2690<class_2248, class_2680> b) { b.method_11667(LOWER, UPPER, FACING); }
    @Override protected class_2464 method_9604(class_2680 s) { return class_2464.field_11458; }
    @Override protected class_265 method_9530(class_2680 s, class_1922 l, class_2338 p, class_3726 c) { return s.method_11654(UPPER) > 0 ? FULL : HALF; }
    @Override public class_2586 method_10123(class_2338 pos, class_2680 state) { return new StorageBE(pos, state); }

    /** Called from the bag items: sneak + right-click on a block puts the bag down (or on top of another bag). */
    public static class_1269 place(class_1838 ctx) {
        class_1657 player = ctx.method_8036();
        if (player == null || !player.method_5715()) return class_1269.field_5811;
        class_1937 level = ctx.method_8045();
        class_1799 stack = ctx.method_8041();
        int idx = index(stack.method_7909());
        if (idx == 0) return class_1269.field_5811;
        if (level.method_8608()) return class_1269.field_5812;
        class_2338 clicked = ctx.method_8037();
        class_2680 cs = level.method_8320(clicked);
        if (cs.method_26204() instanceof BagBlock && cs.method_11654(UPPER) == 0 && level.method_8321(clicked) instanceof StorageBE be) {
            be.method_5447(1, stack.method_46651(1));
            level.method_8501(clicked, cs.method_11657(UPPER, idx));
        } else {
            class_2338 at = clicked.method_10093(ctx.method_8038());
            if (!level.method_8320(at).method_45474()) return class_1269.field_5814;
            level.method_8501(at, BLOCK.method_9564().method_11657(LOWER, idx).method_11657(UPPER, 0).method_11657(FACING, player.method_5735().method_10153()));
            if (level.method_8321(at) instanceof StorageBE be) be.method_5447(0, stack.method_46651(1));
        }
        level.method_8396(null, clicked, class_3417.field_14581.comp_349(), class_3419.field_15245, 0.8f, 0.9f);
        stack.method_7934(1);
        return class_1269.field_21466;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!(player instanceof class_3222 sp) || !(level.method_8321(pos) instanceof StorageBE be)) return class_1269.field_5812;
        int slot = state.method_11654(UPPER) > 0 ? 1 : 0;
        class_1799 it = be.method_5441(slot);
        if (!it.method_7960() && !sp.method_31548().method_7394(it)) sp.method_7328(it, false);
        if (slot == 1) level.method_8501(pos, state.method_11657(UPPER, 0));
        else { be.method_5448(); level.method_8650(pos, false); }
        level.method_8396(null, pos, class_3417.field_14581.comp_349(), class_3419.field_15245, 0.8f, 1.2f);
        return class_1269.field_21466;
    }
}
