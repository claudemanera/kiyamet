package com.kiyamet.furniture;

import com.kiyamet.Kiyamet;
import com.kiyamet.registry.ModItems;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1747;
import net.minecraft.class_1767;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2591;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/** TWD 1.7 furniture: 20 pieces made at the Furniture Table, 3D models, beds you can sleep in, chairs you can sit on, storage, a fridge. */
public final class Furniture {
    public enum Kind { DECOR, SEAT, BED, STORAGE, FRIDGE, LAMP }
    /** id, title, kind, storage slots, light, seat height (px), shape x1 y1 z1 x2 y2 z2, cost (item, n ...) */
    public record Def(String id, String title, Kind kind, int slots, int light, int seatY, int[] box, Object[] cost) {}

    public static final List<Def> DEFS = List.of(
            new Def("double_bed", "Double Bed", Kind.BED, 0, 0, 9, new int[]{0, 0, 0, 16, 9, 16}, new Object[]{"minecraft:red_wool", 4, "minecraft:white_wool", 2, "minecraft:oak_planks", 6}),
            new Def("royal_bed", "Royal Double Bed", Kind.BED, 0, 0, 10, new int[]{0, 0, 0, 16, 10, 16}, new Object[]{"minecraft:blue_wool", 4, "minecraft:white_wool", 2, "minecraft:dark_oak_planks", 6, "minecraft:gold_ingot", 2}),
            new Def("wardrobe", "Wardrobe", Kind.STORAGE, 54, 0, 0, new int[]{0, 0, 2, 16, 31, 16}, new Object[]{"minecraft:oak_planks", 12, "minecraft:chest", 2, "minecraft:iron_nugget", 4}),
            new Def("fridge", "Fridge", Kind.FRIDGE, 54, 0, 0, new int[]{1, 0, 1, 15, 30, 15}, new Object[]{"minecraft:iron_ingot", 10, "minecraft:snow_block", 4, "minecraft:redstone", 4, "kiyamet:circuit", 1}),
            new Def("kitchen_cabinet", "Kitchen Cabinet", Kind.STORAGE, 27, 0, 0, new int[]{0, 0, 1, 16, 16, 16}, new Object[]{"minecraft:spruce_planks", 6, "minecraft:smooth_stone_slab", 2}),
            new Def("kitchen_sink", "Kitchen Sink", Kind.DECOR, 0, 0, 0, new int[]{0, 0, 1, 16, 16, 16}, new Object[]{"minecraft:spruce_planks", 4, "minecraft:iron_ingot", 3, "minecraft:water_bucket", 1}),
            new Def("stove", "Stove", Kind.DECOR, 0, 0, 0, new int[]{0, 0, 1, 16, 16, 16}, new Object[]{"minecraft:iron_ingot", 6, "minecraft:furnace", 1, "minecraft:black_concrete", 2}),
            new Def("dining_table", "Dining Table", Kind.DECOR, 0, 0, 0, new int[]{0, 0, 0, 16, 14, 16}, new Object[]{"minecraft:oak_planks", 6, "minecraft:oak_log", 2}),
            new Def("wooden_chair", "Wooden Chair", Kind.SEAT, 0, 0, 7, new int[]{3, 0, 3, 13, 9, 13}, new Object[]{"minecraft:oak_planks", 3, "minecraft:stick", 2}),
            new Def("armchair", "Armchair", Kind.SEAT, 0, 0, 7, new int[]{1, 0, 1, 15, 10, 15}, new Object[]{"minecraft:brown_wool", 4, "minecraft:oak_planks", 2}),
            new Def("sofa", "Sofa", Kind.SEAT, 0, 0, 7, new int[]{0, 0, 1, 16, 10, 15}, new Object[]{"minecraft:gray_wool", 6, "minecraft:spruce_planks", 2}),
            new Def("coffee_table", "Coffee Table", Kind.DECOR, 0, 0, 0, new int[]{1, 0, 3, 15, 7, 13}, new Object[]{"minecraft:dark_oak_planks", 3, "minecraft:glass_pane", 2}),
            new Def("bookcase", "Bookcase", Kind.STORAGE, 27, 0, 0, new int[]{0, 0, 4, 16, 16, 16}, new Object[]{"minecraft:oak_planks", 6, "minecraft:book", 6}),
            new Def("office_desk", "Office Desk", Kind.STORAGE, 9, 0, 0, new int[]{0, 0, 2, 16, 13, 16}, new Object[]{"minecraft:birch_planks", 5, "minecraft:iron_ingot", 1}),
            new Def("floor_lamp", "Floor Lamp", Kind.LAMP, 0, 15, 0, new int[]{4, 0, 4, 12, 16, 12}, new Object[]{"minecraft:iron_ingot", 2, "minecraft:glowstone", 1, "minecraft:white_wool", 1}),
            new Def("television", "Television", Kind.LAMP, 0, 6, 0, new int[]{1, 0, 5, 15, 13, 12}, new Object[]{"minecraft:black_concrete", 3, "minecraft:glass_pane", 2, "kiyamet:circuit", 2, "minecraft:redstone", 2}),
            new Def("bathtub", "Bathtub", Kind.SEAT, 0, 0, 3, new int[]{0, 0, 2, 16, 9, 14}, new Object[]{"minecraft:white_concrete", 5, "minecraft:iron_ingot", 2, "minecraft:water_bucket", 1}),
            new Def("toilet", "Toilet", Kind.SEAT, 0, 0, 8, new int[]{3, 0, 2, 13, 14, 14}, new Object[]{"minecraft:white_concrete", 4, "minecraft:iron_nugget", 2}),
            new Def("gun_rack", "Gun Rack", Kind.STORAGE, 18, 0, 0, new int[]{0, 0, 11, 16, 16, 16}, new Object[]{"minecraft:dark_oak_planks", 4, "minecraft:iron_ingot", 3}),
            new Def("nightstand", "Nightstand", Kind.STORAGE, 9, 7, 0, new int[]{2, 0, 2, 14, 14, 14}, new Object[]{"minecraft:oak_planks", 3, "minecraft:torch", 1}));

    public static final Map<String, class_2248> BLOCKS = new LinkedHashMap<>();
    public static final List<class_2248> ALL = new ArrayList<>();
    public static class_2248 TABLE;
    public static class_2591<StorageBE> STORAGE_BE;
    public static class_1299<SeatEntity> SEAT;

    static class_2248 block(String name, Function<class_4970.class_2251, class_2248> f, class_4970.class_2251 p) {
        class_5321<class_2248> key = class_5321.method_29179(class_7924.field_41254, Kiyamet.id(name));
        class_2248 b = class_2378.method_39197(class_7923.field_41175, key, f.apply(p.method_63500(key)));
        ModItems.custom(name, ip -> new class_1747(b, ip.method_63685()));
        return b;
    }

    public static boolean isFurniture(class_2248 b) { return ALL.contains(b) || b == TABLE || b instanceof BagBlock; }

    public static void init() {
        for (Def d : DEFS) {
            class_4970.class_2251 p = class_4970.class_2251.method_9630(d.kind == Kind.FRIDGE || d.id.equals("stove") || d.id.equals("gun_rack") ? class_2246.field_10085 : class_2246.field_10161)
                    .method_9629(2f, 4f).method_22488().method_9631(s -> d.light);
            if (d.kind == Kind.BED) p = p.method_9626(class_2498.field_11543);
            if (d.id.equals("bathtub") || d.id.equals("toilet")) p = p.method_9626(class_2498.field_11544);
            class_2248 b = d.kind == Kind.BED ? block(d.id, pp -> new FurnitureBed(d.id.equals("royal_bed") ? class_1767.field_7966 : class_1767.field_7964, pp), p)
                    : block(d.id, pp -> new FurnitureBlock(pp, d), p);
            BLOCKS.put(d.id, b); ALL.add(b);
        }
        TABLE = block("furniture_table", FurnitureTableBlock::new, class_4970.class_2251.method_9630(class_2246.field_9980).method_9632(2.5f));
        BagBlock.register();
        List<class_2248> withBe = new ArrayList<>();
        for (Def d : DEFS) if (d.kind == Kind.STORAGE || d.kind == Kind.FRIDGE) withBe.add(BLOCKS.get(d.id));
        withBe.add(BagBlock.BLOCK);
        STORAGE_BE = class_2378.method_10230(class_7923.field_41181, Kiyamet.id("storage"), FabricBlockEntityTypeBuilder.create(StorageBE::new, withBe.toArray(new class_2248[0])).build());
        class_5321<class_1299<?>> sk = class_5321.method_29179(class_7924.field_41266, Kiyamet.id("seat"));
        SEAT = class_2378.method_39197(class_7923.field_41177, sk, class_1299.class_1300.<SeatEntity>method_5903(SeatEntity::new, class_1311.field_17715).method_17687(0.2f, 0.2f).method_5904().method_27299(8).method_5905(sk));
    }

    public static Def def(String id) { for (Def d : DEFS) if (d.id.equals(id)) return d; return null; }

    private Furniture() {}
}
