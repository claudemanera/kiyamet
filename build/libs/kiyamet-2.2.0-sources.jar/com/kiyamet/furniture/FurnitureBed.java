package com.kiyamet.furniture;

import net.minecraft.class_1767;
import net.minecraft.class_2244;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

/** A real bed (sleep, set spawn) drawn with a 3D block model instead of the vanilla bed renderer. */
public class FurnitureBed extends class_2244 {
    public FurnitureBed(class_1767 c, class_2251 p) { super(c, p); }
    @Override protected class_2464 method_9604(class_2680 s) { return class_2464.field_11458; }
    @Override public class_2586 method_10123(class_2338 pos, class_2680 state) { return null; }
}
