package com.kiyamet.furniture;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3222;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5558;

/** A furniture piece facing the player who placed it: decor, seat, storage, fridge or lamp. */
public class FurnitureBlock extends class_2383 implements class_2343 {
    public final Furniture.Def def;
    private final class_265[] shapes = new class_265[4];

    public FurnitureBlock(class_2251 p, Furniture.Def def) {
        super(p);
        this.def = def;
        method_9590(field_10647.method_11664().method_11657(field_11177, class_2350.field_11043));
        int[] b = def.box();
        for (class_2350 d : class_2350.class_2353.field_11062) shapes[d.method_10161()] = rotate(b, d);
    }

    static class_265 rotate(int[] b, class_2350 d) {
        double x1 = b[0], y1 = b[1], z1 = b[2], x2 = b[3], y2 = b[4], z2 = b[5];
        return switch (d) {
            case field_11035 -> class_2248.method_9541(16 - x2, y1, 16 - z2, 16 - x1, y2, 16 - z1);
            case field_11039 -> class_2248.method_9541(z1, y1, 16 - x2, z2, y2, 16 - x1);
            case field_11034 -> class_2248.method_9541(16 - z2, y1, x1, 16 - z1, y2, x2);
            default -> class_2248.method_9541(x1, y1, z1, x2, y2, z2);
        };
    }

    @Override protected MapCodec<? extends class_2383> method_53969() { return method_54094(p -> new FurnitureBlock(p, def)); }
    @Override protected void method_9515(class_2689.class_2690<class_2248, class_2680> b) { b.method_11667(field_11177); }
    @Override public class_2680 method_9605(class_1750 ctx) { return method_9564().method_11657(field_11177, ctx.method_8042().method_10153()); }
    @Override protected class_265 method_9530(class_2680 s, class_1922 l, class_2338 p, class_3726 c) { return shapes[s.method_11654(field_11177).method_10161()]; }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return def.kind() == Furniture.Kind.STORAGE || def.kind() == Furniture.Kind.FRIDGE ? new StorageBE(pos, state) : null;
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> type) {
        if (level.method_8608() || def.kind() != Furniture.Kind.FRIDGE) return null;
        return (l, p, s, be) -> { if (be instanceof StorageBE sb) sb.fridgeTick(l); };
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!(player instanceof class_3222 sp)) return class_1269.field_5812;
        switch (def.kind()) {
            case SEAT -> SeatEntity.sit(sp, pos, def.seatY() / 16.0);
            case STORAGE, FRIDGE -> { if (level.method_8321(pos) instanceof StorageBE be) sp.method_17355(be); }
            case DECOR -> {
                if (def.id().equals("kitchen_sink")) level.method_8396(null, pos, net.minecraft.class_3417.field_14834, net.minecraft.class_3419.field_15245, 0.6f, 1.2f);
                else return class_1269.field_5811;
            }
            default -> { return class_1269.field_5811; }
        }
        return class_1269.field_21466;
    }
}
