package com.kiyamet.furniture;

import com.kiyamet.npc.Shop;
import com.kiyamet.ui.PanelMenu;
import com.kiyamet.ui.Ui;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_747;

/** Furniture Table: pick a piece, pay the materials, get the furniture. */
public class FurnitureTableBlock extends class_2248 {
    public FurnitureTableBlock(class_2251 p) { super(p); }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (player instanceof class_3222 sp) Menu.open(sp);
        return class_1269.field_5812;
    }

    public static class Menu extends PanelMenu {
        static final int[] SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};

        static void open(class_3222 p) { p.method_17355(new class_747((id, inv, pl) -> new Menu(id, inv, p), class_2561.method_43470("Furniture Table"))); }

        private Menu(int id, class_1661 inv, class_3222 p) { super(id, inv, p); redraw(); }

        boolean has(Furniture.Def d) {
            Object[] c = d.cost();
            for (int i = 0; i < c.length; i += 2) if (Shop.count(player, (String) c[i]) < (Integer) c[i + 1]) return false;
            return true;
        }

        @Override
        protected void draw() {
            c.method_5447(4, Ui.icon(Furniture.TABLE.method_8389(), Ui.text("Furniture Table", class_124.field_1065, class_124.field_1067), Ui.text("Click a piece to build it", class_124.field_1080)));
            for (int i = 0; i < Furniture.DEFS.size(); i++) {
                Furniture.Def d = Furniture.DEFS.get(i);
                boolean ok = has(d);
                List<class_2561> lore = new ArrayList<>();
                lore.add(Ui.text(switch (d.kind()) { case BED -> "Bed: sleep and set spawn"; case SEAT -> "Sit on it"; case STORAGE -> d.slots() + " slots of storage";
                    case FRIDGE -> "Freezer (18) stops food spoiling, fridge (36) slows it 4x"; case LAMP -> "Gives light"; default -> "Decoration"; }, class_124.field_1075));
                Object[] c2 = d.cost();
                for (int j = 0; j < c2.length; j += 2) {
                    String id = (String) c2[j]; int n = (Integer) c2[j + 1], have = Shop.count(player, id);
                    lore.add(class_2561.method_43470((have >= n ? "✔ " : "✘ ") + n + "× ").method_10852(new class_1799(Ui.item(id)).method_7964()).method_27692(have >= n ? class_124.field_1060 : class_124.field_1080));
                }
                lore.add(Ui.text(ok ? "Click to build!" : "Missing materials", ok ? class_124.field_1054 : class_124.field_1063));
                class_1799 icon = new class_1799(Furniture.BLOCKS.get(d.id()).method_8389());
                c.method_5447(SLOTS[i], Ui.glint(Ui.lore(icon, lore), ok));
            }
            c.method_5447(49, Ui.icon(class_1802.field_8077, Ui.text("Close", class_124.field_1061)));
        }

        @Override
        protected boolean click(int slot, class_1713 type) {
            if (slot == 49) { player.method_7346(); return false; }
            for (int i = 0; i < Furniture.DEFS.size(); i++) {
                if (SLOTS[i] != slot) continue;
                Furniture.Def d = Furniture.DEFS.get(i);
                if (!player.method_68878() && !has(d)) return false;
                Object[] c2 = d.cost();
                if (!player.method_68878()) for (int j = 0; j < c2.length; j += 2) Shop.take(player, (String) c2[j], (Integer) c2[j + 1]);
                Shop.give(player, new class_1799(Furniture.BLOCKS.get(d.id()).method_8389()));
                player.method_51469().method_8396(null, player.method_24515(), class_3417.field_20671, class_3419.field_15245, 0.8f, 1f);
                return true;
            }
            return false;
        }
    }
}
