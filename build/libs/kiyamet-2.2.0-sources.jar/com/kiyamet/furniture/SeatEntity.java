package com.kiyamet.furniture;

import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;

/** Invisible seat for chairs, sofas, toilets and bathtubs. Disappears when nobody sits on it. */
public class SeatEntity extends class_1297 {
    public SeatEntity(class_1299<?> t, class_1937 l) { super(t, l); field_5960 = true; }

    public static void sit(class_3222 p, class_2338 pos, double h) {
        class_3218 level = p.method_51469();
        if (!level.method_18467(SeatEntity.class, new net.minecraft.class_238(pos)).isEmpty()) return;
        SeatEntity s = Furniture.SEAT.method_5883(level, class_3730.field_16461);
        if (s == null) return;
        s.method_5814(pos.method_10263() + 0.5, pos.method_10264() + h - 0.1, pos.method_10260() + 0.5);
        level.method_8649(s);
        p.method_5873(s, true, true);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (!method_73183().method_8608() && (method_5685().isEmpty() || method_73183().method_8320(method_24515()).method_26215() && method_73183().method_8320(method_24515().method_10074()).method_26215())) method_31472();
    }

    @Override protected void method_5693(class_2945.class_9222 b) {}
    @Override protected void method_5749(class_11368 in) {}
    @Override protected void method_5652(class_11372 out) {}
    @Override public boolean method_64397(class_3218 l, class_1282 s, float f) { return false; }
}
