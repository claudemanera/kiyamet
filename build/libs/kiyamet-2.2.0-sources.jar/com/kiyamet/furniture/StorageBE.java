package com.kiyamet.furniture;

import com.kiyamet.food.Spoilage;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_2624;
import net.minecraft.class_2680;
import net.minecraft.class_3917;

/** Storage for furniture (wardrobe, cabinets, fridge...) and the placed bags. Fridge: top 2 rows freezer, the rest cold. */
public class StorageBE extends class_2624 {
    class_2371<class_1799> items;

    public StorageBE(class_2338 pos, class_2680 state) {
        super(Furniture.STORAGE_BE, pos, state);
        items = class_2371.method_10213(size(state), class_1799.field_8037);
    }

    static int size(class_2680 s) {
        if (s.method_26204() instanceof FurnitureBlock f) return f.def.slots();
        return 2;
    }

    public boolean fridge() { return method_11010().method_26204() instanceof FurnitureBlock f && f.def.kind() == Furniture.Kind.FRIDGE; }

    void fridgeTick(class_1937 level) {
        if (level.method_75260() % 20 != 0) return;
        boolean changed = false;
        for (int i = 0; i < items.size(); i++) {
            class_1799 s = items.get(i);
            if (s.method_7960() || !Spoilage.spoils(s)) continue;
            Spoilage.stamp(level, s);
            Spoilage.delay(s, i < 18 ? 20 : 15);     // freezer: stopped; fridge: 4x slower
            changed = true;
        }
        if (changed) method_5431();
    }

    @Override protected class_2561 method_17823() { return method_11010().method_26204().method_9518(); }
    @Override protected class_2371<class_1799> method_11282() { return items; }
    @Override protected void method_11281(class_2371<class_1799> list) { items = list; }
    @Override public int method_5439() { return items.size(); }

    @Override
    protected class_1703 method_5465(int id, class_1661 inv) {
        int rows = Math.max(1, items.size() / 9);
        class_3917<class_1707> t = switch (rows) { case 1 -> class_3917.field_18664; case 2 -> class_3917.field_18665; case 3 -> class_3917.field_17326; case 4 -> class_3917.field_18666; case 5 -> class_3917.field_18667; default -> class_3917.field_17327; };
        return new class_1707(t, id, inv, this, rows);
    }

    @Override
    protected void method_11014(class_11368 in) {
        super.method_11014(in);
        items = class_2371.method_10213(size(method_11010()), class_1799.field_8037);
        class_1262.method_5429(in, items);
    }

    @Override
    protected void method_11007(class_11372 out) {
        super.method_11007(out);
        class_1262.method_5426(out, items);
    }
}
