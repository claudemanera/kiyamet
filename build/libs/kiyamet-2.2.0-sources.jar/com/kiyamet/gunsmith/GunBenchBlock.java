package com.kiyamet.gunsmith;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3965;

public class GunBenchBlock extends class_2248 {
    public GunBenchBlock(class_2251 p) { super(p); }

    @Override
    protected class_1269 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (hand != class_1268.field_5808) return class_1269.field_5811;
        if (player instanceof class_3222 sp) GunBenchMenu.open(sp);
        return class_1269.field_5812;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (player instanceof class_3222 sp) GunBenchMenu.open(sp);
        return class_1269.field_5812;
    }
}
