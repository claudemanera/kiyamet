package com.kiyamet.gunsmith;

import com.kiyamet.item.GunItem;
import com.kiyamet.npc.Shop;
import com.kiyamet.skill.Skill;
import com.kiyamet.skill.SkillManager;
import com.kiyamet.ui.PanelMenu;
import com.kiyamet.ui.Ui;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_747;

/**
 * Gunsmith Bench (1.9, simpler): hold a gun. Top row = tabs (Scope, Muzzle, Light, Magazine, Paint, Repair).
 * The middle shows the choices for that tab: click one to fit it, click the fitted one again to take it off.
 */
public class GunBenchMenu extends PanelMenu {
    private static final int[] TABS = {1, 2, 3, 5, 6, 7};
    private static final String[] TAB_NAMES = {"Scope", "Muzzle", "Light", "Magazine", "Paint", "Repair"};
    private static final int[] OPTS = {19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
    private int tab = 0;

    public static void open(class_3222 p) {
        p.method_17355(new class_747((id, inv, pl) -> new GunBenchMenu(id, inv, p), class_2561.method_43470("Gunsmith Bench")));
    }

    private GunBenchMenu(int id, class_1661 inv, class_3222 p) { super(id, inv, p); redraw(); }

    private class_1799 gun() { return player.method_6047(); }
    private boolean isGun() { return gun().method_7909() instanceof GunItem; }
    private int eng() { return SkillManager.get(player).level(Skill.ENGINEERING); }

    private String costText(String[] c) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < c.length; i += 2) { if (b.length() > 0) b.append(", "); b.append(c[i + 1]).append("× ").append(new class_1799(Ui.item(c[i])).method_7964().getString()); }
        return b.toString();
    }

    private boolean canPay(String[] c) {
        if (player.method_68878()) return true;
        for (int i = 0; i < c.length; i += 2) if (Shop.count(player, c[i]) < Integer.parseInt(c[i + 1])) return false;
        return true;
    }

    private void pay(String[] c) {
        if (player.method_68878()) return;
        for (int i = 0; i < c.length; i += 2) Shop.take(player, c[i], Integer.parseInt(c[i + 1]));
    }

    static class_1792 partIcon(String id) {
        return switch (id) {
            case "red_dot" -> class_1802.field_8725; case "holo" -> class_1802.field_8141; case "acog" -> class_1802.field_27070; case "sniper" -> class_1802.field_8449;
            case "short" -> class_1802.field_8675; case "long" -> class_1802.field_8076; case "flashlight" -> class_1802.field_16539; case "laser" -> class_1802.field_8530;
            case "extended" -> Ui.item("kiyamet:magazine"); case "drum" -> Ui.item("kiyamet:magazine_drum"); default -> class_1802.field_8077;
        };
    }

    @Override
    protected void draw() {
        class_1799 g = gun();
        class_1792[] tabIcons = {class_1802.field_27070, class_1802.field_8675, class_1802.field_16539, Ui.item("kiyamet:magazine"), class_1802.field_8264, class_1802.field_8782};
        c.method_5447(8, Ui.glint(Ui.icon(Ui.item("kiyamet:ak47"), Ui.text("BUILD GUNS", class_124.field_1065, class_124.field_1067), Ui.text("Make any of the " + com.kiyamet.registry.ModItems.WEAPONS.length + " guns and all ammo here", class_124.field_1080), Ui.text("Click to open", class_124.field_1054)), true));
        for (int i = 0; i < TABS.length; i++)
            c.method_5447(TABS[i], Ui.glint(Ui.icon(tabIcons[i], Ui.text(TAB_NAMES[i], i == tab ? class_124.field_1060 : class_124.field_1068, class_124.field_1067),
                    Ui.text(i == tab ? "▶ open" : "Click to open", class_124.field_1080)), i == tab));
        if (g.method_7960() || !(isGun() || tab == 5 && g.method_7963())) {
            c.method_5447(4, Ui.icon(class_1802.field_8077, Ui.text("Hold a gun in your hand", class_124.field_1061), Ui.text("(or any tool, for the Repair tab)", class_124.field_1080)));
            c.method_5447(49, Ui.icon(class_1802.field_8077, Ui.text("Close", class_124.field_1061)));
            return;
        }
        List<class_2561> info = new ArrayList<>();
        if (isGun()) for (GunMods.Slot sl : GunMods.Slot.values()) { String cur = GunMods.get(g, sl); info.add(Ui.text(TAB_NAMES[sl.ordinal()] + ": " + (cur.isEmpty() ? "-" : GunMods.part(cur).title()), cur.isEmpty() ? class_124.field_1063 : class_124.field_1075)); }
        if (isGun()) info.add(Ui.text("Paint: " + GunMods.paintOf(GunMods.paint(g)).title(), class_124.field_1076));
        c.method_5447(4, Ui.glint(Ui.lore(g.method_7972(), info), true));
        c.method_5447(49, Ui.icon(class_1802.field_8077, Ui.text("Close", class_124.field_1061)));
        if (tab < 4) {
            GunMods.Slot sl = GunMods.Slot.values()[tab];
            String cur = GunMods.get(g, sl);
            int k = 0;
            for (GunMods.Part part : GunMods.PARTS) {
                if (part.slot() != sl) continue;
                boolean on = cur.equals(part.id()), engOk = eng() >= part.eng() || player.method_68878(), pay = canPay(part.cost());
                List<class_2561> lore = new ArrayList<>();
                lore.add(Ui.text(part.effect(), class_124.field_1075));
                if (on) lore.add(Ui.text("✔ Fitted · click to take it off", class_124.field_1060));
                else {
                    lore.add(Ui.text("Cost: " + costText(part.cost()), pay ? class_124.field_1080 : class_124.field_1061));
                    lore.add(Ui.text("Needs Engineering " + part.eng(), engOk ? class_124.field_1080 : class_124.field_1061));
                    lore.add(Ui.text(engOk && pay ? "Click to fit" : "Not available yet", engOk && pay ? class_124.field_1054 : class_124.field_1061));
                }
                c.method_5447(OPTS[k * 2], Ui.glint(Ui.icon(partIcon(part.id()), Ui.text(part.title(), on ? class_124.field_1060 : class_124.field_1068, class_124.field_1067), lore.toArray(new class_2561[0])), on));
                k++;
            }
        } else if (tab == 4) {
            String curPaint = GunMods.paint(g);
            for (int i = 0; i < GunMods.PAINTS.size() && i < OPTS.length; i++) {
                GunMods.Paint pt = GunMods.PAINTS.get(i);
                boolean on = curPaint.equals(pt.id());
                class_1792 icon = pt.dye().isEmpty() ? class_1802.field_8705 : Ui.item(pt.dye());
                class_1799 st = Ui.icon(icon, class_2561.method_43470(pt.title()).method_27694(x -> x.method_10978(false).method_10982(true).method_36139(pt.color() == -1 ? 0xFFFFFF : pt.color())),
                        Ui.text(on ? "✔ Current paint" : pt.dye().isEmpty() ? "Free" : "Costs 1× " + new class_1799(Ui.item(pt.dye())).method_7964().getString(), on ? class_124.field_1060 : class_124.field_1080));
                c.method_5447(OPTS[i], Ui.glint(st, on));
            }
        } else {
            int dmg = g.method_7919(), max = Math.max(1, g.method_7936());
            c.method_5447(22, Ui.glint(Ui.icon(class_1802.field_8782, Ui.text(dmg == 0 ? "Fully repaired" : "Repair: " + (100 - dmg * 100 / max) + "% → 100%", class_124.field_1075, class_124.field_1067),
                    Ui.text("Uses a repair kit (full), a metal plate (+50%) or an iron ingot (+25%)", class_124.field_1080), Ui.text("Click to repair", class_124.field_1054)), dmg > 0));
        }
    }

    @Override
    protected boolean click(int slot, class_1713 type) {
        if (slot == 49) { player.method_7346(); return false; }
        if (slot == 8) { GunCraftMenu.open(player, 0); return false; }
        for (int i = 0; i < TABS.length; i++) if (slot == TABS[i]) { tab = i; return true; }
        class_1799 g = gun();
        if (tab == 5) {
            if (slot != 22 || !g.method_7963() || g.method_7919() == 0) return false;
            int max = g.method_7936();
            if (player.method_68878() || Shop.take(player, "kiyamet:repair_kit", 1)) g.method_7974(0);
            else if (Shop.take(player, "kiyamet:metal_plate", 1)) g.method_7974(Math.max(0, g.method_7919() - max / 2));
            else if (Shop.take(player, "minecraft:iron_ingot", 1)) g.method_7974(Math.max(0, g.method_7919() - max / 4));
            else { player.method_7353(class_2561.method_43470("You need iron, a metal plate or a repair kit.").method_27692(class_124.field_1061), true); return false; }
            player.method_51469().method_8396(null, player.method_24515(), class_3417.field_14559, class_3419.field_15248, 0.6f, 1.2f);
            return true;
        }
        if (!isGun()) return false;
        if (tab == 4) {
            for (int i = 0; i < GunMods.PAINTS.size() && i < OPTS.length; i++) if (OPTS[i] == slot) {
                GunMods.Paint pt = GunMods.PAINTS.get(i);
                if (GunMods.paint(g).equals(pt.id())) return false;
                if (!pt.dye().isEmpty() && !player.method_68878() && !Shop.take(player, pt.dye(), 1)) { player.method_7353(class_2561.method_43470("You need the dye.").method_27692(class_124.field_1061), true); return false; }
                GunMods.setPaint(g, pt.id());
                player.method_51469().method_8396(null, player.method_24515(), class_3417.field_28391, class_3419.field_15248, 1f, 1f);
                return true;
            }
            return false;
        }
        GunMods.Slot sl = GunMods.Slot.values()[tab];
        int k = 0;
        for (GunMods.Part part : GunMods.PARTS) {
            if (part.slot() != sl) continue;
            if (slot == OPTS[k * 2]) {
                if (GunMods.get(g, sl).equals(part.id())) { GunMods.set(g, sl, ""); player.method_7353(class_2561.method_43470(part.title() + " taken off.").method_27692(class_124.field_1080), true); return true; }
                if (eng() < part.eng() && !player.method_68878()) { player.method_7353(class_2561.method_43470("Needs Engineering " + part.eng()).method_27692(class_124.field_1061), true); return false; }
                if (!canPay(part.cost())) { player.method_7353(class_2561.method_43470("Missing: " + costText(part.cost())).method_27692(class_124.field_1061), true); return false; }
                pay(part.cost());
                GunMods.set(g, sl, part.id());
                SkillManager.addXp(player, Skill.ENGINEERING, 20 + part.eng() / 4);
                player.method_51469().method_8396(null, player.method_24515(), class_3417.field_22463, class_3419.field_15248, 1f, 1.1f);
                player.method_7353(class_2561.method_43470(part.title() + " fitted!").method_27695(class_124.field_1060, class_124.field_1067), true);
                return true;
            }
            k++;
        }
        return false;
    }
}
