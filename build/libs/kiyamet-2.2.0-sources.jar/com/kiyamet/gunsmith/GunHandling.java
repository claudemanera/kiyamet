package com.kiyamet.gunsmith;

import com.kiyamet.ammo.Ammo;
import com.kiyamet.item.GunItem;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_7923;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

/**
 * 1.9 gun handling: every gun has a clip that you reload with R (or it reloads by itself when you pull the trigger on
 * an empty clip). Guns wear with every shot; a worn gun can jam - press R to clear it. Repair at the Gunsmith Bench.
 * Rename your gun on an anvil or with /twd gunname.
 */
public final class GunHandling {
    static class_2487 tag(class_1799 s) { return s.method_58695(class_9334.field_49628, class_9279.field_49302).method_57461(); }
    static void put(class_1799 s, class_2487 t) { s.method_57379(class_9334.field_49628, class_9279.method_57456(t)); }

    public static int clipSize(class_1799 gun) {
        String id = class_7923.field_41178.method_10221(gun.method_7909()).method_12832();
        Ammo.Type t = Ammo.typeFor(id);
        GunItem.Mode m = gun.method_7909() instanceof GunItem g ? g.stats().mode() : GunItem.Mode.SINGLE;
        int base = switch (t) {
            case PISTOL -> id.contains("revolver") || id.contains("magnum") || id.equals("hand_cannon") ? 6 : id.equals("machine_pistol") ? 24 : 12;
            case SHELL -> id.equals("auto_shotgun") || id.equals("ak_shotgun") ? 10 : id.equals("sawed_off") ? 2 : 6;
            case SNIPER -> id.equals("anti_materiel_rifle") ? 3 : 5;
            case ROCKET -> 1;
            case PLASMA -> 20;
            default -> id.equals("rpk") ? 60 : m == GunItem.Mode.SINGLE && id.contains("rifle") ? 8 : 30;
        };
        String mag = GunMods.get(gun, GunMods.Slot.MAG);
        return mag.equals("drum") ? base * 2 : mag.equals("extended") ? base * 3 / 2 : base;
    }

    public static int clip(class_1799 gun) { return tag(gun).method_68083("Clip", 0); }
    public static boolean jammed(class_1799 gun) { return tag(gun).method_68566("Jammed", false); }
    public static float wear(class_1799 gun) { return gun.method_7963() ? gun.method_7919() / (float) Math.max(1, gun.method_7936()) : 0; }

    /** called before a shot: false = no shot (empty, jammed or broken) */
    public static boolean beforeShot(class_3222 p, class_1799 gun, int rounds) {
        if (jammed(gun)) {
            p.method_51469().method_8396(null, p.method_24515(), class_3417.field_14701, class_3419.field_15248, 0.8f, 0.7f);
            p.method_7353(class_2561.method_43470("JAMMED! Press R to clear it.").method_27695(class_124.field_1061, class_124.field_1067), true);
            return false;
        }
        if (gun.method_7963() && gun.method_7919() >= gun.method_7936() - 1) {
            p.method_7353(class_2561.method_43470("This gun is worn out - repair it at the Gunsmith Bench.").method_27692(class_124.field_1061), true);
            return false;
        }
        if (clip(gun) <= 0) { reload(p, gun); return false; }
        class_2487 t = tag(gun);
        t.method_10569("Clip", Math.max(0, clip(gun) - rounds));
        float w = wear(gun);
        float eng = Math.min(0.6f, com.kiyamet.skill.SkillManager.get(p).level(com.kiyamet.skill.Skill.ENGINEERING) / 1500f);
        if (p.method_59922().method_43057() < (0.004f + w * w * 0.12f) * (1f - eng)) {
            t.method_10556("Jammed", true);
            put(gun, t);
            p.method_51469().method_8396(null, p.method_24515(), class_3417.field_14765.comp_349(), class_3419.field_15248, 1f, 0.5f);
            p.method_7353(class_2561.method_43470("Your gun jammed! Press R to clear it.").method_27695(class_124.field_1061, class_124.field_1067), true);
            return false;
        }
        put(gun, t);
        if (gun.method_7963() && !p.method_68878() && p.method_59922().method_43057() >= eng * 0.8f) gun.method_7974(Math.min(gun.method_7936() - 1, gun.method_7919() + 1));
        return true;
    }

    /** R: clear a jam, or fill the clip from your magazines / loose rounds */
    public static void reload(class_3222 p, class_1799 gun) {
        if (p.method_7357().method_7904(gun)) return;
        class_2487 t = tag(gun);
        if (t.method_68566("Jammed", false)) {
            t.method_10556("Jammed", false); put(gun, t);
            p.method_7357().method_62835(gun, 25);
            p.method_51469().method_8396(null, p.method_24515(), class_3417.field_14626.comp_349(), class_3419.field_15248, 1f, 1.3f);
            p.method_7353(class_2561.method_43470("Jam cleared.").method_27692(class_124.field_1060), true);
            com.kiyamet.skill.SkillManager.addXp(p, com.kiyamet.skill.Skill.ENGINEERING, 6);
            return;
        }
        int size = clipSize(gun), have = clip(gun);
        if (have >= size) { p.method_7353(class_2561.method_43470("Clip full (" + have + "/" + size + ")").method_27692(class_124.field_1080), true); return; }
        String id = class_7923.field_41178.method_10221(gun.method_7909()).method_12832();
        Ammo.Type type = Ammo.typeFor(id);
        int got = 0;
        if (p.method_68878()) got = size - have;
        else while (have + got < size && Ammo.take(p, type, 1)) got++;
        if (got == 0) {
            p.method_51469().method_8396(null, p.method_24515(), class_3417.field_14701, class_3419.field_15248, 0.8f, 1.4f);
            p.method_7353(class_2561.method_43470("No " + type.label + " ammo to reload!").method_27692(class_124.field_1061), true);
            return;
        }
        t.method_10569("Clip", have + got); put(gun, t);
        int time = type == Ammo.Type.SHELL ? 12 + got * 6 : type == Ammo.Type.ROCKET ? 50 : type == Ammo.Type.SNIPER ? 45 : 32;
        p.method_7357().method_62835(gun, Math.min(70, time));
        p.method_51469().method_8396(null, p.method_24515(), class_3417.field_14860.comp_349(), class_3419.field_15248, 1f, 0.9f);
        p.method_51469().method_8396(null, p.method_24515(), class_3417.field_15131, class_3419.field_15248, 0.6f, 1.6f);
        p.method_7353(class_2561.method_43470("Reloading... " + (have + got) + "/" + size).method_27692(class_124.field_1054), true);
    }

    public static class_2561 hud(class_1799 gun) {
        int w = Math.round(wear(gun) * 100);
        return class_2561.method_43470("▮ " + clip(gun) + "/" + clipSize(gun) + "  ·  wear " + w + "%" + (jammed(gun) ? "  ·  JAMMED" : ""))
                .method_27692(jammed(gun) ? class_124.field_1061 : clip(gun) == 0 ? class_124.field_1065 : w > 70 ? class_124.field_1054 : class_124.field_1068);
    }

    public static void init() {
        net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback.EVENT.register((d, ctx, env) -> d.register(net.minecraft.class_2170.method_9247("twd")
                .then(net.minecraft.class_2170.method_9247("gunname").then(net.minecraft.class_2170.method_9244("name", com.mojang.brigadier.arguments.StringArgumentType.greedyString()).executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    class_1799 g = p.method_6047();
                    if (!(g.method_7909() instanceof GunItem)) { p.method_64398(class_2561.method_43470("Hold a gun first.").method_27692(class_124.field_1061)); return 0; }
                    String n = com.mojang.brigadier.arguments.StringArgumentType.getString(c, "name");
                    if (n.length() > 32) n = n.substring(0, 32);
                    g.method_57379(class_9334.field_49631, class_2561.method_43470(n).method_27694(s -> s.method_10978(false).method_10977(class_124.field_1065)));
                    p.method_64398(class_2561.method_43470("Your gun is now called \"" + n + "\".").method_27692(class_124.field_1065));
                    return 1;
                })))));
    }

    private GunHandling() {}
}
