package com.kiyamet.gunsmith;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_9279;
import net.minecraft.class_9280;
import net.minecraft.class_9334;

/** Attachments and paint stored on a gun. The item model shows them (custom_model_data strings + tint). */
public final class GunMods {
    public enum Slot { SCOPE, MUZZLE, LIGHT, MAG }

    public record Part(Slot slot, String id, String title, String effect, int eng, String[] cost) {}
    public record Paint(String id, String title, int color, String dye) {}

    public static final List<Part> PARTS = List.of(
            new Part(Slot.SCOPE, "red_dot", "Red Dot Sight", "+10% damage", 10, new String[]{"minecraft:iron_ingot", "2", "minecraft:redstone", "1"}),
            new Part(Slot.SCOPE, "holo", "Holo Sight", "+12% damage, easier to hit", 40, new String[]{"kiyamet:circuit", "1", "minecraft:glass_pane", "2"}),
            new Part(Slot.SCOPE, "acog", "ACOG Scope", "+25% range, +10% damage", 80, new String[]{"kiyamet:lens", "1", "minecraft:iron_ingot", "3"}),
            new Part(Slot.SCOPE, "sniper", "Sniper Scope", "+60% range, +20% damage, 15% slower", 150, new String[]{"kiyamet:lens", "2", "kiyamet:circuit", "1", "minecraft:iron_ingot", "4"}),
            new Part(Slot.MUZZLE, "short", "Short Silencer", "much quieter, -3% damage", 15, new String[]{"minecraft:iron_ingot", "3", "minecraft:white_wool", "1"}),
            new Part(Slot.MUZZLE, "long", "Long Silencer", "silent, +10% range, -6% damage", 60, new String[]{"kiyamet:metal_plate", "2", "minecraft:white_wool", "2"}),
            new Part(Slot.LIGHT, "flashlight", "Flashlight", "night vision while held", 20, new String[]{"minecraft:glowstone_dust", "2", "minecraft:iron_ingot", "2"}),
            new Part(Slot.LIGHT, "laser", "Laser Sight", "+5% damage, much easier to hit", 90, new String[]{"kiyamet:circuit", "1", "minecraft:redstone", "2", "kiyamet:lens", "1"}),
            new Part(Slot.MAG, "extended", "Extended Magazine", "20% faster firing", 20, new String[]{"minecraft:iron_ingot", "4"}),
            new Part(Slot.MAG, "drum", "Drum Magazine", "35% faster firing, a bit louder", 100, new String[]{"kiyamet:metal_plate", "2", "minecraft:iron_ingot", "4"}));

    public static final List<Paint> PAINTS = List.of(
            new Paint("none", "Factory", -1, ""), new Paint("olive", "Olive Drab", 0x8DA35A, "minecraft:green_dye"),
            new Paint("desert", "Desert Tan", 0xE0BE86, "minecraft:yellow_dye"), new Paint("arctic", "Arctic", 0xDCE8F2, "minecraft:white_dye"),
            new Paint("crimson", "Crimson", 0xD0605A, "minecraft:red_dye"), new Paint("navy", "Navy", 0x6680C8, "minecraft:blue_dye"),
            new Paint("gold", "Gold Plated", 0xF2CC55, "minecraft:gold_ingot"), new Paint("shadow", "Shadow", 0x62626E, "minecraft:black_dye"),
            new Paint("rose", "Rose", 0xEEA2CF, "minecraft:pink_dye"), new Paint("jungle", "Jungle", 0x68B884, "minecraft:lime_dye"),
            new Paint("walker", "Walker Blood", 0x7E9A62, "kiyamet:walker_guts"));

    static class_2487 tag(class_1799 s) { return s.method_58695(class_9334.field_49628, class_9279.field_49302).method_57461(); }

    public static String get(class_1799 s, Slot slot) { return tag(s).method_68564("Mod" + slot.name(), ""); }
    public static String paint(class_1799 s) { return tag(s).method_68564("Paint", "none"); }
    public static boolean has(class_1799 s, String id) { for (Slot sl : Slot.values()) if (get(s, sl).equals(id)) return true; return false; }

    public static void set(class_1799 s, Slot slot, String id) {
        class_2487 t = tag(s);
        if (id.isEmpty()) t.method_10551("Mod" + slot.name()); else t.method_10582("Mod" + slot.name(), id);
        s.method_57379(class_9334.field_49628, class_9279.method_57456(t));
        refresh(s);
    }

    public static void setPaint(class_1799 s, String id) {
        class_2487 t = tag(s);
        t.method_10582("Paint", id);
        s.method_57379(class_9334.field_49628, class_9279.method_57456(t));
        refresh(s);
    }

    public static Part part(String id) { for (Part p : PARTS) if (p.id.equals(id)) return p; return null; }
    public static Paint paintOf(String id) { for (Paint p : PAINTS) if (p.id.equals(id)) return p; return PAINTS.get(0); }

    /** Rebuild the model data (what the gun looks like) and the lore (what's on it). */
    public static void refresh(class_1799 s) {
        List<String> strings = new ArrayList<>();
        for (Slot sl : Slot.values()) strings.add(get(s, sl).isEmpty() ? "none" : get(s, sl));
        Paint p = paintOf(paint(s));
        s.method_57379(class_9334.field_49637, new class_9280(List.of(), List.of(), strings, List.of(p.color)));
        List<class_2561> lore = new ArrayList<>();
        for (Slot sl : Slot.values()) {
            Part part = part(get(s, sl));
            if (part != null) lore.add(class_2561.method_43470("⚙ " + part.title + " (" + part.effect + ")").method_27694(st -> st.method_10978(false).method_10977(net.minecraft.class_124.field_1080)));
        }
        if (!p.id.equals("none")) lore.add(class_2561.method_43470("Paint: " + p.title).method_27694(st -> st.method_10978(false).method_36139(p.color)));
        if (lore.isEmpty()) s.method_57381(class_9334.field_49632); else s.method_57379(class_9334.field_49632, new net.minecraft.class_9290(lore));
    }

    private GunMods() {}
}
