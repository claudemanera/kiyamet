package com.kiyamet.item;

import com.kiyamet.Kiyamet;
import com.kiyamet.world.NoiseSystem;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1311;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3857;
import net.minecraft.class_4770;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/** Thrown bombs (1.6): thrown far like a splash potion, go off where they land. */
public class BombProjectile extends class_3857 {
    private static final class_5321<class_1299<?>> KEY = class_5321.method_29179(class_7924.field_41266, Kiyamet.id("thrown_bomb"));
    public static final class_1299<BombProjectile> TYPE = class_2378.method_39197(class_7923.field_41177, KEY,
            class_1299.class_1300.<BombProjectile>method_5903(BombProjectile::new, class_1311.field_17715).method_17687(0.3f, 0.3f).method_27299(6).method_27300(10).method_5905(KEY));
    public static final String[] NEW = {"frag_grenade", "molotov", "smoke_grenade", "flashbang"};

    public BombProjectile(class_1299<? extends BombProjectile> t, class_1937 level) { super(t, level); }
    public BombProjectile(class_1937 level, class_1309 owner, class_1799 stack) { super(TYPE, owner, level, stack); }

    @Override protected class_1792 method_16942() { return com.kiyamet.registry.ModItems.get("frag_grenade"); }

    /** Throw one: far, in an arc, like a splash potion. */
    public static void toss(class_3218 level, class_1657 p, class_1799 stack) {
        BombProjectile b = new BombProjectile(level, p, stack.method_46651(1));
        b.method_24919(p, p.method_36455(), p.method_36454(), -12f, 1.5f, 0.6f);
        level.method_8649(b);
        level.method_8396(null, p.method_24515(), class_3417.field_14910, class_3419.field_15248, 0.8f, 0.7f);
    }

    public static class ThrownItem extends class_1792 {
        public ThrownItem(class_1793 p) { super(p); }
        @Override
        public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
            class_1799 s = player.method_5998(hand);
            if (level instanceof class_3218 sl) {
                toss(sl, player, s);
                player.method_7357().method_62835(s, 20);
                if (!player.method_68878()) s.method_7934(1);
            }
            return class_1269.field_5812;
        }
    }

    @Override
    protected void method_7488(class_239 hit) {
        super.method_7488(hit);
        if (!(method_73183() instanceof class_3218 level) || method_31481()) return;
        class_243 c = method_73189();
        String id = class_7923.field_41178.method_10221(method_7495().method_7909()).method_12832();
        class_1309 owner = method_24921() instanceof class_1309 l ? l : null;
        class_238 box = new class_238(c, c);
        switch (id) {
            case "emp_bomb" -> {
                for (class_1309 e : level.method_8390(class_1309.class, box.method_1014(16), e -> e != owner)) {
                    e.method_6092(new class_1293(class_1294.field_5909, 240, 5)); e.method_6092(new class_1293(class_1294.field_5911, 240, 2));
                    if (e instanceof com.kiyamet.robot.RobotEntity) e.method_64397(level, level.method_48963().method_48809(), 30);
                }
                level.method_65096(class_2398.field_29644, c.field_1352, c.field_1351 + 1, c.field_1350, 300, 6, 1.5, 6, 0.5);
                level.method_8396(null, class_2338.method_49638(c), class_3417.field_19344, class_3419.field_15248, 2f, 0.6f);
            }
            case "black_hole_bomb" -> {
                for (class_1309 e : level.method_8390(class_1309.class, box.method_1014(14), e -> e != owner)) {
                    class_243 pull = c.method_1020(e.method_73189()).method_1029().method_1021(1.8);
                    e.method_18800(pull.field_1352, pull.field_1351 + 0.3, pull.field_1350); e.field_6037 = true;
                    e.method_64397(level, owner == null ? level.method_48963().method_48831() : level.method_48963().method_48815(this, owner), 20);
                }
                level.method_65096(class_2398.field_23190, c.field_1352, c.field_1351, c.field_1350, 500, 2, 2, 2, 0.3);
                level.method_8396(null, class_2338.method_49638(c), class_3417.field_14981, class_3419.field_15248, 0.8f, 1.6f);
            }
            case "frag_grenade" -> {
                level.method_8437(this, c.field_1352, c.field_1351, c.field_1350, 3.2f, class_1937.class_7867.field_40888);
                for (class_1309 e : level.method_8390(class_1309.class, box.method_1014(5), e -> e != owner)) e.method_64397(level, level.method_48963().method_48819(this, owner), 14);
                NoiseSystem.make(level, class_2338.method_49638(c), 48, 10);
            }
            case "molotov" -> {
                class_2338 at = class_2338.method_49638(c);
                for (int dx = -3; dx <= 3; dx++) for (int dz = -3; dz <= 3; dz++) {
                    if (dx * dx + dz * dz > 10 || field_5974.method_43048(4) == 0) continue;
                    for (int dy = 2; dy >= -2; dy--) {
                        class_2338 p = at.method_10069(dx, dy, dz);
                        if (level.method_8320(p).method_26215() && !level.method_8320(p.method_10074()).method_26215()) { level.method_8501(p, class_4770.method_24416(level, p)); break; }
                    }
                }
                for (class_1309 e : level.method_8390(class_1309.class, box.method_1014(4), e -> e != owner)) e.method_5639(10);
                level.method_65096(class_2398.field_11240, c.field_1352, c.field_1351 + 0.5, c.field_1350, 150, 2, 0.5, 2, 0.05);
                level.method_8396(null, at, class_3417.field_15081, class_3419.field_15248, 1f, 0.8f);
                level.method_8396(null, at, class_3417.field_15013, class_3419.field_15248, 1f, 0.8f);
                NoiseSystem.make(level, at, 24, 6);
            }
            case "smoke_grenade" -> {
                for (int i = 0; i < 6; i++) level.method_65096(class_2398.field_17431, c.field_1352, c.field_1351 + 0.5, c.field_1350, 40, 3, 1.5, 3, 0.02);
                for (class_1309 e : level.method_8390(class_1309.class, box.method_1014(9), e -> e != owner)) {
                    e.method_6092(new class_1293(class_1294.field_5919, 200, 0));
                    if (e instanceof class_1308 m && m.method_5968() instanceof class_1657) m.method_5980(null);
                }
                level.method_8396(null, class_2338.method_49638(c), class_3417.field_15102, class_3419.field_15248, 1f, 0.6f);
            }
            case "flashbang" -> {
                for (class_1309 e : level.method_8390(class_1309.class, box.method_1014(10), e -> e != owner)) {
                    e.method_6092(new class_1293(class_1294.field_5919, 120, 0)); e.method_6092(new class_1293(class_1294.field_5916, 160, 0));
                    e.method_6092(new class_1293(class_1294.field_5909, 120, 3));
                    if (e instanceof class_1308 m) m.method_5980(null);
                }
                level.method_65096(class_2398.field_11236, c.field_1352, c.field_1351 + 0.5, c.field_1350, 2, 0.2, 0.2, 0.2, 0);
                level.method_65096(class_2398.field_11207, c.field_1352, c.field_1351 + 0.5, c.field_1350, 80, 1, 1, 1, 0.3);
                level.method_8396(null, class_2338.method_49638(c), class_3417.field_15188, class_3419.field_15248, 3f, 1.4f);
                NoiseSystem.make(level, class_2338.method_49638(c), 40, 8);
            }
            default -> {}
        }
        method_31472();
    }

    public static void init() {
        for (String s : NEW) com.kiyamet.registry.ModItems.custom(s, p -> new ThrownItem(p.method_7889(16)));
    }
}
