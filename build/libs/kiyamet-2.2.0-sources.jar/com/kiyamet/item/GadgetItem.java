package com.kiyamet.item;

import com.kiyamet.skill.Skill;
import com.kiyamet.skill.SkillManager;
import com.kiyamet.world.NoiseSystem;
import com.mojang.datafixers.util.Pair;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_3965;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

/** The 20 lab gadgets (except healing syringe and auto turret, which have their own classes). */
public class GadgetItem extends class_1792 {
    public static final class_6862<class_3195> SCANNABLE = class_6862.method_40092(class_7924.field_41246, com.kiyamet.Kiyamet.id("scannable"));
    private static final Map<UUID, Long> FROZEN = new HashMap<>();
    private static final Map<UUID, Long> CLONES = new HashMap<>();
    private final String id;

    public GadgetItem(class_1793 p, String id) { super(p); this.id = id; }

    private static List<class_1309> enemies(class_3218 l, class_243 at, double r) {
        List<class_1309> out = new ArrayList<>();
        for (class_1309 e : l.method_18467(class_1309.class, new class_238(at, at).method_1014(r))) if (e instanceof class_1569 && e.method_5805()) out.add(e);
        return out;
    }

    @Override
    public class_1269 method_7836(class_1937 lvl, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (!(player instanceof class_3222 p) || !(lvl instanceof class_3218 level)) return class_1269.field_5812;
        int cd = 20;
        boolean consume = false;
        switch (id) {
            case "flashlight" -> { p.method_6092(new class_1293(class_1294.field_5925, 1200, 0, true, false)); cd = 40; }
            case "night_vision" -> { p.method_6092(new class_1293(class_1294.field_5925, 6000, 0, true, false)); cd = 100; }
            case "sonic_lure" -> {
                class_3965 b = Raycast.block(p, 40);
                class_2338 at = b.method_17783() == class_239.class_240.field_1333 ? p.method_24515() : b.method_17777();
                NoiseSystem.make(level, at, 48, 20);
                for (class_1308 m : level.method_18467(class_1308.class, new class_238(at).method_1014(40))) if (m instanceof class_1569) m.method_5942().method_6337(at.method_10263(), at.method_10264(), at.method_10260(), 1.0);
                level.method_65096(class_2398.field_11224, at.method_10263() + .5, at.method_10264() + 1.5, at.method_10260() + .5, 20, .5, .5, .5, 1);
                level.method_8396(null, at, class_3417.field_14793.comp_349(), class_3419.field_15248, 3f, 1f);
                cd = 200; consume = true;
            }
            case "grappling_gun" -> {
                class_3965 b = Raycast.block(p, 36);
                if (b.method_17783() == class_239.class_240.field_1333) return class_1269.field_5814;
                class_243 d = b.method_17784().method_1020(p.method_73189()).method_1029().method_1021(2.0);
                p.method_18800(d.field_1352, Math.max(0.5, d.field_1351 + 0.4), d.field_1350); p.field_6037 = true; p.field_6017 = 0;
                cd = 30;
            }
            case "vein_miner" -> {
                class_3965 b = Raycast.block(p, 6);
                if (b.method_17783() == class_239.class_240.field_1333) return class_1269.field_5814;
                class_2680 start = level.method_8320(b.method_17777());
                List<class_2338> todo = new ArrayList<>(List.of(b.method_17777())), done = new ArrayList<>();
                while (!todo.isEmpty() && done.size() < 48) {
                    class_2338 at = todo.remove(0);
                    if (done.contains(at) || level.method_8320(at).method_26204() != start.method_26204()) continue;
                    done.add(at);
                    for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) todo.add(at.method_10069(dx, dy, dz));
                }
                for (class_2338 at : done) level.method_8651(at, true, p);
                SkillManager.addXp(p, Skill.MINING, done.size() * 3);
                cd = 40;
            }
            case "jetpack" -> {
                class_243 v = p.method_18798();
                p.method_18800(v.field_1352 + p.method_5828(1f).field_1352 * 0.4, 1.1, v.field_1350 + p.method_5828(1f).field_1350 * 0.4); p.field_6037 = true;
                p.method_6092(new class_1293(class_1294.field_5906, 80, 0, true, false));
                level.method_65096(class_2398.field_11240, p.method_23317(), p.method_23318() + 0.5, p.method_23321(), 30, 0.2, 0.1, 0.2, 0.02);
                cd = 30;
            }
            case "flamethrower" -> {
                class_243 look = p.method_5828(1f);
                for (class_1309 e : level.method_18467(class_1309.class, p.method_5829().method_1014(8))) {
                    if (e == p) continue;
                    class_243 to = e.method_73189().method_1020(p.method_73189());
                    if (to.method_1033() < 8 && to.method_1029().method_1026(look) > 0.75) { e.method_5639(5); e.method_64397(level, level.method_48963().method_48802(p), 4); }
                }
                for (int i = 1; i < 16; i++) { class_243 at = p.method_33571().method_1019(look.method_1021(i * 0.5)); level.method_65096(class_2398.field_11240, at.field_1352, at.field_1351, at.field_1350, 4, 0.15 * i / 4, 0.15 * i / 4, 0.15 * i / 4, 0.01); }
                NoiseSystem.make(level, p.method_24515(), 20, 4);
                cd = 8;
            }
            case "gravity_glove" -> {
                List<class_1309> es = Raycast.entities(p, 16, 0.5);
                if (es.isEmpty()) return class_1269.field_5814;
                class_1309 e = es.get(0);
                class_243 look = p.method_5828(1f);
                e.method_18800(look.field_1352 * 2.2, 1.0, look.field_1350 * 2.2); e.field_6037 = true;
                e.method_64397(level, level.method_48963().method_48802(p), 6);
                cd = 40;
            }
            case "structure_scanner" -> {
                Pair<class_2338, class_6880<class_3195>> found = level.method_14178().method_12129().method_12103(level, level.method_30349()
                        .method_30530(class_7924.field_41246).method_46735(SCANNABLE), p.method_24515(), 64, false);
                if (found == null) p.method_64398(class_2561.method_43471("kiyamet.msg.scan_none").method_27692(class_124.field_1080));
                else {
                    class_2338 at = found.getFirst();
                    String name = found.getSecond().method_40230().map(k -> k.method_29177().method_12832()).orElse("?");
                    int dist = (int) Math.sqrt(at.method_10262(p.method_24515()));
                    p.method_64398(class_2561.method_43469("kiyamet.msg.scan_found", name.replace('_', ' '), at.method_10263(), at.method_10260(), dist).method_27692(class_124.field_1075));
                    SkillManager.addXp(p, Skill.EXPLORATION, 20);
                }
                cd = 200;
            }
            case "drone_controller" -> {
                for (class_1309 e : level.method_18467(class_1309.class, p.method_5829().method_1014(48))) if (e instanceof class_1569) e.method_6092(new class_1293(class_1294.field_5912, 300, 0));
                cd = 400;
            }
            case "clone_device" -> {   // 1.6: clones you into a permanent companion with your name, 2 uses
                if (com.kiyamet.npc.RecruitMenu.companions(p) >= com.kiyamet.npc.RecruitMenu.MAX_COMPANIONS) {
                    p.method_7353(net.minecraft.class_2561.method_43470("You already lead " + com.kiyamet.npc.RecruitMenu.MAX_COMPANIONS + " companions.").method_27692(net.minecraft.class_124.field_1061), true);
                    return class_1269.field_5814;
                }
                int lv = Math.max(10, Math.min(com.kiyamet.npc.HumanEntity.MAX_LEVEL, SkillManager.get(p).totalPower() / 40));
                com.kiyamet.npc.HumanEntity h = com.kiyamet.npc.ModHumans.spawn(level, p.method_24515().method_10078(), com.kiyamet.npc.Faction.SURVIVOR, com.kiyamet.npc.Role.GUARD, lv, "");
                if (h == null) return class_1269.field_5814;
                h.setOwner(p);
                h.method_5665(net.minecraft.class_2561.method_43470(p.method_5477().getString()));
                h.method_5673(net.minecraft.class_1304.field_6173, p.method_6047().method_7909() == this ? new class_1799(net.minecraft.class_1802.field_8371) : p.method_6047().method_7972());
                level.method_65096(class_2398.field_23190, h.method_23317(), h.method_23318() + 1, h.method_23321(), 120, 0.4, 1, 0.4, 0.05);
                level.method_8396(null, h.method_24515(), class_3417.field_14941, class_3419.field_15248, 1f, 1f);
                net.minecraft.class_2487 t = stack.method_58695(net.minecraft.class_9334.field_49628, net.minecraft.class_9279.field_49302).method_57461();
                int used = t.method_68083("CloneUses", 0) + 1;
                t.method_10569("CloneUses", used);
                stack.method_57379(net.minecraft.class_9334.field_49628, net.minecraft.class_9279.method_57456(t));
                p.method_64398(net.minecraft.class_2561.method_43470("A clone of you steps out. " + (used >= 2 ? "The device burns out." : "1 charge left.")).method_27695(net.minecraft.class_124.field_1076, net.minecraft.class_124.field_1067));
                if (used >= 2) consume = true;
                cd = 200;
            }
            case "teleport_gun" -> {
                class_3965 b = Raycast.block(p, 64);
                if (b.method_17783() == class_239.class_240.field_1333) return class_1269.field_5814;
                class_2338 at = b.method_17777().method_10093(b.method_17780());
                p.method_5859(at.method_10263() + 0.5, at.method_10264(), at.method_10260() + 0.5); p.field_6017 = 0;
                level.method_8396(null, at, class_3417.field_14879, class_3419.field_15248, 1f, 1f);
                cd = 60;
            }
            case "emp_bomb" -> { BombProjectile.toss(level, p, stack); cd = 20; consume = true; }
            case "laser_rifle" -> {
                List<class_1309> es = Raycast.entities(p, 64, 0.3);
                if (!es.isEmpty()) es.get(0).method_64397(level, level.method_48963().method_48802(p), 16);
                class_243 to = Raycast.impact(p, 64), from = p.method_33571();
                for (int i = 0; i < 40; i++) { class_243 at = from.method_1019(to.method_1020(from).method_1021(i / 40.0)); level.method_65096(class_2398.field_11207, at.field_1352, at.field_1351, at.field_1350, 1, 0, 0, 0, 0); }
                cd = 15;
            }
            case "shield_generator" -> {
                p.method_6092(new class_1293(class_1294.field_5907, 400, 2)); p.method_6092(new class_1293(class_1294.field_5898, 400, 4));
                cd = 1200;
            }
            case "time_stopper" -> {
                for (class_1309 e : enemies(level, p.method_73189(), 24)) if (e instanceof class_1308 m) { m.method_5977(true); FROZEN.put(m.method_5667(), level.method_75260() + 100); }
                level.method_65096(class_2398.field_11215, p.method_23317(), p.method_23318() + 1, p.method_23321(), 300, 8, 2, 8, 0.5);
                cd = 1800;
            }
            case "black_hole_bomb" -> { BombProjectile.toss(level, p, stack); cd = 40; consume = true; }
            case "energy_sword" -> {
                class_243 look = p.method_5828(1f);
                p.method_18800(look.field_1352 * 1.6, 0.2, look.field_1350 * 1.6); p.field_6037 = true;
                for (class_1309 e : level.method_18467(class_1309.class, p.method_5829().method_1014(4))) {
                    if (e == p) continue;
                    if (e.method_73189().method_1020(p.method_73189()).method_1029().method_1026(look) > 0.4) e.method_64397(level, level.method_48963().method_48802(p), 22);
                }
                level.method_65096(class_2398.field_11227, p.method_23317() + look.field_1352 * 2, p.method_23318() + 1, p.method_23321() + look.field_1350 * 2, 3, 1, 0.2, 1, 0);
                cd = 40;
            }
            case "auto_turret" -> {
                com.kiyamet.ally.TurretDrone t = com.kiyamet.ally.ModAllies.TURRET.method_5883(level, class_3730.field_16461);
                if (t != null) {
                    class_243 at = p.method_73189().method_1019(p.method_5720().method_18805(1, 0, 1).method_1029().method_1021(1.5));
                    t.method_5814(at.field_1352, at.field_1351, at.field_1350);
                    t.method_36456(p.method_36454()); t.field_6283 = p.method_36454();
                    t.bonus = com.kiyamet.skill.SkillManager.get(p).level(com.kiyamet.skill.Skill.ENGINEERING) / 100f;
                    level.method_8649(t);
                    level.method_8396(null, t.method_24515(), class_3417.field_14785, class_3419.field_15248, 0.6f, 1.3f);
                    p.method_7353(net.minecraft.class_2561.method_43470("Auto Turret deployed. Sneak + right-click it to pack it up.").method_27692(net.minecraft.class_124.field_1060), true);
                }
                cd = 40; consume = true;
            }
            default -> { return class_1269.field_5811; }
        }
        SkillManager.addXp(p, Skill.ENGINEERING, 3);
        if (consume && !p.method_68878()) stack.method_7934(1);
        p.method_7357().method_62835(stack, cd);
        return class_1269.field_21466;
    }

    /** Unfreezes time-stopped mobs and removes expired clones. */
    public static void tick(class_3218 level) {
        long now = level.method_75260();
        FROZEN.entrySet().removeIf(en -> {
            if (en.getValue() > now) return false;
            if (level.method_66347(en.getKey()) instanceof class_1308 m) { m.method_5977(false); return true; }
            return false;
        });
        CLONES.entrySet().removeIf(en -> {
            if (en.getValue() > now) return false;
            var e = level.method_66347(en.getKey());
            if (e != null) { e.method_31472(); return true; }
            return false;
        });
    }
}
