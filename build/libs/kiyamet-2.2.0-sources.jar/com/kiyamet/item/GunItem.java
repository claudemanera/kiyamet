package com.kiyamet.item;

import com.kiyamet.skill.Skill;
import com.kiyamet.skill.SkillManager;
import com.kiyamet.world.NoiseSystem;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;

/**
 * Guns: fire instantly, hitscan. Since 1.5 they use bullets of their ammo type (magazines first, then loose rounds).
 * Damage grows with Firearms level (+50% at 999).
 */
public class GunItem extends class_1792 {
    public enum Mode { SINGLE, DOUBLE, SHOTGUN, BURST3, PIERCE, EXPLODE, VOID, HARPOON, TESLA, HOMING, CANNON }
    public record Stats(float damage, int cooldown, Mode mode, int noise, int effect) {}
    private final Stats stats;

    public GunItem(class_1793 p, Stats stats) { super(p); this.stats = stats; }
    public Stats stats() { return stats; }

    public static Stats statsFor(String id) {
        return switch (id) {
            case "arrow_pistol" -> new Stats(5, 10, Mode.SINGLE, 20, 0);
            case "arrow_rifle" -> new Stats(10, 20, Mode.SINGLE, 24, 0);
            case "double_arrow_rifle" -> new Stats(9, 24, Mode.DOUBLE, 24, 0);
            case "arrow_shotgun" -> new Stats(4, 30, Mode.SHOTGUN, 28, 0);
            case "silenced_arrow_pistol" -> new Stats(8, 12, Mode.SINGLE, 0, 0);
            case "arrow_repeater" -> new Stats(4, 5, Mode.SINGLE, 24, 0);
            case "toxic_arrow_rifle" -> new Stats(10, 24, Mode.SINGLE, 24, 1);
            case "frost_arrow_gun" -> new Stats(12, 24, Mode.SINGLE, 24, 2);
            case "arrow_sniper" -> new Stats(30, 50, Mode.PIERCE, 40, 0);
            case "incendiary_repeater" -> new Stats(7, 28, Mode.BURST3, 28, 3);
            case "tesla_arrow_gun" -> new Stats(14, 30, Mode.TESLA, 30, 0);
            case "arrow_gatling" -> new Stats(5, 3, Mode.SINGLE, 32, 4);
            case "harpoon_gun" -> new Stats(18, 24, Mode.HARPOON, 20, 0);
            case "arrow_railgun" -> new Stats(60, 40, Mode.PIERCE, 40, 0);
            case "arrow_launcher" -> new Stats(20, 40, Mode.EXPLODE, 48, 0);
            case "void_arrow_launcher" -> new Stats(25, 60, Mode.VOID, 40, 0);
            case "homing_arrow_gun" -> new Stats(16, 20, Mode.HOMING, 24, 0);
            case "apocalypse_cannon" -> new Stats(45, 80, Mode.CANNON, 64, 0);
            case "service_pistol" -> new Stats(6, 9, Mode.SINGLE, 20, 0);
            case "compact_pistol" -> new Stats(5, 7, Mode.SINGLE, 16, 0);
            case "tactical_pistol" -> new Stats(8, 9, Mode.SINGLE, 20, 0);
            case "hand_cannon" -> new Stats(16, 22, Mode.SINGLE, 30, 0);
            case "revolver" -> new Stats(11, 16, Mode.SINGLE, 24, 0);
            case "magnum_revolver" -> new Stats(18, 22, Mode.PIERCE, 30, 0);
            case "machine_pistol" -> new Stats(4, 4, Mode.SINGLE, 24, 0);
            case "golden_pistol" -> new Stats(22, 20, Mode.PIERCE, 30, 0);
            case "flare_pistol" -> new Stats(8, 30, Mode.SINGLE, 36, 3);
            case "ak47" -> new Stats(9, 6, Mode.SINGLE, 28, 0);
            case "akm_classic" -> new Stats(10, 6, Mode.SINGLE, 28, 0);
            case "ak74" -> new Stats(9, 5, Mode.SINGLE, 26, 0);
            case "aks74u" -> new Stats(7, 4, Mode.SINGLE, 26, 0);
            case "ak_tactical" -> new Stats(11, 5, Mode.SINGLE, 26, 0);
            case "rpk" -> new Stats(8, 3, Mode.SINGLE, 32, 0);
            case "golden_ak" -> new Stats(14, 5, Mode.SINGLE, 28, 0);
            case "ak12" -> new Stats(12, 5, Mode.BURST3, 26, 0);
            case "ak_grenadier" -> new Stats(10, 30, Mode.EXPLODE, 40, 0);
            case "bolt_sniper" -> new Stats(28, 45, Mode.PIERCE, 40, 0);
            case "hunting_rifle" -> new Stats(20, 35, Mode.SINGLE, 34, 0);
            case "marksman_rifle" -> new Stats(18, 18, Mode.PIERCE, 32, 0);
            case "anti_materiel_rifle" -> new Stats(55, 70, Mode.PIERCE, 56, 0);
            case "ghillie_sniper" -> new Stats(30, 45, Mode.PIERCE, 14, 0);
            case "silent_sniper" -> new Stats(26, 40, Mode.PIERCE, 0, 0);
            case "lever_rifle" -> new Stats(14, 14, Mode.SINGLE, 26, 0);
            case "longshot_rifle" -> new Stats(48, 55, Mode.PIERCE, 36, 2);
            case "survivor_smg" -> new Stats(5, 4, Mode.SINGLE, 24, 0);
            case "pump_shotgun" -> new Stats(6, 22, Mode.SHOTGUN, 30, 0);
            case "sawed_off" -> new Stats(8, 26, Mode.SHOTGUN, 32, 0);
            case "auto_shotgun" -> new Stats(5, 9, Mode.SHOTGUN, 32, 0);
            case "ak_shotgun" -> new Stats(6, 11, Mode.SHOTGUN, 30, 0);
            case "behemoth_shotgun" -> new Stats(14, 40, Mode.SHOTGUN, 48, 4);
            default -> new Stats(5, 20, Mode.SINGLE, 20, 0);
        };
    }

    // enchantment levels of the shot being fired (set in use())
    private int fire, frost, vamp, boom, head, slayer, ap, toxic, shock, stop, rico, mark, bleed;
    private boolean ricocheting;

    private void hit(class_3218 level, class_3222 p, class_1309 e, float dmg) {
        net.minecraft.class_5819 r = p.method_59922();
        if (slayer > 0 && (e.method_5864().method_20210(net.minecraft.class_3483.field_46232) || e instanceof com.kiyamet.entity.KZombie)) dmg *= 1 + 0.15f * slayer;
        if (ap > 0 && e.method_6096() > 0) dmg *= 1 + 0.1f * ap;
        if (head > 0 && r.method_43057() < 0.08f * head) {
            dmg *= 2;
            level.method_65096(class_2398.field_11205, e.method_23317(), e.method_23320(), e.method_23321(), 12, 0.2, 0.2, 0.2, 0.2);
            p.method_7353(net.minecraft.class_2561.method_43470("HEADSHOT!").method_27695(net.minecraft.class_124.field_1061, net.minecraft.class_124.field_1067), true);
        }
        e.method_64397(level, level.method_48963().method_48803(null, p), dmg);
        if (toxic > 0) e.method_6092(new class_1293(class_1294.field_5899, 60 + 30 * toxic, toxic - 1));
        if (bleed > 0) e.method_6092(new class_1293(class_1294.field_5920, 40 + 20 * bleed, bleed > 2 ? 1 : 0));
        if (mark > 0) e.method_6092(new class_1293(class_1294.field_5912, 100 * mark, 0));
        if (stop > 0) { class_243 k = e.method_73189().method_1020(p.method_73189()).method_1029().method_1021(0.35 * stop); e.method_5762(k.field_1352, 0.1 + 0.05 * stop, k.field_1350); e.field_6037 = true; }
        if (shock > 0) {
            int n = 0;
            for (class_1309 o : level.method_8390(class_1309.class, e.method_5829().method_1014(5), o -> o != p && o != e && o.method_5805() && o instanceof net.minecraft.class_1569)) {
                if (n++ >= shock) break;
                o.method_64397(level, level.method_48963().method_48809(), 2 + shock);
                trail(level, e.method_73189().method_1031(0, 1, 0), o.method_73189().method_1031(0, 1, 0), class_2398.field_29644);
            }
        }
        if (rico > 0 && !ricocheting && r.method_43057() < 0.12f * rico) {
            for (class_1309 o : level.method_8390(class_1309.class, e.method_5829().method_1014(8), o -> o != p && o != e && o.method_5805() && o instanceof net.minecraft.class_1569)) {
                ricocheting = true; trail(level, e.method_73189().method_1031(0, 1, 0), o.method_73189().method_1031(0, 1, 0), class_2398.field_11205); hit(level, p, o, dmg * 0.7f); ricocheting = false; break;
            }
        }
        if (fire > 0) e.method_5639(3 * fire);
        if (frost > 0) { e.method_6092(new class_1293(class_1294.field_5909, 40 + 30 * frost, frost - 1)); e.method_32317(Math.min(300, e.method_32312() + 50 * frost)); }
        if (vamp > 0) p.method_6025(dmg * 0.06f * vamp);
        if (boom > 0) {
            level.method_65096(boom > 1 ? class_2398.field_11221 : class_2398.field_11236, e.method_23317(), e.method_23318() + 1, e.method_23321(), 1, 0, 0, 0, 0);
            level.method_8396(null, e.method_24515(), class_3417.field_15152.comp_349(), class_3419.field_15248, 0.6f, 1.4f);
            for (class_1309 o : level.method_8390(class_1309.class, e.method_5829().method_1014(1.5 + boom), o -> o != p && o != e && o.method_5805()))
                o.method_64397(level, level.method_48963().method_48819(p, p), dmg * 0.35f * boom);
        }
        switch (stats.effect) {
            case 1 -> e.method_6092(new class_1293(class_1294.field_5899, 120, 1));
            case 2 -> { e.method_6092(new class_1293(class_1294.field_5909, 80, 2)); e.method_32317(Math.min(300, e.method_32312() + 80)); }
            case 3 -> e.method_5639(5);
            default -> {}
        }
    }

    private static void trail(class_3218 level, class_243 from, class_243 to, class_2394 type) {
        class_243 d = to.method_1020(from);
        int n = (int) Math.min(60, d.method_1033() * 2);
        for (int i = 0; i < n; i++) { class_243 at = from.method_1019(d.method_1021(i / (double) n)); level.method_65096(type, at.field_1352, at.field_1351, at.field_1350, 1, 0, 0, 0, 0); }
    }

    @Override
    public class_1269 method_7836(class_1937 lvl, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (!(player instanceof class_3222 p) || !(lvl instanceof class_3218 level)) return class_1269.field_5812;
        int arrows = stats.mode == Mode.SHOTGUN ? 1 : stats.mode == Mode.BURST3 ? 3 : stats.mode == Mode.DOUBLE ? 2 : 1;
        int archery = SkillManager.get(p).level(Skill.ARCHERY);
        int saver = com.kiyamet.enchant.Enchants.gunLevel(level, stack, "ammo_saver");
        int cost = p.method_59922().method_43057() < Math.min(0.4f, archery / 2500f) + saver * 0.12f ? 0 : arrows;   // Firearms and Ammo Saver save rounds
        String gunId = net.minecraft.class_7923.field_41178.method_10221(stack.method_7909()).method_12832();
        com.kiyamet.ammo.Ammo.Type ammo = com.kiyamet.ammo.Ammo.typeFor(gunId);
        if (!com.kiyamet.gunsmith.GunHandling.beforeShot(p, stack, cost)) {   // 1.9: clip, wear and jams
            p.method_7357().method_62835(stack, 6);
            return class_1269.field_5814;
        }
        // 1.5 attachments
        String scope = com.kiyamet.gunsmith.GunMods.get(stack, com.kiyamet.gunsmith.GunMods.Slot.SCOPE), muzzle = com.kiyamet.gunsmith.GunMods.get(stack, com.kiyamet.gunsmith.GunMods.Slot.MUZZLE);
        String light = com.kiyamet.gunsmith.GunMods.get(stack, com.kiyamet.gunsmith.GunMods.Slot.LIGHT), mag = com.kiyamet.gunsmith.GunMods.get(stack, com.kiyamet.gunsmith.GunMods.Slot.MAG);
        float modDmg = switch (scope) { case "red_dot" -> 1.10f; case "holo" -> 1.12f; case "acog" -> 1.10f; case "sniper" -> 1.20f; default -> 1f; }
                * (muzzle.equals("short") ? 0.97f : muzzle.equals("long") ? 0.94f : 1f) * (light.equals("laser") ? 1.05f : 1f);
        double modRange = (scope.equals("acog") ? 1.25 : scope.equals("sniper") ? 1.6 : 1) * (muzzle.equals("long") ? 1.1 : 1);
        float modCd = (scope.equals("sniper") ? 1.15f : 1f) * (mag.equals("extended") ? 0.8f : mag.equals("drum") ? 0.65f : 1f);
        double aim = (scope.equals("holo") ? 0.25 : 0) + (light.equals("laser") ? 0.35 : 0);
        int modNoise = muzzle.equals("long") ? -99 : muzzle.equals("short") ? -2 : mag.equals("drum") ? 1 : 0;
        int silent = com.kiyamet.enchant.Enchants.gunLevel(level, stack, "silent_rounds");
        float dmg = modDmg * stats.damage * (1f + SkillManager.get(p).level(Skill.ARCHERY) / 2000f) * (1f + 0.12f * com.kiyamet.enchant.Enchants.gunLevel(level, stack, "high_caliber"));
        fire = com.kiyamet.enchant.Enchants.gunLevel(level, stack, "incendiary_rounds");
        frost = com.kiyamet.enchant.Enchants.gunLevel(level, stack, "frost_rounds");
        vamp = com.kiyamet.enchant.Enchants.gunLevel(level, stack, "vampiric_rounds");
        boom = com.kiyamet.enchant.Enchants.gunLevel(level, stack, "explosive_tips");
        head = com.kiyamet.enchant.Enchants.gunLevel(level, stack, "headhunter");
        slayer = com.kiyamet.enchant.Enchants.gunLevel(level, stack, "walker_slayer");
        ap = com.kiyamet.enchant.Enchants.gunLevel(level, stack, "armor_piercing");
        toxic = com.kiyamet.enchant.Enchants.gunLevel(level, stack, "toxic_rounds");
        shock = com.kiyamet.enchant.Enchants.gunLevel(level, stack, "shock_rounds");
        stop = com.kiyamet.enchant.Enchants.gunLevel(level, stack, "stopping_power");
        rico = com.kiyamet.enchant.Enchants.gunLevel(level, stack, "ricochet");
        mark = com.kiyamet.enchant.Enchants.gunLevel(level, stack, "marked_target");
        bleed = com.kiyamet.enchant.Enchants.gunLevel(level, stack, "bleeding_rounds");
        class_243 eye = p.method_33571().method_1031(0, -0.1, 0);
        double range = modRange * (stats.mode == Mode.PIERCE ? 96 : 48) * (1 + 0.15 * com.kiyamet.enchant.Enchants.gunLevel(level, stack, "long_barrel"));
        switch (stats.mode) {
            case SINGLE, HOMING -> {
                List<class_1309> es = Raycast.entities(p, range, (stats.mode == Mode.HOMING ? 2.5 : 0.3) + aim);
                if (!es.isEmpty()) hit(level, p, es.get(0), dmg);
                trail(level, eye, Raycast.impact(p, range), class_2398.field_11205);
            }
            case DOUBLE, BURST3 -> {
                List<class_1309> es = Raycast.entities(p, range, 0.3 + aim);
                if (!es.isEmpty()) for (int i = 0; i < arrows; i++) hit(level, p, es.get(0), dmg);
                trail(level, eye, Raycast.impact(p, range), stats.effect == 3 ? class_2398.field_11240 : class_2398.field_11205);
            }
            case SHOTGUN -> {
                for (class_1309 e : Raycast.entities(p, 14, 1.4)) hit(level, p, e, dmg * 3);
                trail(level, eye, Raycast.impact(p, 14), class_2398.field_11205);
            }
            case PIERCE -> {
                for (class_1309 e : Raycast.entities(p, range, 0.3)) hit(level, p, e, dmg);
                trail(level, eye, Raycast.impact(p, range), class_2398.field_11207);
            }
            case EXPLODE, CANNON -> {
                class_243 at = Raycast.impact(p, 64);
                level.method_8437(p, at.field_1352, at.field_1351, at.field_1350, stats.mode == Mode.CANNON ? 4.5f : 2.5f, class_1937.class_7867.field_40888);
                for (class_1309 e : level.method_18467(class_1309.class, new net.minecraft.class_238(at, at).method_1014(stats.mode == Mode.CANNON ? 6 : 3))) if (e != p) hit(level, p, e, dmg);
                trail(level, eye, at, class_2398.field_11251);
            }
            case VOID -> {
                class_243 at = Raycast.impact(p, 48);
                for (class_1309 e : level.method_18467(class_1309.class, new net.minecraft.class_238(at, at).method_1014(9))) {
                    if (e == p) continue;
                    class_243 pull = at.method_1020(e.method_73189()).method_1029().method_1021(1.2);
                    e.method_18800(pull.field_1352, pull.field_1351 + 0.2, pull.field_1350); e.field_6037 = true; hit(level, p, e, dmg);
                }
                level.method_65096(class_2398.field_23190, at.field_1352, at.field_1351, at.field_1350, 150, 1.2, 1.2, 1.2, 0.2);
            }
            case HARPOON -> {
                List<class_1309> es = Raycast.entities(p, 32, 0.4);
                if (!es.isEmpty()) {
                    class_1309 e = es.get(0); hit(level, p, e, dmg);
                    class_243 pull = p.method_73189().method_1020(e.method_73189()).method_1029().method_1021(1.6);
                    e.method_18800(pull.field_1352, 0.4, pull.field_1350); e.field_6037 = true;
                } else {
                    class_243 at = Raycast.impact(p, 32), pull = at.method_1020(p.method_73189()).method_1029().method_1021(1.8);
                    p.method_18800(pull.field_1352, pull.field_1351 + 0.3, pull.field_1350); p.field_6037 = true;
                }
                trail(level, eye, Raycast.impact(p, 32), class_2398.field_11241);
            }
            case TESLA -> {
                List<class_1309> es = Raycast.entities(p, range, 0.3);
                if (!es.isEmpty()) {
                    class_1309 first = es.get(0); hit(level, p, first, dmg);
                    int jumps = 0;
                    for (class_1309 e : level.method_18467(class_1309.class, first.method_5829().method_1014(6))) {
                        if (e == p || e == first || jumps >= 3) continue;
                        hit(level, p, e, 8); jumps++;
                        trail(level, first.method_73189().method_1031(0, 1, 0), e.method_73189().method_1031(0, 1, 0), class_2398.field_29644);
                    }
                    class_1538 bolt = class_1299.field_6112.method_5883(level, class_3730.field_16461);
                    if (bolt != null) { bolt.method_5814(first.method_23317(), first.method_23318(), first.method_23321()); bolt.method_29498(true); level.method_8649(bolt); }
                }
                trail(level, eye, Raycast.impact(p, range), class_2398.field_29644);
            }
        }
        if (stats.effect == 4) p.method_6092(new class_1293(class_1294.field_5909, 10, 1, true, false));
        boolean quiet = stats.noise == 0 || modNoise < 0;
        if (quiet) level.method_8396(null, p.method_24515(), class_3417.field_15187, class_3419.field_15248, 0.25f, 1.6f);
        else if (ammo == com.kiyamet.ammo.Ammo.Type.SHELL || ammo == com.kiyamet.ammo.Ammo.Type.ROCKET)
            level.method_8396(null, p.method_24515(), class_3417.field_15152.comp_349(), class_3419.field_15248, 0.45f, stats.mode == Mode.CANNON ? 0.6f : 1.5f);
        else level.method_8396(null, p.method_24515(), class_3417.field_14917, class_3419.field_15248, 1.0f,
                ammo == com.kiyamet.ammo.Ammo.Type.SNIPER ? 0.55f : ammo == com.kiyamet.ammo.Ammo.Type.PISTOL ? 1.25f : 0.9f);
        if (!quiet) level.method_65096(class_2398.field_11251, eye.field_1352 + p.method_5720().field_1352, eye.field_1351 + p.method_5720().field_1351, eye.field_1350 + p.method_5720().field_1350, 3, 0.05, 0.05, 0.05, 0.01);
        int noise = Math.max(0, Math.round((stats.noise + modNoise) * Math.max(0.1f, 1 - 0.3f * silent)));
        if (noise > 0) NoiseSystem.make(level, p.method_24515(), noise, 6);
        p.method_7357().method_62835(stack, Math.max(2, Math.round(modCd * stats.cooldown * (1 - 0.1f * com.kiyamet.enchant.Enchants.gunLevel(level, stack, "rapid_fire")))));
        p.method_7353(com.kiyamet.ammo.Ammo.hud(p, stack, ammo).method_27661().method_10852(net.minecraft.class_2561.method_43470("  |  ").method_27692(net.minecraft.class_124.field_1063)).method_10852(com.kiyamet.gunsmith.GunHandling.hud(stack)), true);
        return class_1269.field_21466;
    }
}
