package com.kiyamet.item;

import com.kiyamet.skill.Skill;
import com.kiyamet.skill.SkillManager;
import com.kiyamet.world.Infection;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import net.minecraft.class_3417;

/** Bandage, medkit, healing syringe and vaccine: right click to use. Medicine skill makes healing stronger. */
public class HealItem extends class_1792 {
    public enum Kind { BANDAGE, MEDKIT, SYRINGE, VACCINE }
    private final Kind kind;

    public HealItem(class_1793 props, Kind kind) { super(props); this.kind = kind; }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (!(player instanceof class_3222 p)) return class_1269.field_5812;
        int medicine = SkillManager.get(p).level(Skill.MEDICINE);
        float boost = 1f + medicine / 999f;
        switch (kind) {
            case BANDAGE -> { if (p.method_6032() >= p.method_6063()) return class_1269.field_5811; p.method_6025(4f * boost); SkillManager.addXp(p, Skill.MEDICINE, 12); }
            case MEDKIT -> { p.method_6025(12f * boost); p.method_6016(class_1294.field_5899); SkillManager.addXp(p, Skill.MEDICINE, 30); }
            case SYRINGE -> { p.method_6025(8f * boost); p.method_6092(new class_1293(class_1294.field_5924, 200, 1)); SkillManager.addXp(p, Skill.MEDICINE, 25); }
            case VACCINE -> { if (Infection.get(p) <= 0) return class_1269.field_5811; Infection.cure(p); SkillManager.addXp(p, Skill.MEDICINE, 60); }
        }
        level.method_8396(null, p.method_24515(), class_3417.field_14581.comp_349(), net.minecraft.class_3419.field_15248, 1f, 1.2f);
        if (!p.method_68878()) stack.method_7934(1);
        p.method_7357().method_62835(stack, kind == Kind.BANDAGE ? 20 : 60);
        return class_1269.field_21466;
    }
}
