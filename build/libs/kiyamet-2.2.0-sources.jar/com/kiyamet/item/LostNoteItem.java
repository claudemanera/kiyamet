package com.kiyamet.item;

import com.kiyamet.skill.Skill;
import com.kiyamet.skill.SkillManager;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_9279;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

/** Notes left by people from before and during the fall. Reading one for the first time gives Exploration XP. */
public class LostNoteItem extends class_1792 {
    public static final String[][] NOTES = {
            {"Day 3", "They said stay inside. The radio said help is coming. The radio stopped saying anything this morning. - M."},
            {"To whoever finds this", "The pharmacy on the corner still has bandages in the back room. The front is full of them. Go around."},
            {"Mom", "I waited at the school for two days. If you read this, I went north to the farm. Please come. - Lily"},
            {"Rule #1", "Never shoot unless you have to. The noise brings more of them. Use a knife. Aim for the head."},
            {"Ration log", "4 cans of beans, 1 bag of rice, 2 bottles. Dave took more than his share again. Something has to be done."},
            {"Warning", "DO NOT TRUST THE PEOPLE AT THE WAREHOUSE. They take your stuff and leave you outside the fence at night."},
            {"Hospital, floor 2", "We locked the doors. Dr. Reyes says it's in everyone already. You don't need a bite. You just need to die."},
            {"Map scribble", "Fuel at the truck stop off the highway. Raiders watch it from the water tower. Go at dawn."},
            {"Last entry", "I got bit on the arm. I'm writing this so nobody opens the cellar. Sorry. Tell Sam I tried."},
            {"Kid's drawing", "A drawing of a house, a dog and four people. Someone wrote under it: 'we will go home soon'."},
            {"Scout report", "Herd moving east along the river. Hundreds. They follow the loudest thing. Don't be the loudest thing."},
            {"Church sign", "All are welcome. Leave your weapons at the door. Ring the bell twice. Not three times. Never three."},
            {"Mechanic's note", "The pickup runs. Just needs a canister of fuel and someone stupid enough to drive it through town."},
            {"Soldier", "Command stopped answering on day 9. We're holding the bridge until the ammo runs out. It's running out."},
            {"Masked ones", "They wear the dead. They walk with them. If the herd goes quiet and parts around you, it's not the dead you should fear."},
            {"Trade terms", "One medkit = five rubies. One gun = we talk. Your people = not for sale. Sign here."},
            {"Farmer's diary", "Planted the last seeds today. If it rains, we eat in the fall. If it doesn't... we'll see who's left."},
            {"Prison note", "Cell block C is clear. We have walls and a yard. It isn't freedom, but it's a home now."},
            {"Love letter", "If the world ends tomorrow I'm still glad I met you in that grocery store, fighting over the last can of peaches."},
            {"Blood Moon", "The old man said when the moon turns red, the dead don't sleep. We laughed. We're not laughing now."},
            {"Engineer", "Built a generator from a lawn mower and two car batteries. The fence hums now. They stay away from the hum."},
            {"Commander's order", "Every settlement pays or burns. No exceptions. - The Commander"},
            {"Unsent text", "where are you. the bridge is closed. im at the gas station. please answer. please"},
            {"Doctor's warning", "Fever, then sleep, then they wake up. Keep the infected tied before they sleep. Vaccine works if early."},
            {"Kingdom notice", "Fair at noon. Bring what you can spare. Those who share, eat. Those who hoard, walk."},
    };

    public LostNoteItem(class_1793 p) { super(p); }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 s = player.method_5998(hand);
        if (!(player instanceof class_3222 sp)) return class_1269.field_5812;
        class_9279 data = s.method_58695(class_9334.field_49628, class_9279.field_49302);
        int id = data.method_57461().method_68083("Note", -1);
        boolean first = id < 0;
        if (first) {
            id = sp.method_59922().method_43048(NOTES.length);
            class_2487 tag = data.method_57461();
            tag.method_10569("Note", id);
            s.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
            s.method_57379(class_9334.field_49631, class_2561.method_43470("Lost Note: " + NOTES[id][0]).method_27694(st -> st.method_10978(false).method_10977(class_124.field_1054)));
            List<class_2561> lore = new ArrayList<>();
            for (String line : wrap(NOTES[id][1], 34)) lore.add(class_2561.method_43470(line).method_27694(st -> st.method_10978(true).method_10977(class_124.field_1080)));
            s.method_57379(class_9334.field_49632, new class_9290(lore));
            SkillManager.addXp(sp, Skill.EXPLORATION, 40);
        }
        sp.method_64398(class_2561.method_43470("✉ " + NOTES[id][0]).method_27695(class_124.field_1054, class_124.field_1067));
        sp.method_64398(class_2561.method_43470("\"" + NOTES[id][1] + "\"").method_27695(class_124.field_1080, class_124.field_1056));
        if (first) sp.method_64398(class_2561.method_43470("+40 Exploration XP").method_27692(class_124.field_1060));
        level.method_8396(null, sp.method_24515(), class_3417.field_17481, class_3419.field_15248, 1f, 1f);
        return class_1269.field_5812;
    }

    static List<String> wrap(String s, int w) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : s.split(" ")) {
            if (line.length() + word.length() + 1 > w && line.length() > 0) { out.add(line.toString()); line.setLength(0); }
            if (line.length() > 0) line.append(' ');
            line.append(word);
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }
}
