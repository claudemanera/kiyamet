package com.kiyamet.item;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

/** Hitscan helpers for guns and gadgets. */
public final class Raycast {
    public static class_3965 block(class_1657 p, double range) {
        class_243 from = p.method_33571(), to = from.method_1019(p.method_5828(1f).method_1021(range));
        return p.method_73183().method_17742(new class_3959(from, to, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, p));
    }

    /** Living entities hit by the ray before it reaches a wall, nearest first. */
    public static List<class_1309> entities(class_1657 p, double range, double grow) {
        class_1937 level = p.method_73183();
        class_243 from = p.method_33571();
        class_3965 wall = block(p, range);
        class_243 to = wall.method_17783() == class_239.class_240.field_1333 ? from.method_1019(p.method_5828(1f).method_1021(range)) : wall.method_17784();
        List<class_1309> out = new ArrayList<>();
        for (class_1297 e : level.method_8335(p, new class_238(from, to).method_1014(grow + 1))) {
            if (!(e instanceof class_1309 le) || !le.method_5805()) continue;
            Optional<class_243> hit = e.method_5829().method_1014(grow).method_992(from, to);
            if (hit.isPresent()) out.add(le);
        }
        out.sort(Comparator.comparingDouble(e -> e.method_5858(p)));
        return out;
    }

    /** Point where the shot lands: first entity, else wall, else max range. */
    public static class_243 impact(class_1657 p, double range) {
        List<class_1309> es = entities(p, range, 0.3);
        if (!es.isEmpty()) return es.get(0).method_73189().method_1031(0, es.get(0).method_17682() / 2, 0);
        class_3965 b = block(p, range);
        return b.method_17783() == class_239.class_240.field_1333 ? p.method_33571().method_1019(p.method_5828(1f).method_1021(range)) : b.method_17784();
    }

    private Raycast() {}
}
