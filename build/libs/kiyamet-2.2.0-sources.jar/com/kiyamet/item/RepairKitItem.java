package com.kiyamet.item;

import com.kiyamet.defense.BlockDurability;
import com.kiyamet.skill.Skill;
import com.kiyamet.skill.SkillManager;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/** Restores 50% of a damaged wall's durability (100% at Engineering 100). */
public class RepairKitItem extends class_1792 {
    public RepairKitItem(class_1793 p) { super(p); }

    @Override
    public class_1269 method_7884(class_1838 ctx) {
        if (!(ctx.method_8045() instanceof class_3218 level) || !(ctx.method_8036() instanceof class_3222 p)) return class_1269.field_5812;
        int eng = SkillManager.get(p).level(Skill.ENGINEERING);
        if (!BlockDurability.repair(level, ctx.method_8037(), eng >= 100 ? 1f : 0.5f)) {
            p.method_7353(class_2561.method_43470("This block is not damaged."), true);
            return class_1269.field_5814;
        }
        if (!p.method_68878()) ctx.method_8041().method_7934(1);
        SkillManager.addXp(p, Skill.ENGINEERING, 20);
        level.method_65096(class_2398.field_29642, ctx.method_8037().method_10263() + 0.5, ctx.method_8037().method_10264() + 0.5, ctx.method_8037().method_10260() + 0.5, 20, 0.5, 0.5, 0.5, 0.1);
        level.method_8396(null, ctx.method_8037(), class_3417.field_14559, class_3419.field_15245, 0.6f, 1.4f);
        return class_1269.field_5812;
    }
}
