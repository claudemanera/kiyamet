package com.kiyamet.item;

import com.kiyamet.skill.Skill;
import com.kiyamet.skill.SkillManager;
import com.kiyamet.twd.Camouflage;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/** Smear walker guts on yourself: zombies ignore you for 2 minutes (+1 s per 4 Stealth levels). Water washes it off. */
public class WalkerGutsItem extends class_1792 {
    public WalkerGutsItem(class_1793 p) { super(p); }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (!(level instanceof class_3218 sl) || !(player instanceof class_3222 sp)) return class_1269.field_5812;
        if (sp.method_5721()) { sp.method_7353(class_2561.method_43470("It would wash right off in the rain.").method_27692(class_124.field_1080), true); return class_1269.field_5814; }
        int stealth = SkillManager.get(sp).level(Skill.STEALTH);
        int ticks = (120 + stealth / 4) * 20;
        sp.method_6092(new class_1293(Camouflage.EFFECT, ticks, 0));
        sp.method_6092(new class_1293(class_1294.field_5916, 60, 0));
        for (class_1308 m : sl.method_8390(class_1308.class, sp.method_5829().method_1014(32), m -> m.method_5968() == sp && m instanceof com.kiyamet.entity.KZombie))
            if (m.method_6065() != sp) m.method_5980(null);
        sl.method_65096(new class_2388(class_2398.field_11217, class_2246.field_10002.method_9564()), sp.method_23317(), sp.method_23318() + 1, sp.method_23321(), 40, 0.3, 0.6, 0.3, 0.1);
        sl.method_8396(null, sp.method_24515(), class_3417.field_15095, class_3419.field_15248, 1f, 0.6f);
        sp.method_64398(class_2561.method_43470("You smear walker guts on yourself. The dead ignore you for " + ticks / 20 + " s.").method_27692(class_124.field_1077));
        SkillManager.addXp(sp, Skill.STEALTH, 25);
        if (!sp.method_68878()) stack.method_7934(1);
        return class_1269.field_5812;
    }
}
