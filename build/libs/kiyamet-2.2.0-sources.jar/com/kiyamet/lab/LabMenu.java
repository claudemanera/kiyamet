package com.kiyamet.lab;

import com.kiyamet.skill.Skill;
import com.kiyamet.skill.SkillManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_124;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

/**
 * Laboratory Table screen: category tabs on top, 36 recipes in the middle (glowing = craftable now), page buttons below.
 */
public class LabMenu extends class_1707 {
    public static final int PER_PAGE = 36, FIRST = 9;
    enum Cat {
        ALL("All recipes", "minecraft:crafting_table"), PARTS("Parts", "kiyamet:circuit"), DEFENSE("Base defense", "kiyamet:steel_block"),
        GADGETS("Gadgets", "kiyamet:flashlight"), WEAPONS("Arrow weapons", "kiyamet:arrow_rifle"), READY("Craftable now", "minecraft:emerald");
        final String title, icon;
        Cat(String title, String icon) { this.title = title; this.icon = icon; }
    }
    private static final int[] TAB_SLOTS = {1, 2, 3, 5, 6, 7};

    private final class_1277 shown;
    private final class_1657 owner;
    private int page;
    private Cat cat = Cat.ALL;
    private List<LabRecipes.Recipe> list = List.of();

    public LabMenu(int id, class_1661 inv) {
        this(id, inv, new class_1277(54));
    }

    private LabMenu(int id, class_1661 inv, class_1277 c) {
        super(class_3917.field_17327, id, inv, c, 6);
        this.shown = c;
        this.owner = inv.field_7546;
        refresh();
    }

    private static class_1792 item(String id) { return class_7923.field_41178.method_63535(class_2960.method_60654(id)); }

    private int engineering() { return owner instanceof class_3222 sp ? SkillManager.get(sp).level(Skill.ENGINEERING) : 1; }

    private static boolean in(String[] arr, String id) {
        for (String a : arr) if (id.equals("kiyamet:" + a)) return true;
        return false;
    }

    private boolean canCraft(LabRecipes.Recipe r, int eng) {
        if (eng < r.level()) return false;
        for (Map.Entry<String, Integer> e : r.parts().entrySet()) if (count(e.getKey()) < e.getValue()) return false;
        return true;
    }

    private boolean matches(LabRecipes.Recipe r, int eng) {
        String id = r.result();
        return switch (cat) {
            case ALL -> true;
            case PARTS -> in(com.kiyamet.registry.ModItems.PARTS, id) || id.equals("kiyamet:repair_kit") || id.equals("kiyamet:medkit");
            case DEFENSE -> item(id) instanceof net.minecraft.class_1747;
            case GADGETS -> in(com.kiyamet.registry.ModItems.GADGETS, id) || id.endsWith("_keys") || id.contains("robot_core") || id.equals("kiyamet:radio");
            case WEAPONS -> in(com.kiyamet.registry.ModItems.WEAPONS, id);
            case READY -> canCraft(r, eng);
        };
    }

    private void refresh() {
        shown.method_5448();
        int eng = engineering();
        list = LabRecipes.ALL.stream().filter(r -> matches(r, eng)).toList();
        int pages = Math.max(1, (list.size() + PER_PAGE - 1) / PER_PAGE);
        if (page >= pages) page = pages - 1;
        for (int i = 0; i < 9; i++) shown.method_5447(i, com.kiyamet.ui.Ui.dark());
        for (int i = 45; i < 54; i++) shown.method_5447(i, com.kiyamet.ui.Ui.dark());
        Cat[] cats = Cat.values();
        for (int t = 0; t < cats.length; t++) {
            Cat c = cats[t];
            boolean sel = c == cat;
            class_1799 tab = com.kiyamet.ui.Ui.icon(item(c.icon), class_2561.method_43470(c.title).method_27695(sel ? class_124.field_1065 : class_124.field_1068, class_124.field_1067),
                    class_2561.method_43470(sel ? "▶ Selected" : "Click to show").method_27692(sel ? class_124.field_1054 : class_124.field_1080));
            shown.method_5447(TAB_SLOTS[t], com.kiyamet.ui.Ui.glint(tab, sel));
        }
        for (int i = 0; i < PER_PAGE && page * PER_PAGE + i < list.size(); i++) {
            LabRecipes.Recipe r = list.get(page * PER_PAGE + i);
            class_1799 s = new class_1799(item(r.result()), r.count());
            List<class_2561> lore = new ArrayList<>();
            boolean lvlOk = eng >= r.level();
            boolean ready = canCraft(r, eng);
            lore.add(class_2561.method_43470(ready ? "✔ Ready to craft" : lvlOk ? "✘ Missing parts" : "✘ Locked").method_27695(ready ? class_124.field_1060 : class_124.field_1061, class_124.field_1067));
            lore.add(class_2561.method_43469("kiyamet.lab.level", r.level()).method_27692(lvlOk ? class_124.field_1077 : class_124.field_1061));
            lore.add(class_2561.method_43470("Parts:").method_27692(class_124.field_1080));
            for (Map.Entry<String, Integer> e : r.parts().entrySet()) {
                int have = count(e.getKey());
                boolean enough = have >= e.getValue();
                lore.add(class_2561.method_43470((enough ? " ✔ " : " ✘ ") + e.getValue() + "x ").method_10852(item(e.getKey()).method_63680())
                        .method_10852(class_2561.method_43470("  (" + have + ")")).method_27692(enough ? class_124.field_1080 : class_124.field_1079));
            }
            lore.add(class_2561.method_43470("+" + (int) (15 + r.level() * 0.6) + " Engineering XP").method_27692(class_124.field_1075));
            if (ready) lore.add(class_2561.method_43470("Click to craft").method_27692(class_124.field_1054));
            com.kiyamet.ui.Ui.lore(s, lore);
            shown.method_5447(FIRST + i, com.kiyamet.ui.Ui.glint(s, ready));
        }
        if (list.isEmpty()) shown.method_5447(22, com.kiyamet.ui.Ui.icon(net.minecraft.class_1802.field_8077, class_2561.method_43470("Nothing here yet").method_27692(class_124.field_1061),
                class_2561.method_43470(cat == Cat.READY ? "Gather more parts or level up Engineering." : "Level up Engineering to unlock more.").method_27692(class_124.field_1080)));
        if (page > 0) shown.method_5447(45, com.kiyamet.ui.Ui.icon(item("minecraft:arrow"), class_2561.method_43471("kiyamet.lab.prev").method_27692(class_124.field_1054)));
        if (page + 1 < pages) shown.method_5447(53, com.kiyamet.ui.Ui.icon(item("minecraft:spectral_arrow"), class_2561.method_43471("kiyamet.lab.next").method_27692(class_124.field_1054)));
        long unlocked = LabRecipes.ALL.stream().filter(r -> eng >= r.level()).count();
        shown.method_5447(49, com.kiyamet.ui.Ui.icon(item("minecraft:book"), class_2561.method_43469("kiyamet.lab.info", eng).method_27695(class_124.field_1075, class_124.field_1067),
                class_2561.method_43470("Page " + (page + 1) + " / " + pages).method_27692(class_124.field_1080),
                class_2561.method_43470("Unlocked recipes: " + unlocked + " / " + LabRecipes.ALL.size()).method_27692(class_124.field_1080),
                com.kiyamet.ui.Ui.bar(unlocked / (double) LabRecipes.ALL.size(), 20)));
    }

    private int count(String id) {
        class_1792 it = item(id);
        int n = 0;
        for (int i = 0; i < owner.method_31548().method_5439(); i++) {
            class_1799 s = owner.method_31548().method_5438(i);
            if (s.method_31574(it)) n += s.method_7947();
        }
        return n;
    }

    private void take(String id, int amount) {
        class_1792 it = item(id);
        for (int i = 0; i < owner.method_31548().method_5439() && amount > 0; i++) {
            class_1799 s = owner.method_31548().method_5438(i);
            if (s.method_31574(it)) { int t = Math.min(amount, s.method_7947()); s.method_7934(t); amount -= t; }
        }
    }

    @Override
    public void method_7593(int slot, int button, class_1713 type, class_1657 player) {
        if (slot < 0 || slot >= 54) { if (type != class_1713.field_7794) super.method_7593(slot, button, type, player); return; }
        if (!(player instanceof class_3222 sp)) return;
        for (int t = 0; t < TAB_SLOTS.length; t++) if (slot == TAB_SLOTS[t]) {
            cat = Cat.values()[t]; page = 0; refresh();
            sp.method_51469().method_8396(null, sp.method_24515(), class_3417.field_15015.comp_349(), class_3419.field_15248, 0.4f, 1.2f);
            return;
        }
        if (slot == 45 && page > 0) { page--; refresh(); return; }
        if (slot == 53 && (page + 1) * PER_PAGE < list.size()) { page++; refresh(); return; }
        int idx = page * PER_PAGE + slot - FIRST;
        if (slot < FIRST || slot >= FIRST + PER_PAGE || idx >= list.size()) return;
        LabRecipes.Recipe r = list.get(idx);
        if (engineering() < r.level()) { sp.method_64398(class_2561.method_43469("kiyamet.lab.need_level", r.level()).method_27692(class_124.field_1061)); return; }
        for (Map.Entry<String, Integer> e : r.parts().entrySet())
            if (count(e.getKey()) < e.getValue()) { sp.method_64398(class_2561.method_43471("kiyamet.lab.need_parts").method_27692(class_124.field_1061)); return; }
        int times = type == class_1713.field_7794 ? 8 : 1;          // shift-click crafts up to 8 at once
        for (int n = 0; n < times && canCraft(r, engineering()); n++) {
            r.parts().forEach(this::take);
            class_1799 out = new class_1799(item(r.result()), r.count());
            if (!sp.method_31548().method_7394(out)) sp.method_7328(out, false);
            SkillManager.addXp(sp, Skill.ENGINEERING, 15 + r.level() * 0.6);
        }
        sp.method_51469().method_8396(null, sp.method_24515(), class_3417.field_22463, class_3419.field_15245, 1f, 1.1f);
        refresh();
    }

    @Override
    public class_1799 method_7601(class_1657 player, int index) { return class_1799.field_8037; }

    @Override
    public void method_7595(class_1657 player) {
        shown.method_5448();
        super.method_7595(player);
    }

    @Override
    public boolean method_7597(class_1657 player) { return true; }
}
