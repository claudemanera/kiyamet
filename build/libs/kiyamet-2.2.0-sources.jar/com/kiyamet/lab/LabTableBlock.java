package com.kiyamet.lab;

import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_747;

public class LabTableBlock extends class_2248 {
    public LabTableBlock(class_2251 p) { super(p); }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!level.method_8608()) player.method_17355(new class_747((id, inv, pl) -> new LabMenu(id, inv), class_2561.method_43471("block.kiyamet.lab_table")));
        return class_1269.field_5812;
    }
}
