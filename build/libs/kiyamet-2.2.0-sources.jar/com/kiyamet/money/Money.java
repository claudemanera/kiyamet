package com.kiyamet.money;

import com.kiyamet.registry.ModItems;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1914;
import net.minecraft.class_1916;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_9279;
import net.minecraft.class_9290;
import net.minecraft.class_9306;
import net.minecraft.class_9334;

/**
 * TWD 1.6 money: paper dollars ($1, $5, $10, $20, $50, $100) and a Money Bag. Every trade in the game is paid in dollars now,
 * villagers included (their emeralds become $10 bills). Old prices in "rubies" are $10 each.
 */
public final class Money {
    public static final int[] BILLS = {100, 50, 20, 10, 5, 1};
    public static final int RATE = 10;    // one old ruby price = $10

    public static class_1792 bill(int v) { return ModItems.get("dollar_" + v); }
    static int value(class_1799 s) { for (int v : BILLS) if (!s.method_7960() && s.method_31574(bill(v))) return v; return 0; }

    public static int total(class_1657 p) {
        int n = 0;
        class_1661 inv = p.method_31548();
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 s = inv.method_5438(i);
            n += value(s) * s.method_7947();
            if (s.method_7909() instanceof BagItem) n += BagItem.balance(s);
        }
        return n;
    }

    /** Pays: takes bills (and change comes back), then money from bags. */
    public static boolean take(class_3222 p, int dollars) {
        if (p.method_68878() || dollars <= 0) return true;
        if (total(p) < dollars) return false;
        class_1661 inv = p.method_31548();
        int loose = 0;
        for (int i = 0; i < inv.method_5439(); i++) { class_1799 s = inv.method_5438(i); int v = value(s); if (v > 0) { loose += v * s.method_7947(); inv.method_5447(i, class_1799.field_8037); } }
        int left = dollars - loose;
        if (left <= 0) { give(p, -left); return true; }
        for (int i = 0; i < inv.method_5439() && left > 0; i++) {
            class_1799 s = inv.method_5438(i);
            if (s.method_7909() instanceof BagItem) { int b = BagItem.balance(s), k = Math.min(b, left); BagItem.set(s, b - k); left -= k; }
        }
        return true;
    }

    public static List<class_1799> bills(int dollars) {
        List<class_1799> out = new ArrayList<>();
        for (int v : BILLS) { int n = dollars / v; dollars %= v; while (n > 0) { int k = Math.min(n, 64); out.add(new class_1799(bill(v), k)); n -= k; } }
        return out;
    }

    public static void give(class_3222 p, int dollars) {
        for (class_1799 s : bills(dollars)) if (!p.method_31548().method_7394(s)) p.method_7328(s, false);
    }

    /** A single stack worth about that much (for chests and drops). */
    public static class_1799 stack(int dollars) {
        for (int v : BILLS) if (dollars >= v && dollars / v <= 64 && dollars % v == 0) return new class_1799(bill(v), dollars / v);
        return new class_1799(bill(10), Math.max(1, Math.min(64, dollars / 10)));
    }

    public static String fmt(int d) { return "$" + String.format("%,d", d); }

    // ------------------------------------------------------------------ items
    public static class BillItem extends class_1792 {
        public BillItem(class_1793 p) { super(p); }
    }

    /** Money Bag ($20,000) / Gold Money Bag ($100,000): all your cash lives here. Bills you pick up go straight in.
     *  Right-click: put loose bills in · sneak + right-click: take $100 out · sneak + right-click a block: put it down. */
    public static class BagItem extends class_1792 {
        public final int cap;
        public BagItem(class_1793 p, int cap) { super(p); this.cap = cap; }
        @Override
        public class_1269 method_7884(net.minecraft.class_1838 ctx) {
            class_1269 r = com.kiyamet.furniture.BagBlock.place(ctx);
            return r != class_1269.field_5811 ? r : super.method_7884(ctx);
        }
        static int balance(class_1799 s) { return s.method_58695(class_9334.field_49628, class_9279.field_49302).method_57461().method_68083("Dollars", 0); }
        static void set(class_1799 s, int d) {
            class_2487 t = s.method_58695(class_9334.field_49628, class_9279.field_49302).method_57461();
            t.method_10569("Dollars", Math.max(0, d));
            s.method_57379(class_9334.field_49628, class_9279.method_57456(t));
            int cap = s.method_7909() instanceof BagItem b ? b.cap : 0;
            s.method_57379(class_9334.field_49632, new class_9290(List.of(class_2561.method_43470("Holds " + fmt(Math.max(0, d)) + " / " + fmt(cap)).method_27694(st -> st.method_10978(false).method_10977(class_124.field_1060)),
                    class_2561.method_43470("Right-click: put your bills in · Sneak: take $100 out").method_27694(st -> st.method_10978(false).method_10977(class_124.field_1063)))));
        }
        /** Moves loose bills into the bag up to its limit (gives change back as smaller bills if needed). */
        static int deposit(class_3222 p, class_1799 bag) {
            int room = ((BagItem) bag.method_7909()).cap - balance(bag);
            if (room <= 0) return 0;
            class_1661 inv = p.method_31548();
            int add = 0;
            for (int v : BILLS) for (int i = 0; i < inv.method_5439() && room - add >= v; i++) {
                class_1799 s = inv.method_5438(i);
                if (value(s) != v) continue;
                int k = Math.min(s.method_7947(), (room - add) / v);
                s.method_7934(k); add += k * v;
            }
            if (add > 0) set(bag, balance(bag) + add);
            return add;
        }

        @Override
        public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
            if (!(player instanceof class_3222 p)) return class_1269.field_5812;
            class_1799 bag = player.method_5998(hand);
            int b = balance(bag);
            if (p.method_5715()) {
                int k = Math.min(100, b);
                if (k <= 0) return class_1269.field_5814;
                set(bag, b - k); give(p, k);
            } else {
                int add = deposit(p, bag);
                if (add == 0) { p.method_7353(class_2561.method_43470("Bag: " + fmt(b) + " / " + fmt(cap)).method_27692(class_124.field_1060), true); return class_1269.field_5814; }
            }
            level.method_8396(null, p.method_24515(), class_3417.field_34376, class_3419.field_15248, 0.8f, 1.1f);
            p.method_7353(class_2561.method_43470("Money Bag: " + fmt(balance(bag)) + "   ·   You carry " + fmt(total(p))).method_27692(class_124.field_1060), true);
            return class_1269.field_21466;
        }
    }

    // ------------------------------------------------------------------ villagers trade in dollars
    static class_9306 cost(class_9306 c) {
        return c.comp_2424().comp_349() == class_1802.field_8687 ? new class_9306(bill(10), c.comp_2425()) : c;
    }

    static void convert(class_1916 offers) {
        for (int i = 0; i < offers.size(); i++) {
            class_1914 o = offers.get(i);
            boolean em = o.method_57556().comp_2424().comp_349() == class_1802.field_8687 || o.method_57557().map(c -> c.comp_2424().comp_349() == class_1802.field_8687).orElse(false) || o.method_8250().method_31574(class_1802.field_8687);
            if (!em) continue;
            class_1799 res = o.method_8250().method_31574(class_1802.field_8687) ? new class_1799(bill(10), o.method_8250().method_7947()) : o.method_8250();
            Optional<class_9306> b = o.method_57557().map(Money::cost);
            offers.set(i, new class_1914(cost(o.method_57556()), b, res, o.method_8249(), o.method_8248(), o.method_19279(), o.method_19278(), o.method_21725()));
        }
    }

    public static void init() {
        for (int v : BILLS) ModItems.custom("dollar_" + v, BillItem::new);
        ModItems.custom("money_bag", p -> new BagItem(p.method_7889(1), 20_000));
        ModItems.custom("gold_money_bag", p -> new BagItem(p.method_7889(1).method_7894(net.minecraft.class_1814.field_8903), 100_000));
        // cash you pick up goes straight into your bag
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.method_3780() % 20 != 7) return;
            for (class_3222 p : server.method_3760().method_14571()) {
                class_1661 inv = p.method_31548();
                boolean bills = false;
                for (int i = 0; i < inv.method_5439() && !bills; i++) bills = value(inv.method_5438(i)) > 0;
                if (!bills) continue;
                for (int i = 0; i < inv.method_5439(); i++) if (inv.method_5438(i).method_7909() instanceof BagItem) BagItem.deposit(p, inv.method_5438(i));
            }
        });
        UseEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
            if (!level.method_8608() && entity instanceof net.minecraft.class_3988 v) convert(v.method_8264());
            return class_1269.field_5811;
        });
        // walkers drop a few dollars and a little something
        ServerLivingEntityEvents.AFTER_DEATH.register((e, src) -> {
            if (!(e instanceof com.kiyamet.entity.KZombie z) || !(src.method_5529() instanceof class_1657) || !(e.method_73183() instanceof class_3218 level)) return;
            var r = level.field_9229;
            if (r.method_43057() < 0.6f) {
                int[] pick = {1, 1, 1, 5, 5, 10, 20};
                e.method_5775(level, new class_1799(bill(pick[r.method_43048(pick.length)]), 1 + r.method_43048(3)));
            }
            if (r.method_43057() < 0.35f) {
                String[] small = switch (z.kind.id) {
                    case "doctor_zombie", "nurse_zombie" -> new String[]{"kiyamet:bandage", "kiyamet:bandage", "kiyamet:medkit"};
                    case "police_zombie" -> new String[]{"kiyamet:pistol_ammo", "kiyamet:pistol_ammo", "kiyamet:magazine_small"};
                    case "farmer_zombie" -> new String[]{"kiyamet:tomato_seeds", "kiyamet:corn_seeds", "kiyamet:onion", "minecraft:bread"};
                    case "armored_zombie", "tank_zombie" -> new String[]{"minecraft:iron_nugget", "kiyamet:metal_plate", "kiyamet:rifle_ammo"};
                    case "toxic_zombie" -> new String[]{"minecraft:spider_eye", "kiyamet:vaccine"};
                    case "hunter_zombie", "runner_zombie" -> new String[]{"kiyamet:rifle_ammo", "minecraft:leather", "kiyamet:shotgun_shell"};
                    case "exploder_zombie" -> new String[]{"minecraft:gunpowder", "kiyamet:frag_grenade"};
                    case "alpha_zombie", "mutant_zombie" -> new String[]{"kiyamet:ruby", "kiyamet:circuit", "kiyamet:sniper_ammo"};
                    default -> new String[]{"minecraft:bread", "kiyamet:pistol_ammo", "minecraft:string", "minecraft:paper", "kiyamet:bandage", "minecraft:apple"};
                };
                e.method_5775(level, new class_1799(com.kiyamet.ui.Ui.item(small[r.method_43048(small.length)]), 1 + (r.method_43048(3) == 0 ? 1 : 0)));
            }
        });
    }

    private Money() {}
}
