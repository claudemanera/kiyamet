package com.kiyamet.net;

import com.kiyamet.Kiyamet;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Client -> server: a mod key was pressed. */
public record KeyAction(int action) implements class_8710 {
    public static final int SKILLS = 0, POWERS = 1, COMPANIONS = 2, GAUNTLET_USE = 3, GAUNTLET_CYCLE = 4, CAMOUFLAGE = 5, NIGHT_VISION = 6, SHADOW_STEP = 7, BACKPACK = 8, SQUAD = 9, GAUNTLET_MENU = 10;
    /** 2.2: 20 + element ordinal switches that power of the Creation Axe */
    public static final int CREATION = 20;
    public static final class_9154<KeyAction> TYPE = new class_9154<>(Kiyamet.id("key_action"));
    public static final class_9139<ByteBuf, KeyAction> CODEC = class_9139.method_56434(class_9135.field_48550, KeyAction::action, KeyAction::new);

    @Override
    public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
