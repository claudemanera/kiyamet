package com.kiyamet.net;

import com.kiyamet.npc.HumanEntity;
import com.kiyamet.skill.Powers;
import com.kiyamet.skill.PowersMenu;
import com.kiyamet.skill.SkillManager;
import com.kiyamet.skill.SkillsMenu;
import com.kiyamet.stone.GauntletData;
import com.kiyamet.stone.GauntletItem;
import com.kiyamet.stone.StoneKind;
import com.kiyamet.stone.StonePowers;
import com.kiyamet.ui.Ui;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.List;

/** Server side of the key bindings (Options > Controls > The Walking Dead). */
public final class KeyActions {
    public static void init() {
        PayloadTypeRegistry.playC2S().register(KeyAction.TYPE, KeyAction.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(KeyAction.TYPE, (payload, ctx) -> {
            class_3222 p = ctx.player();
            ctx.server().execute(() -> handle(p, payload.action()));
        });
    }

    private static class_1799 gauntlet(class_3222 p) {
        for (int i = 0; i < p.method_31548().method_5439(); i++)
            if (p.method_31548().method_5438(i).method_7909() instanceof GauntletItem) return p.method_31548().method_5438(i);
        return class_1799.field_8037;
    }

    private static void msg(class_3222 p, String s, class_124 c) { p.method_7353(class_2561.method_43470(s).method_27692(c), true); }

    static void handle(class_3222 p, int action) {
        if (!p.method_5805()) return;
        if (action >= KeyAction.CREATION && action < KeyAction.CREATION + com.kiyamet.element.Element.values().length) {
            class_1799 axe = p.method_6047();
            if (!(axe.method_7909() instanceof com.kiyamet.creation.CreationAxe)) { msg(p, "Hold the Creation Axe to call its powers.", class_124.field_1080); return; }
            com.kiyamet.creation.CreationAxe.toggle(p, axe, com.kiyamet.element.Element.values()[action - KeyAction.CREATION]);
            return;
        }
        switch (action) {
            case KeyAction.SKILLS -> SkillsMenu.open(p);
            case KeyAction.GAUNTLET_MENU -> { if (p.method_6047().method_7909() instanceof GauntletItem) com.kiyamet.stone.GauntletMenu.open(p); }
            case KeyAction.POWERS -> PowersMenu.open(p);
            case KeyAction.COMPANIONS -> {
                List<HumanEntity> mine = ((class_3218) p.method_51469()).method_8390(HumanEntity.class, p.method_5829().method_1014(128), h -> h.isOwnedBy(p));
                if (mine.isEmpty()) { msg(p, "You have no companions nearby.", class_124.field_1080); return; }
                boolean anyFollow = mine.stream().anyMatch(h -> h.order() == HumanEntity.Order.FOLLOW);
                for (HumanEntity h : mine) h.setOrder(anyFollow ? HumanEntity.Order.STAY : HumanEntity.Order.FOLLOW);
                msg(p, anyFollow ? "Companions: hold position!" : "Companions: follow me!", class_124.field_1075);
            }
            case KeyAction.GAUNTLET_USE, KeyAction.GAUNTLET_CYCLE -> {
                if (action == KeyAction.GAUNTLET_USE && p.method_6047().method_7909() instanceof com.kiyamet.item.GunItem) { com.kiyamet.gunsmith.GunHandling.reload(p, p.method_6047()); return; }
                class_1799 g = gauntlet(p);
                if (g.method_7960()) { msg(p, "You don't carry a Stone Gauntlet.", class_124.field_1080); return; }
                GauntletData d = g.method_58695(GauntletData.TYPE, GauntletData.EMPTY);
                if (action == KeyAction.GAUNTLET_CYCLE) {
                    GauntletData c = d.cycle();
                    g.method_57379(GauntletData.TYPE, c);
                    if (c.current() != null) p.method_7353(class_2561.method_43470("Stone: ").method_10852(class_2561.method_43471("item.kiyamet." + c.current().id)).method_27692(class_124.field_1075), true);
                    return;
                }
                StoneKind k = d.current();
                if (k == null) { msg(p, "The gauntlet is empty.", class_124.field_1080); return; }
                if (p.method_7357().method_7904(g)) { msg(p, "Stone power is recharging...", class_124.field_1080); return; }
                if (StonePowers.activate(p, k)) p.method_7357().method_62835(g, StonePowers.cooldown(p, k));
            }
            case KeyAction.CAMOUFLAGE -> {
                for (int i = 0; i < p.method_31548().method_5439(); i++) {
                    class_1799 s = p.method_31548().method_5438(i);
                    if (s.method_31574(Ui.item("kiyamet:walker_guts"))) { s.method_7909().method_7836(p.method_51469(), p, class_1268.field_5808); return; }
                }
                msg(p, "You have no walker guts.", class_124.field_1080);
            }
            case KeyAction.NIGHT_VISION -> toggle(p, Powers.Power.NIGHT_VISION);
            case KeyAction.SHADOW_STEP -> toggle(p, Powers.Power.INVISIBLE);
            case KeyAction.SQUAD -> com.kiyamet.npc.SquadMenu.open(p);
            case KeyAction.BACKPACK -> com.kiyamet.backpack.BackpackMenu.openWorn(p);
            default -> {}
        }
    }

    private static void toggle(class_3222 p, Powers.Power pw) {
        if (!pw.unlocked(SkillManager.get(p))) { msg(p, pw.title + " is locked (" + pw.skill.name().toLowerCase() + " " + pw.level + ")", class_124.field_1061); return; }
        Powers.toggle(p, pw);
        msg(p, pw.title + (Powers.enabled(p, pw) ? ": ON" : ": OFF"), Powers.enabled(p, pw) ? class_124.field_1060 : class_124.field_1061);
    }

    private KeyActions() {}
}
