package com.kiyamet.npc;

import com.kiyamet.ui.PanelMenu;
import com.kiyamet.ui.Ui;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_747;

/** Character creator for a companion: each row cycles one feature (◀ / ▶). The companion updates live. */
public class AppearanceMenu extends PanelMenu {
    private final HumanEntity h;
    private static final String[] ROWS = {"Skin tone", "Hair style", "Hair colour", "Eyes", "Beard", "Face detail", "Outfit", "Outfit colour",
            "Headwear", "Mask", "Accessory", "Gear colour"};
    // rows 1-4 hold three features each (cols 0-2, 3-5, 6-8)
    private static final int[][] LAYOUT = {{9, 0}, {12, 1}, {15, 2}, {18, 3}, {21, 4}, {24, 5}, {27, 6}, {30, 7}, {33, 11}, {36, 8}, {39, 9}, {42, 10}};

    public static void open(class_3222 p, HumanEntity h) {
        p.method_17355(new class_747((id, inv, pl) -> new AppearanceMenu(id, inv, p, h), class_2561.method_43470("Appearance: " + h.method_5477().getString())));
    }

    private AppearanceMenu(int id, class_1661 inv, class_3222 p, HumanEntity h) {
        super(id, inv, p);
        this.h = h;
        redraw();
    }

    private static int count(int row) {
        return switch (row) {
            case 0 -> Appearance.SKINS; case 1 -> Appearance.HAIRS; case 2 -> Appearance.HAIR_COLORS; case 3 -> 4; case 4 -> 4;
            case 5 -> Appearance.DETAILS; case 6 -> Appearance.OUTFITS; case 7 -> Appearance.OUTFIT_COLORS;
            case 8 -> Gear.HEADWEAR; case 9 -> Gear.MASKS; case 10 -> Gear.ACCESSORIES; default -> Gear.COLORS;
        };
    }

    private int value(Appearance a, int row) {
        Gear g = h.gear();
        return switch (row) {
            case 8 -> g.headwear(); case 9 -> g.mask(); case 10 -> g.accessory(); case 11 -> g.color();
            case 0 -> a.skin(); case 1 -> a.hair(); case 2 -> a.hairColor(); case 3 -> a.eyes(); case 4 -> a.beard();
            case 5 -> a.detail(); case 6 -> a.outfit(); default -> a.outfitColor();
        };
    }

    private static String label(int row, int v) {
        return switch (row) {
            case 0 -> Appearance.SKIN_NAMES[v]; case 1 -> Appearance.HAIR_NAMES[v]; case 2 -> Appearance.HAIR_COLOR_NAMES[v];
            case 3 -> Appearance.EYE_NAMES[v]; case 4 -> Appearance.BEARD_NAMES[v]; case 5 -> Appearance.DETAIL_NAMES[v];
            case 6 -> Appearance.OUTFIT_NAMES[v]; case 7 -> Appearance.OUTFIT_COLOR_NAMES[v];
            case 8 -> Gear.HEADWEAR_NAMES[v]; case 9 -> Gear.MASK_NAMES[v]; case 10 -> Gear.ACCESSORY_NAMES[v]; default -> Appearance.OUTFIT_COLOR_NAMES[v];
        };
    }

    private static class_1792 icon(int row) {
        return switch (row) {
            case 0 -> class_1802.field_8575; case 1 -> class_1802.field_8868; case 2 -> class_1802.field_8099; case 3 -> class_1802.field_8449; case 4 -> class_1802.field_8276;
            case 5 -> class_1802.field_27070; case 6 -> class_1802.field_8577; case 7 -> class_1802.field_8264;
            case 8 -> class_1802.field_8267; case 9 -> class_1802.field_17519; case 10 -> class_1802.field_8719; default -> class_1802.field_8345;
        };
    }

    private static Appearance with(Appearance a, int row, int v) {
        return with0(a, row, v).withFemale(a.female());
    }

    private static Appearance with0(Appearance a, int row, int v) {
        return switch (row) {
            case 0 -> new Appearance(v, a.hair(), a.hairColor(), a.face(), a.detail(), a.outfit(), a.outfitColor(), a.mask());
            case 1 -> new Appearance(a.skin(), v, a.hairColor(), a.face(), a.detail(), a.outfit(), a.outfitColor(), a.mask());
            case 2 -> new Appearance(a.skin(), a.hair(), v, a.face(), a.detail(), a.outfit(), a.outfitColor(), a.mask());
            case 3 -> new Appearance(a.skin(), a.hair(), a.hairColor(), (a.face() & 12) | v, a.detail(), a.outfit(), a.outfitColor(), a.mask());
            case 4 -> new Appearance(a.skin(), a.hair(), a.hairColor(), (a.face() & 3) | v << 2, a.detail(), a.outfit(), a.outfitColor(), a.mask());
            case 5 -> new Appearance(a.skin(), a.hair(), a.hairColor(), a.face(), v, a.outfit(), a.outfitColor(), a.mask());
            case 6 -> new Appearance(a.skin(), a.hair(), a.hairColor(), a.face(), a.detail(), v, a.outfitColor(), a.mask());
            default -> new Appearance(a.skin(), a.hair(), a.hairColor(), a.face(), a.detail(), a.outfit(), v, a.mask());
        };
    }

    @Override
    protected void draw() {
        Appearance a = h.appearance();
        c.method_5447(4, Ui.glint(Ui.icon(class_1802.field_8694, Ui.text("Character creator", class_124.field_1076, class_124.field_1067),
                Ui.text("◀ left arrow / right arrow ▶ to change", class_124.field_1080), Ui.text("Look at your companion to see it live", class_124.field_1080)), true));
        for (int[] l : LAYOUT) {
            int slot = l[0], row = l[1], v = value(a, row), n = count(row);
            c.method_5447(slot, Ui.icon(class_1802.field_8107, Ui.text("◀ Previous", class_124.field_1054)));
            var ic = Ui.icon(icon(row), Ui.text(ROWS[row] + ": " + label(row, v), class_124.field_1068, class_124.field_1067),
                    Ui.text((v + 1) + " / " + n, class_124.field_1080), Ui.bar((v + 1) / (double) n, 12));
            c.method_5447(slot + 1, ic);
            c.method_5447(slot + 2, Ui.icon(class_1802.field_8236, Ui.text("Next ▶", class_124.field_1054)));
        }
        c.method_5447(45, Ui.icon(class_1802.field_8107, Ui.text("Back", class_124.field_1054)));
        c.method_5447(47, Ui.icon(a.female() ? class_1802.field_8330 : class_1802.field_8273, Ui.text("Body: " + (a.female() ? "Woman" : "Man"), class_124.field_1076, class_124.field_1067), Ui.text("Click to switch", class_124.field_1080)));
        c.method_5447(51, Ui.icon(class_1802.field_8550, Ui.text("Remove all gear", class_124.field_1080)));
        c.method_5447(49, Ui.icon(class_1802.field_8598, Ui.text("Randomize everything", class_124.field_1075)));
        c.method_5447(53, Ui.icon(class_1802.field_8839, Ui.text("Done", class_124.field_1060)));
    }

    @Override
    protected boolean click(int slot, class_1713 type) {
        if (!h.method_5805() || !h.isOwnedBy(player)) { player.method_7346(); return false; }
        if (slot == 45) { CompanionMenu.open(player, h); return false; }
        if (slot == 53) { player.method_7346(); return false; }
        if (slot == 49) {
            h.setAppearance(Appearance.random(h.method_59922(), Faction.SURVIVOR, Role.MEMBER, h.appearance().female()));
            h.setGear(new Gear(h.method_59922().method_43048(3) == 0 ? 0 : h.method_59922().method_43048(Gear.HEADWEAR), h.method_59922().method_43048(3) == 0 ? h.method_59922().method_43048(Gear.MASKS) : 0,
                    h.method_59922().method_43048(Gear.ACCESSORIES), h.method_59922().method_43048(Gear.COLORS)));
            return true;
        }
        if (slot == 51) { h.setGear(Gear.NONE); return true; }
        if (slot == 47) { h.setAppearance(h.appearance().withFemale(!h.appearance().female())); return true; }
        for (int[] l : LAYOUT) {
            int row = l[1], n = count(row);
            if (slot == l[0] || slot == l[0] + 2) {
                Appearance a = h.appearance();
                int v = (value(a, row) + (slot == l[0] ? n - 1 : 1)) % n;
                if (row >= 8) h.setGear(h.gear().with(row - 8, v));
                else h.setAppearance(with(a, row, v));
                return true;
            }
        }
        return false;
    }
}
