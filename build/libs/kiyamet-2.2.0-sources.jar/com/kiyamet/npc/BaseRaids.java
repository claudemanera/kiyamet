package com.kiyamet.npc;

import com.kiyamet.Kiyamet;
import com.kiyamet.entity.KZombie;
import com.kiyamet.entity.ModEntities;
import com.kiyamet.entity.ZombieKind;
import com.kiyamet.registry.ModItems;
import com.kiyamet.skill.Skill;
import com.kiyamet.skill.SkillManager;
import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.EntitySleepEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1259;
import net.minecraft.class_1263;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_3213;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3730;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;
import net.minecraft.server.MinecraftServer;
import java.util.*;

/**
 * Blood Moons and raids on your base (the last bed you slept in).
 * Raids come every 1-2 game weeks: the risk grows with every day since the last raid,
 * jumps on a Blood Moon night and again 2-3 days after one. Raiders bring walkers with them
 * (and the Masked at high power, the Commander at very high power), attack in waves, smash walls
 * and steal from your chests if they are still there at dawn.
 */
public final class BaseRaids {
    public static final AttachmentType<class_2338> BASE = AttachmentRegistry.create(Kiyamet.id("raid_base"),
            b -> b.persistent(class_2338.field_25064).copyOnDeath());
    public static final AttachmentType<Integer> LAST_RAID = AttachmentRegistry.create(Kiyamet.id("raid_last"),
            b -> b.initializer(() -> -1).persistent(Codec.INT).copyOnDeath());
    public static final AttachmentType<Integer> LAST_BLOOD = AttachmentRegistry.create(Kiyamet.id("raid_last_blood_moon"),
            b -> b.initializer(() -> -100).persistent(Codec.INT).copyOnDeath());

    static boolean bloodMoon;
    private static long lastDuskDay = -1;
    /** Player -> server tick when tonight's raid starts. */
    private static final Map<UUID, Long> PENDING = new HashMap<>();
    private static final Map<UUID, Raid> ACTIVE = new HashMap<>();

    public static boolean bloodMoon() { return bloodMoon; }

    /** Refused tribute: they come tonight. */
    public static void scheduleTonight(class_3222 p) {
        if (ACTIVE.containsKey(p.method_5667())) return;
        PENDING.put(p.method_5667(), (long) p.method_51469().method_8503().method_3780() + 600);
    }

    /** Paid tribute: the raid clock starts over with a few days of grace. */
    public static void paid(class_3222 p) {
        PENDING.remove(p.method_5667());
        p.setAttached(LAST_RAID, day(p) + 3);
    }

    public static boolean busy(class_3222 p) { return PENDING.containsKey(p.method_5667()) || ACTIVE.containsKey(p.method_5667()); }

    public static void init() {
        EntitySleepEvents.START_SLEEPING.register((e, pos) -> {
            if (!(e instanceof class_3222 p) || p.method_51469().method_27983() != class_1937.field_25179) return;
            if (!p.method_51469().method_8390(com.kiyamet.twd.ShelterCore.class, p.method_5829().method_1014(512), c -> p.method_5667().equals(c.owner())).isEmpty()) return;
            class_2338 old = p.getAttached(BASE);
            p.setAttached(BASE, pos.method_10062());
            if (old == null || old.method_10262(pos) > 48 * 48)
                p.method_64398(class_2561.method_43470("This is your base now. Defend it - raiders will come for it.").method_27692(class_124.field_1065));
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.method_3780() % 20 != 0) return;
            class_3218 ow = server.method_30002();
            long time = ow.method_8532(), day = time / 24000, tod = time % 24000;
            if (tod >= 12500 && tod < 13000 && lastDuskDay != day) { lastDuskDay = day; dusk(server, ow, (int) day); }
            if (bloodMoon && (tod < 12000 || tod >= 23200)) endBloodMoon(server);
            if (bloodMoon && server.method_3780() % 600 == 0) bloodMoonTick(ow);

            long now = server.method_3780();
            for (Iterator<Map.Entry<UUID, Long>> it = PENDING.entrySet().iterator(); it.hasNext(); ) {
                Map.Entry<UUID, Long> en = it.next();
                if (now < en.getValue()) continue;
                class_3222 p = server.method_3760().method_14602(en.getKey());
                if (p == null) continue;                             // waits until they log back in
                if (tod < 12500 || tod > 22000) continue;            // raids only start at night
                class_2338 base = p.getAttached(BASE);
                if (p.method_51469() != ow) continue;
                if (base != null && p.method_24515().method_10262(base) > 120 * 120) {
                    if (now - en.getValue() < 40) p.method_64398(class_2561.method_43470("Your radio crackles: raiders are circling your base, waiting for you to come home...").method_27692(class_124.field_1061));
                    continue;                                        // they wait for you to come back
                }
                it.remove();
                start(p, ow, base != null ? base : p.method_24515(), false);
            }
            ACTIVE.values().removeIf(r -> r.tick(server, ow, tod));
        });

        CommandRegistrationCallback.EVENT.register((d, ctx, env) -> d.register(class_2170.method_9247("twd")
                .then(class_2170.method_9247("raid").executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    if (!p.method_68878()) return info(p);
                    class_2338 base = p.getAttached(BASE);
                    start(p, p.method_51469(), base != null ? base : p.method_24515(), true);
                    return 1;
                }))
                .then(class_2170.method_9247("raidinfo").executes(c -> info(c.getSource().method_9207())))
                .then(class_2170.method_9247("bloodmoon").executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    if (!p.method_68878()) { p.method_64398(class_2561.method_43470("Creative mode only.")); return 0; }
                    if (bloodMoon) endBloodMoon(c.getSource().method_9211()); else startBloodMoon(c.getSource().method_9211(), (int) (p.method_51469().method_8532() / 24000));
                    return 1;
                }))));
    }

    // ---------------------------------------------------------------- schedule

    private static int day(class_3222 p) { return (int) (p.method_51469().method_8503().method_30002().method_8532() / 24000); }

    /** Tonight's raid chance for this player (0..1). */
    public static float risk(class_3222 p, int day, boolean blood) {
        int last = p.getAttachedOrElse(LAST_RAID, -1);
        if (last < 0) { last = Math.max(0, day - 2); p.setAttached(LAST_RAID, last); }  // first week is quiet
        int since = day - last;
        if (day < 6 || since < 4) return 0;
        float c = (since - 4) * 0.08f;
        if (blood) c += 0.25f;
        int afterBlood = day - p.getAttachedOrElse(LAST_BLOOD, -100);
        if (afterBlood >= 2 && afterBlood <= 3) c += 0.3f;
        if (since >= 14) c = 1;
        return class_3532.method_15363(c, 0, 1);
    }

    public static String riskLabel(class_3222 p) {
        if (ACTIVE.containsKey(p.method_5667())) return "UNDER ATTACK";
        if (PENDING.containsKey(p.method_5667())) return "Tonight!";
        float r = risk(p, day(p), false);
        return r <= 0 ? "Low" : r < 0.25f ? "Medium" : r < 0.5f ? "High" : "Very high";
    }

    private static int info(class_3222 p) {
        int d = day(p), since = d - p.getAttachedOrElse(LAST_RAID, d);
        class_2338 base = p.getAttached(BASE);
        p.method_64398(class_2561.method_43470("Base: " + (base == null ? "none (sleep in a bed to set it)" : base.method_23854())
                + "  |  Days since last raid: " + since + "  |  Raid risk: " + riskLabel(p)
                + (bloodMoon ? "  |  BLOOD MOON" : "")).method_27692(class_124.field_1065));
        return 1;
    }

    private static void dusk(MinecraftServer server, class_3218 ow, int day) {
        boolean full = ow.method_76332(class_2338.field_10980) >= 0.99f;
        if (day >= 4 && ow.field_9229.method_43057() < (full ? 0.4f : 0.06f)) startBloodMoon(server, day);
        for (class_3222 p : server.method_3760().method_14571()) {
            if (p.method_7325() || PENDING.containsKey(p.method_5667()) || ACTIVE.containsKey(p.method_5667())) continue;
            if (ow.field_9229.method_43057() >= risk(p, day, bloodMoon)) continue;
            PENDING.put(p.method_5667(), (long) server.method_3780() + 1200 + ow.field_9229.method_43048(4800));
            p.method_64398(class_2561.method_43470("Smoke on the horizon. Engines in the distance... Raiders are coming for your base tonight.").method_27695(class_124.field_1061, class_124.field_1067));
            ow.method_8396(null, p.method_24515(), class_3417.field_17266.comp_349(), class_3419.field_15251, 0.6f, 0.7f);
            for (HumanEntity h : ow.method_8390(HumanEntity.class, p.method_5829().method_1014(48), h -> h.isOwnedBy(p) && h.job() == Job.SCOUT)) {
                p.method_64398(class_2561.method_43470("[" + h.method_5477().getString() + "] I saw them on the road. A big group, with walkers following. Get ready.").method_27692(class_124.field_1075));
                break;
            }
        }
    }

    private static void startBloodMoon(MinecraftServer server, int day) {
        bloodMoon = true;
        for (class_3222 p : server.method_3760().method_14571()) {
            p.setAttached(LAST_BLOOD, day);
            title(p, class_2561.method_43470("BLOOD MOON").method_27695(class_124.field_1079, class_124.field_1067),
                    class_2561.method_43470("The dead are restless tonight").method_27692(class_124.field_1061));
            p.method_51469().method_8396(null, p.method_24515(), class_3417.field_14792, class_3419.field_15251, 0.5f, 0.5f);
            p.method_64398(class_2561.method_43470("A Blood Moon rises. Walkers are faster, stronger and there are many more of them. Raiders like nights like this.").method_27692(class_124.field_1079));
        }
    }

    private static void endBloodMoon(MinecraftServer server) {
        bloodMoon = false;
        for (class_3222 p : server.method_3760().method_14571())
            p.method_64398(class_2561.method_43470("The Blood Moon sets. In 2-3 days raiders may use the chaos to strike.").method_27692(class_124.field_1080));
    }

    private static final ZombieKind[] WALKERS = {ZombieKind.FARMER, ZombieKind.FARMER, ZombieKind.WOMAN, ZombieKind.NURSE, ZombieKind.DOCTOR,
            ZombieKind.POLICE, ZombieKind.RUNNER, ZombieKind.CRAWLER, ZombieKind.TOXIC, ZombieKind.ARMORED};

    /** Every 30 s of a Blood Moon: more walkers near every player, and all of them get stronger. */
    private static void bloodMoonTick(class_3218 ow) {
        for (class_3222 p : ow.method_18456()) {
            if (p.method_7325() || p.method_68878()) continue;
            List<KZombie> near = ow.method_18467(KZombie.class, p.method_5829().method_1014(48));
            for (KZombie z : near) buff(z);
            if (near.size() > 30) continue;
            class_2338 at = ModHumans.surface(ow, p.method_24515(), 24, 40);
            if (at == null) continue;
            int n = 3 + ow.field_9229.method_43048(3);
            for (int i = 0; i < n; i++) {
                KZombie z = walker(ow, at, WALKERS[ow.field_9229.method_43048(WALKERS.length)]);
                if (z != null) { buff(z); z.method_5980(p); }
            }
        }
    }

    private static void buff(class_1308 z) {
        z.method_6092(new class_1293(class_1294.field_5904, 700, 0, true, false));
        z.method_6092(new class_1293(class_1294.field_5910, 700, 0, true, false));
    }

    static KZombie walker(class_3218 level, class_2338 at, ZombieKind kind) {
        KZombie z = ModEntities.ZOMBIES.get(kind).method_5883(level, class_3730.field_16467);
        if (z == null) return null;
        z.method_5814(at.method_10263() + level.field_9229.method_43048(7) - 3 + 0.5, at.method_10264(), at.method_10260() + level.field_9229.method_43048(7) - 3 + 0.5);
        z.method_5943(level, level.method_8404(at), class_3730.field_16467, null);
        z.method_5971();
        level.method_8649(z);
        return z;
    }

    private static void title(class_3222 p, class_2561 t, class_2561 sub) {
        p.field_13987.method_14364(new class_5905(10, 60, 20));
        p.field_13987.method_14364(new class_5903(sub));
        p.field_13987.method_14364(new class_5904(t));
    }

    // ---------------------------------------------------------------- the raid

    private static void start(class_3222 p, class_3218 level, class_2338 base, boolean test) {
        if (ACTIVE.containsKey(p.method_5667())) { p.method_64398(class_2561.method_43470("A raid is already on.")); return; }
        PENDING.remove(p.method_5667());
        Raid r = new Raid(p, level, base, ModHumans.power(p));
        ACTIVE.put(p.method_5667(), r);
        r.spawnWave(level);
    }

    private static final String[] DIRS = {"east", "south-east", "south", "south-west", "west", "north-west", "north", "north-east"};

    private static final class Raid {
        final UUID player;
        final class_2338 base;
        final int power, waves;
        final boolean blood;
        final class_3213 bar;
        final Set<UUID> mobs = new HashSet<>();
        int wave, waveSize, pause, lifetime;

        Raid(class_3222 p, class_3218 level, class_2338 base, int power) {
            this.player = p.method_5667();
            this.base = base;
            this.power = power;
            this.blood = bloodMoon;
            this.waves = (power < 800 ? 2 : power < 2500 ? 3 : 4) + (bloodMoon ? 1 : 0);
            this.bar = new class_3213(class_2561.method_43470("Base Raid"), class_1259.class_1260.field_5784, class_1259.class_1261.field_5791);
            title(p, class_2561.method_43470("RAID!").method_27695(class_124.field_1061, class_124.field_1067),
                    class_2561.method_43470(waves + " waves of raiders and walkers").method_27692(class_124.field_1065));
        }

        void spawnWave(class_3218 level) {
            class_2338 at = null;
            double ang = 0;
            for (int t = 0; t < 10 && at == null; t++) {
                class_2338 c = ModHumans.surface(level, base, 38, 52);
                if (c != null) { at = c; ang = Math.atan2(c.method_10260() - base.method_10260(), c.method_10263() - base.method_10263()); }
            }
            if (at == null) at = base.method_10069(40, 0, 0);
            String dir = DIRS[Math.floorMod((int) Math.round(ang / (Math.PI / 4)), 8)];
            boolean last = wave == waves - 1;
            int lvBase = class_3532.method_15340(5 + power / 25 + wave * 6, 5, 240);

            int raiders = class_3532.method_15340(3 + wave * 2 + power / 600, 3, 12);
            List<HumanEntity> crew = new ArrayList<>();
            boolean cmd = last && power >= 4000;
            for (int i = 0; i < raiders; i++) {
                Role role = i == 0 ? (cmd ? Role.COMMANDER : Role.LEADER) : Role.MEMBER;
                int lv = role == Role.COMMANDER ? 260 + level.field_9229.method_43048(41) : class_3532.method_15340(lvBase + level.field_9229.method_43048(21) - 10 + (role == Role.LEADER ? 15 : 0), 1, 250);
                HumanEntity h = ModHumans.spawn(level, at.method_10069(level.field_9229.method_43048(7) - 3, 0, level.field_9229.method_43048(7) - 3), Faction.RAIDER, role, lv, null);
                if (h != null) { crew.add(h); add(h); }
            }
            if (cmd || power >= 800 && level.field_9229.method_43057() < 0.6f) com.kiyamet.vehicle.ModVehicles.raiderRide(level, at, crew, cmd, power);
            if (power >= 1500 && wave >= 1) {
                int masked = 2 + level.field_9229.method_43048(2);
                for (int i = 0; i < masked; i++)
                    add(ModHumans.spawn(level, at.method_10069(level.field_9229.method_43048(9) - 4, 0, level.field_9229.method_43048(9) - 4), Faction.WHISPERER, Role.MEMBER, class_3532.method_15340(lvBase + 10, 20, 240), null));
            }
            int walkers = class_3532.method_15340(4 + wave * 3 + power / 500, 4, 18);
            if (blood) walkers = walkers * 3 / 2;
            for (int i = 0; i < walkers; i++) {
                ZombieKind k = power >= 2000 && level.field_9229.method_43057() < 0.12f ? (level.field_9229.method_43056() ? ZombieKind.TANK : ZombieKind.EXPLODER)
                        : WALKERS[level.field_9229.method_43048(WALKERS.length)];
                KZombie z = walker(level, at, k);
                if (z != null) { if (blood) buff(z); add(z); }
            }
            waveSize = mobs.size();
            class_3222 p = level.method_8503().method_3760().method_14602(player);
            if (p != null) {
                p.method_64398(class_2561.method_43470("Wave " + (wave + 1) + "/" + waves + ": " + raiders + " raiders and " + walkers + " walkers from the " + dir + "!")
                        .method_27695(class_124.field_1061, class_124.field_1067));
                level.method_8396(null, base, class_3417.field_17266.comp_349(), class_3419.field_15251, 4f, 1f);
            }
        }

        void add(class_1297 e) {
            if (e == null) return;
            if (e instanceof HumanEntity h) h.raiding = true;
            mobs.add(e.method_5667());
        }

        /** @return true when the raid is over. */
        boolean tick(MinecraftServer server, class_3218 level, long tod) {
            lifetime++;
            class_3222 p = server.method_3760().method_14602(player);
            List<class_1308> alive = new ArrayList<>();
            for (Iterator<UUID> it = mobs.iterator(); it.hasNext(); ) {
                class_1297 e = level.method_66347(it.next());
                if (e instanceof class_1308 m && m.method_5805()) alive.add(m); else it.remove();
            }
            // show the bar to everyone around the base
            for (class_3222 sp : level.method_18456()) {
                boolean near = sp.method_24515().method_10262(base) < 160 * 160;
                if (near && !bar.method_14092().contains(sp)) bar.method_14088(sp);
                else if (!near && bar.method_14092().contains(sp)) bar.method_14089(sp);
            }
            bar.method_5413(class_2561.method_43470("Base Raid - Wave " + (wave + 1) + "/" + waves + "  (" + alive.size() + " left)"));
            bar.method_5408(waveSize == 0 ? 0 : class_3532.method_15363(alive.size() / (float) waveSize, 0, 1));

            // march on the base
            for (class_1308 m : alive) {
                if (m.method_5968() == null || !m.method_5968().method_5805()) {
                    if (m.method_24515().method_10262(base) > 6 * 6) m.method_5942().method_6337(base.method_10263() + 0.5, base.method_10264(), base.method_10260() + 0.5, 1.0);
                    else if (p != null && !p.method_68878() && p.method_24515().method_10262(base) < 40 * 40) m.method_5980(p);
                }
                if (m instanceof HumanEntity h && h.raiding) m.method_5971();
            }

            if (alive.isEmpty()) {
                if (wave + 1 >= waves) { win(level, p); return true; }
                if (++pause >= 10) {
                    pause = 0;
                    wave++;
                    spawnWave(level);
                } else if (pause == 1 && p != null) p.method_64398(class_2561.method_43470("Wave cleared. More are coming...").method_27692(class_124.field_1065));
                return false;
            }
            // daylight (or 15 minutes): the raiders grab what they can and run
            if ((tod > 23500 || tod < 11000) && lifetime > 300 || lifetime > 900) { lose(level, p, alive); return true; }
            return false;
        }

        void finish(class_3218 level, class_3222 p) {
            bar.method_14094();
            if (p != null) p.setAttached(LAST_RAID, day(p));
        }

        void win(class_3218 level, class_3222 p) {
            finish(level, p);
            if (p == null) return;
            title(p, class_2561.method_43470("RAID DEFEATED").method_27695(class_124.field_1060, class_124.field_1067),
                    class_2561.method_43470("Your base still stands").method_27692(class_124.field_1065));
            level.method_8396(null, p.method_24515(), class_3417.field_15195, class_3419.field_15248, 1f, 1f);
            List<class_1799> loot = new ArrayList<>();
            loot.addAll(com.kiyamet.money.Money.bills((5 + waves * 3 + power / 300) * com.kiyamet.money.Money.RATE));
            loot.add(new class_1799(ModItems.get("medkit"), 1 + waves / 2));
            loot.add(new class_1799(class_1802.field_8107, 32 + waves * 8));
            loot.add(new class_1799(class_1802.field_8176, 8));
            if (power >= 800) loot.add(new class_1799(ModItems.get("circuit"), 2 + waves));
            if (power >= 2500) loot.add(new class_1799(ModItems.get("tech_core"), 1));
            if (blood) loot.add(new class_1799(ModItems.get("vaccine"), 1));
            for (class_1799 s : loot) level.method_8649(new class_1542(level, base.method_10263() + 0.5, base.method_10264() + 1.2, base.method_10260() + 0.5, s));
            for (Skill s : new Skill[]{Skill.SWORDS, Skill.ARCHERY, Skill.DEFENSE}) SkillManager.addXp(p, s, 150 + waves * 60);
            p.method_64398(class_2561.method_43470("The raiders are dead. Their supplies are at your base. (+XP Swords, Firearms, Defense)").method_27692(class_124.field_1060));
        }

        void lose(class_3218 level, class_3222 p, List<class_1308> alive) {
            finish(level, p);
            int stolen = 0;
            class_2338.class_2339 mp = new class_2338.class_2339();
            outer:
            for (int dx = -10; dx <= 10; dx++) for (int dy = -4; dy <= 4; dy++) for (int dz = -10; dz <= 10; dz++) {
                class_2586 be = level.method_8321(mp.method_10103(base.method_10263() + dx, base.method_10264() + dy, base.method_10260() + dz));
                if (!(be instanceof class_1263 c)) continue;
                for (int i = 0; i < c.method_5439() && stolen < 4; i++) {
                    if (!c.method_5438(i).method_7960() && level.field_9229.method_43057() < 0.25f) { c.method_5447(i, class_1799.field_8037); stolen++; }
                }
                if (stolen >= 4) break outer;
            }
            for (class_1308 m : alive) if (m instanceof HumanEntity) m.method_31472(); else m.method_5971();
            if (p != null) p.method_64398(class_2561.method_43470("The raiders fled with your supplies" + (stolen > 0 ? " (" + stolen + " stacks stolen from your chests)" : "") + ". The walkers they brought are still out there.")
                    .method_27692(class_124.field_1079));
        }
    }

    private BaseRaids() {}
}
