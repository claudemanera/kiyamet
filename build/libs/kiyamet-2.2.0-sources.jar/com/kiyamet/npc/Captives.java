package com.kiyamet.npc;

import com.kiyamet.entity.KZombie;
import com.kiyamet.registry.ModItems;
import com.kiyamet.twd.Camouflage;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_9817;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

/**
 * Prisoners. Put a lead (kayış) on any ordinary walker - or on a raider who's badly hurt (under 40% health) and they
 * surrender. Captives don't fight. Lead them somewhere closed and tie them: to a fence (a normal leash knot) or to
 * iron bars (they're chained there). Talk to them (right-click): raiders can be interrogated, fed, recruited or let go;
 * walkers can be milked for guts or put down. Two or more walkers on leads beside you hide you from other walkers,
 * like the pets with no jaws and no arms.
 */
public final class Captives {
    /** Shared captive state, stored on each walker / human. */
    public static final class Data {
        public boolean captive;
        public class_2338 post;
        public long since;
        public int fed;
        public long cooldown;
        public boolean talked;
    }

    public static void init() {
        // tie captives to iron bars
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (!(level instanceof class_3218 sl) || !(player instanceof class_3222 sp)) return class_1269.field_5811;
            class_2338 pos = hit.method_17777();
            if (!level.method_8320(pos).method_27852(class_2246.field_10576)) return class_1269.field_5811;
            int n = 0;
            for (class_9817 l : class_9817.method_71004(sp)) {
                Data d = data(l);
                if (d == null || !d.captive) continue;
                d.post = pos.method_10062();
                l.method_65894();
                n++;
            }
            if (n == 0) return class_1269.field_5811;
            sl.method_8396(null, pos, class_3417.field_15226, class_3419.field_15245, 1f, 0.8f);
            sp.method_7353(class_2561.method_43470(n + " captive" + (n > 1 ? "s" : "") + " chained to the bars.").method_27692(class_124.field_1080), true);
            return class_1269.field_5812;
        });

        // walker pets hide you
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.method_3780() % 40 != 0) return;
            for (class_3222 p : server.method_3760().method_14571()) {
                int pets = 0;
                for (class_9817 l : class_9817.method_71004(p)) if (l instanceof KZombie z && z.captives.captive && z.method_5739(p) < 8) pets++;
                if (pets >= 2) p.method_6092(new class_1293(Camouflage.EFFECT, 60, 0, true, false, true));
            }
        });
    }

    static Data data(Object o) {
        if (o instanceof KZombie z) return z.captives;
        if (o instanceof HumanEntity h) return h.captives;
        return null;
    }

    /** Can a lead be put on this right now? */
    public static boolean canCapture(class_1308 m) {
        Data d = data(m);
        if (d == null) return false;
        if (d.captive) return true;
        if (m instanceof KZombie z) return z.kind.capturable();
        if (m instanceof HumanEntity h) return (h.faction() == Faction.RAIDER || h.faction() == Faction.WHISPERER) && h.role() != Role.COMMANDER && !h.envoy && h.method_6032() < h.method_6063() * 0.4f;
        return false;
    }

    /** Every tick on the server for walkers and humans. */
    public static void tick(class_3218 level, class_1308 m, Data d) {
        if (!d.captive) {
            if (m instanceof class_9817 l && l.method_60953()) capture(level, m, d, l.method_60952());
            return;
        }
        m.method_5980(null);
        m.method_5971();
        if (d.post != null && !(m instanceof class_9817 l && l.method_60953())) {
            if (!level.method_8320(d.post).method_27852(class_2246.field_10576)) { d.post = null; return; }
            double dist = m.method_73189().method_1022(class_243.method_24953(d.post));
            if (dist > 8) m.method_5859(d.post.method_10263() + 0.5, d.post.method_10264(), d.post.method_10260() + 0.5);
            else if (dist > 2.5) m.method_5942().method_6337(d.post.method_10263() + 0.5, d.post.method_10264(), d.post.method_10260() + 0.5, 1.0);
            if (m.field_6012 % 40 == 0) {   // the chain
                class_243 a = class_243.method_24953(d.post), b = m.method_73189().method_1031(0, m.method_17682() * 0.6, 0);
                for (int i = 1; i < 6; i++) { class_243 q = a.method_35590(b, i / 6.0); level.method_65096(class_2398.field_23956, q.field_1352, q.field_1351, q.field_1350, 1, 0, 0, 0, 0); }
            }
        }
    }

    static void capture(class_3218 level, class_1308 m, Data d, class_1297 holder) {
        d.captive = true;
        d.since = level.method_75260();
        m.method_5980(null);
        if (holder instanceof class_3222 p) {
            if (m instanceof HumanEntity h) {
                Talk.say(p, h, Talk.pick(h.method_59922(), "Okay! Okay! I give up! Don't kill me!", "Fine... you got me.", "Alright, alright. I surrender."));
            } else if (m instanceof KZombie z) {
                String who = z.formerName != null ? z.formerName : "The walker";
                p.method_64398(class_2561.method_43470(who + " snaps at the rope, but it holds. " + (z.formerName != null ? "Its eyes... it was " + z.formerName + "." : "You pull its teeth and bind its arms.")).method_27692(class_124.field_1077));
            }
            p.method_64398(class_2561.method_43470("Captured! Tie them to a fence or iron bars (right-click the bars). Right-click them to talk.").method_27692(class_124.field_1080));
        }
        level.method_8396(null, m.method_24515(), class_3417.field_15226, class_3419.field_15254, 1f, 0.8f);
    }

    static int days(class_3218 level, Data d) { return (int) ((level.method_75260() - d.since) / 24000); }

    // ------------------------------------------------------------------ talking to a captive raider

    public static void talk(class_3222 p, HumanEntity h) {
        class_3218 level = (class_3218) p.method_51469();
        Data d = h.captives;
        int days = days(level, d);
        Talk.say(p, h, days == 0 ? Talk.pick(h.method_59922(), "What do you want?", "Come to gloat?", "Untie me and we'll talk.")
                : Talk.pick(h.method_59922(), "Day " + (days + 1) + "... you gonna keep me here forever?", "My arms are numb.", "...", "You again."));
        Talk.ask(p, h, 25, "", null,
                new Talk.Option("Where's your crew's stash?", pl -> interrogate(pl, h, level)),
                new Talk.Option("Here, eat something. (1 food in hand)", pl -> feed(pl, h)),
                new Talk.Option("Join us. Start over.", pl -> {
                    float chance = 0.08f + days * 0.15f + d.fed * 0.1f;
                    if (h.method_59922().method_43057() < chance) {
                        d.captive = false; d.post = null;
                        if (h.method_60953()) h.method_65894();
                        Talk.say(pl, h, "...You fed me. You didn't kill me. Nobody in my crew would've done that. I'm in.");
                        h.setOwner(pl);
                        pl.method_64398(class_2561.method_43470(h.method_5477().getString() + " joins you!").method_27695(class_124.field_1075, class_124.field_1067));
                    } else Talk.say(pl, h, Talk.pick(h.method_59922(), "Join you? Ha. Ask me again in a few days.", "Not a chance.", "I'm thinking about it. Maybe. Bring food."));
                }),
                new Talk.Option("You're free. Go.", pl -> {
                    Talk.say(pl, h, "...Seriously? I won't forget this.");
                    Talk.later(pl, 40, () -> { if (h.method_5805()) { level.method_65096(class_2398.field_11203, h.method_23317(), h.method_23318() + 1, h.method_23321(), 10, 0.3, 0.5, 0.3, 0.02); h.method_31472(); } });
                }),
                new Talk.Option("Nothing.", pl -> {}));
    }

    private static void feed(class_3222 p, HumanEntity h) {
        class_1799 held = p.method_6047();
        if (!held.method_57826(net.minecraft.class_9334.field_50075)) { Talk.say(p, h, "That's not food."); return; }
        held.method_7934(1);
        h.captives.fed++;
        h.method_6025(4);
        Talk.say(p, h, Talk.pick(h.method_59922(), "*eats fast* ...Thanks.", "Why are you doing this?", "...I didn't think you'd feed me."));
    }

    private static void interrogate(class_3222 p, HumanEntity h, class_3218 level) {
        Data d = h.captives;
        if (d.talked) { Talk.say(p, h, "I already told you everything!"); return; }
        if (level.method_75260() < d.cooldown) { Talk.say(p, h, "I said I ain't talking. Leave me alone."); return; }
        float chance = 0.35f + days(level, d) * 0.2f + d.fed * 0.05f;
        if (h.method_59922().method_43057() >= chance) { d.cooldown = level.method_75260() + 2400; Talk.say(p, h, Talk.pick(h.method_59922(), "I ain't telling you nothing.", "Go to hell.", "You'll have to do better than that.")); return; }
        d.talked = true;
        double a = level.field_9229.method_43058() * Math.PI * 2;
        int dist = 80 + level.field_9229.method_43048(80);
        class_2338 at = level.method_8598(net.minecraft.class_2902.class_2903.field_13203,
                h.method_24515().method_10069((int) (Math.cos(a) * dist), 0, (int) (Math.sin(a) * dist)));
        level.method_8652(at, class_2246.field_16328.method_9564(), 3);
        if (level.method_8321(at) instanceof net.minecraft.class_3719 b) {
            b.method_5447(4, com.kiyamet.money.Money.stack((6 + level.field_9229.method_43048(10)) * 10));
            b.method_5447(10, new class_1799(class_1802.field_8107, 32));
            b.method_5447(13, new class_1799(ModItems.get("medkit"), 1 + level.field_9229.method_43048(2)));
            b.method_5447(16, new class_1799(ModItems.get("circuit"), 1 + level.field_9229.method_43048(3)));
            if (level.field_9229.method_43056()) b.method_5447(22, new class_1799(ModItems.get("fuel_canister"), 1));
        }
        String dir = WorldEvents.dir(at, h.method_24515());
        Talk.say(p, h, "Fine! There's a barrel buried at our old drop point. " + dist + " steps " + dir + " of here. Happy?");
        p.method_64398(class_2561.method_43470("Stash: " + at.method_10263() + " " + at.method_10264() + " " + at.method_10260() + " (" + dir + ")").method_27692(class_124.field_1065));
    }

    // ------------------------------------------------------------------ captive walkers

    public static void walker(class_3222 p, KZombie z) {
        class_3218 level = (class_3218) p.method_51469();
        Data d = z.captives;
        boolean friend = z.formerOwner != null && z.formerOwner.equals(p.method_5667());
        String name = z.formerName != null ? z.formerName : "Walker";
        p.method_64398(class_2561.method_43470(name + ": ").method_27695(class_124.field_1077, class_124.field_1067)
                .method_10852(class_2561.method_43470(friend ? "*growls... the face is still " + name + "'s*" : "*snarls and snaps its teeth*").method_27695(class_124.field_1080, class_124.field_1056)));
        Talk.askAs(p, z, name, class_124.field_1077, 15, "", null,
                new Talk.Option("Collect walker guts (camouflage)", pl -> {
                    if (level.method_75260() < d.cooldown) { pl.method_7353(class_2561.method_43470("Nothing left to take. Wait a few minutes.").method_27692(class_124.field_1080), true); return; }
                    d.cooldown = level.method_75260() + 20 * 180;
                    com.kiyamet.npc.Shop.give(pl, new class_1799(ModItems.get("walker_guts"), 2));
                    level.method_8396(null, z.method_24515(), class_3417.field_21070, class_3419.field_15254, 1f, 0.6f);
                }),
                new Talk.Option(friend ? "Rest now, " + name + "." : "Put it down.", pl -> {
                    if (friend) pl.method_64398(class_2561.method_43470("You close " + name + "'s eyes one last time.").method_27695(class_124.field_1080, class_124.field_1056));
                    z.method_5768(level);
                }),
                new Talk.Option("Leave it.", pl -> {}));
    }

    public static void save(net.minecraft.class_11372 out, Data d) {
        out.method_71472("Captive", d.captive);
        if (d.post != null) out.method_71466("CaptivePost", d.post.method_10063());
        out.method_71466("CaptiveSince", d.since);
        out.method_71465("CaptiveFed", d.fed);
        out.method_71472("CaptiveTalked", d.talked);
    }

    public static void load(net.minecraft.class_11368 in, Data d) {
        d.captive = in.method_71433("Captive", false);
        long post = in.method_71425("CaptivePost", Long.MIN_VALUE);
        d.post = post == Long.MIN_VALUE ? null : class_2338.method_10092(post);
        d.since = in.method_71425("CaptiveSince", 0);
        d.fed = in.method_71424("CaptiveFed", 0);
        d.talked = in.method_71433("CaptiveTalked", false);
    }

    private Captives() {}
}
