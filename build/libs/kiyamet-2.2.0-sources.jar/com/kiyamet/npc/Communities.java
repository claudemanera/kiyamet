package com.kiyamet.npc;

import com.kiyamet.Kiyamet;
import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5819;
import java.util.HashMap;
import java.util.Map;

/**
 * Settlements. Each has its own reputation with each player (-100..100). On first contact the community decides:
 * welcome you (rep +20) or treat you as a threat (rep -50). Attacking a member drops reputation and turns them hostile.
 */
public final class Communities {
    public static final AttachmentType<Map<String, Integer>> REPUTATION = AttachmentRegistry.create(Kiyamet.id("reputation"),
            b -> b.initializer(Map::of).persistent(Codec.unboundedMap(Codec.STRING, Codec.INT)).copyOnDeath());

    public record Type(String id, String title, float friendly, String[] greetings) {}

    public static final Map<String, Type> TYPES = new HashMap<>();

    static {
        add("prison", "Prison Survivor", 0.65f, "These walls kept the dead out. Mostly.", "Don't go near cell block C.", "We grow what we can in the yard.");
        add("farm", "Farmhand", 0.8f, "The barn? Don't open the barn.", "We've got eggs if you've got cash.", "Wipe your boots, we're decent folk.");
        add("walled_town", "Townsfolk", 0.6f, "Welcome to the Safe Zone. Rules are rules.", "We have showers. Real ones.", "Keep the gate shut behind you.");
        add("hilltop", "Hilltop Settler", 0.7f, "We trade, we farm, we survive.", "The blacksmith could use more iron.", "Watch out for the raiders on the roads.");
        add("kingdom", "Kingdom Citizen", 0.75f, "Hail, traveller! The Kingdom welcomes you.", "We grow pomegranates. Well, apples.", "Our guards train every morning.");
        add("sanctuary", "Raider", 0f, "You're on our turf.");
        add("terminal", "Terminal Dweller", 0.35f, "Sanctuary for all. Community for all.", "Come in, we'll get you a plate.", "Don't mind the train cars.");
        add("camp", "Camper", 0.7f, "Keep your voice down, they hear everything.", "We move at dawn.", "Got any spare arrows?");
    }

    private static void add(String id, String title, float friendly, String... greetings) { TYPES.put(id, new Type(id, title, friendly, greetings)); }

    public static String title(String type) { Type t = TYPES.get(type); return t == null ? "Survivor" : t.title; }

    public static String greeting(class_5819 r, String type) {
        Type t = TYPES.get(type);
        return t == null ? "Stay safe out there." : t.greetings[r.method_43048(t.greetings.length)];
    }

    public static String displayName(String type) {
        return switch (type) {
            case "prison" -> "The Prison"; case "farm" -> "The Farm"; case "walled_town" -> "The Safe Zone"; case "hilltop" -> "Hilltop";
            case "kingdom" -> "The Kingdom"; case "sanctuary" -> "The Sanctuary"; case "terminal" -> "The Terminal"; default -> "The Camp";
        };
    }

    /** Finds the community key: shared with members already settled nearby, else a new one from this member's position. */
    public static String assign(class_3218 level, HumanEntity h) {
        for (HumanEntity o : level.method_8390(HumanEntity.class, h.method_5829().method_1014(64),
                o -> o != h && !o.community().isEmpty() && o.communityType().equals(h.communityType())))
            return o.community();
        return h.communityType() + "@" + (h.method_24515().method_10263() >> 4) + "," + (h.method_24515().method_10260() >> 4);
    }

    public static int reputation(class_1657 p, String key) {
        if (key == null || key.isEmpty()) return 0;
        return p.getAttachedOrElse(REPUTATION, Map.of()).getOrDefault(key, 0);
    }

    public static boolean known(class_1657 p, String key) { return p.getAttachedOrElse(REPUTATION, Map.of()).containsKey(key); }

    public static void change(class_3222 p, String key, int delta) {
        if (key.isEmpty()) return;
        Map<String, Integer> m = new HashMap<>(p.getAttachedOrElse(REPUTATION, Map.of()));
        int before = m.getOrDefault(key, 0), after = Math.max(-100, Math.min(100, before + delta));
        m.put(key, after);
        p.setAttached(REPUTATION, Map.copyOf(m));
        String type = key.contains("@") ? key.substring(0, key.indexOf('@')) : key;
        if (before >= 0 && after < 0) p.method_64398(class_2561.method_43470(displayName(type) + " now sees you as an enemy!").method_27695(class_124.field_1061, class_124.field_1067));
        if (before < 0 && after >= 0) p.method_64398(class_2561.method_43470(displayName(type) + " is willing to trust you again.").method_27692(class_124.field_1060));
    }

    /** First contact: called every 2 s for players near a community member they have never met. */
    public static void set(class_3222 p, String key, int value) {
        Map<String, Integer> m = new HashMap<>(p.getAttachedOrElse(REPUTATION, Map.of()));
        m.put(key, value);
        p.setAttached(REPUTATION, Map.copyOf(m));
    }

    public static void firstContact(class_3218 level, class_3222 p, HumanEntity h) {
        String key = h.community();
        if (key.isEmpty() || known(p, key)) return;
        Type t = TYPES.get(h.communityType());
        float friendly = t == null ? 0.6f : t.friendly;
        friendly += Math.min(0.15f, com.kiyamet.skill.SkillManager.get(p).totalPower() / 40000f);   // famous survivors are trusted more
        boolean ok = level.field_9229.method_43057() < friendly;
        if (ok && !Talk.busy(p)) {                       // friendly communities stop you at the gate and ask
            set(p, key, 0);
            Dialogues.threeQuestions(level, p, h);
            return;
        }
        Map<String, Integer> m = new HashMap<>(p.getAttachedOrElse(REPUTATION, Map.of()));
        m.put(key, ok ? 20 : -50);
        p.setAttached(REPUTATION, Map.copyOf(m));
        String name = displayName(h.communityType());
        if (ok) {
            p.method_64398(class_2561.method_43470("» " + name + " lets you in. Find their leader or trader.").method_27695(class_124.field_1060, class_124.field_1067));
            level.method_8396(null, p.method_24515(), class_3417.field_17265, class_3419.field_15254, 1f, 1.2f);
        } else {
            p.method_64398(class_2561.method_43470("» " + name + " sees you as a threat! They open fire!").method_27695(class_124.field_1061, class_124.field_1067));
            level.method_8396(null, p.method_24515(), class_3417.field_17266.comp_349(), class_3419.field_15251, 1f, 1.4f);
        }
    }

    public static void onMemberHurt(class_3218 level, HumanEntity h, class_3222 p) {
        change(p, h.community(), reputation(p, h.community()) >= 0 ? -60 : -10);
        for (HumanEntity ally : h.allies(level, 40)) if (ally.method_5968() == null) ally.method_5980(p);
    }

    private Communities() {}
}
