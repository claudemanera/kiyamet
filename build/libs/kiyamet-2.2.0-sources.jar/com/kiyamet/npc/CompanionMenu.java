package com.kiyamet.npc;

import com.kiyamet.ui.PanelMenu;
import com.kiyamet.ui.Ui;
import net.minecraft.class_124;
import net.minecraft.class_1304;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import net.minecraft.class_747;

/** Companion panel: stats, orders, gear, glow, looks editor, dismiss. */
public class CompanionMenu extends PanelMenu {
    private static final int INFO = 4, FOLLOW = 19, STAY = 20, GUARD = 21, WEAPON = 23, LOOKS = 24, GLOW = 25,
            HEAL = 30, BAG = 31, TP = 32, DISMISS = 49, JOB = 28, RENAME = 34, RUN = 39, SQUAD = 41, GATHER = 37, SETTLE = 40, FAMILY = 42;
    private final HumanEntity h;
    private boolean confirmDismiss;

    public static void open(class_3222 p, HumanEntity h) {
        p.method_17355(new class_747((id, inv, pl) -> new CompanionMenu(id, inv, p, h), class_2561.method_43470("Companion: " + h.method_5477().getString())));
    }

    private CompanionMenu(int id, class_1661 inv, class_3222 p, HumanEntity h) {
        super(id, inv, p);
        this.h = h;
        redraw();
    }

    @Override
    protected void draw() {
        int lv = h.lvl();
        Appearance a = h.appearance();
        class_1799 info = Ui.icon(class_1802.field_8575, class_2561.method_43470(h.method_5477().getString()).method_27695(class_124.field_1075, class_124.field_1067),
                Ui.text("Level " + lv + " / " + HumanEntity.MAX_LEVEL, class_124.field_1054),
                Ui.text("Type: " + h.profession().title, class_124.field_1068),
                Ui.text(h.specialty() == Specialty.NONE ? "No specialty" : "★ " + h.specialty().title + ": " + h.specialty().desc, h.specialty() == Specialty.NONE ? class_124.field_1063 : class_124.field_1076),
                lv >= HumanEntity.MAX_LEVEL ? Ui.text("★ MAX LEVEL", class_124.field_1076) : Ui.bar(h.xp() / (double) HumanEntity.xpToNext(lv), 20),
                Ui.text("XP " + h.xp() + " / " + HumanEntity.xpToNext(lv) + "  (earned from kills)", class_124.field_1063),
                Ui.text("Health " + (int) h.method_6032() + " / " + (int) h.method_6063(), class_124.field_1061),
                Ui.text("Damage " + String.format("%.1f", h.method_45325(class_5134.field_23721) * Weapon.tier(h.method_6047())), class_124.field_1065),
                Ui.text("Armor " + (int) h.method_45325(class_5134.field_23724), class_124.field_1080),
                Ui.text("Look: " + Appearance.OUTFIT_NAMES[Math.min(a.outfit(), Appearance.OUTFITS - 1)] + ", " + Appearance.HAIR_NAMES[a.hair()], class_124.field_1063),
                Ui.text("Rename: use a name tag on them", class_124.field_1063));
        c.method_5447(INFO, Ui.glint(info, true));
        HumanEntity.Order o = h.order();
        c.method_5447(FOLLOW, Ui.glint(Ui.icon(class_1802.field_8719, Ui.text("Follow me", o == HumanEntity.Order.FOLLOW ? class_124.field_1060 : class_124.field_1068, class_124.field_1067),
                Ui.text("Stays close, teleports if left behind", class_124.field_1080)), o == HumanEntity.Order.FOLLOW));
        c.method_5447(STAY, Ui.glint(Ui.icon(class_1802.field_8788, Ui.text("Stay here", o == HumanEntity.Order.STAY ? class_124.field_1060 : class_124.field_1068, class_124.field_1067),
                Ui.text("Holds this exact spot", class_124.field_1080)), o == HumanEntity.Order.STAY));
        c.method_5447(GUARD, Ui.glint(Ui.icon(class_1802.field_8255, Ui.text("Guard this area", o == HumanEntity.Order.GUARD ? class_124.field_1060 : class_124.field_1068, class_124.field_1067),
                Ui.text("Patrols 10 blocks around here, fights intruders", class_124.field_1080)), o == HumanEntity.Order.GUARD));
        class_1799 w = h.method_6047().method_7972();
        if (w.method_7960()) w = new class_1799(class_1802.field_8077);
        Ui.lore(w, java.util.List.of(Ui.text("Current weapon" + (Weapon.ranged(h.method_6047()) ? " (ranged)" : " (melee)"), class_124.field_1065),
                Ui.text("Click: swap with the item in your main hand", class_124.field_1054),
                Ui.text("Weapon power scales with their level", class_124.field_1080)));
        c.method_5447(WEAPON, w);
        c.method_5447(22, Ui.icon(h.morale >= 70 ? class_1802.field_8463 : h.morale >= 45 ? class_1802.field_8279 : h.morale >= 25 ? class_1802.field_8511 : class_1802.field_17515,
                Ui.text("Morale: " + Math.round(h.morale) + "/100 (" + Mind.moraleLabel(h.morale) + ")", h.morale >= 70 ? class_124.field_1060 : h.morale >= 45 ? class_124.field_1054 : h.morale >= 25 ? class_124.field_1065 : class_124.field_1061, class_124.field_1067),
                Ui.bar(h.morale / 100.0, 20),
                Ui.text("High: +15% damage, faster · Low: weaker, may leave", class_124.field_1080),
                Ui.text("Raise it: food from your hand, a fire, your shelter, rest, music", class_124.field_1080)));
        c.method_5447(LOOKS, Ui.icon(class_1802.field_8694, Ui.text("Change appearance", class_124.field_1076, class_124.field_1067),
                Ui.text("Skin, hair, face, details, outfit", class_124.field_1080)));
        boolean glow = h.method_36361();
        c.method_5447(GLOW, Ui.glint(Ui.icon(glow ? class_1802.field_8601 : class_1802.field_8054, Ui.text("Glow: " + (glow ? "ON" : "OFF"), glow ? class_124.field_1054 : class_124.field_1080, class_124.field_1067),
                Ui.text("Makes them visible through walls", class_124.field_1080)), glow));
        c.method_5447(HEAL, Ui.icon(Ui.item("kiyamet:medkit"), Ui.text("Heal with a medkit / bandage", class_124.field_1061),
                Ui.text("Uses one from your inventory", class_124.field_1080)));
        int used = 0;
        for (int i = 0; i < h.inventory().method_5439(); i++) if (!h.inventory().method_5438(i).method_7960()) used++;
        c.method_5447(BAG, Ui.icon(class_1802.field_8106, Ui.text("Inventory (" + used + " / 27)", class_124.field_1065, class_124.field_1067),
                Ui.text("Give them supplies to carry", class_124.field_1080), Ui.text("Medkits & bandages inside are used automatically", class_124.field_1080)));
        c.method_5447(TP, Ui.icon(class_1802.field_8634, Ui.text("Call to me", class_124.field_1062), Ui.text("Teleports them to you and sets Follow", class_124.field_1080)));
        Job j = h.job();
        c.method_5447(JOB, Ui.glint(Ui.icon(j.icon, Ui.text("Job: " + j.title, class_124.field_1065, class_124.field_1067), Ui.text(j.desc, class_124.field_1080),
                Ui.text("Click to change (Gunner, Scout, Guardian, Looter)", class_124.field_1054)), j != Job.NONE));
        c.method_5447(RENAME, Ui.icon(class_1802.field_8448, Ui.text("Rename", class_124.field_1075), Ui.text("Type the new name in chat", class_124.field_1080)));
        c.method_5447(RUN, Ui.icon(class_1802.field_8388, Ui.text("Send on a supply run (5 min)", class_124.field_1065), Ui.text("Comes back with loot in their inventory", class_124.field_1080)));
        c.method_5447(GATHER, Ui.glint(Ui.icon(class_1802.field_8403, Ui.text("Gather resources", class_124.field_1060, class_124.field_1067),
                Ui.text(o == HumanEntity.Order.GATHER ? "Now: " + h.gather : "Wood, stone, ores, or 'Develop'", class_124.field_1080),
                Ui.text("Develop: tools → stone → iron armor → ores", class_124.field_1063)), o == HumanEntity.Order.GATHER));
        c.method_5447(SETTLE, Ui.glint(Ui.icon(class_1802.field_16315, Ui.text(h.work.isEmpty() ? "Settle here" : "Settler: " + com.kiyamet.settle.Settlement.title(h.work), class_124.field_1060, class_124.field_1067),
                Ui.text(h.work.isEmpty() ? "Live and work at the nearest Settlement Bell" : "Click to bring them back with you", class_124.field_1080)), !h.work.isEmpty()));
        if (h.partner || com.kiyamet.settle.Family.canPartner(h) || h.bornDay >= 0)
            c.method_5447(FAMILY, Ui.glint(Ui.icon(h.bornDay >= 0 ? class_1802.field_17534 : class_1802.field_8880, Ui.text(h.bornDay >= 0 ? "Your child · " + com.kiyamet.settle.Family.stage((net.minecraft.class_3218) h.method_73183(), h).title
                    : h.partner ? (h.pregnantDay >= 0 ? "♥ Partner · expecting" : "♥ Partner") : "Ask to be your partner", class_124.field_1076, class_124.field_1067),
                    Ui.text(h.partner ? "Sleep near each other at night..." : h.bornDay >= 0 ? "Grows up with the calendar" : "Needs morale 60+", class_124.field_1080)), h.partner));
        c.method_5447(SQUAD, Ui.icon(class_1802.field_16315, Ui.text("Group panel", class_124.field_1076, class_124.field_1067), Ui.text("Orders for everyone, group supply runs", class_124.field_1080)));
        c.method_5447(DISMISS, Ui.icon(confirmDismiss ? class_1802.field_8626 : class_1802.field_8264, Ui.text(confirmDismiss ? "Click again to confirm" : "Dismiss companion", class_124.field_1061),
                Ui.text("They become a free survivor again", class_124.field_1080)));
    }

    @Override
    protected boolean click(int slot, class_1713 type) {
        if (!h.method_5805() || !h.isOwnedBy(player) || h.isAway()) { player.method_7346(); return false; }
        if (slot != DISMISS) confirmDismiss = false;
        switch (slot) {
            case SETTLE -> com.kiyamet.settle.Settlement.toggle(player, h);
            case FAMILY -> { if (h.bornDay < 0) com.kiyamet.settle.Family.propose(player, h); }
            case FOLLOW -> h.setOrder(HumanEntity.Order.FOLLOW);
            case STAY -> h.setOrder(HumanEntity.Order.STAY);
            case GUARD -> h.setOrder(HumanEntity.Order.GUARD);
            case WEAPON -> {
                class_1799 mine = player.method_6047().method_7972();
                class_1799 theirs = h.method_6047().method_7972();
                h.method_5673(class_1304.field_6173, mine);
                player.method_6122(net.minecraft.class_1268.field_5808, theirs);
            }
            case LOOKS -> { AppearanceMenu.open(player, h); return false; }
            case JOB -> h.setJob(Job.values()[(h.job().ordinal() + 1) % Job.values().length]);
            case RENAME -> { Rename.start(player, h); return false; }
            case RUN -> { h.sendAway(5, 1); player.method_7346(); player.method_64398(class_2561.method_43470(h.method_5477().getString() + " heads out on a supply run.").method_27692(class_124.field_1065)); return false; }
            case SQUAD -> { SquadMenu.open(player); return false; }
            case GATHER -> { GatherMenu.open(player, h); return false; }
            case GLOW -> h.method_5834(!h.method_36361());
            case HEAL -> {
                for (String id : new String[]{"kiyamet:medkit", "kiyamet:bandage"}) {
                    int slotIdx = find(id);
                    if (slotIdx >= 0) {
                        player.method_31548().method_5438(slotIdx).method_7934(1);
                        h.method_6025(id.endsWith("medkit") ? h.method_6063() : h.method_6063() * 0.3f);
                        return true;
                    }
                }
                player.method_7353(class_2561.method_43470("You have no medkit or bandage.").method_27692(class_124.field_1061), true);
                return false;
            }
            case BAG -> {
                player.method_17355(new class_747((id, inv, pl) -> net.minecraft.class_1707.method_19245(id, inv, h.inventory()),
                        class_2561.method_43470(h.method_5477().getString() + "'s inventory")));
                return false;
            }
            case TP -> { h.method_5859(player.method_23317(), player.method_23318(), player.method_23321()); h.setOrder(HumanEntity.Order.FOLLOW); }
            case DISMISS -> {
                if (!confirmDismiss) { confirmDismiss = true; return true; }
                h.setOwner(null);
                player.method_7346();
                player.method_64398(class_2561.method_43470(h.method_5477().getString() + " goes their own way.").method_27692(class_124.field_1080));
                return false;
            }
            default -> { return false; }
        }
        return true;
    }

    private int find(String id) {
        for (int i = 0; i < player.method_31548().method_5439(); i++)
            if (player.method_31548().method_5438(i).method_31574(Ui.item(id))) return i;
        return -1;
    }
}
