package com.kiyamet.npc;

import com.kiyamet.ui.PanelMenu;
import com.kiyamet.ui.Ui;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_747;
import net.minecraft.class_7923;

/** Pick what a companion should gather. */
public class GatherMenu extends PanelMenu {
    static final class_1792[] ICONS = {class_1802.field_8465, class_1802.field_8583, class_1802.field_20412, class_1802.field_8713, class_1802.field_33400, class_1802.field_33401, class_1802.field_33402, class_1802.field_8477, class_1802.field_8858, class_1802.field_8831};
    static final int[] SLOTS = {20, 21, 22, 23, 24, 29, 30, 31, 32, 33};
    private final HumanEntity h;

    public static void open(class_3222 p, HumanEntity h) {
        p.method_17355(new class_747((id, inv, pl) -> new GatherMenu(id, inv, p, h), class_2561.method_43470(h.method_5477().getString() + ": gather")));
    }

    private GatherMenu(int id, class_1661 inv, class_3222 p, HumanEntity h) { super(id, inv, p); this.h = h; redraw(); }

    @Override
    protected void draw() {
        c.method_5447(4, Ui.icon(class_1802.field_8403, Ui.text("What should " + h.method_5477().getString() + " gather?", class_124.field_1065, class_124.field_1067),
                Ui.text("Everything goes into their inventory", class_124.field_1080), Ui.text("They come back when the bag is full", class_124.field_1080)));
        for (int i = 0; i < Gatherer.KINDS.length; i++) {
            boolean now = h.order() == HumanEntity.Order.GATHER && h.gather.equals(Gatherer.KINDS[i][0]);
            c.method_5447(SLOTS[i], Ui.glint(Ui.icon(ICONS[i], Ui.text(Gatherer.KINDS[i][1], i == 0 ? class_124.field_1076 : class_124.field_1060, class_124.field_1067),
                    Ui.text(i == 0 ? "Chops wood, makes tools, mines stone and iron," : "Click to send them", class_124.field_1080),
                    Ui.text(i == 0 ? "smelts it into iron armor, then mines ores for you" : "", class_124.field_1080)), now));
        }
        class_1799 hand = player.method_6047();
        c.method_5447(40, Ui.icon(hand.method_7909() instanceof class_1747 ? hand.method_7909() : class_1802.field_8077, Ui.text("Gather the block in my hand", class_124.field_1075, class_124.field_1067),
                Ui.text(hand.method_7909() instanceof class_1747 ? hand.method_7964().getString() : "Hold a block (log, ore, stone...)", class_124.field_1080)));
        c.method_5447(49, Ui.icon(class_1802.field_8719, Ui.text("Stop - follow me", class_124.field_1061)));
    }

    @Override
    protected boolean click(int slot, class_1713 type) {
        if (!h.method_5805() || !h.isOwnedBy(player)) { player.method_7346(); return false; }
        String kind = null;
        for (int i = 0; i < SLOTS.length; i++) if (slot == SLOTS[i]) kind = Gatherer.KINDS[i][0];
        if (slot == 40 && player.method_6047().method_7909() instanceof class_1747 bi) kind = "block:" + class_7923.field_41175.method_10221(bi.method_7711());
        if (slot == 49) { h.setOrder(HumanEntity.Order.FOLLOW); player.method_7346(); return false; }
        if (kind == null) return false;
        h.gather = kind;
        h.setOrder(HumanEntity.Order.GATHER);
        Talk.say(player, h, kind.equals("develop") ? "On it. I'll start with some wood and work my way up." : "Got it. I'll bring it back.");
        player.method_7346();
        return false;
    }
}
