package com.kiyamet.npc;

import java.util.EnumSet;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1277;
import net.minecraft.class_1304;
import net.minecraft.class_1352;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3481;
import net.minecraft.class_7923;

/**
 * Companion gathering (1.6). Orders: wood, stone, coal, iron, copper, gold, diamond, sand, dirt, "the block in my hand",
 * or DEVELOP: chops wood, makes wooden tools, mines stone, makes stone tools, mines iron and coal, smelts it,
 * makes itself iron armor and an iron pickaxe, then keeps mining ores for you. Everything goes into its inventory.
 */
public class Gatherer extends class_1352 {
    public static final String[][] KINDS = {{"develop", "Develop: tools → armor → ores"}, {"wood", "Wood"}, {"stone", "Stone"}, {"coal", "Coal"}, {"iron", "Iron"},
            {"copper", "Copper"}, {"gold", "Gold"}, {"diamond", "Diamonds"}, {"sand", "Sand"}, {"dirt", "Dirt"}};
    private final HumanEntity h;
    private class_2338 target;
    private int mining, search, stuck;
    private double lastDist;

    public Gatherer(HumanEntity h) { this.h = h; method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406)); }

    @Override public boolean method_6264() { return h.order() == HumanEntity.Order.GATHER && h.method_5968() == null && h.method_73183() instanceof class_3218; }
    @Override public boolean method_6266() { return method_6264(); }
    @Override public void method_6270() { target = null; mining = 0; h.method_73183().method_8517(h.method_5628(), class_2338.field_10980, -1); }

    // ------------------------------------------------------------------ what to look for
    static boolean wants(String kind, class_2680 s) {
        if (s.method_26215()) return false;
        return switch (kind) {
            case "wood" -> s.method_26164(class_3481.field_15475);
            case "stone" -> s.method_27852(class_2246.field_10340) || s.method_27852(class_2246.field_10445) || s.method_27852(class_2246.field_28888) || s.method_27852(class_2246.field_10115) || s.method_27852(class_2246.field_10508) || s.method_27852(class_2246.field_10474) || s.method_27852(class_2246.field_27165);
            case "coal" -> s.method_26164(class_3481.field_29193);
            case "iron" -> s.method_26164(class_3481.field_28988);
            case "copper" -> s.method_26164(class_3481.field_29195);
            case "gold" -> s.method_26164(class_3481.field_23062);
            case "diamond" -> s.method_26164(class_3481.field_28989);
            case "sand" -> s.method_26164(class_3481.field_15466);
            case "dirt" -> s.method_27852(class_2246.field_10566) || s.method_27852(class_2246.field_10219) || s.method_27852(class_2246.field_10253);
            default -> kind.startsWith("block:") && class_7923.field_41175.method_10221(s.method_26204()).toString().equals(kind.substring(6));
        };
    }

    int count(class_1792 it) { int n = 0; class_1277 c = h.inventory(); for (int i = 0; i < c.method_5439(); i++) if (c.method_5438(i).method_31574(it)) n += c.method_5438(i).method_7947(); return n; }
    int countTag(net.minecraft.class_6862<class_1792> t) { int n = 0; class_1277 c = h.inventory(); for (int i = 0; i < c.method_5439(); i++) if (c.method_5438(i).method_31573(t)) n += c.method_5438(i).method_7947(); return n; }
    boolean take(class_1792 it, int n) { class_1277 c = h.inventory(); if (count(it) < n) return false; for (int i = 0; i < c.method_5439() && n > 0; i++) if (c.method_5438(i).method_31574(it)) { int k = Math.min(n, c.method_5438(i).method_7947()); c.method_5438(i).method_7934(k); n -= k; } return true; }
    boolean takeTag(net.minecraft.class_6862<class_1792> t, int n) { class_1277 c = h.inventory(); if (countTag(t) < n) return false; for (int i = 0; i < c.method_5439() && n > 0; i++) if (c.method_5438(i).method_31573(t)) { int k = Math.min(n, c.method_5438(i).method_7947()); c.method_5438(i).method_7934(k); n -= k; } return true; }
    boolean has(class_1792 it) { return count(it) > 0 || h.method_6047().method_31574(it); }
    void give(class_1799 s) { class_1799 left = h.inventory().method_5491(s); if (!left.method_7960()) h.method_5775((class_3218) h.method_73183(), left); }

    int pickTier() {
        if (has(class_1802.field_8377)) return 4; if (has(class_1802.field_8403)) return 3; if (has(class_1802.field_8387)) return 2; if (has(class_1802.field_8647)) return 1; return 0;
    }

    void say(String s) {
        if (h.ownerPlayer() instanceof class_3222 p && p.method_5739(h) < 64)
            p.method_64398(class_2561.method_43470("<" + h.method_5477().getString() + "> ").method_27692(class_124.field_1075).method_10852(class_2561.method_43470(s).method_27692(class_124.field_1068)));
    }

    /** Develop mode: craft and decide what to gather next. */
    String develop() {
        int logs = countTag(net.minecraft.class_3489.field_15539);
        int tier = pickTier();
        if (tier == 0) {
            if (logs >= 5) { takeTag(net.minecraft.class_3489.field_15539, 5); give(new class_1799(class_1802.field_8647)); give(new class_1799(class_1802.field_8406)); give(new class_1799(class_1802.field_8600, 4));
                say("Made a wooden pickaxe and axe. Going for stone."); return "stone"; }
            return "wood";
        }
        if (tier == 1) {
            if (count(class_1802.field_20412) + count(class_1802.field_29025) >= 8 && (logs >= 1 || count(class_1802.field_8600) >= 3)) {
                if (!take(class_1802.field_20412, 8)) { int c = count(class_1802.field_20412); take(class_1802.field_20412, c); take(class_1802.field_29025, 8 - c); }
                give(new class_1799(class_1802.field_8387)); give(new class_1799(class_1802.field_8062)); give(new class_1799(class_1802.field_8528));
                say("Stone tools done. Now I need iron and coal."); return "iron";
            }
            return logs < 1 && count(class_1802.field_8600) < 3 ? "wood" : "stone";
        }
        boolean armored = h.method_6118(class_1304.field_6174).method_31574(class_1802.field_8523);
        if (tier == 2 || !armored) {
            int raw = count(class_1802.field_33400) + count(class_1802.field_8620), coal = count(class_1802.field_8713) + count(class_1802.field_8665);
            if (raw >= 27 && coal >= 4) {
                take(class_1802.field_33400, Math.min(count(class_1802.field_33400), 27)); int ci = 27 - 0; if (!take(class_1802.field_8713, 4)) take(class_1802.field_8665, 4);
                h.method_5673(class_1304.field_6169, new class_1799(class_1802.field_8743)); h.method_5673(class_1304.field_6174, new class_1799(class_1802.field_8523));
                h.method_5673(class_1304.field_6172, new class_1799(class_1802.field_8396)); h.method_5673(class_1304.field_6166, new class_1799(class_1802.field_8660));
                give(new class_1799(class_1802.field_8403)); give(new class_1799(class_1802.field_8475));
                say("Smelted the iron. I've got full iron armor and an iron pickaxe now! I'll mine ores for you.");
                return "coal";
            }
            return coal < 4 ? (h.method_59922().method_43056() ? "coal" : "iron") : "iron";
        }
        // geared up: keep mining what's valuable
        int r = (h.field_6012 / 2400) % 4;
        return r == 0 ? "diamond" : r == 1 ? "iron" : r == 2 ? "gold" : "coal";
    }

    void tool(class_2680 s) {
        class_1792 best = null;
        if (s.method_26164(class_3481.field_33713)) best = has(class_1802.field_8475) ? class_1802.field_8475 : has(class_1802.field_8062) ? class_1802.field_8062 : has(class_1802.field_8406) ? class_1802.field_8406 : null;
        else if (s.method_26164(class_3481.field_33715)) best = has(class_1802.field_8377) ? class_1802.field_8377 : has(class_1802.field_8403) ? class_1802.field_8403 : has(class_1802.field_8387) ? class_1802.field_8387 : has(class_1802.field_8647) ? class_1802.field_8647 : null;
        else if (s.method_26164(class_3481.field_33716)) best = null;
        if (best == null || h.method_6047().method_31574(best)) return;
        // swap: hand item into the bag, tool out of the bag
        class_1277 c = h.inventory();
        for (int i = 0; i < c.method_5439(); i++) if (c.method_5438(i).method_31574(best)) {
            class_1799 t = c.method_5438(i).method_7972(); c.method_5447(i, h.method_6047().method_7972()); h.method_5673(class_1304.field_6173, t); return;
        }
    }

    boolean canHarvest(class_2680 s) {
        if (!s.method_29291()) return true;
        int need = s.method_26164(class_3481.field_33717) ? 3 : s.method_26164(class_3481.field_33718) ? 2 : s.method_26164(class_3481.field_33719) ? 1 : 1;
        return pickTier() >= need + (need == 1 ? 0 : 0) || (need == 1 && pickTier() >= 1);
    }

    class_2338 find(class_3218 level, String kind) {
        class_2338 c = h.method_24515(); class_2338 best = null; double bd = Double.MAX_VALUE;
        int r = kind.equals("wood") || kind.equals("sand") || kind.equals("dirt") ? 18 : 14;
        for (class_2338 p : class_2338.method_10097(c.method_10069(-r, -10, -r), c.method_10069(r, 8, r))) {
            class_2680 s = level.method_8320(p);
            if (!wants(kind, s) || !canHarvest(s)) continue;
            double d = p.method_10262(c) + Math.abs(p.method_10264() - c.method_10264()) * 6;
            if (d < bd) { bd = d; best = p.method_10062(); }
        }
        return best;
    }

    @Override
    public void method_6268() {
        class_3218 level = (class_3218) h.method_73183();
        String kind = h.gather.equals("develop") ? develop() : h.gather;
        if (h.inventory().method_5438(h.inventory().method_5439() - 1).method_7960() == false && full()) {
            say("My bag is full - coming back to you."); h.setOrder(HumanEntity.Order.FOLLOW); return;
        }
        if (target == null || !wants(kind, level.method_8320(target)) && !level.method_8320(target).method_26215() && mining == 0) {
            if (--search > 0) return;
            search = 30;
            target = find(level, kind);
            mining = 0; stuck = 0; lastDist = 999;
            if (target == null) {
                if (h.field_6012 % 400 < 30) say(switch (kind) { case "wood" -> "No trees around here."; case "stone" -> "Can't find stone nearby."; default -> "No " + kind + " nearby. Take me somewhere else?"; });
                if (h.ownerPlayer() instanceof class_3222 p && h.method_5739(p) > 10) h.method_5942().method_6335(p, 1.0);
                return;
            }
        }
        if (level.method_8320(target).method_26215()) { target = null; return; }
        class_243 c = class_243.method_24953(target);
        double d = h.method_33571().method_1022(c);
        h.method_5988().method_20248(c.field_1352, c.field_1351, c.field_1350);
        if (d > 4.2) {
            if (h.field_6012 % 10 == 0) {
                h.method_5942().method_6337(target.method_10263() + 0.5, target.method_10264(), target.method_10260() + 0.5, 1.0);
                if (d > lastDist - 0.3) stuck++; else stuck = 0;
                lastDist = d;
            }
            if (stuck > 6) tunnel(level, c);        // can't get there: dig a way through
            return;
        }
        h.method_5942().method_6340();
        mine(level, target);
    }

    boolean full() { class_1277 c = h.inventory(); for (int i = 0; i < c.method_5439(); i++) if (c.method_5438(i).method_7960()) return false; return true; }

    void tunnel(class_3218 level, class_243 to) {
        class_243 dir = to.method_1020(h.method_73189()).method_1029();
        class_2338 feet = h.method_24515();
        class_2338 step = class_2338.method_49637(h.method_23317() + dir.field_1352 * 1.2, h.method_23318() + (dir.field_1351 < -0.5 ? -1 : 0), h.method_23321() + dir.field_1350 * 1.2);
        for (class_2338 p : new class_2338[]{step, step.method_10084()}) {
            class_2680 s = level.method_8320(p);
            if (!s.method_26215() && s.method_26214(level, p) >= 0 && s.method_26214(level, p) < 30 && s.method_26227().method_15769() && !p.equals(feet.method_10074())) { mine(level, p); return; }
        }
        stuck = 0;
    }

    void mine(class_3218 level, class_2338 p) {
        class_2680 s = level.method_8320(p);
        tool(s);
        float hard = s.method_26214(level, p);
        float speed = Math.max(1f, h.method_6047().method_7924(s));
        int need = Math.max(4, (int) (hard * 30 / speed));
        mining++;
        if (mining % 5 == 0) h.method_6104(class_1268.field_5808);
        level.method_8517(h.method_5628(), p, Math.min(9, mining * 10 / need));
        if (mining < need) return;
        mining = 0;
        level.method_8517(h.method_5628(), p, -1);
        List<class_1799> drops = class_2248.method_9609(s, level, p, level.method_8321(p), h, h.method_6047());
        level.method_8651(p, false, h);
        for (class_1799 it : drops) give(it);
        if (p.equals(target)) target = null;
    }
}
