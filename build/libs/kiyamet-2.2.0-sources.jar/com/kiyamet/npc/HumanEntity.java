package com.kiyamet.npc;

import com.kiyamet.boss.BossEntity;
import com.kiyamet.entity.KZombie;
import com.kiyamet.robot.RobotEntity;
import com.kiyamet.ui.Ui;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.animation.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.EnumSet;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_124;
import net.minecraft.class_1259;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_1324;
import net.minecraft.class_1347;
import net.minecraft.class_1352;
import net.minecraft.class_1361;
import net.minecraft.class_1366;
import net.minecraft.class_1376;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1542;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3213;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4255;
import net.minecraft.class_5134;

/**
 * Every living person in the apocalypse: survivors, community members, raiders, masked ones and companions.
 * One level (1-300) drives health, armour and weapon damage. Companions level up from their kills.
 */
public class HumanEntity extends class_1314 implements GeoEntity {
    public static final int MAX_LEVEL = 300;
    public static final RawAnimation IDLE = RawAnimation.begin().thenLoop("misc.idle");
    public static final RawAnimation WALK = RawAnimation.begin().thenLoop("move.walk");
    public static final RawAnimation ATTACK = RawAnimation.begin().thenPlay("attack.swing");

    private static final class_2940<Integer> APPEARANCE = class_2945.method_12791(HumanEntity.class, class_2943.field_13327);
    private static final class_2940<Integer> LEVEL = class_2945.method_12791(HumanEntity.class, class_2943.field_13327);
    private static final class_2940<Integer> FACTION = class_2945.method_12791(HumanEntity.class, class_2943.field_13327);
    private static final class_2940<Integer> ROLE = class_2945.method_12791(HumanEntity.class, class_2943.field_13327);

    public enum Order { FOLLOW, STAY, GUARD, GATHER }
    /** what a GATHER order collects (see Gatherer) */
    public String gather = "";

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private boolean initialized;
    private int xp;
    @Nullable private UUID owner;
    private Order order = Order.FOLLOW;
    @Nullable private class_2338 home;
    private String community = "", communityType = "";
    private int shotCooldown;
    private Job job = Job.NONE;
    private int team;

    public int team() { return team; }
    public void setTeam(int t) { team = Math.floorMod(t, 3); }
    /** Game time when the current supply run ends (0 = not away). */
    private long awayUntil;
    private int awayMinutes, awayGroup;

    public Job job() { return job; }
    public void setJob(Job j) { job = j; applyStats(false); }
    public boolean isAway() { return awayUntil > 0; }
    public long awayUntil() { return awayUntil; }
    private static final class_2940<Integer> GEAR = class_2945.method_12791(HumanEntity.class, class_2943.field_13327);
    private static final class_2940<Integer> PROFESSION = class_2945.method_12791(HumanEntity.class, class_2943.field_13327);

    public Specialty specialty() { return profession().specialty(); }
    public Profession profession() { int p = field_6011.method_12789(PROFESSION); return p < 0 ? Profession.SURVIVOR : Profession.values()[Math.min(p, Profession.values().length - 1)]; }
    public boolean hasProfession() { return field_6011.method_12789(PROFESSION) >= 0; }
    public Gear gear() { return Gear.unpack(field_6011.method_12789(GEAR)); }
    public int gearCode() { return field_6011.method_12789(GEAR); }
    public void setGear(Gear g) { field_6011.method_12778(GEAR, g.pack()); }
    public void setProfession(Profession p) { field_6011.method_12778(PROFESSION, p.ordinal()); }
    @Nullable private class_3213 bar;
    /** Companion backpack: 27 slots, opened from the companion panel. Medkits and bandages inside are used automatically. */
    private final net.minecraft.class_1277 inventory = new net.minecraft.class_1277(27);

    public net.minecraft.class_1277 inventory() { return inventory; }

    public HumanEntity(class_1299<? extends class_1314> type, class_1937 level) {
        super(type, level);
        method_5971();
        method_5952(false);
    }

    // ---------------------------------------------------------------- data

    @Override
    protected void method_5693(class_2945.class_9222 b) {
        super.method_5693(b);
        b.method_56912(APPEARANCE, 0);
        b.method_56912(LEVEL, 1);
        b.method_56912(FACTION, Faction.SURVIVOR.ordinal());
        b.method_56912(ROLE, Role.MEMBER.ordinal());
        b.method_56912(GEAR, 0);
        b.method_56912(PROFESSION, -1);
    }

    public Appearance appearance() { return Appearance.unpack(field_6011.method_12789(APPEARANCE)); }
    public int appearanceCode() { return field_6011.method_12789(APPEARANCE); }
    public void setAppearance(Appearance a) { field_6011.method_12778(APPEARANCE, a.pack()); }
    public int lvl() { return field_6011.method_12789(LEVEL); }
    public Faction faction() { return Faction.byId(field_6011.method_12789(FACTION)); }
    public Role role() { return Role.byId(field_6011.method_12789(ROLE)); }
    public boolean isWhisperer() { return faction() == Faction.WHISPERER; }
    /** Part of a base raid: allied with the walkers it came with. */
    public boolean raiding;
    /** A raider envoy who came to demand tribute: peaceful until refused. */
    public boolean envoy;
    public final Captives.Data captives = new Captives.Data();
    /** Companion morale 0-100 (see Mind). */
    public float morale = 70;
    /** 1.9 settlement + family */
    public String work = "";                       // settlement job: FARMER, SMITH, DOCTOR, GUARD, COOK ("" = not settled)
    @Nullable public class_2338 settleAt;            // the settlement bell they live by
    public boolean partner;                        // your partner
    public long pregnantDay = -1, bornDay = -1;    // calendar day index
    public @Nullable class_2338 home() { return home; }
    public void setHome(@Nullable class_2338 h) { home = h; }
    public String community() { return community; }
    public String communityType() { return communityType; }
    @Nullable public UUID owner() { return owner; }
    public Order order() { return order; }
    public int xp() { return xp; }
    public static int xpToNext(int level) { return 40 + level * 10; }

    public boolean isOwnedBy(class_1657 p) { return owner != null && owner.equals(p.method_5667()); }

    @Nullable public class_3222 ownerPlayer() {
        return owner != null && method_73183() instanceof class_3218 sl ? sl.method_8503().method_3760().method_14602(owner) : null;
    }

    /** Sets everything at once (used by spawners and the structure loader). */
    public void setup(Faction f, Role r, int level, @Nullable String communityType) {
        field_6011.method_12778(FACTION, f.ordinal());
        field_6011.method_12778(ROLE, r.ordinal());
        field_6011.method_12778(LEVEL, Math.max(1, Math.min(MAX_LEVEL, level)));
        if (communityType != null) this.communityType = communityType;
        boolean fresh = field_6011.method_12789(APPEARANCE) == 0;
        boolean female = fresh ? field_5974.method_43057() < (f == Faction.RAIDER ? 0.3f : 0.42f) : appearance().female();
        if (!hasProfession()) setProfession(Profession.choose(field_5974, f, r, this.communityType, female));
        Profession prof = profession();
        if (prof.gender == 2) female = true;
        if (prof.gender == 1) female = false;
        if (fresh) {
            setAppearance(prof.dress(field_5974, Appearance.random(field_5974, f, r, female)));
            setGear(prof.gear(field_5974));
        }
        if (method_6047().method_7960()) {
            String w = prof.randomWeapon(field_5974);
            method_5673(class_1304.field_6173, w.isEmpty() ? Weapon.random(field_5974, f, r, level) : new class_1799(Ui.item(w)));
        }
        method_5946(class_1304.field_6173, f == Faction.COMPANION ? 1f : 0.15f);
        String name = Names.random(field_5974, f, r, appearance().female());
        if (name != null && !method_16914()) method_5665(class_2561.method_43470(name));
        initialized = true;
        applyStats(true);
    }

    public void applyStats(boolean heal) {
        int lv = lvl();
        Role r = role();
        set(class_5134.field_23716, (20 + lv * 1.1) * r.hpMult * (job == Job.GUARDIAN ? 1.4 : 1.0));
        set(class_5134.field_23721, (2 + lv * 0.07) * r.dmgMult);
        set(class_5134.field_23724, Math.min(30, lv * 0.075 * r.hpMult + (job == Job.GUARDIAN ? 6 : 0)));
        set(class_5134.field_23725, Math.min(12, lv * 0.03));
        set(class_5134.field_23719, (faction() == Faction.WHISPERER ? 0.2 : 0.3 + Math.min(0.06, lv * 0.0002)) * (job == Job.SCOUT ? 1.15 : 1.0));
        set(class_5134.field_23718, Math.min(0.8, lv / 375.0));
        if (heal) method_6033(method_6063());
        refreshBar();
    }

    private void set(net.minecraft.class_6880<net.minecraft.class_1320> a, double v) {
        class_1324 inst = method_5996(a);
        if (inst != null) inst.method_6192(v);
    }

    public void setOwner(@Nullable class_3222 p) {
        owner = p == null ? null : p.method_5667();
        if (p != null) {
            field_6011.method_12778(FACTION, Faction.COMPANION.ordinal());
            community = "";
            home = null;
            order = Order.FOLLOW;
            method_5946(class_1304.field_6173, 1f);
        } else field_6011.method_12778(FACTION, Faction.SURVIVOR.ordinal());
        method_5980(null);
    }

    /** 1.9: a companion whose mind broke turns on you - steals something and joins the raiders. */
    public void betray(class_3222 from) {
        owner = null; community = ""; home = null;
        field_6011.method_12778(FACTION, Faction.RAIDER.ordinal());
        var inv = from.method_31548();
        java.util.List<Integer> slots = new java.util.ArrayList<>();
        for (int i = 9; i < 36; i++) if (!inv.method_5438(i).method_7960()) slots.add(i);
        if (!slots.isEmpty()) {
            int i = slots.get(field_5974.method_43048(slots.size()));
            class_1799 stolen = inv.method_5441(i);
            from.method_64398(class_2561.method_43470(method_5477().getString() + " stole your " + stolen.method_7964().getString() + " (x" + stolen.method_7947() + ")! Kill them to get it back.").method_27692(class_124.field_1061));
            method_5673(class_1304.field_6171, stolen); method_5946(class_1304.field_6171, 1f);
        }
        method_5980(from);
        refreshBar();
    }

    public void setOrder(Order o) {
        order = o;
        if (o != Order.FOLLOW) home = method_24515();
        method_5942().method_6340();
    }

    public void setAppearanceCode(int code) { field_6011.method_12778(APPEARANCE, code); }

    @Override
    protected void method_5652(class_11372 out) {
        super.method_5652(out);
        out.method_71465("Appearance", field_6011.method_12789(APPEARANCE));
        out.method_71465("Level", lvl());
        out.method_71472("Raiding", raiding);
        out.method_71472("Envoy", envoy);
        Captives.save(out, captives);
        out.method_71464("Morale", morale);
        out.method_71469("Faction", faction().name());
        out.method_71469("Role", role().name());
        out.method_71465("Xp", xp);
        out.method_71469("Profession", profession().name());
        out.method_71469("Job", job.name());
        out.method_71465("KTeam", team);
        out.method_71466("AwayUntil", awayUntil);
        out.method_71465("AwayMinutes", awayMinutes);
        out.method_71465("AwayGroup", awayGroup);
        out.method_71465("Gear", field_6011.method_12789(GEAR));
        out.method_71469("Order", order.name());
        out.method_71469("Gather", gather);
        out.method_71469("Community", community);
        out.method_71469("Work", work);
        if (settleAt != null) out.method_71466("SettleAt", settleAt.method_10063());
        out.method_71472("Partner", partner);
        out.method_71466("PregnantDay", pregnantDay);
        out.method_71466("BornDay", bornDay);
        out.method_71469("CommunityType", communityType);
        if (owner != null) out.method_71469("Owner", owner.toString());
        if (home != null) out.method_71466("Home", home.method_10063());
        out.method_71472("Ready", initialized);
        java.util.List<class_1799> items = new java.util.ArrayList<>();
        for (int i = 0; i < inventory.method_5439(); i++) items.add(inventory.method_5438(i));
        out.method_71468("Inventory", class_1799.field_49266.listOf(), items);
    }

    @Override
    protected void method_5749(class_11368 in) {
        super.method_5749(in);
        field_6011.method_12778(APPEARANCE, in.method_71424("Appearance", 0));
        field_6011.method_12778(LEVEL, Math.max(1, in.method_71424("Level", 1)));
        raiding = in.method_71433("Raiding", false);
        envoy = in.method_71433("Envoy", false);
        Captives.load(in, captives);
        morale = in.method_71423("Morale", 70f);
        work = in.method_71428("Work", "");
        long sa = in.method_71425("SettleAt", Long.MIN_VALUE); settleAt = sa == Long.MIN_VALUE ? null : class_2338.method_10092(sa);
        partner = in.method_71433("Partner", false);
        pregnantDay = in.method_71425("PregnantDay", -1L);
        bornDay = in.method_71425("BornDay", -1L);
        try { field_6011.method_12778(FACTION, Faction.valueOf(in.method_71428("Faction", "SURVIVOR")).ordinal()); } catch (IllegalArgumentException ignored) {}
        try { field_6011.method_12778(ROLE, Role.valueOf(in.method_71428("Role", "MEMBER")).ordinal()); } catch (IllegalArgumentException ignored) {}
        xp = in.method_71424("Xp", 0);
        job = Job.byName(in.method_71428("Job", "NONE"));
        team = in.method_71424("KTeam", 0);
        awayUntil = in.method_71425("AwayUntil", 0L);
        awayMinutes = in.method_71424("AwayMinutes", 0);
        awayGroup = in.method_71424("AwayGroup", 1);
        String prof = in.method_71428("Profession", "");
        if (!prof.isEmpty()) setProfession(Profession.byName(prof));
        else switch (Specialty.byName(in.method_71428("Specialty", "NONE"))) {
            case NURSE -> setProfession(Profession.NURSE);
            case HUNTRESS -> setProfession(Profession.HUNTRESS);
            case SCAVENGER -> setProfession(Profession.SCAVENGER);
            case ENGINEER -> setProfession(Profession.ENGINEER);
            default -> {}
        }
        field_6011.method_12778(GEAR, in.method_71424("Gear", 0));
        try { order = Order.valueOf(in.method_71428("Order", "FOLLOW")); } catch (IllegalArgumentException ignored) {}
        gather = in.method_71428("Gather", "");
        community = in.method_71428("Community", "");
        communityType = in.method_71428("CommunityType", "");
        String o = in.method_71428("Owner", "");
        owner = o.isEmpty() ? null : UUID.fromString(o);
        long h = in.method_71425("Home", Long.MIN_VALUE);
        home = h == Long.MIN_VALUE ? null : class_2338.method_10092(h);
        initialized = in.method_71433("Ready", false);
        in.method_71426("Inventory", class_1799.field_49266.listOf()).ifPresent(l -> { for (int i = 0; i < l.size() && i < inventory.method_5439(); i++) inventory.method_5447(i, l.get(i)); });
    }

    // ---------------------------------------------------------------- AI

    @Override
    protected void method_5959() {
        field_6201.method_6277(0, new class_1347(this));
        field_6201.method_6277(1, new class_4255(this, true));
        field_6201.method_6277(2, new ShootGoal());
        field_6201.method_6277(3, new class_1366(this, 1.15, true) {
            @Override public boolean method_6264() { return !Weapon.ranged(method_6047()) || closeToTarget() ? super.method_6264() : false; }
            @Override public boolean method_6266() { return (!Weapon.ranged(method_6047()) || closeToTarget()) && super.method_6266(); }
        });
        field_6201.method_6277(4, new FollowOwnerGoal());
        field_6201.method_6277(4, new Gatherer(this));
        field_6201.method_6277(5, new StayHomeGoal());
        field_6201.method_6277(6, new class_1394(this, 0.7) {
            @Override public boolean method_6264() { return order == Order.FOLLOW && owner == null && super.method_6264(); }
        });
        field_6201.method_6277(7, new class_1361(this, class_1657.class, 10f));
        field_6201.method_6277(8, new class_1376(this));

        field_6185.method_6277(1, new class_1399(this).method_6318(HumanEntity.class));
        field_6185.method_6277(2, new OwnerDefenseGoal());
        field_6185.method_6277(3, new class_1400<>(this, class_1657.class, 10, true, false, (t, l) -> isHostileTo(t)));
        field_6185.method_6277(4, new class_1400<>(this, HumanEntity.class, 10, true, false, (t, l) -> isHostileTo(t)));
        field_6185.method_6277(5, new class_1400<>(this, class_1588.class, 10, true, false,
                (t, l) -> !isWhisperer() && !(raiding && t instanceof KZombie) && (t instanceof KZombie || t instanceof RobotEntity || t instanceof BossEntity && owner != null)));
    }

    private boolean closeToTarget() {
        class_1309 t = method_5968();
        return t != null && method_5739(t) < 3.5;
    }

    /** Who this person wants to fight. */
    public boolean isHostileTo(class_1309 e) {
        if (e == this || !e.method_5805()) return false;
        if (envoy || e instanceof HumanEntity he && (he.envoy || he.captives.captive) || captives.captive) return false;
        Faction f = faction();
        if (e instanceof class_1657 p) {
            if (p.method_68878() || p.method_7325()) return false;
            return switch (f) {
                case RAIDER, WHISPERER -> true;
                case COMMUNITY -> Communities.reputation(p, community) < 0;
                default -> false;
            };
        }
        if (e instanceof HumanEntity h) {
            Faction o = h.faction();
            boolean bad = o == Faction.RAIDER || o == Faction.WHISPERER;
            boolean me = f == Faction.RAIDER || f == Faction.WHISPERER;
            if (f == Faction.COMPANION) return bad || (o == Faction.COMMUNITY && ownerPlayer() != null && Communities.reputation(ownerPlayer(), h.community) < 0 && h.method_5968() != null);
            if (me) return !bad;                                         // raiders and masked ones prey on everyone else
            return bad;                                                  // decent folk fight raiders
        }
        return false;
    }

    class ShootGoal extends class_1352 {
        ShootGoal() { method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406)); }

        @Override public boolean method_6264() {
            class_1309 t = method_5968();
            return t != null && t.method_5805() && Weapon.ranged(method_6047()) && !closeToTarget();
        }

        @Override public void method_6268() {
            class_1309 t = method_5968();
            if (t == null) return;
            method_5988().method_6226(t, 30f, 30f);
            double d = method_5739(t);
            boolean see = method_6057(t);
            if (d > 14 || !see) method_5942().method_6335(t, 1.05);
            else method_5942().method_6340();
            if (shotCooldown > 0 || !see || d > 24 || !(method_73183() instanceof class_3218 sl)) return;
            class_1799 w = method_6047();
            shotCooldown = w.method_7909() instanceof com.kiyamet.item.GunItem ? 22 : w.method_31574(class_1802.field_8399) ? 30 : 26;
            if (role() == Role.COMMANDER) shotCooldown = 12;
            if (specialty() == Specialty.HUNTRESS) shotCooldown = (int) (shotCooldown * 0.7);
            if (job == Job.GUNNER) shotCooldown = (int) (shotCooldown * 0.8);
            class_243 from = method_33571(), to = t.method_33571();
            float spread = (float) Math.max(0.05, 0.5 - lvl() / 600.0);
            boolean hit = field_5974.method_43057() > spread * 0.6 || specialty() == Specialty.HUNTRESS && d < 12;
            int n = (int) (from.method_1022(to) * 2);
            for (int i = 0; i < n; i++) { class_243 at = from.method_1019(to.method_1020(from).method_1021(i / (double) n)); sl.method_65096(class_2398.field_11205, at.field_1352, at.field_1351, at.field_1350, 1, 0, 0, 0, 0); }
            sl.method_8396(null, method_24515(), w.method_7909() instanceof com.kiyamet.item.GunItem ? class_3417.field_15187 : class_3417.field_14600, class_3419.field_15251, 1f, 0.9f + field_5974.method_43057() * 0.2f);
            triggerAnim("attack", "attack");
            if (hit) {
                float dmg = (float) (method_45325(class_5134.field_23721) * 0.85 * Weapon.tier(w) * (specialty() == Specialty.HUNTRESS ? 1.3 : 1.0) * (job == Job.GUNNER ? 1.25 : 1.0));
                t.method_64397(sl, sl.method_48963().method_48803(null, HumanEntity.this), dmg);
            }
            if (w.method_7909() instanceof com.kiyamet.item.GunItem) com.kiyamet.world.NoiseSystem.make(sl, method_24515(), 20, 2);
        }
    }

    class FollowOwnerGoal extends class_1352 {
        FollowOwnerGoal() { method_6265(EnumSet.of(class_4134.field_18405)); }

        @Override public boolean method_6264() {
            class_3222 p = ownerPlayer();
            return order == Order.FOLLOW && p != null && p.method_51469() == method_73183() && method_5739(p) > 5 && method_5968() == null;
        }

        @Override public boolean method_6266() { return method_6264() && ownerPlayer() != null && method_5739(ownerPlayer()) > 3; }

        @Override public void method_6268() {
            class_3222 p = ownerPlayer();
            if (p == null) return;
            method_5988().method_6226(p, 10f, method_5978());
            if (method_5739(p) > 28) { method_5859(p.method_23317() + field_5974.method_43048(3) - 1, p.method_23318(), p.method_23321() + field_5974.method_43048(3) - 1); method_5942().method_6340(); }
            else method_5942().method_6335(p, method_5739(p) > 10 ? 1.3 : 1.0);
        }
    }

    class StayHomeGoal extends class_1352 {
        StayHomeGoal() { method_6265(EnumSet.of(class_4134.field_18405)); }

        private int radius() { return order == Order.STAY ? 1 : order == Order.GUARD ? 10 : 18; }

        @Override public boolean method_6264() {
            if (home == null || order == Order.GATHER || order == Order.FOLLOW && owner != null) return false;
            return home.method_10262(method_24515()) > radius() * radius() && (method_5968() == null || order == Order.STAY);
        }

        @Override public void method_6269() { method_5942().method_6337(home.method_10263() + 0.5, home.method_10264(), home.method_10260() + 0.5, 1.0); }

        @Override public boolean method_6266() { return home != null && !method_5942().method_6357() && home.method_10262(method_24515()) > 4; }
    }

    class OwnerDefenseGoal extends class_1352 {
        @Override public boolean method_6264() {
            class_3222 p = ownerPlayer();
            if (p == null) return false;
            class_1309 a = p.method_6065();
            class_1309 b = p.method_6052();
            class_1309 pick = a != null && a.method_5805() && a != HumanEntity.this ? a : b != null && b.method_5805() && !(b instanceof HumanEntity h && h.isOwnedBy(p)) ? b : null;
            if (pick == null || pick == method_5968() || pick.method_5739(HumanEntity.this) > 32) return false;
            method_5980(pick);
            return false;
        }
    }

    // ---------------------------------------------------------------- ticking

    @Override
    public void method_5773() {
        super.method_5773();
        if (!(method_73183() instanceof class_3218 sl)) return;
        if (!initialized) setup(faction(), role(), lvl(), null);
        if (awayUntil > 0) { tickAway(sl); return; }
        if (owner != null && (field_6012 + method_5628()) % 1200 == 0) com.kiyamet.settle.Settlement.work(sl, this);
        if (bornDay >= 0 && field_6012 % 40 == 0) com.kiyamet.settle.Family.grow(sl, this);
        if (bornDay >= 0 && method_5752().contains(com.kiyamet.settle.Family.CARRY_TAG)) com.kiyamet.settle.Family.follow(sl, this);
        if (owner != null && field_6012 % 60 == 0) Radio.report(this);
        if (owner != null && job == Job.SCOUT && field_6012 % 100 == 0) scout(sl);
        if (owner != null && job == Job.GUARDIAN && field_6012 % 40 == 0) guard(sl);
        if (owner != null && job == Job.LOOTER && field_6012 % 6000 == 3000) scavenge();
        Captives.tick(sl, this, captives);
        if (faction() == Faction.COMPANION && field_6012 % 20 == 3 && ownerPlayer() instanceof class_3222 mo && mo.method_51469() == sl && !isAway()) Mind.companion(sl, this, mo);
        // 1.6: ride along in the owner's vehicle, get out when they do
        if (faction() == Faction.COMPANION && field_6012 % 10 == 7 && ownerPlayer() instanceof class_3222 op && op.method_51469() == sl) {
            if (op.method_5854() instanceof com.kiyamet.vehicle.VehicleEntity v && order == Order.FOLLOW && method_5854() != v && method_5739(v) < 16
                    && v.method_5685().size() < v.kind.seats.length) { method_5848(); method_5873(v, true, true); }
            else if (method_5854() instanceof com.kiyamet.vehicle.VehicleEntity v && op.method_5854() != v && v.autoDest == null) method_5848();
        }
        if (raiding && !captives.captive) com.kiyamet.defense.DefenseRules.tickRaider(sl, this);
        if (faction() == Faction.COMPANION && field_6012 % 20 == 7 && field_5974.method_43048(450) == 0 && ownerPlayer() instanceof class_3222 op
                && op.method_51469() == sl && method_5739(op) < 24 && !Talk.busy(op) && !isAway()) Dialogues.chatter(op, this);
        if (role() == Role.LEADER && faction() == Faction.COMMUNITY && field_6012 % 400 == 100
                && sl.method_18467(com.kiyamet.twd.MissionBoard.class, method_5829().method_1014(40)).isEmpty()) {
            com.kiyamet.twd.MissionBoard b = com.kiyamet.twd.ModTwd.MISSION_BOARD.method_5883(sl, net.minecraft.class_3730.field_16467);
            if (b != null) {
                class_2338 at = sl.method_8598(net.minecraft.class_2902.class_2903.field_13203, method_24515().method_10069(3, 0, 2));
                b.method_5814(at.method_10263() + 0.5, at.method_10264(), at.method_10260() + 0.5);
                b.community = community;
                sl.method_8649(b);
            }
        }
        if (shotCooldown > 0) shotCooldown--;
        if (home == null && owner == null && faction() == Faction.COMMUNITY) home = method_24515();
        if (faction() == Faction.COMMUNITY && community.isEmpty() && field_6012 > 5) community = Communities.assign(sl, this);
        if (bar != null) bar.method_5408(method_6032() / method_6063());
        if (field_6012 % 100 == 0 && method_6032() < method_6063() && method_5968() == null) method_6025(1 + lvl() / 60f);
        if (faction() == Faction.COMPANION && owner != null && field_6012 % 40 == 0 && ownerPlayer() == null && order == Order.FOLLOW) setOrder(Order.STAY);
        if (field_6012 % 40 == 0 && method_6032() < method_6063() * 0.4f) selfHeal();
        if (specialty() == Specialty.NURSE && field_6012 % 200 == 0) nurse(sl);
        if (specialty() == Specialty.ENGINEER && field_6012 % 300 == 150) engineer(sl);
        if (specialty() == Specialty.SCAVENGER && owner != null && field_6012 % 3600 == 1800) scavenge();
    }

    public void setCommunity(String key) { community = key; }

    // ---------------------------------------------------------------- jobs & supply runs

    private void scout(class_3218 sl) {
        List<net.minecraft.class_1308> foes = sl.method_8390(net.minecraft.class_1308.class, method_5829().method_1014(40), m -> m instanceof net.minecraft.class_1569 && m.method_5805());
        for (net.minecraft.class_1308 m : foes) m.method_6092(new net.minecraft.class_1293(net.minecraft.class_1294.field_5912, 120, 0, false, false));
        class_3222 p = ownerPlayer();
        if (p != null && foes.size() >= 6 && field_6012 % 600 == 0)
            p.method_64398(class_2561.method_43470(method_5477().getString() + " (Scout): " + foes.size() + " hostiles nearby!").method_27692(class_124.field_1065));
    }

    private void guard(class_3218 sl) {
        class_3222 p = ownerPlayer();
        if (p == null || method_5739(p) > 16) return;
        for (net.minecraft.class_1308 m : sl.method_8390(net.minecraft.class_1308.class, method_5829().method_1014(10), m -> m.method_5968() == p && !(m instanceof HumanEntity h && h.isOwnedBy(p))))
            m.method_5980(this);
    }

    /** Sends this companion on a supply run with {@code group} people for {@code minutes}. */
    public void sendAway(int minutes, int group) {
        if (!(method_73183() instanceof class_3218 sl)) return;
        awayMinutes = minutes;
        awayGroup = Math.max(1, group);
        awayUntil = sl.method_75260() + minutes * 1200L;
        method_5648(true);
        method_5684(true);
        method_5803(true);
        method_5977(true);
        field_5960 = true;
        method_5980(null);
        sl.method_65096(class_2398.field_11204, method_23317(), method_23318() + 1, method_23321(), 20, 0.3, 0.6, 0.3, 0.02);
    }

    private void tickAway(class_3218 sl) {
        class_3222 p = ownerPlayer();
        if (p != null && p.method_51469() == sl) method_5814(p.method_23317(), p.method_23318() + 0.1, p.method_23321());   // stays with you, unseen
        if (sl.method_75260() < awayUntil) return;
        awayUntil = 0;
        method_5648(false);
        method_5684(false);
        method_5803(false);
        method_5977(false);
        field_5960 = false;
        setOrder(Order.FOLLOW);
        // danger: the longer the run and the lower the level, the riskier
        float risk = Math.max(0.01f, awayMinutes * 0.02f - lvl() / 400f - (awayGroup - 1) * 0.02f);
        if (field_5974.method_43057() < risk * 0.25f) {
            if (p != null) p.method_64398(class_2561.method_43470(method_5477().getString() + " never came back from the supply run...").method_27695(class_124.field_1079, class_124.field_1067));
            method_31472();
            return;
        }
        if (field_5974.method_43057() < risk) method_6033(Math.max(1, method_6032() * 0.4f));
        int rolls = (int) Math.ceil(awayMinutes * (1 + lvl() / 150.0) * (job == Job.LOOTER ? 2 : 1) * (1 + (awayGroup - 1) * 0.15));
        String[][] loot = {{"minecraft:bread", "4"}, {"minecraft:cooked_beef", "3"}, {"minecraft:arrow", "16"}, {"kiyamet:bandage", "2"}, {"minecraft:iron_ingot", "3"},
                {"minecraft:coal", "6"}, {"kiyamet:metal_plate", "2"}, {"kiyamet:circuit", "1"}, {"kiyamet:fuel_canister", "1"}, {"minecraft:leather", "3"},
                {"kiyamet:medkit", "1"}, {"kiyamet:dollar_10", "2"}, {"minecraft:gold_ingot", "2"}, {"kiyamet:energy_cell", "1"}, {"minecraft:diamond", "1"}, {"kiyamet:vaccine", "1"}};
        int found = 0;
        for (int i = 0; i < rolls; i++) {
            int max = lvl() > 150 ? loot.length : lvl() > 60 ? loot.length - 2 : loot.length - 5;
            String[] e = loot[field_5974.method_43048(max)];
            class_1799 rest = inventory.method_5491(new class_1799(Ui.item(e[0]), Integer.parseInt(e[1])));
            if (rest.method_7960()) found++;
        }
        xp += awayMinutes * 15;
        onKill(sl, null);
        sl.method_65096(class_2398.field_11211, method_23317(), method_23318() + 1, method_23321(), 15, 0.4, 0.6, 0.4, 0);
        if (p != null) p.method_64398(class_2561.method_43470(method_5477().getString() + " is back from the supply run with " + found + " finds" +
                (method_6032() < method_6063() * 0.5f ? " (badly hurt)" : "") + ". Check their inventory!").method_27692(class_124.field_1060));
    }

    private void nurse(class_3218 sl) {
        float amount = 2 + lvl() / 40f;
        boolean healed = false;
        class_3222 p = ownerPlayer();
        if (p != null && p.method_5739(this) < 10 && p.method_6032() < p.method_6063()) {
            p.method_6025(amount); p.method_6016(net.minecraft.class_1294.field_5899); healed = true;
            if (lvl() >= 120 && field_6012 % 6000 == 0 && com.kiyamet.world.Infection.get(p) > 0) {
                com.kiyamet.world.Infection.cure(p);
                p.method_64398(class_2561.method_43470(method_5477().getString() + " treated your infection.").method_27692(class_124.field_1060));
            }
        }
        for (HumanEntity h : sl.method_8390(HumanEntity.class, method_5829().method_1014(8), h -> h.method_6032() < h.method_6063()
                && (owner != null ? owner.equals(h.owner) : !community.isEmpty() && community.equals(h.community)))) { h.method_6025(amount); healed = true; }
        if (healed) sl.method_65096(class_2398.field_11201, method_23317(), method_23318() + 2.1, method_23321(), 3, 0.4, 0.2, 0.4, 0);
    }

    private void engineer(class_3218 sl) {
        float f = lvl() >= 150 ? 0.4f : 0.2f;
        int fixed = 0;
        for (class_2338 p : com.kiyamet.defense.BlockDurability.damagedNear(sl, method_24515(), 10)) {
            if (fixed >= 6) break;
            if (com.kiyamet.defense.BlockDurability.repair(sl, p, f)) {
                fixed++;
                sl.method_65096(class_2398.field_29643, p.method_10263() + 0.5, p.method_10264() + 0.5, p.method_10260() + 0.5, 5, 0.3, 0.3, 0.3, 0);
            }
        }
        for (net.minecraft.class_1309 e : sl.method_8390(net.minecraft.class_1309.class, method_5829().method_1014(10),
                e -> (e instanceof com.kiyamet.robot.RobotEntity r && r.isAlly() || e instanceof com.kiyamet.ally.TurretDrone) && e.method_6032() < e.method_6063())) {
            e.method_6025(e.method_6063() * f * 0.5f);
            sl.method_65096(class_2398.field_29643, e.method_23317(), e.method_23318() + 1, e.method_23321(), 8, 0.4, 0.4, 0.4, 0);
            fixed++;
        }
        if (fixed > 0) { method_6104(net.minecraft.class_1268.field_5808); sl.method_8396(null, method_24515(), net.minecraft.class_3417.field_14559, net.minecraft.class_3419.field_15254, 0.3f, 1.4f); }
    }

    private void scavenge() {
        String[][] finds = {{"minecraft:bread", "3"}, {"minecraft:arrow", "12"}, {"kiyamet:bandage", "2"}, {"minecraft:iron_ingot", "2"}, {"minecraft:cooked_chicken", "3"},
                {"kiyamet:metal_plate", "1"}, {"minecraft:string", "4"}, {"kiyamet:fuel_canister", "1"}, {"kiyamet:circuit", "1"}, {"kiyamet:walker_guts", "2"},
                {"kiyamet:medkit", "1"}, {"kiyamet:dollar_10", "1"}, {"minecraft:leather", "3"}, {"kiyamet:energy_cell", "1"}};
        int pick = field_5974.method_43048(lvl() >= 100 ? finds.length : finds.length - 3);
        class_1799 found = new class_1799(Ui.item(finds[pick][0]), Integer.parseInt(finds[pick][1]) + lvl() / 100);
        class_1799 rest = inventory.method_5491(found);
        class_3222 p = ownerPlayer();
        if (p != null) p.method_64398(class_2561.method_43470(method_5477().getString() + " found " + found.method_7947() + "× " + found.method_7964().getString()
                + (rest.method_7960() ? "" : " (her bag is full!)")).method_27692(class_124.field_1065));
    }

    private void selfHeal() {
        for (String id : new String[]{"kiyamet:medkit", "kiyamet:bandage", "kiyamet:healing_syringe"}) {
            for (int i = 0; i < inventory.method_5439(); i++) {
                class_1799 s = inventory.method_5438(i);
                if (s.method_31574(Ui.item(id))) {
                    s.method_7934(1);
                    method_6025(id.endsWith("medkit") ? method_6063() * 0.6f : id.endsWith("bandage") ? method_6063() * 0.2f : method_6063() * 0.4f);
                    method_5783(class_3417.field_14581.comp_349(), 1f, 1.3f);
                    return;
                }
            }
        }
    }

    private void refreshBar() {
        if (role() == Role.COMMANDER && bar == null) {
            bar = new class_3213(method_5476(), class_1259.class_1260.field_5784, class_1259.class_1261.field_5796);
        }
    }

    @Override
    public void method_5837(class_3222 player) {
        super.method_5837(player);
        if (bar != null) bar.method_14088(player);
    }

    @Override
    public void method_5742(class_3222 player) {
        super.method_5742(player);
        if (bar != null) bar.method_14089(player);
    }

    @Override
    public boolean method_6121(class_3218 level, class_1297 target) {
        float base = (float) method_45325(class_5134.field_23721) * Weapon.tier(method_6047());
        boolean hit = target.method_64397(level, level.method_48963().method_48812(this), base);
        if (hit) { triggerAnim("attack", "attack"); method_6104(class_1268.field_5808); }
        return hit;
    }

    @Override
    public boolean method_64397(class_3218 level, class_1282 source, float amount) {
        if (awayUntil > 0) return false;
        class_1297 attacker = source.method_5529();
        if (attacker instanceof class_1657 p && isOwnedBy(p)) return false;                               // no friendly fire
        if (attacker instanceof HumanEntity h && h.owner != null && owner != null && h.owner.equals(owner)) return false;
        if (attacker instanceof class_3222 p && faction() == Faction.COMMUNITY) Communities.onMemberHurt(level, this, p);
        return super.method_64397(level, source, amount * com.kiyamet.twd.Headshot.multiplier(level, this, source));
    }

    /** Companions earn XP from kills and level up to 300. */
    public void onKill(class_3218 level, @Nullable class_1309 victim) {
        if (faction() != Faction.COMPANION) return;
        int gain = victim == null ? 0 : victim instanceof BossEntity ? 400 : victim instanceof HumanEntity h ? 20 + h.lvl() / 3 : victim instanceof RobotEntity ? 25 : 10;
        xp += gain;
        while (lvl() < MAX_LEVEL && xp >= xpToNext(lvl())) {
            xp -= xpToNext(lvl());
            field_6011.method_12778(LEVEL, lvl() + 1);
            applyStats(false);
            method_6025(method_6063() * 0.25f);
            level.method_65096(class_2398.field_11220, method_23317(), method_23318() + 1, method_23321(), 30, 0.4, 0.6, 0.4, 0.3);
            level.method_8396(null, method_24515(), class_3417.field_14709, class_3419.field_15254, 0.8f, 1.2f);
            class_3222 p = ownerPlayer();
            if (p != null && lvl() % 5 == 0)
                p.method_64398(class_2561.method_43470(method_5477().getString() + " reached level " + lvl() + "!").method_27692(class_124.field_1075));
        }
    }

    @Override
    public void method_6078(class_1282 source) {
        super.method_6078(source);
        if (!(method_73183() instanceof class_3218 sl)) return;
        if (faction() != Faction.COMPANION) {
            int rubies = lvl() / 40 + (role() == Role.COMMANDER ? 12 : role() == Role.LEADER ? 4 : 0);
            if (rubies > 0) sl.method_8649(new class_1542(sl, method_23317(), method_23318() + 0.5, method_23321(), com.kiyamet.money.Money.stack(rubies * com.kiyamet.money.Money.RATE)));
            if (field_5974.method_43057() < 0.4f) sl.method_8649(new class_1542(sl, method_23317(), method_23318() + 0.5, method_23321(), new class_1799(class_1802.field_8107, 4 + field_5974.method_43048(12))));
            if (field_5974.method_43057() < 0.2f) sl.method_8649(new class_1542(sl, method_23317(), method_23318() + 0.5, method_23321(), new class_1799(Ui.item("kiyamet:bandage"))));
        } else {
            class_3222 p = ownerPlayer();
            if (p != null) p.method_64398(class_2561.method_43470(method_5477().getString() + " has died.").method_27695(class_124.field_1079, class_124.field_1067));
        }
        if (bar != null) bar.method_14094();
        Radio.forget(this);
        net.minecraft.class_1264.method_5452(sl, this, inventory);
        // Everyone is infected: the dead come back.
        if (faction() != Faction.WHISPERER && field_5974.method_43057() < 0.8f) {
            com.kiyamet.entity.ZombieKind zk = appearance().female() ? com.kiyamet.entity.ZombieKind.WOMAN : profession() == Profession.DOCTOR ? com.kiyamet.entity.ZombieKind.DOCTOR
                    : profession() == Profession.POLICE ? com.kiyamet.entity.ZombieKind.POLICE : profession() == Profession.FARMER ? com.kiyamet.entity.ZombieKind.FARMER : com.kiyamet.entity.ZombieKind.RUNNER;
            KZombie z = com.kiyamet.entity.ModEntities.ZOMBIES.get(zk).method_5883(sl, net.minecraft.class_3730.field_16468);
            if (z != null) {
                z.method_5814(method_23317(), method_23318(), method_23321());
                // the dead keep their name: you can see who they were
                z.method_5665(class_2561.method_43470(method_5477().getString()).method_27692(class_124.field_1077));
                z.method_5880(true);
                z.method_5971();
                z.formerName = method_5477().getString();
                if (faction() == Faction.COMPANION && ownerPlayer() != null) z.formerOwner = ownerPlayer().method_5667();
                sl.method_8503().execute(() -> { if (sl.method_66347(z.method_5667()) == null) sl.method_8649(z); });
            }
        }
    }

    // ---------------------------------------------------------------- interaction

    @Override
    public boolean method_5931() { return Captives.canCapture(this); }

    @Override
    protected class_1269 method_5992(class_1657 player, class_1268 hand) {
        class_1799 held = player.method_5998(hand);
        if (held.method_31574(class_1802.field_8448)) return class_1269.field_5811;
        if (!(player instanceof class_3222 sp) || !(method_73183() instanceof class_3218)) return class_1269.field_5812;
        if (hand != class_1268.field_5808) return class_1269.field_5811;
        if (captives.captive && !held.method_31574(class_1802.field_8719)) { Captives.talk(sp, this); return class_1269.field_5812; }
        if (faction() == Faction.COMPANION && isOwnedBy(sp) && held.method_57826(net.minecraft.class_9334.field_50075) && !sp.method_5715()) {
            held.method_7934(1);
            method_6025(4);
            morale = Math.min(100, morale + 15);
            Talk.say(sp, this, Talk.pick(field_5974, "Thanks. I needed that.", "Real food... you're the best.", "*eats* Okay. I can keep going.", "You didn't have to share. Thank you."));
            return class_1269.field_5812;
        }
        if (method_5968() == player) return class_1269.field_5814;
        if (envoy) { WorldEvents.envoyTalk(sp, this); return class_1269.field_5812; }
        if (com.kiyamet.twd.Story.interact(sp, this)) return class_1269.field_5812;
        switch (faction()) {
            case COMPANION -> {
                if (isOwnedBy(sp)) CompanionMenu.open(sp, this);
                else sp.method_7353(class_2561.method_43470("This companion follows someone else."), true);
            }
            case SURVIVOR -> Dialogues.survivor(sp, this);
            case COMMUNITY -> {
                if (Communities.reputation(sp, community) < 0) { sp.method_7353(class_2561.method_43470("They don't trust you.").method_27692(class_124.field_1061), true); break; }
                switch (role()) {
                    case TRADER -> Dialogues.trader(sp, this);
                    case LEADER -> Dialogues.leader(sp, this);
                    default -> sp.method_7353(class_2561.method_43470(method_5477().getString() + ": " + Communities.greeting(field_5974, communityType)), false);
                }
            }
            default -> {}
        }
        return class_1269.field_5812;
    }

    @Override
    public boolean method_5974(double d) { return false; }

    @Override
    public class_2561 method_23315() {
        if (hasProfession() && faction() != Faction.RAIDER && faction() != Faction.WHISPERER && role() == Role.MEMBER) return class_2561.method_43470(profession().title);
        return class_2561.method_43470(faction() == Faction.COMMUNITY && role() == Role.MEMBER ? Communities.title(communityType) : role() == Role.MEMBER ? faction().title : faction().title + " " + role().title);
    }

    @Override
    public class_2561 method_5476() {
        class_2561 base = method_16914() ? method_5797() : method_23315();
        class_124 c = switch (faction()) {
            case RAIDER, WHISPERER -> class_124.field_1061;
            case COMPANION -> class_124.field_1075;
            case COMMUNITY -> class_124.field_1060;
            default -> class_124.field_1068;
        };
        return class_2561.method_43473().method_10852(base).method_10852(class_2561.method_43470(" [Lv " + lvl() + "]").method_27692(class_124.field_1080)).method_27692(c);
    }

    @Override
    public boolean method_5733() { return faction() == Faction.COMPANION || specialty() != Specialty.NONE || role() == Role.LEADER || role() == Role.COMMANDER || role() == Role.TRADER || super.method_5733(); }

    // ---------------------------------------------------------------- GeckoLib

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<HumanEntity>("main", 4, t -> t.setAndContinue(t.isMoving() ? WALK : IDLE)));
        controllers.add(new AnimationController<HumanEntity>("attack", 0, t -> PlayState.STOP).triggerableAnim("attack", ATTACK));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    public List<HumanEntity> allies(class_3218 sl, double r) {
        return sl.method_8390(HumanEntity.class, method_5829().method_1014(r), h -> h != this && !community.isEmpty() && community.equals(h.community));
    }
}
