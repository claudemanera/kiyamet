package com.kiyamet.npc;

import net.minecraft.class_1792;
import net.minecraft.class_1802;

/** The 4 companion jobs, chosen in the companion panel. */
public enum Job {
    NONE("No job", "Fights normally", class_1802.field_8407),
    GUNNER("Gunner", "+25% ranged damage, shoots 20% faster, keeps distance", class_1802.field_8399),
    SCOUT("Scout", "Marks enemies within 40 blocks (glow), warns you of hordes, +15% speed", class_1802.field_27070),
    GUARDIAN("Guardian", "+40% health, +6 armor, pulls enemies off you", class_1802.field_8255),
    LOOTER("Looter", "Brings back twice the loot from supply runs and finds things while following", class_1802.field_8106);

    public final String title, desc;
    public final class_1792 icon;

    Job(String title, String desc, class_1792 icon) { this.title = title; this.desc = desc; this.icon = icon; }

    public static Job byName(String s) { try { return valueOf(s); } catch (IllegalArgumentException e) { return NONE; } }
}
