package com.kiyamet.npc;

import com.kiyamet.ui.PanelMenu;
import com.kiyamet.ui.Ui;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import net.minecraft.class_747;

/** Community leader: reputation, donations, recruit volunteers (needs trust). */
public class LeaderMenu extends PanelMenu {
    private final HumanEntity h;

    public static void open(class_3222 p, HumanEntity h) {
        p.method_17355(new class_747((id, inv, pl) -> new LeaderMenu(id, inv, p, h),
                class_2561.method_43470(Communities.displayName(h.communityType()) + " - " + h.method_5477().getString())));
    }

    private LeaderMenu(int id, class_1661 inv, class_3222 p, HumanEntity h) {
        super(id, inv, p);
        this.h = h;
        redraw();
    }

    private int rep() { return Communities.reputation(player, h.community()); }

    @Override
    protected void draw() {
        int rep = rep();
        int members = h.allies((class_3218) player.method_51469(), 64).size() + 1;
        String standing = rep >= 80 ? "Hero of the community" : rep >= 50 ? "Trusted friend" : rep >= 20 ? "Welcome guest" : "Stranger";
        c.method_5447(4, Ui.glint(Ui.icon(class_1802.field_16315, class_2561.method_43470(Communities.displayName(h.communityType())).method_27695(class_124.field_1065, class_124.field_1067),
                Ui.text("Leader: " + h.method_5477().getString() + " (Lv " + h.lvl() + ")", class_124.field_1054),
                Ui.text("Members nearby: " + members, class_124.field_1080),
                Ui.text("Your standing: " + standing + " (" + rep + ")", class_124.field_1060), Ui.bar((rep + 100) / 200.0, 20)), true));
        c.method_5447(20, Ui.icon(Ui.item("kiyamet:dollar_50"), Ui.text("Donate $50", class_124.field_1061), Ui.text("+10 reputation", class_124.field_1060)));
        c.method_5447(22, Ui.icon(class_1802.field_8861, Ui.text("Donate 32 wheat", class_124.field_1065), Ui.text("+6 reputation", class_124.field_1060)));
        boolean canRecruit = rep >= 40;
        c.method_5447(24, Ui.glint(Ui.icon(class_1802.field_8371, Ui.text("Ask for a volunteer ($120)", canRecruit ? class_124.field_1075 : class_124.field_1063, class_124.field_1067),
                Ui.text(canRecruit ? "A skilled member joins you as a companion" : "Needs reputation 40", canRecruit ? class_124.field_1080 : class_124.field_1061)), canRecruit));
        c.method_5447(31, Ui.icon(class_1802.field_8895, Ui.text("\"" + Communities.greeting(h.method_59922(), h.communityType()) + "\"", class_124.field_1056, class_124.field_1080)));
        c.method_5447(49, Ui.icon(class_1802.field_8077, Ui.text("Close", class_124.field_1061)));
    }

    @Override
    protected boolean click(int slot, class_1713 type) {
        if (!h.method_5805()) { player.method_7346(); return false; }
        switch (slot) {
            case 49 -> { player.method_7346(); return false; }
            case 20 -> { if (!Shop.take(player, Shop.RUBY, 5)) return false; Communities.change(player, h.community(), 10); }
            case 22 -> { if (!Shop.take(player, "minecraft:wheat", 32)) return false; Communities.change(player, h.community(), 6); }
            case 24 -> {
                if (rep() < 40 || RecruitMenu.companions(player) >= RecruitMenu.MAX_COMPANIONS) return false;
                if (!Shop.take(player, Shop.RUBY, 12)) return false;
                class_3218 sl = (class_3218) player.method_51469();
                HumanEntity v = ModHumans.HUMAN.method_5883(sl, class_3730.field_16471);
                if (v == null) return false;
                v.method_5814(h.method_23317() + 1, h.method_23318(), h.method_23321() + 1);
                v.setup(Faction.SURVIVOR, Role.MEMBER, Math.max(20, h.lvl() / 2 + h.method_59922().method_43048(30)), null);
                sl.method_8649(v);
                v.setOwner(player);
                player.method_64398(class_2561.method_43470(v.method_5477().getString() + " volunteers to join you!").method_27692(class_124.field_1075));
                player.method_7346();
                return false;
            }
            default -> { return false; }
        }
        return true;
    }
}
