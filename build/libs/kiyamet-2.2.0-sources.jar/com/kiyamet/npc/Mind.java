package com.kiyamet.npc;

import com.kiyamet.Kiyamet;
import com.kiyamet.entity.KZombie;
import com.kiyamet.season.Seasons;
import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.EntitySleepEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2170;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2387;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2767;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3730;
import net.minecraft.class_5134;
import net.minecraft.class_5819;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import java.util.*;

/**
 * TWD 1.5 mental health and morale.
 * Your mind (0-100) wears down near walkers, alone in the dark, under a Blood Moon, when friends die or come back as
 * walkers, when you kill people, freeze or starve. It recovers with sleep, food, music, a fire, your shelter and
 * your people around you. Low: whispers, footsteps, things that aren't there - and at the bottom, walkers that vanish
 * when you swing at them.
 * Companions have morale (0-100): long fights, wounds, hunger, the night and losing friends drag it down; rest,
 * a warm fire, food from your hand and a safe base lift it. High morale = harder hits; low = weaker, grumbling,
 * and at the very bottom they may walk away.
 */
public final class Mind {
    public static final AttachmentType<Float> SANITY = AttachmentRegistry.create(Kiyamet.id("sanity"), b -> b.initializer(() -> 80f).persistent(Codec.FLOAT).copyOnDeath());
    private static final Map<UUID, Integer> STATE = new HashMap<>();
    private static final Map<UUID, Integer> FOOD = new HashMap<>();
    private static final Set<UUID> SEEN_FRIENDS = new HashSet<>();

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.method_3780() % 20 != 0) return;
            for (class_3222 p : server.method_3760().method_14571()) if (!p.method_7325() && !p.method_68878()) tick(p);
        });
        EntitySleepEvents.STOP_SLEEPING.register((e, pos) -> { if (e instanceof class_3222 p) change(p, 30, "A night's sleep clears your head."); });
        ServerLivingEntityEvents.AFTER_DEATH.register((e, src) -> {
            if (src.method_5529() instanceof class_3222 p && e instanceof HumanEntity h && h.faction() != Faction.RAIDER && h.faction() != Faction.WHISPERER)
                change(p, -6, "You killed someone who wasn't a raider. It weighs on you.");
            else if (src.method_5529() instanceof class_3222 p && e instanceof HumanEntity) change(p, -1.5f, null);
            if (e instanceof HumanEntity h && h.faction() == Faction.COMPANION && h.ownerPlayer() != null) {
                change(h.ownerPlayer(), -15, "Losing " + h.method_5477().getString() + " hits you hard.");
                for (HumanEntity o : ((class_3218) e.method_73183()).method_8390(HumanEntity.class, e.method_5829().method_1014(48), o -> o != h && o.isOwnedBy(h.ownerPlayer())))
                    o.morale = Math.max(0, o.morale - 20);
            }
        });
        CommandRegistrationCallback.EVENT.register((d, ctx, env) -> d.register(class_2170.method_9247("twd")
                .then(class_2170.method_9247("mind").executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    float s = p.getAttachedOrElse(SANITY, 80f);
                    p.method_64398(class_2561.method_43470("🧠 Mind: " + Math.round(s) + "/100 - " + label(s)).method_27695(color(s), class_124.field_1067));
                    return 1;
                }))));
    }

    public static float sanity(class_3222 p) { return p.getAttachedOrElse(SANITY, 80f); }

    public static void change(class_3222 p, float d, String why) {
        if (d < 0) return;                                    // 1.9: your own mind stays steady
        float s = class_3532.method_15363(sanity(p) + d, 0, 100);
        p.setAttached(SANITY, s);
        if (why != null) p.method_64398(class_2561.method_43470("🧠 " + why + " (" + (d > 0 ? "+" : "") + Math.round(d) + ")").method_27692(d > 0 ? class_124.field_1062 : class_124.field_1064));
    }

    static String label(float s) { return s >= 70 ? "Steady" : s >= 50 ? "Uneasy" : s >= 30 ? "Shaken" : s >= 12 ? "Breaking" : "Lost"; }
    static class_124 color(float s) { return s >= 70 ? class_124.field_1060 : s >= 50 ? class_124.field_1054 : s >= 30 ? class_124.field_1065 : s >= 12 ? class_124.field_1061 : class_124.field_1079; }
    static int bucket(float s) { return s >= 70 ? 4 : s >= 50 ? 3 : s >= 30 ? 2 : s >= 12 ? 1 : 0; }

    private static void tick(class_3222 p) {
        if (sanity(p) < 100) p.setAttached(SANITY, 100f);    // 1.9: the player's mind no longer breaks - only companions' minds do
        if (true) return;
        class_3218 level = p.method_51469();
        class_5819 r = level.field_9229;
        class_2338 pos = p.method_24515();
        float d = 0;
        List<KZombie> walkers = level.method_8390(KZombie.class, p.method_5829().method_1014(12), z -> !z.captives.captive);
        d -= Math.min(1.2f, walkers.size() * 0.08f);
        boolean night = !level.method_8530(), sky = level.method_8311(pos.method_10084());
        long friends = level.method_8390(HumanEntity.class, p.method_5829().method_1014(10), h -> h.isOwnedBy(p)).size();
        if (night && sky) d -= 0.06f;
        if (night && friends == 0) d -= 0.05f;
        if (BaseRaids.bloodMoon()) d -= 0.15f;
        int st = Seasons.state(p.getAttachedOrElse(Seasons.BODY, 20f));
        if (st <= -2 || st >= 3) d -= 0.06f;
        if (p.method_7344().method_7586() < 6) d -= 0.06f;
        d += Math.min(3, friends) * 0.03f;
        boolean safe = Seasons.warmNear(level, pos, 5) || com.kiyamet.twd.ShelterCore.protects(level, pos) || com.kiyamet.world.ModStructures.inSanctuary(level, pos);
        if (safe && walkers.isEmpty()) d += 0.15f;
        if (music(level, pos)) d += 0.3f;
        int food = p.method_7344().method_7586();
        Integer lastFood = FOOD.put(p.method_5667(), food);
        if (lastFood != null && food > lastFood) d += (food - lastFood) * 0.6f;
        // seeing a friend who turned
        for (KZombie z : walkers) if (z.formerName != null && z.method_5739(p) < 10 && SEEN_FRIENDS.add(z.method_5667()))
            change(p, -6, "That walker... it was " + z.formerName + ".");
        float s = class_3532.method_15363(sanity(p) + d, 0, 100);
        p.setAttached(SANITY, s);
        int b = bucket(s);
        Integer was = STATE.put(p.method_5667(), b);
        if (was != null && was != b) p.method_64398(class_2561.method_43470("🧠 Your mind: " + label(s) + (b < was ? " - rest, eat, find your people and a fire." : ".")).method_27692(color(s)));
        symptoms(p, level, s, r);
    }

    static boolean music(class_3218 level, class_2338 c) {
        for (class_2338 q : class_2338.method_10097(c.method_10069(-8, -3, -8), c.method_10069(8, 3, 8))) {
            class_2680 b = level.method_8320(q);
            if (b.method_27852(class_2246.field_10223) && b.method_11654(class_2387.field_11180)) return true;
        }
        return false;
    }

    private static final String[] WHISPERS = {"Did something move behind you?", "You hear footsteps... then nothing.", "Someone whispers your name.",
            "For a second the trees looked like people.", "You hear a radio crackle. There's no radio.", "Something is breathing right behind you.",
            "You smell rot. Close. Very close.", "A child laughs somewhere in the dark."};

    private static void symptoms(class_3222 p, class_3218 level, float s, class_5819 r) {
        if (s < 50 && r.method_43048(40) == 0) whisper(p, r.method_43056() ? class_3417.field_14564 : class_7923.field_41172.method_47983(class_3417.field_15174), 0.6f);
        if (s < 30) {
            if (r.method_43048(30) == 0) p.method_64398(class_2561.method_43470(WHISPERS[r.method_43048(WHISPERS.length)]).method_27695(class_124.field_1063, class_124.field_1056));
            if (r.method_43048(25) == 0) p.method_6092(new class_1293(class_1294.field_5916, 120, 0, true, false, false));
            p.method_6092(new class_1293(class_1294.field_5911, 40, 0, true, false, false));
        }
        if (s < 12) {
            if (r.method_43048(15) == 0) p.method_6092(new class_1293(class_1294.field_38092, 80, 0, true, false, false));
            if (r.method_43048(45) == 0) hallucination(p, level);
        }
    }

    static void whisper(class_3222 p, class_6880<class_3414> sound, float vol) {
        class_243 behind = p.method_73189().method_1020(p.method_5720().method_1021(3));
        p.field_13987.method_14364(new class_2767(sound, class_3419.field_15256, behind.field_1352, behind.field_1351 + 1, behind.field_1350, vol, 0.7f + p.method_59922().method_43057() * 0.3f, p.method_59922().method_43055()));
    }

    /** A walker that isn't really there: it charges, does no harm, and vanishes when hit or after a few seconds. */
    private static void hallucination(class_3222 p, class_3218 level) {
        class_243 at = p.method_73189().method_1020(p.method_5720().method_18805(1, 0, 1).method_1029().method_1021(-8));
        KZombie z = com.kiyamet.entity.ModEntities.ZOMBIES.get(com.kiyamet.entity.ZombieKind.FARMER).method_5883(level, class_3730.field_16467);
        if (z == null) return;
        z.method_5814(at.field_1352, level.method_8598(net.minecraft.class_2902.class_2903.field_13203, class_2338.method_49638(at)).method_10264(), at.field_1350);
        z.hallucination = level.method_75260() + 120;
        z.method_5980(p);
        level.method_8649(z);
    }

    // ------------------------------------------------------------------ companion morale

    private static final net.minecraft.class_2960 MORALE_DMG = Kiyamet.id("morale_damage"), MORALE_SPD = Kiyamet.id("morale_speed");

    /** Called every second for owned companions. */
    public static void companion(class_3218 level, HumanEntity h, class_3222 owner) {
        float m = h.morale;
        boolean fighting = h.method_5968() != null;
        if (fighting) m -= 0.12f;
        if (h.method_6032() < h.method_6063() * 0.5f) m -= 0.1f;
        if (!level.method_8530()) m -= 0.03f;
        if (BaseRaids.bloodMoon()) m -= 0.08f;
        if (!fighting && (Seasons.warmNear(level, h.method_24515(), 5) || com.kiyamet.twd.ShelterCore.protects(level, h.method_24515()))) m += 0.25f;
        else if (!fighting && h.order() == HumanEntity.Order.STAY) m += 0.06f;
        else if (!fighting && level.method_8530()) m += 0.02f;
        if (music(level, h.method_24515())) m += 0.2f;
        h.morale = class_3532.method_15363(m, 0, 100);
        // effects
        double dmg = h.morale >= 70 ? 0.15 : h.morale < 30 ? -0.15 : 0, spd = h.morale >= 70 ? 0.05 : h.morale < 30 ? -0.05 : 0;
        apply(h.method_5996(class_5134.field_23721), MORALE_DMG, dmg);
        apply(h.method_5996(class_5134.field_23719), MORALE_SPD, spd);
        class_5819 r = h.method_59922();
        if (h.morale < 25 && r.method_43048(240) == 0 && !Talk.busy(owner))
            Talk.say(owner, h, Talk.pick(r, "I can't keep doing this...", "How long until it ends? Ever?", "I'm so tired. Can we stop somewhere safe?", "I keep seeing their faces."));
        if (h.morale < 8 && r.method_43048(4000) == 0 && !Talk.busy(owner)) {      // very rare: the broken mind turns on you
            Talk.say(owner, h, Talk.pick(r, "You did this to us. All of it.", "I'm taking what I'm owed.", "They were right about you."));
            owner.method_64398(class_2561.method_43470("⚠ " + h.method_5477().getString() + "'s mind broke - they've turned against you!").method_27695(class_124.field_1079, class_124.field_1067));
            h.betray(owner);
            return;
        }
        if (h.morale < 10 && r.method_43048(600) == 0) {
            Talk.say(owner, h, "I'm sorry. I can't. I'm leaving.");
            h.setOwner(null);
            owner.method_64398(class_2561.method_43470(h.method_5477().getString() + " has left your group. (Morale broke)").method_27695(class_124.field_1079, class_124.field_1067));
        }
    }

    private static void apply(class_1324 a, net.minecraft.class_2960 id, double v) {
        if (a == null) return;
        class_1322 cur = a.method_6199(id);
        if (v == 0) { if (cur != null) a.method_6200(id); return; }
        if (cur == null || cur.comp_2449() != v) a.method_55696(new class_1322(id, v, class_1322.class_1323.field_6330));
    }

    public static String moraleLabel(float m) { return m >= 70 ? "High" : m >= 45 ? "Okay" : m >= 25 ? "Low" : "Breaking"; }

    private Mind() {}
}
