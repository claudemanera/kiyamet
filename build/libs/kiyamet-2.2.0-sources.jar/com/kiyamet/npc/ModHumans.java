package com.kiyamet.npc;

import com.kiyamet.Kiyamet;
import com.kiyamet.entity.KZombie;
import com.kiyamet.entity.ModEntities;
import com.kiyamet.entity.ZombieKind;
import com.kiyamet.skill.SkillManager;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_124;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1314;
import net.minecraft.class_1937;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3730;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ModHumans {
    private static final class_5321<class_1299<?>> KEY = class_5321.method_29179(class_7924.field_41266, Kiyamet.id("human"));
    public static final class_1299<HumanEntity> HUMAN = class_2378.method_39197(class_7923.field_41177, KEY,
            class_1299.class_1300.<HumanEntity>method_5903(HumanEntity::new, class_1311.field_6294).method_17687(0.6f, 1.95f).method_55687(1.62f).method_27299(10).method_5905(KEY));

    public static void init() {
        FabricDefaultAttributeRegistry.register(HUMAN, class_1314.method_26828()
                .method_26868(class_5134.field_23716, 20).method_26868(class_5134.field_23721, 3).method_26868(class_5134.field_23719, 0.3)
                .method_26868(class_5134.field_23717, 32).method_26868(class_5134.field_23724, 0).method_26868(class_5134.field_23725, 0).method_26868(class_5134.field_23718, 0));

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (source.method_5529() instanceof HumanEntity killer && entity.method_73183() instanceof class_3218 sl) killer.onKill(sl, entity);
            if (entity instanceof HumanEntity dead && dead.faction() == Faction.RAIDER && entity.method_73183() instanceof class_3218 sl4 && sl4.field_9229.method_43057() < 0.1f)
                dead.method_5775(sl4, new net.minecraft.class_1799(com.kiyamet.twd.ModTwd.LOST_NOTE));
            // 1.4: enchanted weapons and blue gun tomes out in the world
            if (entity.method_73183() instanceof class_3218 sl5 && source.method_5529() instanceof class_3222 killerP) {
                int pw = power(killerP);
                boolean boss = entity instanceof com.kiyamet.boss.BossEntity;
                boolean raider = entity instanceof HumanEntity hd && (hd.faction() == Faction.RAIDER || hd.faction() == Faction.WHISPERER);
                float wc = boss ? 1f : raider ? (((HumanEntity) entity).role() == Role.MEMBER ? 0.05f : 0.18f) : 0f;
                if (sl5.field_9229.method_43057() < wc) entity.method_5775(sl5, com.kiyamet.enchant.EnchantLoot.weapon(sl5, pw));
                float tc = boss ? 0.6f : raider ? 0.04f : entity instanceof KZombie ? 0.004f : 0f;
                if (sl5.field_9229.method_43057() < tc) entity.method_5775(sl5, com.kiyamet.enchant.GunTomeItem.random(sl5.field_9229));
            }
            // everyone is infected: 80% of dead players rise again as a walker
            if (entity instanceof class_3222 p && p.method_51469().field_9229.method_43057() < 0.8f) {
                KZombie z = ModEntities.ZOMBIES.get(p.method_51469().field_9229.method_43056() ? ZombieKind.RUNNER : ZombieKind.FARMER).method_5883(p.method_51469(), class_3730.field_16468);
                if (z != null) {
                    z.method_5814(p.method_23317(), p.method_23318(), p.method_23321());
                    z.method_5665(class_2561.method_43470(p.method_5477().getString()).method_27692(class_124.field_1077));
                    z.method_5880(true);
                    z.formerName = p.method_5477().getString();
                    z.method_5971();
                    p.method_51469().method_8649(z);
                }
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int t = server.method_3780();
            if (t % 40 == 0) for (class_3222 p : server.method_3760().method_14571()) {
                if (p.method_7325()) continue;
                class_3218 sl = p.method_51469();
                for (HumanEntity h : sl.method_8390(HumanEntity.class, p.method_5829().method_1014(22), h -> h.faction() == Faction.COMMUNITY && !h.community().isEmpty()))
                    Communities.firstContact(sl, p, h);
            }
            if (t % 2400 == 1200) for (class_3222 p : server.method_3760().method_14571()) events(p);
        });

        CommandRegistrationCallback.EVENT.register((d, ctx, env) -> d.register(class_2170.method_9247("twd")
                .then(class_2170.method_9247("spawn").then(class_2170.method_9244("what", StringArgumentType.word()).executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    if (!p.method_68878()) { p.method_64398(class_2561.method_43470("Creative mode only.")); return 0; }
                    String w = StringArgumentType.getString(c, "what");
                    class_2338 at = p.method_24515().method_10069(6, 0, 0);
                    switch (w) {
                        case "raiders" -> raiders(p.method_51469(), at, power(p), false);
                        case "commander" -> raiders(p.method_51469(), at, power(p), true);
                        case "masked" -> whisperers(p.method_51469(), at, power(p));
                        case "car" -> com.kiyamet.vehicle.ModVehicles.abandoned(p.method_51469(), at);
                        case "survivor" -> spawn(p.method_51469(), at, Faction.SURVIVOR, Role.MEMBER, 5 + p.method_59922().method_43048(40), null);
                        default -> { p.method_64398(class_2561.method_43470("raiders | commander | masked | survivor")); return 0; }
                    }
                    return 1;
                })))));
    }

    static int power(class_3222 p) { return SkillManager.get(p).totalPower(); }

    public static HumanEntity spawn(class_3218 level, class_2338 pos, Faction f, Role r, int lv, String community) {
        HumanEntity h = HUMAN.method_5883(level, class_3730.field_16467);
        if (h == null) return null;
        h.method_5814(pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5);
        h.setup(f, r, lv, community);
        level.method_8649(h);
        return h;
    }

    static class_2338 surface(class_3218 level, class_2338 around, int min, int max) {
        for (int tries = 0; tries < 12; tries++) {
            double a = level.field_9229.method_43058() * Math.PI * 2, d = min + level.field_9229.method_43048(max - min);
            int x = around.method_10263() + (int) (Math.cos(a) * d), z = around.method_10260() + (int) (Math.sin(a) * d);
            int y = level.method_8624(class_2902.class_2903.field_13203, x, z);
            class_2338 p = new class_2338(x, y, z);
            if (!level.method_8316(p.method_10074()).method_15769() || !level.method_8316(p).method_15769()) continue;
            if (com.kiyamet.world.ModStructures.inSanctuary(level, p)) continue;
            return p;
        }
        return null;
    }

    /** Roaming events around each player: lone survivors, raider gangs, masked herds and the raider commander. */
    private static void events(class_3222 p) {
        class_3218 level = p.method_51469();
        if (level.method_27983() != class_1937.field_25179 || p.method_7325()) return;
        if (level.method_8390(HumanEntity.class, p.method_5829().method_1014(128), h -> h.faction() == Faction.RAIDER || h.faction() == Faction.WHISPERER).size() > 10) return;
        int power = power(p);
        float roll = level.field_9229.method_43057();
        class_2338 at = surface(level, p.method_24515(), 40, 64);
        if (at == null) return;
        if (power >= 4000 && roll < 0.02f) {
            raiders(level, at, power, true);
            p.method_64398(class_2561.method_43470("Engines roar in the distance... the Raider Commander is coming for you.").method_27695(class_124.field_1079, class_124.field_1067));
            level.method_8396(null, p.method_24515(), class_3417.field_17266.comp_349(), class_3419.field_15251, 2f, 0.6f);
        } else if (power >= 1500 && roll < 0.08f) {
            whisperers(level, at, power);
            p.method_64398(class_2561.method_43470("You hear whispers among the groans of the dead...").method_27695(class_124.field_1063, class_124.field_1056));
        } else if (power >= 300 && roll < 0.2f) {
            raiders(level, at, power, false);
            p.method_64398(class_2561.method_43470("Voices and laughter nearby. Raiders.").method_27692(class_124.field_1061));
        } else if (roll < 0.42f) {
            spawn(level, at, Faction.SURVIVOR, Role.MEMBER, 1 + level.field_9229.method_43048(10 + power / 40), null);
        } else if (roll < 0.5f && level.method_18467(com.kiyamet.vehicle.VehicleEntity.class, p.method_5829().method_1014(160)).isEmpty()) {
            com.kiyamet.vehicle.ModVehicles.abandoned(level, at);
        }
    }

    public static java.util.List<HumanEntity> raiders(class_3218 level, class_2338 at, int power, boolean commander) {
        int base = class_3532.method_15340(5 + power / 25, 5, 240);
        int n = 3 + level.field_9229.method_43048(3) + (commander ? 3 : 0);
        java.util.List<HumanEntity> out = new java.util.ArrayList<>();
        for (int i = 0; i < n; i++) {
            Role r = i == 0 ? (commander ? Role.COMMANDER : Role.LEADER) : Role.MEMBER;
            int lv = r == Role.COMMANDER ? 260 + level.field_9229.method_43048(41) : class_3532.method_15340(base + level.field_9229.method_43048(21) - 10 + (r == Role.LEADER ? 15 : 0), 1, 250);
            HumanEntity h = spawn(level, at.method_10069(level.field_9229.method_43048(5) - 2, 0, level.field_9229.method_43048(5) - 2), Faction.RAIDER, r, lv, null);
            if (h != null) out.add(h);
        }
        // from 800 power raiders come with cars; the Commander always rolls in with an armored truck
        if (commander || power >= 800 && level.field_9229.method_43057() < 0.6f) com.kiyamet.vehicle.ModVehicles.raiderRide(level, at, out, commander, power);
        return out;
    }

    public static void whisperers(class_3218 level, class_2338 at, int power) {
        int base = class_3532.method_15340(20 + power / 30, 20, 220);
        int n = 4 + level.field_9229.method_43048(3);
        for (int i = 0; i < n; i++)
            spawn(level, at.method_10069(level.field_9229.method_43048(7) - 3, 0, level.field_9229.method_43048(7) - 3), Faction.WHISPERER,
                    i == 0 && power > 5000 ? Role.COMMANDER : i == 0 ? Role.LEADER : Role.MEMBER, i == 0 && power > 5000 ? 270 + level.field_9229.method_43048(31) : base + level.field_9229.method_43048(20), null);
        for (int i = 0; i < 8; i++) {
            KZombie z = ModEntities.ZOMBIES.get(level.field_9229.method_43056() ? ZombieKind.FARMER : ZombieKind.TOXIC).method_5883(level, class_3730.field_16467);
            if (z == null) continue;
            z.method_5814(at.method_10263() + level.field_9229.method_43048(11) - 5, at.method_10264(), at.method_10260() + level.field_9229.method_43048(11) - 5);
            z.method_5943(level, level.method_8404(at), class_3730.field_16467, null);
            level.method_8649(z);
        }
    }

    private ModHumans() {}
}
