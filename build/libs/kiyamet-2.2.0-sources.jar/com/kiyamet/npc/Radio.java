package com.kiyamet.npc;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Walkie-talkie: call your whole group. 20 seconds later every companion teleports to you, like tamed wolves —
 * even ones left far away (their chunks are loaded for the call). Sneak + use opens the group panel.
 */
public class Radio extends class_1792 {
    public record Last(class_5321<class_1937> dim, class_2338 pos, String name, int level, int team, String job) {}
    record Call(long at, java.util.Set<UUID> who) {}
    private static final Map<UUID, Map<UUID, Last>> KNOWN = new HashMap<>();
    private static final Map<UUID, Call> CALLS = new HashMap<>();
    public static final int DELAY = 400;

    public Radio(class_1793 p) { super(p); }

    /** Companions report where they are every few seconds. */
    public static void report(HumanEntity h) {
        if (h.owner() == null || h.isAway()) return;
        KNOWN.computeIfAbsent(h.owner(), k -> new HashMap<>()).put(h.method_5667(), new Last(h.method_73183().method_27983(), h.method_24515(), h.method_5477().getString(), h.lvl(), h.team(), h.job().title));
    }

    public static void forget(HumanEntity h) {
        if (h.owner() != null && KNOWN.containsKey(h.owner())) KNOWN.get(h.owner()).remove(h.method_5667());
    }

    public static Map<UUID, Last> known(class_3222 p) { return KNOWN.getOrDefault(p.method_5667(), Map.of()); }

    public static boolean calling(class_3222 p) { return CALLS.containsKey(p.method_5667()); }

    public static long callEnds(class_3222 p) { Call c = CALLS.get(p.method_5667()); return c == null ? 0 : c.at; }

    /** Starts a call for the given companions; they arrive after 20 seconds. */
    public static int call(class_3222 p, java.util.Collection<UUID> who) {
        Map<UUID, Last> mine = known(p);
        java.util.Set<UUID> ids = new java.util.HashSet<>();
        MinecraftServer server = p.method_51469().method_8503();
        for (UUID u : who) {
            Last l = mine.get(u);
            if (l == null) continue;
            ids.add(u);
            class_3218 sl = server.method_3847(l.dim);
            if (sl != null) sl.method_17988(l.pos.method_10263() >> 4, l.pos.method_10260() >> 4, true);
        }
        if (ids.isEmpty()) return 0;
        Call old = CALLS.get(p.method_5667());
        if (old != null) ids.addAll(old.who);
        CALLS.put(p.method_5667(), new Call(p.method_51469().method_75260() + DELAY, ids));
        p.method_51469().method_8396(null, p.method_24515(), class_3417.field_18311.comp_349(), class_3419.field_15248, 1f, 0.6f);
        return ids.size();
    }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        if (!(player instanceof class_3222 p)) return class_1269.field_5812;
        RadioMenu.open(p);
        p.method_51469().method_8396(null, p.method_24515(), class_3417.field_15204.comp_349(), class_3419.field_15248, 0.6f, 1.6f);
        return class_1269.field_21466;
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CALLS.isEmpty()) return;
            CALLS.entrySet().removeIf(e -> {
                class_3222 p = server.method_3760().method_14602(e.getKey());
                if (p == null) return true;
                if (p.method_51469().method_75260() < e.getValue().at) return false;
                int arrived = 0;
                Map<UUID, Last> mine = KNOWN.getOrDefault(p.method_5667(), Map.of());
                for (Map.Entry<UUID, Last> m : new HashMap<>(mine).entrySet()) {
                    if (!e.getValue().who.contains(m.getKey())) continue;
                    class_3218 sl = server.method_3847(m.getValue().dim);
                    if (sl == null) continue;
                    class_1297 ent = sl.method_66347(m.getKey());
                    if (ent instanceof HumanEntity h && h.method_5805() && h.isOwnedBy(p) && !h.isAway()) {
                        double x = p.method_23317() + p.method_59922().method_43048(5) - 2, z = p.method_23321() + p.method_59922().method_43048(5) - 2;
                        if (sl != p.method_51469()) continue;                       // other dimension: can't reach
                        h.method_5859(x, p.method_23318(), z);
                        h.setOrder(HumanEntity.Order.FOLLOW);
                        p.method_51469().method_65096(class_2398.field_11214, x, p.method_23318() + 1, z, 20, 0.3, 0.6, 0.3, 0.2);
                        arrived++;
                    }
                    sl.method_17988(m.getValue().pos.method_10263() >> 4, m.getValue().pos.method_10260() >> 4, false);
                }
                p.method_64398(class_2561.method_43470("[Radio] " + arrived + " companion(s) arrived.").method_27692(class_124.field_1075));
                return true;
            });
        });
    }
}
