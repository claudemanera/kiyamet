package com.kiyamet.npc;

import com.kiyamet.ui.PanelMenu;
import com.kiyamet.ui.Ui;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_747;

/**
 * Walkie-talkie screen: your companions sorted into 3 groups (Alpha, Bravo, Charlie). Click a person to call them,
 * right-click to move them to the next group, or call a whole group / everyone. Calls arrive in 20 seconds.
 */
public class RadioMenu extends PanelMenu {
    static final String[] TEAMS = {"Alpha", "Bravo", "Charlie"};
    static final class_1792[] TEAM_ICON = {class_1802.field_8586, class_1802.field_8128, class_1802.field_8778};
    static final class_124[] TEAM_COLOR = {class_124.field_1061, class_124.field_1078, class_124.field_1060};
    private final int[] rowSlot = {9, 18, 27};

    public static void open(class_3222 p) {
        p.method_17355(new class_747((id, inv, pl) -> new RadioMenu(id, inv, p), class_2561.method_43470("Walkie-Talkie")));
    }

    private RadioMenu(int id, class_1661 inv, class_3222 p) {
        super(id, inv, p);
        redraw();
    }

    private HumanEntity live(UUID u) {
        for (class_3218 sl : player.method_51469().method_8503().method_3738()) {
            class_1297 e = sl.method_66347(u);
            if (e instanceof HumanEntity h) return h;
        }
        return null;
    }

    @Override
    protected void draw() {
        Map<UUID, Radio.Last> known = Radio.known(player);
        long now = player.method_51469().method_75260();
        boolean calling = Radio.calling(player);
        c.method_5447(4, Ui.glint(Ui.icon(Ui.item("kiyamet:radio"), Ui.text("Walkie-Talkie", class_124.field_1075, class_124.field_1067),
                Ui.text(calling ? "Calling... arriving in " + Math.max(1, (Radio.callEnds(player) - now) / 20) + " s" : "Channel open. " + known.size() + " companion(s) on the radio", calling ? class_124.field_1054 : class_124.field_1060),
                Ui.text("Left-click a person: call them", class_124.field_1080), Ui.text("Right-click a person: move to next group", class_124.field_1080)), true));
        for (int t = 0; t < 3; t++) {
            int count = 0;
            for (Radio.Last l : known.values()) if (l.team() == t) count++;
            c.method_5447(rowSlot[t], Ui.icon(TEAM_ICON[t], Ui.text("Group " + TEAMS[t] + " (" + count + ")", TEAM_COLOR[t], class_124.field_1067), Ui.text("Click: call the whole group", class_124.field_1054)));
            int col = 1;
            for (Map.Entry<UUID, Radio.Last> e : known.entrySet()) {
                Radio.Last l = e.getValue();
                if (l.team() != t || col > 8) continue;
                int dist = l.dim() == player.method_51469().method_27983() ? (int) Math.sqrt(l.pos().method_10262(player.method_24515())) : -1;
                HumanEntity h = live(e.getKey());
                class_1799 s = Ui.icon(h != null && h.isAway() ? class_1802.field_8557 : class_1802.field_8575, class_2561.method_43470(l.name()).method_27695(TEAM_COLOR[t], class_124.field_1067),
                        Ui.text("Lv " + l.level() + " · " + l.job(), class_124.field_1080),
                        Ui.text(dist < 0 ? "In another dimension" : dist + " blocks away", class_124.field_1068),
                        Ui.text(h == null ? "Out of range (will be reached)" : h.isAway() ? "On a supply run" : h.order() == HumanEntity.Order.FOLLOW ? "Following you" : "Holding position", class_124.field_1063),
                        Ui.text("Left: call · Right: change group", class_124.field_1054));
                c.method_5447(rowSlot[t] + col, s);
                col++;
            }
        }
        c.method_5447(37, Ui.glint(Ui.icon(class_1802.field_16315, Ui.text("Call EVERYONE", class_124.field_1065, class_124.field_1067), Ui.text("All companions reach you in 20 s", class_124.field_1080)), true));
        c.method_5447(39, Ui.icon(class_1802.field_8719, Ui.text("Everyone nearby: follow me", class_124.field_1075)));
        c.method_5447(41, Ui.icon(class_1802.field_8788, Ui.text("Everyone nearby: hold position", class_124.field_1075)));
        c.method_5447(43, Ui.icon(class_1802.field_16315, Ui.text("Open group panel", class_124.field_1076), Ui.text("Supply runs, glow, picks", class_124.field_1080)));
        c.method_5447(49, Ui.icon(class_1802.field_8077, Ui.text("Close", class_124.field_1061)));
        if (player instanceof net.minecraft.class_3222 sp) {
            String risk = BaseRaids.riskLabel(sp);
            net.minecraft.class_2338 base = sp.getAttached(BaseRaids.BASE);
            c.method_5447(47, Ui.icon(class_1802.field_8399, Ui.text("Raid risk: " + risk, risk.equals("Low") ? class_124.field_1060 : class_124.field_1061, class_124.field_1067),
                    Ui.text(base == null ? "No base yet: sleep in a bed to set it" : "Base: " + base.method_23854(), class_124.field_1080),
                    Ui.text(BaseRaids.bloodMoon() ? "BLOOD MOON tonight" : "Raids come every 1-2 weeks", BaseRaids.bloodMoon() ? class_124.field_1079 : class_124.field_1080)));
        }
    }

    private UUID at(int slot) {
        for (int t = 0; t < 3; t++) {
            int col = slot - rowSlot[t];
            if (col >= 1 && col <= 8) {
                int n = 0;
                for (Map.Entry<UUID, Radio.Last> e : Radio.known(player).entrySet()) {
                    if (e.getValue().team() != t) continue;
                    if (++n == col) return e.getKey();
                }
            }
        }
        return null;
    }

    private void callMsg(int n, String who) {
        if (n == 0) player.method_7353(class_2561.method_43470("Static... nobody answers.").method_27692(class_124.field_1080), true);
        else player.method_64398(class_2561.method_43470("[Radio] \"" + who + ", come to me!\" — arriving in 20 seconds.").method_27692(class_124.field_1075));
    }

    @Override
    protected boolean click(int slot, class_1713 type) {
        Map<UUID, Radio.Last> known = Radio.known(player);
        for (int t = 0; t < 3; t++) if (slot == rowSlot[t]) {
            List<UUID> ids = new ArrayList<>();
            int tt = t;
            known.forEach((u, l) -> { if (l.team() == tt) ids.add(u); });
            callMsg(Radio.call(player, ids), "Group " + TEAMS[t]);
            return true;
        }
        UUID u = at(slot);
        if (u != null) {
            HumanEntity h = live(u);
            if (type == class_1713.field_7790 && lastButton == 1) {
                if (h != null) { h.setTeam(h.team() + 1); Radio.report(h); }
                else player.method_7353(class_2561.method_43470("Out of range: call them first to change their group.").method_27692(class_124.field_1080), true);
            } else callMsg(Radio.call(player, List.of(u)), known.get(u).name());
            return true;
        }
        switch (slot) {
            case 37 -> callMsg(Radio.call(player, known.keySet()), "Everyone");
            case 39 -> forNear(h -> h.setOrder(HumanEntity.Order.FOLLOW));
            case 41 -> forNear(h -> h.setOrder(HumanEntity.Order.STAY));
            case 43 -> { SquadMenu.open(player); return false; }
            case 49 -> { player.method_7346(); return false; }
            default -> { return false; }
        }
        return true;
    }

    private void forNear(java.util.function.Consumer<HumanEntity> f) {
        ((class_3218) player.method_51469()).method_8390(HumanEntity.class, player.method_5829().method_1014(128), h -> h.isOwnedBy(player) && !h.isAway()).forEach(f);
    }

    private int lastButton;

    @Override
    public void method_7593(int slot, int button, class_1713 type, net.minecraft.class_1657 p) {
        lastButton = button;
        super.method_7593(slot, button, type, p);
    }
}
