package com.kiyamet.npc;

import com.kiyamet.ui.PanelMenu;
import com.kiyamet.ui.Ui;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_747;

/** Talk to a lone survivor: recruit them for rubies (or a medkit if they are hurt). Max 6 companions. */
public class RecruitMenu extends PanelMenu {
    public static final int MAX_COMPANIONS = 6;
    private final HumanEntity h;

    public static void open(class_3222 p, HumanEntity h) {
        p.method_17355(new class_747((id, inv, pl) -> new RecruitMenu(id, inv, p, h), class_2561.method_43470("Survivor: " + h.method_5477().getString())));
    }

    private RecruitMenu(int id, class_1661 inv, class_3222 p, HumanEntity h) {
        super(id, inv, p);
        this.h = h;
        redraw();
    }

    public static int cost(HumanEntity h) { return 3 + h.lvl() / 8; }

    public static long companions(class_3222 p) {
        return ((net.minecraft.class_3218) p.method_51469()).method_8390(HumanEntity.class, p.method_5829().method_1014(512), x -> x.isOwnedBy(p)).size();
    }

    @Override
    protected void draw() {
        c.method_5447(4, Ui.icon(class_1802.field_8575, class_2561.method_43470(h.method_5477().getString()).method_27695(class_124.field_1068, class_124.field_1067),
                Ui.text("Level " + h.lvl(), class_124.field_1054),
                Ui.text("Type: " + h.profession().title, class_124.field_1068),
                Ui.text(h.specialty() == Specialty.NONE ? "No specialty" : "★ " + h.specialty().title + ": " + h.specialty().desc, h.specialty() == Specialty.NONE ? class_124.field_1080 : class_124.field_1076),
                Ui.text("\"I could use some company out here.\"", class_124.field_1080)));
        int cost = cost(h), have = Shop.count(player, Shop.RUBY);
        c.method_5447(20, Ui.glint(Ui.icon(Ui.item("kiyamet:dollar_100"), Ui.text("Recruit for " + com.kiyamet.money.Money.fmt(cost * com.kiyamet.money.Money.RATE), have >= cost ? class_124.field_1060 : class_124.field_1061, class_124.field_1067),
                Ui.text("You have " + have, class_124.field_1080), Ui.text("Companions: " + companions(player) + " / " + MAX_COMPANIONS, class_124.field_1080)), have >= cost));
        c.method_5447(22, Ui.icon(Ui.item("kiyamet:medkit"), Ui.text("Give a medkit instead", class_124.field_1075), Ui.text("A kind deed: they join for free", class_124.field_1080)));
        c.method_5447(24, Ui.icon(class_1802.field_8229, Ui.text("Share food (3 bread)", class_124.field_1065), Ui.text("50% chance they join", class_124.field_1080)));
        c.method_5447(49, Ui.icon(class_1802.field_8077, Ui.text("Leave", class_124.field_1061)));
    }

    public static void join(class_3222 player, HumanEntity h, String line) {
        Talk.say(player, h, line);
        h.setOwner(player);
        player.method_64398(class_2561.method_43470(h.method_5477().getString() + " joins you! Right-click them for orders.").method_27695(class_124.field_1075, class_124.field_1067));
        player.method_51469().method_8396(null, h.method_24515(), net.minecraft.class_3417.field_14815, net.minecraft.class_3419.field_15254, 1f, 1f);
    }

    private void join() {
        h.setOwner(player);
        player.method_7346();
        player.method_64398(class_2561.method_43470(h.method_5477().getString() + " joins you! Right-click them for orders.").method_27695(class_124.field_1075, class_124.field_1067));
        player.method_51469().method_8396(null, h.method_24515(), net.minecraft.class_3417.field_14815, net.minecraft.class_3419.field_15254, 1f, 1f);
    }

    @Override
    protected boolean click(int slot, class_1713 type) {
        if (!h.method_5805() || h.faction() != Faction.SURVIVOR) { player.method_7346(); return false; }
        if (slot == 49) { player.method_7346(); return false; }
        if (slot != 20 && slot != 22 && slot != 24) return false;
        if (companions(player) >= MAX_COMPANIONS) { player.method_7353(class_2561.method_43470("You already lead " + MAX_COMPANIONS + " companions.").method_27692(class_124.field_1061), true); return false; }
        if (slot == 20 && Shop.take(player, Shop.RUBY, cost(h))) join();
        else if (slot == 22 && Shop.take(player, "kiyamet:medkit", 1)) join();
        else if (slot == 24 && Shop.take(player, "minecraft:bread", 3)) {
            if (h.method_59922().method_43056()) join();
            else { player.method_7353(class_2561.method_43470("\"Thanks... but I'm not ready to trust you yet.\"").method_27692(class_124.field_1080), true); return true; }
        } else player.method_7353(class_2561.method_43470("You don't have that.").method_27692(class_124.field_1061), true);
        return true;
    }
}
