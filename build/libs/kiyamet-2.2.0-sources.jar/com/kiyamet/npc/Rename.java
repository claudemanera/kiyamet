package com.kiyamet.npc;

import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** "Rename" button: the next chat message you type becomes the companion's name (and is not sent to chat). */
public final class Rename {
    private static final Map<UUID, UUID> PENDING = new HashMap<>();

    public static void start(class_3222 p, HumanEntity h) {
        PENDING.put(p.method_5667(), h.method_5667());
        p.method_7346();
        p.method_64398(class_2561.method_43470("Type the new name for " + h.method_5477().getString() + " in chat (or type 'cancel').").method_27692(class_124.field_1075));
    }

    public static void init() {
        ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, params) -> {
            UUID target = PENDING.remove(sender.method_5667());
            if (target == null) return true;
            String name = message.method_44862().trim();
            if (name.equalsIgnoreCase("cancel") || name.isEmpty()) { sender.method_64398(class_2561.method_43470("Renaming cancelled.")); return false; }
            if (name.length() > 24) name = name.substring(0, 24);
            class_1297 e = ((class_3218) sender.method_51469()).method_66347(target);
            if (e instanceof HumanEntity h && h.isOwnedBy(sender)) {
                h.method_5665(class_2561.method_43470(name));
                sender.method_64398(class_2561.method_43470("Your companion is now called " + name + ".").method_27692(class_124.field_1060));
            }
            return false;
        });
    }

    private Rename() {}
}
