package com.kiyamet.npc;

import com.kiyamet.ui.Ui;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

/** Inventory helpers for payments. Prices written as "RUBY" are paid in dollars since 1.6 ($10 each). */
public final class Shop {
    public static final String RUBY = "kiyamet:ruby";

    public static int count(class_3222 p, class_1792 it) {
        int n = 0;
        for (int i = 0; i < p.method_31548().method_5439(); i++) { class_1799 s = p.method_31548().method_5438(i); if (s.method_31574(it)) n += s.method_7947(); }
        return n;
    }

    public static int count(class_3222 p, String id) { return id.equals(RUBY) ? com.kiyamet.money.Money.total(p) / com.kiyamet.money.Money.RATE : count(p, Ui.item(id)); }

    public static boolean take(class_3222 p, String id, int amount) {
        if (id.equals(RUBY)) return com.kiyamet.money.Money.take(p, amount * com.kiyamet.money.Money.RATE);   // 1.6: prices are paid in dollars
        class_1792 it = Ui.item(id);
        if (p.method_68878()) return true;
        if (count(p, it) < amount) return false;
        for (int i = 0; i < p.method_31548().method_5439() && amount > 0; i++) {
            class_1799 s = p.method_31548().method_5438(i);
            if (s.method_31574(it)) { int t = Math.min(amount, s.method_7947()); s.method_7934(t); amount -= t; }
        }
        return true;
    }

    public static void give(class_3222 p, class_1799 s) {
        if (!p.method_31548().method_7394(s)) p.method_7328(s, false);
    }

    private Shop() {}
}
