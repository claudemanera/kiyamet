package com.kiyamet.npc;

import com.kiyamet.ui.PanelMenu;
import com.kiyamet.ui.Ui;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_747;

/** Your whole group in one place: pick people, send them on a supply run together, or give group orders. */
public class SquadMenu extends PanelMenu {
    private static final int[] SLOTS = {10, 11, 12, 14, 15, 16};
    private final Set<UUID> picked = new HashSet<>();
    private List<HumanEntity> squad = List.of();

    public static void open(class_3222 p) {
        p.method_17355(new class_747((id, inv, pl) -> new SquadMenu(id, inv, p), class_2561.method_43470("Your group")));
    }

    private SquadMenu(int id, class_1661 inv, class_3222 p) {
        super(id, inv, p);
        redraw();
    }

    private List<HumanEntity> members() {
        return new ArrayList<>(((class_3218) player.method_51469()).method_8390(HumanEntity.class, player.method_5829().method_1014(512), h -> h.isOwnedBy(player)));
    }

    @Override
    protected void draw() {
        squad = members();
        long now = player.method_51469().method_75260();
        c.method_5447(4, Ui.glint(Ui.icon(class_1802.field_16315, Ui.text("Group: " + squad.size() + " / " + RecruitMenu.MAX_COMPANIONS, class_124.field_1065, class_124.field_1067),
                Ui.text("Click people to pick them, then send them out.", class_124.field_1080),
                Ui.text("Longer runs = more loot but more danger. Bigger groups are safer.", class_124.field_1080)), true));
        for (int i = 0; i < SLOTS.length; i++) {
            if (i >= squad.size()) { c.method_5447(SLOTS[i], Ui.icon(class_1802.field_8871, Ui.text("Empty place", class_124.field_1063))); continue; }
            HumanEntity h = squad.get(i);
            boolean away = h.isAway(), sel = picked.contains(h.method_5667());
            class_1799 s = Ui.icon(away ? class_1802.field_8557 : h.job().icon, class_2561.method_43470(h.method_5477().getString()).method_27695(sel ? class_124.field_1060 : class_124.field_1068, class_124.field_1067),
                    Ui.text("Lv " + h.lvl() + " · " + h.profession().title + " · " + h.job().title, class_124.field_1080),
                    Ui.text("Health " + (int) h.method_6032() + " / " + (int) h.method_6063(), class_124.field_1061),
                    away ? Ui.text("On a supply run: back in " + Math.max(1, (h.awayUntil() - now) / 1200 + 1) + " min", class_124.field_1054)
                         : Ui.text(sel ? "✔ Picked (click to unpick)" : "Click to pick", sel ? class_124.field_1060 : class_124.field_1054));
            c.method_5447(SLOTS[i], Ui.glint(s, sel));
        }
        c.method_5447(28, Ui.icon(class_1802.field_8719, Ui.text("Everyone: follow me", class_124.field_1075)));
        c.method_5447(30, Ui.icon(class_1802.field_8788, Ui.text("Everyone: stay here", class_124.field_1075)));
        c.method_5447(32, Ui.icon(class_1802.field_8634, Ui.text("Call everyone to me", class_124.field_1075)));
        c.method_5447(34, Ui.icon(class_1802.field_8601, Ui.text("Toggle glow for everyone", class_124.field_1054)));
        c.method_5447(37, Ui.icon(class_1802.field_8539, Ui.text("Pick everyone available", class_124.field_1068)));
        c.method_5447(39, Ui.icon(class_1802.field_8106, Ui.text("Supply run: 3 minutes", class_124.field_1060), Ui.text("Safe, small haul", class_124.field_1080)));
        c.method_5447(40, Ui.icon(class_1802.field_8106, Ui.text("Supply run: 6 minutes", class_124.field_1065), Ui.text("Some risk, good haul", class_124.field_1080)));
        c.method_5447(41, Ui.icon(class_1802.field_8106, Ui.text("Supply run: 10 minutes", class_124.field_1061), Ui.text("Dangerous, big haul", class_124.field_1080)));
        c.method_5447(43, Ui.icon(class_1802.field_8077, Ui.text("Clear picks", class_124.field_1080)));
        c.method_5447(49, Ui.icon(class_1802.field_8107, Ui.text("Close", class_124.field_1061)));
    }

    @Override
    protected boolean click(int slot, class_1713 type) {
        for (int i = 0; i < SLOTS.length; i++) if (slot == SLOTS[i] && i < squad.size()) {
            HumanEntity h = squad.get(i);
            if (h.isAway()) return false;
            if (!picked.remove(h.method_5667())) picked.add(h.method_5667());
            return true;
        }
        switch (slot) {
            case 28 -> squad.forEach(h -> { if (!h.isAway()) h.setOrder(HumanEntity.Order.FOLLOW); });
            case 30 -> squad.forEach(h -> { if (!h.isAway()) h.setOrder(HumanEntity.Order.STAY); });
            case 32 -> squad.forEach(h -> { if (!h.isAway()) { h.method_5859(player.method_23317(), player.method_23318(), player.method_23321()); h.setOrder(HumanEntity.Order.FOLLOW); } });
            case 34 -> { boolean on = squad.stream().noneMatch(HumanEntity::method_36361); squad.forEach(h -> h.method_5834(on)); }
            case 37 -> squad.forEach(h -> { if (!h.isAway()) picked.add(h.method_5667()); });
            case 43 -> picked.clear();
            case 39, 40, 41 -> {
                int minutes = slot == 39 ? 3 : slot == 40 ? 6 : 10;
                List<HumanEntity> go = squad.stream().filter(h -> picked.contains(h.method_5667()) && !h.isAway()).toList();
                if (go.isEmpty()) { player.method_7353(class_2561.method_43470("Pick someone first.").method_27692(class_124.field_1061), true); return false; }
                for (HumanEntity h : go) h.sendAway(minutes, go.size());
                picked.clear();
                player.method_64398(class_2561.method_43470(go.size() + " companion(s) left on a " + minutes + "-minute supply run.").method_27692(class_124.field_1065));
            }
            case 49 -> { player.method_7346(); return false; }
            default -> { return false; }
        }
        return true;
    }
}
