package com.kiyamet.npc;

import com.kiyamet.Kiyamet;
import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_124;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/** 1.6: every new player starts with one companion at their side (use the Gather button to send them for wood, stone and ores). */
public final class Starter {
    public static final AttachmentType<Boolean> GIVEN = AttachmentRegistry.create(Kiyamet.id("starter_companion"), b -> b.initializer(() -> false).persistent(Codec.BOOL).copyOnDeath());

    public static void init() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 p = handler.method_32311();
            server.execute(() -> {
                if (p.getAttachedOrElse(GIVEN, false) || !(p.method_51469() instanceof class_3218 level)) return;
                p.setAttached(GIVEN, true);
                HumanEntity h = ModHumans.spawn(level, p.method_24515().method_10089(2), Faction.SURVIVOR, Role.MEMBER, 15, "");
                if (h == null) return;
                h.setOwner(p);
                h.method_5673(class_1304.field_6173, new class_1799(class_1802.field_8528));
                p.method_64398(class_2561.method_43470(h.method_5477().getString() + " has your back. Right-click them for orders - try 'Gather resources' → Develop.").method_27695(class_124.field_1075, class_124.field_1067));
                Talk.sayLater(p, h, 60, "Hey. Stick together and we might just make it. Want me to gather some wood?");
            });
        });
    }

    private Starter() {}
}
