package com.kiyamet.npc;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_2170;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5250;
import net.minecraft.server.MinecraftServer;
import java.util.*;
import java.util.function.Consumer;

/**
 * Conversations in the normal game chat. The game never pauses: people say their lines in chat with a short
 * "typing" delay, and your answers appear as clickable [1] [2] [3] options (or just type the number).
 * Walking away (20 blocks) or waiting 60 seconds ends the talk.
 */
public final class Talk {
    public record Option(String text, Consumer<class_3222> then) {}

    private static final class Convo {
        UUID npc;
        List<Option> options = List.of();
        long expires;
        Consumer<class_3222> onTimeout;
    }

    private record Later(long at, UUID player, Runnable run) {}

    private static final Map<UUID, Convo> ACTIVE = new HashMap<>();
    private static final List<Later> QUEUE = new ArrayList<>();
    private static MinecraftServer server;

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(s -> {
            server = s;
            long now = s.method_3780();
            if (!QUEUE.isEmpty()) {
                List<Later> due = new ArrayList<>();
                for (Iterator<Later> it = QUEUE.iterator(); it.hasNext(); ) { Later l = it.next(); if (l.at <= now) { due.add(l); it.remove(); } }
                for (Later l : due) if (s.method_3760().method_14602(l.player) != null) l.run.run();
            }
            if (now % 20 != 0) return;
            for (Iterator<Map.Entry<UUID, Convo>> it = ACTIVE.entrySet().iterator(); it.hasNext(); ) {
                Map.Entry<UUID, Convo> e = it.next();
                class_3222 p = s.method_3760().method_14602(e.getKey());
                Convo c = e.getValue();
                class_1297 npc = p == null ? null : ((class_3218) p.method_51469()).method_66347(c.npc);
                boolean gone = p == null || npc == null || !npc.method_5805() || npc.method_5739(p) > 28;
                if (gone || now > c.expires) {
                    it.remove();
                    if (p != null && c.onTimeout != null) c.onTimeout.accept(p);
                }
            }
        });

        ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, params) -> {
            Convo c = ACTIVE.get(sender.method_5667());
            if (c == null) return true;
            String t = message.method_44862().trim();
            if (t.length() == 1 && Character.isDigit(t.charAt(0))) { choose(sender, t.charAt(0) - '0'); return false; }
            return true;
        });

        CommandRegistrationCallback.EVENT.register((d, ctx, env) -> d.register(class_2170.method_9247("twd")
                .then(class_2170.method_9247("talk").then(class_2170.method_9244("n", IntegerArgumentType.integer(1, 9)).executes(c -> {
                    choose(c.getSource().method_9207(), IntegerArgumentType.getInteger(c, "n"));
                    return 1;
                })))));
    }

    public static boolean busy(class_3222 p) { return ACTIVE.containsKey(p.method_5667()); }

    private static long now() { return server == null ? 0 : server.method_3780(); }

    public static void later(class_3222 p, int ticks, Runnable r) {
        if (ticks <= 0) r.run(); else QUEUE.add(new Later(now() + ticks, p.method_5667(), r));
    }

    static class_124 color(HumanEntity h) {
        return switch (h.faction()) {
            case COMMUNITY -> class_124.field_1060;
            case SURVIVOR -> class_124.field_1054;
            case RAIDER -> class_124.field_1061;
            case COMPANION -> class_124.field_1075;
            default -> class_124.field_1068;
        };
    }

    /** Typing time for a line, in ticks. */
    static int typing(String line) { return Math.min(50, 12 + line.length() / 2); }

    /** A line in chat from this person: "Name: text". */
    public static void say(class_3222 p, HumanEntity h, String line) {
        p.method_64398(class_2561.method_43470(h.method_5477().getString() + ": ").method_27695(color(h), class_124.field_1067)
                .method_10852(class_2561.method_43470(line).method_27692(class_124.field_1068)));
        p.method_51469().method_8396(null, h.method_24515(), class_3417.field_15175, class_3419.field_15254, 0.35f, h.appearance().female() ? 1.35f : 0.9f);
    }

    /** Say a line after a delay. */
    public static void sayLater(class_3222 p, HumanEntity h, int delay, String line) {
        later(p, delay, () -> { if (h.method_5805()) say(p, h, line); });
    }

    /** A line from a named character that isn't (or needn't be) a visible person. */
    public static void sayAs(class_3222 p, String name, class_124 col, String line) {
        p.method_64398(class_2561.method_43470(name + ": ").method_27695(col, class_124.field_1067).method_10852(class_2561.method_43470(line).method_27692(class_124.field_1068)));
    }

    public static void sayAsLater(class_3222 p, int delay, String name, class_124 col, String line) { later(p, delay, () -> sayAs(p, name, col, line)); }

    /** Say a question after a delay, then show the options and wait for the answer. */
    public static void ask(class_3222 p, HumanEntity h, int delay, String line, Consumer<class_3222> onTimeout, Option... options) {
        askAs(p, h, h.method_5477().getString(), color(h), delay, line, onTimeout, options);
    }

    /** Like ask, for any speaker; the talk ends if you walk 28 blocks from {@code anchor}. */
    public static void askAs(class_3222 p, class_1297 anchor, String name, class_124 col, int delay, String line, Consumer<class_3222> onTimeout, Option... options) {
        Convo c = new Convo();
        c.npc = anchor.method_5667();
        c.options = List.of(options);
        c.onTimeout = onTimeout;
        c.expires = now() + delay + 20 * 60;
        ACTIVE.put(p.method_5667(), c);
        later(p, delay, () -> {
            if (!anchor.method_5805() || ACTIVE.get(p.method_5667()) != c) return;
            if (!line.isEmpty()) sayAs(p, name, col, line);
            for (int i = 0; i < options.length; i++) {
                int n = i + 1;
                class_5250 opt = class_2561.method_43470("   [" + n + "] ").method_27695(class_124.field_1065, class_124.field_1067)
                        .method_10852(class_2561.method_43470(options[i].text).method_27692(class_124.field_1080));
                opt.method_27694(st -> st.method_10958(new class_2558.class_10609("/twd talk " + n))
                        .method_10949(new class_2568.class_10613(class_2561.method_43470("Click, or type " + n + " in chat"))));
                p.method_64398(opt);
            }
        });
    }

    static void choose(class_3222 p, int n) {
        Convo c = ACTIVE.get(p.method_5667());
        if (c == null || n < 1 || n > c.options.size()) return;
        ACTIVE.remove(p.method_5667());
        Option o = c.options.get(n - 1);
        p.method_64398(class_2561.method_43470("You: ").method_27695(class_124.field_1080, class_124.field_1067)
                .method_10852(class_2561.method_43470(o.text).method_27695(class_124.field_1080, class_124.field_1056)));
        o.then.accept(p);
    }

    public static void end(class_3222 p) { ACTIVE.remove(p.method_5667()); }

    static String pick(net.minecraft.class_5819 r, String... lines) { return lines[r.method_43048(lines.length)]; }

    private Talk() {}
}
