package com.kiyamet.npc;

import com.kiyamet.ui.PanelMenu;
import com.kiyamet.ui.Ui;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_747;

/** Community trader: buy supplies for rubies (top) or sell your loot for rubies (bottom). Good trades raise reputation. */
public class TradeMenu extends PanelMenu {
    record Offer(String item, int count, int rubies) {}

    static final List<Offer> SELL = List.of(
            new Offer("minecraft:bread", 6, 1), new Offer("minecraft:cooked_beef", 4, 2),
            new Offer("kiyamet:bandage", 3, 2), new Offer("kiyamet:medkit", 1, 5), new Offer("kiyamet:vaccine", 1, 10),
            new Offer("kiyamet:walker_guts", 3, 1), new Offer("kiyamet:fuel_canister", 2, 3), new Offer("kiyamet:metal_plate", 4, 3),
            new Offer("kiyamet:circuit", 2, 4),
            new Offer("kiyamet:arrow_pistol", 1, 18), new Offer("kiyamet:pistol_ammo", 24, 2), new Offer("kiyamet:rifle_ammo", 20, 3), new Offer("kiyamet:shotgun_shell", 12, 3), new Offer("kiyamet:magazine", 1, 4), new Offer("kiyamet:barbed_wire", 8, 3),
            new Offer("kiyamet:repair_kit", 2, 4), new Offer("kiyamet:energy_cell", 1, 7), new Offer("kiyamet:radio", 1, 6));
    static final List<Offer> BUY = List.of(
            new Offer("minecraft:rotten_flesh", 32, 1), new Offer("minecraft:iron_ingot", 6, 1), new Offer("minecraft:gold_ingot", 4, 1),
            new Offer("minecraft:diamond", 1, 3), new Offer("minecraft:wheat", 24, 1), new Offer("minecraft:leather", 8, 1),
            new Offer("minecraft:coal", 16, 1), new Offer("minecraft:emerald", 2, 1), new Offer("kiyamet:tech_core", 1, 5), new Offer("kiyamet:ruby", 1, 3));

    private final HumanEntity h;

    public static void open(class_3222 p, HumanEntity h) {
        p.method_17355(new class_747((id, inv, pl) -> new TradeMenu(id, inv, p, h), class_2561.method_43470("Trader: " + h.method_5477().getString())));
    }

    private TradeMenu(int id, class_1661 inv, class_3222 p, HumanEntity h) {
        super(id, inv, p);
        this.h = h;
        redraw();
    }

    @Override
    protected void draw() {
        int rubies = Shop.count(player, Shop.RUBY);
        c.method_5447(4, Ui.glint(Ui.icon(Ui.item("kiyamet:money_bag"), Ui.text("Your money: " + com.kiyamet.money.Money.fmt(com.kiyamet.money.Money.total(player)), class_124.field_1060, class_124.field_1067),
                Ui.text("Top: buy  |  Bottom: sell", class_124.field_1080), Ui.text("Reputation: " + Communities.reputation(player, h.community()), class_124.field_1060)), true));
        for (int i = 0; i < SELL.size(); i++) {
            Offer o = SELL.get(i);
            class_1799 s = new class_1799(Ui.item(o.item()), o.count());
            Ui.lore(s, List.of(Ui.text("Buy for " + com.kiyamet.money.Money.fmt(o.rubies() * com.kiyamet.money.Money.RATE), rubies >= o.rubies() ? class_124.field_1060 : class_124.field_1061), Ui.text("Click to buy", class_124.field_1054)));
            c.method_5447(9 + i, s);
        }
        for (int i = 0; i < BUY.size(); i++) {
            Offer o = BUY.get(i);
            int have = Shop.count(player, o.item());
            class_1799 s = new class_1799(Ui.item(o.item()), o.count());
            Ui.lore(s, List.of(Ui.text("Sell " + o.count() + " for " + com.kiyamet.money.Money.fmt(o.rubies() * com.kiyamet.money.Money.RATE), have >= o.count() ? class_124.field_1060 : class_124.field_1063),
                    Ui.text("You have " + have, class_124.field_1080), Ui.text("Click to sell", class_124.field_1054)));
            c.method_5447(36 + i, Ui.glint(s, have >= o.count()));
        }
        for (int i = 27; i < 36; i++) c.method_5447(i, Ui.frame());
        c.method_5447(49, Ui.icon(net.minecraft.class_1802.field_8077, Ui.text("Close", class_124.field_1061)));
    }

    @Override
    protected boolean click(int slot, class_1713 type) {
        if (!h.method_5805()) { player.method_7346(); return false; }
        if (slot == 49) { player.method_7346(); return false; }
        if (slot >= 9 && slot < 9 + SELL.size()) {
            Offer o = SELL.get(slot - 9);
            if (!Shop.take(player, Shop.RUBY, o.rubies())) { player.method_7353(class_2561.method_43470("Not enough money.").method_27692(class_124.field_1061), true); return false; }
            Shop.give(player, new class_1799(Ui.item(o.item()), o.count()));
            Communities.change(player, h.community(), 1);
            return true;
        }
        if (slot >= 36 && slot < 36 + BUY.size()) {
            Offer o = BUY.get(slot - 36);
            if (!Shop.take(player, o.item(), o.count())) return false;
            com.kiyamet.money.Money.give(player, o.rubies() * com.kiyamet.money.Money.RATE);
            Communities.change(player, h.community(), 1);
            return true;
        }
        return false;
    }
}
