package com.kiyamet.npc;

import com.kiyamet.ui.Ui;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_5819;

/** What NPCs carry. Ranged weapons shoot hitscan arrows; damage always scales with the NPC's single level. */
public final class Weapon {
    public static boolean ranged(class_1799 s) {
        return s.method_7909() instanceof class_1753 || s.method_7909() instanceof class_1764 || s.method_7909() instanceof com.kiyamet.item.GunItem;
    }

    /** Extra multiplier by weapon tier on top of the level-based damage. */
    public static float tier(class_1799 s) {
        if (s.method_7960()) return 0.6f;
        if (s.method_7909() instanceof com.kiyamet.item.GunItem) return 1.35f;
        if (s.method_31574(class_1802.field_8399)) return 1.15f;
        if (s.method_31574(class_1802.field_8102)) return 1.0f;
        if (s.method_31574(class_1802.field_22022) || s.method_31574(class_1802.field_22025)) return 1.5f;
        if (s.method_31574(class_1802.field_8802) || s.method_31574(class_1802.field_8556)) return 1.3f;
        if (s.method_31574(class_1802.field_8371) || s.method_31574(class_1802.field_8475)) return 1.12f;
        return 1.0f;
    }

    public static class_1799 random(class_5819 r, Faction f, Role role, int level) {
        String[] melee = {"minecraft:wooden_sword", "minecraft:stone_axe", "minecraft:iron_axe", "minecraft:iron_sword", "minecraft:stone_sword"};
        String[] guns = {"kiyamet:arrow_pistol", "kiyamet:silenced_arrow_pistol", "kiyamet:arrow_rifle", "kiyamet:arrow_shotgun", "kiyamet:arrow_repeater", "kiyamet:service_pistol", "kiyamet:revolver", "kiyamet:ak47", "kiyamet:hunting_rifle", "kiyamet:survivor_smg", "kiyamet:aks74u"};
        String[] bigGuns = {"kiyamet:arrow_sniper", "kiyamet:arrow_gatling", "kiyamet:double_arrow_rifle", "kiyamet:incendiary_repeater", "kiyamet:rpk", "kiyamet:bolt_sniper", "kiyamet:ak12", "kiyamet:marksman_rifle", "kiyamet:ak_tactical"};
        if (f == Faction.WHISPERER) return new class_1799(Ui.item(r.method_43056() ? "minecraft:stone_sword" : "minecraft:iron_axe"));
        if (role == Role.COMMANDER) return new class_1799(Ui.item(bigGuns[r.method_43048(bigGuns.length)]));
        float gunChance = f == Faction.RAIDER ? 0.6f : role == Role.GUARD ? 0.55f : 0.2f;
        if (level > 150) gunChance += 0.2f;
        float roll = r.method_43057();
        if (roll < gunChance) return new class_1799(Ui.item((level > 180 ? bigGuns : guns)[r.method_43048(level > 180 ? bigGuns.length : guns.length)]));
        if (roll < gunChance + 0.2f) return new class_1799(r.method_43056() ? class_1802.field_8102 : class_1802.field_8399);
        String m = level > 200 ? "minecraft:diamond_sword" : melee[r.method_43048(melee.length)];
        return new class_1799(Ui.item(m));
    }

    private Weapon() {}
}
