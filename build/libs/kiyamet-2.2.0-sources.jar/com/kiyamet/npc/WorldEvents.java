package com.kiyamet.npc;

import com.kiyamet.entity.KZombie;
import com.kiyamet.entity.ZombieKind;
import com.kiyamet.registry.ModItems;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1799;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.server.MinecraftServer;
import java.util.*;

/**
 * World events: walker herds crossing the land, acid rain, and raider envoys demanding tribute
 * (pay and the raid clock resets, refuse and they come tonight).
 */
public final class WorldEvents {
    static boolean acidRain;
    private static boolean wasRaining;

    private record Herd(List<UUID> walkers, class_2338 dest, long until) {}
    private static final List<Herd> HERDS = new ArrayList<>();

    private record Envoy(UUID human, UUID player, int demand, long until) {}
    private static final Map<UUID, Envoy> ENVOYS = new HashMap<>();   // envoy entity -> deal
    private static final Map<UUID, Long> LEAVING = new HashMap<>();    // envoy entity -> despawn tick

    public static boolean acidRain() { return acidRain; }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int t = server.method_3780();
            class_3218 ow = server.method_30002();
            if (t % 20 == 0) weather(server, ow);
            if (t % 40 == 0 && acidRain) acid(ow);
            if (t % 20 == 5) herds(ow, t);
            if (t % 20 == 10) envoys(server, ow, t);
            if (t % 2400 == 600) for (class_3222 p : server.method_3760().method_14571()) roll(p, ow);
        });

        // hitting the envoy = refusing
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((e, src, amount) -> {
            if (e instanceof HumanEntity h && h.envoy && src.method_5529() instanceof class_3222 p) { refuse(p, h); }
            return true;
        });

        CommandRegistrationCallback.EVENT.register((d, ctx, env) -> d.register(class_2170.method_9247("twd")
                .then(class_2170.method_9247("event").then(class_2170.method_9244("what", com.mojang.brigadier.arguments.StringArgumentType.word()).executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    if (!p.method_68878()) { p.method_64398(class_2561.method_43470("Creative mode only.")); return 0; }
                    switch (com.mojang.brigadier.arguments.StringArgumentType.getString(c, "what")) {
                        case "herd" -> herd(p, p.method_51469());
                        case "acid" -> { acidRain = !acidRain; p.method_64398(class_2561.method_43470("Acid rain: " + acidRain)); }
                        case "tribute" -> envoy(p, p.method_51469());
                        default -> p.method_64398(class_2561.method_43470("herd | acid | tribute"));
                    }
                    return 1;
                })))));
    }

    private static void roll(class_3222 p, class_3218 ow) {
        if (p.method_51469() != ow || p.method_7325()) return;
        int power = ModHumans.power(p);
        float r = ow.field_9229.method_43057();
        if (power >= 150 && r < 0.07f) herd(p, ow);
        else if (power >= 500 && r < 0.11f && !BaseRaids.busy(p) && ENVOYS.values().stream().noneMatch(e -> e.player.equals(p.method_5667())) && ow.method_8530()) envoy(p, ow);
    }

    // ---------------------------------------------------------------- acid rain

    private static void weather(MinecraftServer server, class_3218 ow) {
        boolean raining = ow.method_8419();
        if (raining && !wasRaining && ow.method_8532() / 24000 >= 5 && ow.field_9229.method_43057() < 0.3f) {
            acidRain = true;
            for (class_3222 p : server.method_3760().method_14571())
                p.method_64398(class_2561.method_43470("The rain burns. ACID RAIN - get under a roof or wear a helmet!").method_27695(class_124.field_1060, class_124.field_1067));
        }
        if (!raining && acidRain) {
            acidRain = false;
            for (class_3222 p : server.method_3760().method_14571()) p.method_64398(class_2561.method_43470("The acid rain has stopped.").method_27692(class_124.field_1080));
        }
        wasRaining = raining;
    }

    private static void acid(class_3218 ow) {
        for (class_3222 p : ow.method_18456()) {
            if (p.method_68878() || p.method_7325()) continue;
            if (p.method_5854() instanceof com.kiyamet.vehicle.VehicleEntity v && v.kind != com.kiyamet.vehicle.VehicleKind.ATV && v.kind != com.kiyamet.vehicle.VehicleKind.MOTORCYCLE) continue;
            if (!ow.method_8520(class_2338.method_49638(p.method_33571()).method_10084())) continue;
            class_1799 helmet = p.method_6118(class_1304.field_6169);
            if (!helmet.method_7960() && helmet.method_7963()) helmet.method_7970(1, p, class_1304.field_6169);
            else p.method_64397(ow, ow.method_48963().method_48831(), 1f);
            ow.method_65096(class_2398.field_11234, p.method_23317(), p.method_23318() + 1.8, p.method_23321(), 4, 0.3, 0.2, 0.3, 0);
        }
        // the acid also hurts walkers and raiders out in the open, a little
        for (class_3222 p : ow.method_18456())
            for (class_1308 m : ow.method_8390(class_1308.class, p.method_5829().method_1014(32), m -> (m instanceof KZombie || m instanceof HumanEntity h && h.faction() == Faction.RAIDER) && ow.method_8520(m.method_24515().method_10086(2))))
                if (ow.field_9229.method_43057() < 0.3f) m.method_64397(ow, ow.method_48963().method_48831(), 1f);
    }

    // ---------------------------------------------------------------- herds

    private static final ZombieKind[] HERD = {ZombieKind.FARMER, ZombieKind.FARMER, ZombieKind.WOMAN, ZombieKind.NURSE, ZombieKind.DOCTOR, ZombieKind.POLICE, ZombieKind.CRAWLER, ZombieKind.TOXIC, ZombieKind.ARMORED, ZombieKind.SCREAMER};

    static void herd(class_3222 p, class_3218 level) {
        class_2338 start = ModHumans.surface(level, p.method_24515(), 56, 72);
        if (start == null) return;
        class_2338 dest = new class_2338(2 * p.method_31477() - start.method_10263() + level.field_9229.method_43048(31) - 15, p.method_31478(), 2 * p.method_31479() - start.method_10260() + level.field_9229.method_43048(31) - 15);
        int n = 18 + level.field_9229.method_43048(17) + Math.min(16, ModHumans.power(p) / 400);
        List<UUID> ids = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            class_2338 at = start.method_10069(level.field_9229.method_43048(13) - 6, 0, level.field_9229.method_43048(13) - 6);
            at = level.method_8598(net.minecraft.class_2902.class_2903.field_13203, at);
            KZombie z = BaseRaids.walker(level, at, HERD[level.field_9229.method_43048(HERD.length)]);
            if (z != null) ids.add(z.method_5667());
        }
        HERDS.add(new Herd(ids, dest, level.method_75260() + 20 * 60 * 4));
        String dir = dir(start, p.method_24515());
        p.method_64398(class_2561.method_43470("The ground trembles... a HERD of " + n + " walkers is moving through, coming from the " + dir + ". Stay quiet or get out of the way.").method_27695(class_124.field_1077, class_124.field_1067));
        level.method_8396(null, p.method_24515(), class_3417.field_15174, class_3419.field_15251, 2f, 0.5f);
        for (HumanEntity h : level.method_8390(HumanEntity.class, p.method_5829().method_1014(48), h -> h.isOwnedBy(p) && h.job() == Job.SCOUT)) {
            p.method_64398(class_2561.method_43470("[" + h.method_5477().getString() + "] Herd from the " + dir + "! Dozens of them. Let them pass.").method_27692(class_124.field_1075));
            break;
        }
    }

    static String dir(class_2338 from, class_2338 to) {
        double a = Math.atan2(from.method_10260() - to.method_10260(), from.method_10263() - to.method_10263());
        String[] d = {"east", "south-east", "south", "south-west", "west", "north-west", "north", "north-east"};
        return d[Math.floorMod((int) Math.round(a / (Math.PI / 4)), 8)];
    }

    private static void herds(class_3218 level, int t) {
        for (Iterator<Herd> it = HERDS.iterator(); it.hasNext(); ) {
            Herd h = it.next();
            boolean over = level.method_75260() > h.until;
            int alive = 0;
            for (UUID u : h.walkers) {
                class_1297 e = level.method_66347(u);
                if (!(e instanceof KZombie z) || !z.method_5805()) continue;
                alive++;
                if (over) { if (level.method_18460(z, 40) == null) z.method_31472(); continue; }
                if (z.method_5968() == null && t % 60 == 5) z.method_5942().method_6337(h.dest.method_10263() + 0.5, h.dest.method_10264(), h.dest.method_10260() + 0.5, 0.9);
            }
            if (over || alive == 0) it.remove();
        }
    }

    // ---------------------------------------------------------------- tribute

    static void envoy(class_3222 p, class_3218 level) {
        class_2338 at = ModHumans.surface(level, p.method_24515(), 18, 26);
        if (at == null) return;
        int power = ModHumans.power(p);
        HumanEntity h = ModHumans.spawn(level, at, Faction.RAIDER, Role.LEADER, class_3532.method_15340(20 + power / 25, 20, 240), null);
        if (h == null) return;
        h.envoy = true;
        h.method_5980(null);
        h.method_5665(class_2561.method_43470("Raider Envoy").method_27692(class_124.field_1065));
        int demand = class_3532.method_15340(8 + power / 150, 8, 40);
        ENVOYS.put(h.method_5667(), new Envoy(h.method_5667(), p.method_5667(), demand, level.method_75260() + 20 * 150));
        p.method_64398(class_2561.method_43470("A raider walks up with his hands raised. He wants to talk - right-click him.").method_27692(class_124.field_1065));
    }

    static void envoyTalk(class_3222 p, HumanEntity h) {
        Envoy e = ENVOYS.get(h.method_5667());
        if (e == null || !e.player.equals(p.method_5667())) { Talk.say(p, h, "Not you. Where's the one in charge?"); return; }
        Dialogues.envoy(p, h, e.demand,
                d -> { Envoy cur = ENVOYS.get(h.method_5667()); if (cur != null) ENVOYS.put(h.method_5667(), new Envoy(cur.human, cur.player, d, cur.until)); },
                () -> pay(p, h),
                () -> refuse(p, h));
    }

    private static void pay(class_3222 p, HumanEntity h) {
        Envoy e = ENVOYS.get(h.method_5667());
        if (e == null) return;
        if (!Shop.take(p, Shop.RUBY, e.demand)) return;
        BaseRaids.paid(p);
        Talk.say(p, h, "Smart. Nobody touches your place for a while.");
        p.method_64398(class_2561.method_43470("(" + com.kiyamet.money.Money.fmt(e.demand * com.kiyamet.money.Money.RATE) + " paid - no raids for at least a week)").method_27692(class_124.field_1065));
        leave(h);
    }

    private static void refuse(class_3222 p, HumanEntity h) {
        Envoy e = ENVOYS.remove(h.method_5667());
        h.envoy = false;
        h.method_5665(null);
        if (e == null) return;
        class_3222 owner = p.method_51469().method_8503().method_3760().method_14602(e.player);
        if (owner == null) return;
        BaseRaids.scheduleTonight(owner);
        owner.method_64398(class_2561.method_43470("Raiders will hit your base after dark!").method_27695(class_124.field_1061, class_124.field_1067));
    }

    private static void leave(HumanEntity h) {
        ENVOYS.remove(h.method_5667());
        LEAVING.put(h.method_5667(), h.method_73183().method_75260() + 400);
        class_2338 away = h.method_24515().method_10069(h.method_59922().method_43048(80) - 40, 0, h.method_59922().method_43048(80) - 40);
        h.method_5942().method_6337(away.method_10263(), away.method_10264(), away.method_10260(), 1.0);
    }

    private static void envoys(MinecraftServer server, class_3218 level, int t) {
        for (Iterator<Map.Entry<UUID, Envoy>> it = ENVOYS.entrySet().iterator(); it.hasNext(); ) {
            Envoy e = it.next().getValue();
            class_1297 ent = level.method_66347(e.human);
            if (!(ent instanceof HumanEntity h) || !h.method_5805()) { it.remove(); continue; }
            class_3222 p = server.method_3760().method_14602(e.player);
            h.method_5980(null);
            if (p != null && p.method_51469() == level && h.method_5739(p) > 4) h.method_5942().method_6335(p, 0.9);
            else h.method_5942().method_6340();
            if (p != null && p.method_51469() == level) h.method_5988().method_35111(p);
            if (level.method_75260() > e.until) {
                it.remove();
                h.envoy = false;
                h.method_5665(null);
                if (p != null) {
                    BaseRaids.scheduleTonight(p);
                    p.method_64398(class_2561.method_43470("[Envoy] \"No answer is an answer.\" - Raiders will hit your base tonight!").method_27695(class_124.field_1061, class_124.field_1067));
                }
                leave(h);
            }
        }
        for (Iterator<Map.Entry<UUID, Long>> it = LEAVING.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Long> en = it.next();
            if (level.method_75260() < en.getValue()) continue;
            class_1297 ent = level.method_66347(en.getKey());
            if (ent instanceof HumanEntity h && h.faction() == Faction.RAIDER && level.method_18460(h, 24) == null) h.method_31472();
            it.remove();
        }
    }

    private WorldEvents() {}
}
