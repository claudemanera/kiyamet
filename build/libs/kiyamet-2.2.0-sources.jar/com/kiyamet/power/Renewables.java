package com.kiyamet.power;

import com.kiyamet.Kiyamet;
import com.kiyamet.registry.ModItems;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_124;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3481;
import net.minecraft.class_3726;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraft.class_9886;

/**
 * 1.9 clean power. Solar panels power everything within 8 blocks while the sun is up (and they can see the sky);
 * wind turbines turn day and night - faster up high and in storms. Both count as power for turrets, electric fences,
 * lights... exactly like a running generator, but need no fuel. Electric tools charge while you stand in power:
 * the drill mines 3x3, the chainsaw fells a whole tree.
 */
public final class Renewables {
    public static class_2248 SOLAR, TURBINE;
    public static class_1792 DRILL, CHAINSAW;
    public static final int MAX_CHARGE = 400;

    public static class Source extends class_2248 {
        final boolean solar;
        final class_265 shape;
        public Source(class_2251 p, boolean solar) { super(p); this.solar = solar; shape = solar ? class_2248.method_9541(0, 0, 0, 16, 6, 16) : class_2248.method_9541(5, 0, 5, 11, 16, 11); }
        @Override protected class_265 method_9530(class_2680 s, class_1922 l, class_2338 p, class_3726 c) { return shape; }
        public boolean producing(class_1937 level, class_2338 pos) {
            if (solar) return level.method_8530() && level.method_8311(pos.method_10084());
            return level.method_8311(pos.method_10086(2)) || pos.method_10264() > 90;
        }
    }

    static class_2248 block(String name, java.util.function.Function<class_4970.class_2251, class_2248> f, class_4970.class_2251 p) {
        class_5321<class_2248> key = class_5321.method_29179(class_7924.field_41254, Kiyamet.id(name));
        class_2248 b = class_2378.method_39197(class_7923.field_41175, key, f.apply(p.method_63500(key)));
        ModItems.custom(name, ip -> new class_1747(b, ip.method_63685()));
        return b;
    }

    /** is a solar panel or turbine producing power within range of pos? (used by Power.isPowered) */
    public static boolean near(class_3218 level, class_2338 pos, int range) {
        for (class_2338 p : class_2338.method_10097(pos.method_10069(-range, -range, -range), pos.method_10069(range, range, range))) {
            class_2680 s = level.method_8320(p);
            if (s.method_26204() instanceof Source src && src.producing(level, p)) return true;
        }
        return false;
    }

    static class_2487 tag(class_1799 s) { return s.method_58695(class_9334.field_49628, class_9279.field_49302).method_57461(); }
    public static int charge(class_1799 s) { return tag(s).method_68083("Charge", MAX_CHARGE / 2); }
    static void setCharge(class_1799 s, int c) { class_2487 t = tag(s); t.method_10569("Charge", Math.max(0, Math.min(MAX_CHARGE, c))); s.method_57379(class_9334.field_49628, class_9279.method_57456(t)); }

    public static void init() {
        SOLAR = block("solar_panel", p -> new Source(p, true), class_4970.class_2251.method_9630(class_2246.field_10085).method_9632(2f).method_22488());
        TURBINE = block("wind_turbine", p -> new Source(p, false), class_4970.class_2251.method_9630(class_2246.field_10085).method_9632(2f).method_22488());
        DRILL = ModItems.custom("electric_drill", p -> new class_1792(p.method_66330(class_9886.field_52588, 1f, -2.6f).method_7895(2400)));
        CHAINSAW = ModItems.custom("chainsaw", p -> new class_1792(p.method_67190(class_9886.field_52588, 7f, -3.0f).method_7895(2400)));
        // charging: every second, tools in your inventory charge while you stand in power
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.method_3780() % 20 != 0) return;
            for (class_3222 p : server.method_3760().method_14571()) {
                boolean powered = false; boolean checked = false;
                for (int i = 0; i < p.method_31548().method_5439(); i++) {
                    class_1799 s = p.method_31548().method_5438(i);
                    if (!(s.method_31574(DRILL) || s.method_31574(CHAINSAW)) || charge(s) >= MAX_CHARGE) continue;
                    if (!checked) { powered = com.kiyamet.defense.Power.isPowered(p.method_51469(), p.method_24515()); checked = true; }
                    if (!powered) break;
                    setCharge(s, charge(s) + 10);
                }
            }
        });
        PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, be) -> {
            if (!(player instanceof class_3222 p) || !(level instanceof class_3218 sl) || p.method_5715()) return;
            class_1799 tool = p.method_6047();
            if (tool.method_31574(DRILL) && state.method_26164(class_3481.field_33715)) drill(sl, p, tool, pos);
            else if (tool.method_31574(CHAINSAW) && state.method_26164(class_3481.field_15475)) fell(sl, p, tool, pos, state);
        });
    }

    static boolean busy = false;

    static void drill(class_3218 l, class_3222 p, class_1799 tool, class_2338 pos) {
        if (busy) return;
        if (charge(tool) <= 0) { p.method_7353(class_2561.method_43470("Drill battery empty - stand near a generator, solar panel or turbine.").method_27692(class_124.field_1061), true); return; }
        class_2350 face = p.method_5735(); boolean vertical = Math.abs(p.method_36455()) > 50;
        busy = true;
        int n = 0;
        for (int a = -1; a <= 1; a++) for (int b = -1; b <= 1; b++) {
            if (a == 0 && b == 0) continue;
            class_2338 q = vertical ? pos.method_10069(a, 0, b) : face.method_10166() == class_2350.class_2351.field_11048 ? pos.method_10069(0, a, b) : pos.method_10069(a, b, 0);
            class_2680 s = l.method_8320(q);
            if (s.method_26215() || !s.method_26164(class_3481.field_33715) || s.method_26214(l, q) < 0 || s.method_26214(l, q) > 50) continue;
            if (p.field_13974.method_14266(q)) n++;
        }
        busy = false;
        setCharge(tool, charge(tool) - 1 - n / 3);
        if (n > 0) l.method_8396(null, pos, class_3417.field_16865, class_3419.field_15248, 0.5f, 1.6f);
        p.method_7353(class_2561.method_43470("Drill: " + charge(tool) + "/" + MAX_CHARGE).method_27692(class_124.field_1075), true);
    }

    static void fell(class_3218 l, class_3222 p, class_1799 tool, class_2338 start, class_2680 st) {
        if (busy) return;
        if (charge(tool) <= 0) { p.method_7353(class_2561.method_43470("Chainsaw battery empty - stand near a generator, solar panel or turbine.").method_27692(class_124.field_1061), true); return; }
        Set<Long> seen = new HashSet<>();
        ArrayDeque<class_2338> q = new ArrayDeque<>();
        q.add(start); seen.add(start.method_10063());
        List<class_2338> logs = new java.util.ArrayList<>();
        while (!q.isEmpty() && logs.size() < 96) {
            class_2338 c = q.poll();
            for (int dx = -1; dx <= 1; dx++) for (int dy = 0; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) {
                class_2338 n = c.method_10069(dx, dy, dz);
                if (seen.add(n.method_10063()) && l.method_8320(n).method_26164(class_3481.field_15475)) { logs.add(n); q.add(n); }
            }
        }
        busy = true;
        for (class_2338 b : logs) if (p.field_13974.method_14266(b)) {}
        busy = false;
        setCharge(tool, charge(tool) - 1 - logs.size() / 4);
        l.method_8396(null, start, class_3417.field_14929, class_3419.field_15248, 0.8f, 1.8f);
        p.method_7353(class_2561.method_43470("Chainsaw: " + charge(tool) + "/" + MAX_CHARGE + " · felled " + (logs.size() + 1) + " logs").method_27692(class_124.field_1075), true);
    }

    private Renewables() {}
}
