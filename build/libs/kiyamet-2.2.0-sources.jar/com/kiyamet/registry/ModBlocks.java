package com.kiyamet.registry;

import com.kiyamet.Kiyamet;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2323;
import net.minecraft.class_2378;
import net.minecraft.class_2431;
import net.minecraft.class_2498;
import net.minecraft.class_2560;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_6019;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8177;

/** Base-defense blocks + ruby ore. Durability values (zombie break time) live in DefenseRules (phase 7). */
public final class ModBlocks {
    public static final List<class_2248> ALL = new ArrayList<>();

    public static final class_2248 REINFORCED_PLANKS = reg("reinforced_planks", class_2248::new,
            class_4970.class_2251.method_9630(class_2246.field_10161).method_9629(4f, 6f));
    public static final class_2248 STEEL_BLOCK = reg("steel_block", class_2248::new,
            class_4970.class_2251.method_9637().method_31710(class_3620.field_16005).method_9629(8f, 12f).method_9626(class_2498.field_11533).method_29292());
    public static final class_2248 STEEL_GRATE = reg("steel_grate", class_2248::new,
            class_4970.class_2251.method_9630(class_2246.field_10033).method_9629(7f, 10f).method_9626(class_2498.field_11533).method_29292());
    public static final class_2248 RUBY_BLOCK = reg("ruby_block", class_2248::new,
            class_4970.class_2251.method_9637().method_31710(class_3620.field_16020).method_9629(10f, 20f).method_9626(class_2498.field_27197)
                    .method_9631(s -> 4).method_29292());
    public static final class_2248 TITANIUM_BLOCK = reg("titanium_block", class_2248::new,
            class_4970.class_2251.method_9637().method_31710(class_3620.field_15993).method_9629(15f, 1200f).method_9626(class_2498.field_22150).method_29292());
    public static final class_2248 ENERGY_WALL = reg("energy_wall", class_2248::new,
            class_4970.class_2251.method_9630(class_2246.field_10033).method_9629(50f, 3600000f).method_9631(s -> 10).method_29292());
    public static final class_2248 STEEL_GATE = reg("steel_gate", p -> new class_2323(class_8177.field_42819, p),
            class_4970.class_2251.method_9630(class_2246.field_9973).method_9629(9f, 12f));
    public static final class_2248 BARBED_WIRE = reg("barbed_wire", class_2560::new,
            class_4970.class_2251.method_9630(class_2246.field_10343).method_9632(2f).method_9626(class_2498.field_24119));
    public static final class_2248 RAZOR_WIRE = reg("razor_wire", class_2560::new,
            class_4970.class_2251.method_9630(class_2246.field_10343).method_9632(3f).method_9626(class_2498.field_24119));
    public static final class_2248 ELECTRIC_FENCE = reg("electric_fence", class_2248::new,
            class_4970.class_2251.method_9630(class_2246.field_10589).method_9632(2f).method_9626(class_2498.field_24119));
    public static final class_2248 SPIKE_TRAP = reg("spike_trap", class_2248::new,
            class_4970.class_2251.method_9630(class_2246.field_10589).method_9632(1.5f).method_9626(class_2498.field_11533));
    public static final class_2248 RUBY_ORE = reg("ruby_ore", p -> new class_2431(class_6019.method_35017(3, 7), p),
            class_4970.class_2251.method_9630(class_2246.field_10442));
    public static final class_2248 DEEPSLATE_RUBY_ORE = reg("deepslate_ruby_ore", p -> new class_2431(class_6019.method_35017(3, 7), p),
            class_4970.class_2251.method_9630(class_2246.field_29029));

    public static final class_2248 GUN_BENCH = reg("gun_bench", com.kiyamet.gunsmith.GunBenchBlock::new,
            class_4970.class_2251.method_9637().method_31710(class_3620.field_15996).method_9629(3f, 6f).method_9626(class_2498.field_11547));
    public static final class_2248 VEHICLE_WORKSHOP = reg("vehicle_workshop", com.kiyamet.vehicle.WorkshopBlock::new,
            class_4970.class_2251.method_9637().method_31710(class_3620.field_16005).method_9629(4f, 8f).method_9626(class_2498.field_11533));
    public static final class_2248 LAB_TABLE = reg("lab_table", com.kiyamet.lab.LabTableBlock::new,
            class_4970.class_2251.method_9637().method_31710(class_3620.field_16005).method_9629(4f, 8f).method_9626(class_2498.field_11533).method_22488());

    public static final class_2248 GENERATOR = reg("generator", com.kiyamet.defense.GeneratorBlock::new,
            class_4970.class_2251.method_9637().method_31710(class_3620.field_16005).method_9629(5f, 10f).method_9626(class_2498.field_11533).method_29292()
                    .method_9631(s -> s.method_11654(com.kiyamet.defense.GeneratorBlock.LIT) && s.method_11654(com.kiyamet.defense.GeneratorBlock.ON) ? 9 : 0));

    // 2.2: the Temple of Wisdom in the End - white, glowing, and nothing can break it
    public static final class_2248 WISDOM_STONE = reg("wisdom_stone", class_2248::new,
            class_4970.class_2251.method_9637().method_31710(class_3620.field_16022).method_9629(-1f, 3600000f).method_9631(s -> 5).method_9626(class_2498.field_27203).method_42327()
                    .method_50012(net.minecraft.class_3619.field_15972));
    public static final class_2248 WISDOM_GLASS = reg("wisdom_glass", net.minecraft.class_8923::new,
            class_4970.class_2251.method_9630(class_2246.field_10033).method_9629(-1f, 3600000f).method_9631(s -> 9).method_42327().method_22488()
                    .method_50012(net.minecraft.class_3619.field_15972));
    public static final class_2248 WISDOM_LIGHT = reg("wisdom_light", class_2248::new,
            class_4970.class_2251.method_9637().method_31710(class_3620.field_16022).method_9629(-1f, 3600000f).method_9631(s -> 15).method_9626(class_2498.field_27197).method_42327()
                    .method_50012(net.minecraft.class_3619.field_15972));
    public static final class_2248 CREATION_TABLE = reg("creation_table", com.kiyamet.creation.CreationTableBlock::new,
            class_4970.class_2251.method_9637().method_31710(class_3620.field_16022).method_9629(-1f, 3600000f).method_9631(s -> 15).method_9626(class_2498.field_27197).method_42327().method_22488()
                    .method_50012(net.minecraft.class_3619.field_15972));
    public static final class_2248 CREATION_ALTAR = reg("creation_altar", com.kiyamet.creation.CreationAltarBlock::new,
            class_4970.class_2251.method_9637().method_31710(class_3620.field_16022).method_9629(6f, 3600000f).method_9631(s -> 15).method_9626(class_2498.field_27197).method_22488()
                    .method_50012(net.minecraft.class_3619.field_15972));

    // 2.2: plates - put food on them like an item frame on the table
    public static final class_2248 PLATE = reg("plate", com.kiyamet.food.PlateBlock::new,
            class_4970.class_2251.method_9637().method_31710(class_3620.field_16022).method_9632(0.4f).method_9626(class_2498.field_42771).method_22488());

    private static class_2248 reg(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 props) {
        class_5321<class_2248> key = class_5321.method_29179(class_7924.field_41254, Kiyamet.id(name));
        class_2248 block = class_2378.method_39197(class_7923.field_41175, key, factory.apply(props.method_63500(key)));
        ALL.add(block);
        return block;
    }

    public static void init() {}
    private ModBlocks() {}
}
