package com.kiyamet.registry;

import com.kiyamet.Kiyamet;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1765;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/** Every item of the mod. Behaviour (stones, gadgets, arrow guns) is added in later phases by swapping the factory. */
public final class ModItems {
    public static final List<class_1792> ALL = new ArrayList<>();

    public static final String[] STONES = {"fire_stone", "frost_stone", "storm_stone", "nature_stone", "blood_stone",
            "shadow_stone", "soul_stone", "time_stone", "void_stone", "earth_stone", "star_stone", "dragon_stone"};
    public static final String[] GADGETS = {"flashlight", "sonic_lure", "grappling_gun", "night_vision", "vein_miner", "jetpack",
            "healing_syringe", "auto_turret", "flamethrower", "gravity_glove", "structure_scanner", "drone_controller", "clone_device",
            "teleport_gun", "emp_bomb", "laser_rifle", "shield_generator", "time_stopper", "black_hole_bomb", "energy_sword"};
    public static final String[] WEAPONS = {"arrow_pistol", "arrow_rifle", "double_arrow_rifle", "arrow_shotgun", "silenced_arrow_pistol",
            "arrow_repeater", "toxic_arrow_rifle", "frost_arrow_gun", "arrow_sniper", "incendiary_repeater", "tesla_arrow_gun", "arrow_gatling",
            "harpoon_gun", "arrow_railgun", "arrow_launcher", "void_arrow_launcher", "homing_arrow_gun", "apocalypse_cannon",
            "service_pistol", "compact_pistol", "tactical_pistol", "hand_cannon", "revolver", "magnum_revolver", "machine_pistol", "golden_pistol", "flare_pistol", "ak47", "akm_classic", "ak74", "aks74u", "ak_tactical", "rpk", "golden_ak", "ak12", "ak_grenadier", "bolt_sniper", "hunting_rifle", "marksman_rifle", "anti_materiel_rifle", "ghillie_sniper", "silent_sniper", "lever_rifle", "longshot_rifle", "survivor_smg",
            "pump_shotgun", "sawed_off", "auto_shotgun", "ak_shotgun", "behemoth_shotgun"};
    public static final String[] PARTS = {"circuit", "energy_cell", "vaccine", "bandage", "tech_core", "metal_plate", "fuel_canister",
            "lens", "void_shard", "energy_core", "ruby"};
    public static final String[] SINGLE = {"robot_core_trooper", "robot_core_drone", "robot_core_heavy", "radio", "walker_guts", "medkit", "repair_kit", "stone_gauntlet", "stone_codex_page_1", "stone_codex_page_2",
            "stone_codex_page_3", "stone_codex_page_4", "stone_codex_page_5", "stone_codex_page_6"};

    static {
        for (String s : STONES) { com.kiyamet.stone.StoneKind k = com.kiyamet.stone.StoneKind.byId(s); custom(s, p -> new com.kiyamet.stone.StoneItem(p.method_7889(1).method_7894(net.minecraft.class_1814.field_8904), k)); }
        for (String s : GADGETS) {
            if (s.equals("healing_syringe")) custom(s, p -> new com.kiyamet.item.HealItem(p.method_7889(4), com.kiyamet.item.HealItem.Kind.SYRINGE));
            else { String id = s; custom(s, p -> new com.kiyamet.item.GadgetItem(p.method_7889(id.equals("emp_bomb") || id.equals("black_hole_bomb") || id.equals("sonic_lure") ? 8 : 1), id)); }
        }
        for (String s : WEAPONS) { com.kiyamet.item.GunItem.Stats st = com.kiyamet.item.GunItem.statsFor(s); custom(s, p -> new com.kiyamet.item.GunItem(p.method_7895(500 + Math.round(st.damage() * 20)), st)); }
        for (String s : com.kiyamet.ammo.Ammo.AMMO) simple(s, 99);
        for (String[] m : com.kiyamet.ammo.Ammo.MAGS) { int cap = Integer.parseInt(m[1]); custom(m[0], p -> new com.kiyamet.ammo.MagazineItem(p.method_7889(1), cap)); }
        for (String s : PARTS) {
            if (s.equals("bandage")) custom(s, p -> new com.kiyamet.item.HealItem(p.method_7889(16), com.kiyamet.item.HealItem.Kind.BANDAGE));
            else if (s.equals("vaccine")) custom(s, p -> new com.kiyamet.item.HealItem(p.method_7889(8), com.kiyamet.item.HealItem.Kind.VACCINE));
            else simple(s, 64);
        }
        for (String s : SINGLE) {
            if (s.equals("medkit")) custom(s, p -> new com.kiyamet.item.HealItem(p.method_7889(8), com.kiyamet.item.HealItem.Kind.MEDKIT));
            else if (s.equals("robot_core_trooper")) custom(s, p -> new com.kiyamet.robot.RobotCoreItem(p.method_7889(1).method_7894(net.minecraft.class_1814.field_8904), com.kiyamet.robot.RobotKind.ROBOT_TROOPER));
            else if (s.equals("robot_core_drone")) custom(s, p -> new com.kiyamet.robot.RobotCoreItem(p.method_7889(1).method_7894(net.minecraft.class_1814.field_8904), com.kiyamet.robot.RobotKind.SCOUT_DRONE));
            else if (s.equals("robot_core_heavy")) custom(s, p -> new com.kiyamet.robot.RobotCoreItem(p.method_7889(1).method_7894(net.minecraft.class_1814.field_8904), com.kiyamet.robot.RobotKind.ROBOT_HEAVY));
            else if (s.equals("radio")) custom(s, p -> new com.kiyamet.npc.Radio(p.method_7889(1)));
            else if (s.equals("walker_guts")) custom(s, p -> new com.kiyamet.item.WalkerGutsItem(p.method_7889(16)));
            else if (s.equals("repair_kit")) custom(s, p -> new com.kiyamet.item.RepairKitItem(p.method_7889(16)));
            else if (s.equals("stone_gauntlet")) custom(s, p -> new com.kiyamet.stone.GauntletItem(p.method_7889(1).method_7894(net.minecraft.class_1814.field_8904)));
            else simple(s, 1);
        }
        for (class_2248 b : ModBlocks.ALL) {
            class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, class_7923.field_41175.method_10221(b));
            class_1792.class_1793 p = new class_1792.class_1793().method_63686(key).method_63685();
            if (b == ModBlocks.GENERATOR) p = p.method_7889(21);
            class_1792 item = b == ModBlocks.STEEL_GATE ? new class_1765(b, p) : new class_1747(b, p);
            ALL.add(class_2378.method_39197(class_7923.field_41178, key, item));
        }
    }

    public static final class_5321<class_1761> TAB_KEY = class_5321.method_29179(class_7924.field_44688, Kiyamet.id("main"));

    private static class_1792 simple(String name, int stack) {
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, Kiyamet.id(name));
        class_1792 item = class_2378.method_39197(class_7923.field_41178, key, new class_1792(new class_1792.class_1793().method_63686(key).method_7889(stack)));
        ALL.add(item);
        return item;
    }

    public static class_1792 custom(String name, java.util.function.Function<class_1792.class_1793, class_1792> factory) {
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, Kiyamet.id(name));
        class_1792 item = class_2378.method_39197(class_7923.field_41178, key, factory.apply(new class_1792.class_1793().method_63686(key)));
        ALL.add(item);
        return item;
    }

    public static class_1792 get(String name) {
        return class_7923.field_41178.method_63535(Kiyamet.id(name));
    }

    public static void init() {}

    private ModItems() {}
}
