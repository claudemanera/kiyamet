package com.kiyamet.registry;

import com.kiyamet.Kiyamet;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_2893;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public final class ModWorldgen {
    public static void init() {
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), class_2893.class_2895.field_13176,
                class_5321.method_29179(class_7924.field_41245, Kiyamet.id("ore_ruby")));
    }
    private ModWorldgen() {}
}
