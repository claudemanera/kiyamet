package com.kiyamet.robot;

import com.kiyamet.skill.Skill;
import com.kiyamet.skill.SkillManager;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;

/** Robot core: use on the ground to build a robot companion that fights for you (max 3). */
public class RobotCoreItem extends class_1792 {
    public static final int MAX = 3;
    private final RobotKind kind;

    public RobotCoreItem(class_1793 p, RobotKind kind) { super(p); this.kind = kind; }

    @Override
    public class_1269 method_7884(class_1838 ctx) {
        if (!(ctx.method_8045() instanceof class_3218 level) || !(ctx.method_8036() instanceof class_3222 p)) return class_1269.field_5812;
        long mine = level.method_8390(RobotEntity.class, p.method_5829().method_1014(256), r -> r.isAlly() && p.method_5667().equals(r.owner())).size();
        if (mine >= MAX) { p.method_7353(class_2561.method_43470("You already command " + MAX + " robots.").method_27692(class_124.field_1061), true); return class_1269.field_5814; }
        RobotEntity r = ModRobots.TYPES.get(kind).method_5883(level, class_3730.field_16471);
        if (r == null) return class_1269.field_5814;
        class_2338 at = ctx.method_8037().method_10093(ctx.method_8038());
        r.method_5814(at.method_10263() + 0.5, at.method_10264() + (kind.flying ? 2 : 0), at.method_10260() + 0.5);
        r.makeAlly(p, SkillManager.get(p).level(Skill.ENGINEERING));
        level.method_8649(r);
        level.method_65096(class_2398.field_29644, r.method_23317(), r.method_23318() + 1, r.method_23321(), 60, 0.5, 0.8, 0.5, 0.3);
        level.method_8396(null, at, class_3417.field_21077, class_3419.field_15248, 1f, 0.7f);
        p.method_64398(class_2561.method_43470("Robot online. Right-click: follow/stay, iron ingot: repair.").method_27692(class_124.field_1075));
        if (!p.method_68878()) ctx.method_8041().method_7934(1);
        return class_1269.field_5812;
    }
}
