package com.kiyamet.robot;

import com.kiyamet.entity.KZombie;
import com.kiyamet.world.Difficulty;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1366;
import net.minecraft.class_1376;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1542;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_7923;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.animation.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/** Robot soldiers of the tech sites: melee + laser shots. Drones hover. Immune to poison and infection. */
public class RobotEntity extends class_1588 implements GeoEntity {
    public static final RawAnimation IDLE = RawAnimation.begin().thenLoop("misc.idle");
    public static final RawAnimation WALK = RawAnimation.begin().thenLoop("move.walk");
    public static final RawAnimation ATTACK = RawAnimation.begin().thenPlay("attack.swing");
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    public final RobotKind kind;
    private int laserCooldown = 40;
    private static final net.minecraft.class_2940<Boolean> ALLY =
            net.minecraft.class_2945.method_12791(RobotEntity.class, net.minecraft.class_2943.field_13323);
    @org.jetbrains.annotations.Nullable private java.util.UUID owner;
    private boolean staying;

    public boolean isAlly() { return field_6011.method_12789(ALLY); }
    @org.jetbrains.annotations.Nullable public java.util.UUID owner() { return owner; }

    @Override
    protected void method_5693(net.minecraft.class_2945.class_9222 b) {
        super.method_5693(b);
        b.method_56912(ALLY, false);
    }

    /** Built at the Laboratory Table: fights for its owner. Engineering makes it tougher. */
    public void makeAlly(net.minecraft.class_3222 p, int engineering) {
        owner = p.method_5667();
        field_6011.method_12778(ALLY, true);
        method_5971();
        double mult = 1 + engineering / 500.0;
        var hp = method_5996(net.minecraft.class_5134.field_23716);
        if (hp != null) hp.method_6192(kind.health * 2 * mult);
        var dmg = method_5996(net.minecraft.class_5134.field_23721);
        if (dmg != null) dmg.method_6192(kind.damage * mult);
        method_6033(method_6063());
        method_5665(net.minecraft.class_2561.method_43470(p.method_5477().getString() + "'s " + (kind == RobotKind.ROBOT_HEAVY ? "Heavy Robot" : kind == RobotKind.SCOUT_DRONE ? "Drone" : "Robot")));
        method_5980(null);
    }

    @org.jetbrains.annotations.Nullable private net.minecraft.class_3222 ownerPlayer() {
        return owner != null && method_73183() instanceof class_3218 sl ? sl.method_8503().method_3760().method_14602(owner) : null;
    }

    private boolean enemyOfMe(class_1309 e) {
        if (!isAlly()) return e instanceof class_1657 || e instanceof KZombie || e instanceof RobotEntity r && r.isAlly();
        if (e instanceof class_1657) return false;
        if (e instanceof RobotEntity r) return !r.isAlly();
        if (e instanceof com.kiyamet.npc.HumanEntity h) return h.faction() == com.kiyamet.npc.Faction.RAIDER || h.faction() == com.kiyamet.npc.Faction.WHISPERER;
        return e instanceof net.minecraft.class_1569;
    }

    @Override
    protected void method_5652(net.minecraft.class_11372 out) {
        super.method_5652(out);
        out.method_71472("Ally", isAlly());
        out.method_71472("Staying", staying);
        if (owner != null) out.method_71469("Owner", owner.toString());
    }

    @Override
    protected void method_5749(net.minecraft.class_11368 in) {
        super.method_5749(in);
        field_6011.method_12778(ALLY, in.method_71433("Ally", false));
        staying = in.method_71433("Staying", false);
        String o = in.method_71428("Owner", "");
        owner = o.isEmpty() ? null : java.util.UUID.fromString(o);
    }

    @Override
    protected net.minecraft.class_1269 method_5992(class_1657 player, net.minecraft.class_1268 hand) {
        if (!isAlly() || !player.method_5667().equals(owner) || hand != net.minecraft.class_1268.field_5808) return super.method_5992(player, hand);
        if (method_73183().method_8608()) return net.minecraft.class_1269.field_5812;
        net.minecraft.class_1799 held = player.method_6047();
        if (held.method_31574(net.minecraft.class_1802.field_8620) && method_6032() < method_6063()) {
            method_6025(method_6063() * 0.25f);
            if (!player.method_68878()) held.method_7934(1);
            method_5783(class_3417.field_21077, 1f, 1.2f);
        } else {
            staying = !staying;
            method_5942().method_6340();
            player.method_7353(net.minecraft.class_2561.method_43470(method_5477().getString() + (staying ? ": holding position." : ": following you.")), true);
        }
        return net.minecraft.class_1269.field_5812;
    }

    @Override
    public boolean method_64397(class_3218 level, class_1282 source, float amount) {
        if (isAlly() && source.method_5529() != null && (source.method_5529().method_5667().equals(owner) || source.method_5529() instanceof com.kiyamet.npc.HumanEntity h && owner != null && owner.equals(h.owner()))) return false;
        return super.method_64397(level, source, amount);
    }

    @Override
    public boolean method_5974(double d) { return !isAlly() && super.method_5974(d); }

    public RobotEntity(class_1299<? extends class_1588> type, class_1937 level, RobotKind kind) {
        super(type, level);
        this.kind = kind;
        method_5959();                 // Mob's constructor calls registerGoals() before kind is set
        this.field_6194 = 8 + (int) (kind.health / 8);
        if (kind.flying) method_5875(true);
    }

    @Override public boolean method_6094() { return true; }

    @Override
    protected void method_5959() {
        if (kind == null) return;
        field_6201.method_6277(0, new class_1347(this));
        if (!kind.flying) {
            field_6201.method_6277(2, new class_1366(this, 1.0, true));
            field_6201.method_6277(6, new class_1394(this, 0.7));
        }
        field_6201.method_6277(7, new class_1361(this, class_1657.class, 16f));
        field_6201.method_6277(8, new class_1376(this));
        field_6185.method_6277(1, new class_1399(this));
        field_6185.method_6277(2, new class_1400<>(this, class_1309.class, 10, true, false, (t, l) -> enemyOfMe(t)));
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<RobotEntity>("main", 4, test -> test.setAndContinue(test.isMoving() || kind.flying ? WALK : IDLE)));
        controllers.add(new AnimationController<RobotEntity>("attack", 0, test -> PlayState.STOP).triggerableAnim("attack", ATTACK));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    @Override
    public boolean method_6049(class_1293 effect) {
        return effect.method_5579() != net.minecraft.class_1294.field_5899 && super.method_6049(effect);
    }

    @Override
    public boolean method_6121(class_3218 level, class_1297 target) {
        boolean hit = super.method_6121(level, target);
        if (hit) triggerAnim("attack", "attack");
        return hit;
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (!(method_73183() instanceof class_3218 level)) return;
        class_1309 target = method_5968();
        if (target != null && !enemyOfMe(target) && !(method_6065() == target && !isAlly())) { method_5980(null); target = null; }
        if (isAlly() && !staying && target == null && !kind.flying) {
            var p = ownerPlayer();
            if (p != null && p.method_51469() == level) {
                double d = method_5739(p);
                if (d > 28) method_5859(p.method_23317() + 1, p.method_23318(), p.method_23321() + 1);
                else if (d > 6) method_5942().method_6335(p, 1.1);
            }
        }
        if (kind.flying && isAlly() && target == null) {
            var p = ownerPlayer();
            if (p != null && p.method_51469() == level && !staying) {
                class_243 goal = p.method_73189().method_1031(0, 3, 0), d = goal.method_1020(method_73189());
                if (d.method_1033() > 30) method_5859(goal.field_1352, goal.field_1351, goal.field_1350);
                method_18799(method_18798().method_1021(0.6).method_1019((d.method_1033() > 1 ? d.method_1029().method_1021(kind.speed) : d).method_1021(0.4)));
            }
        } else if (kind.flying) {
            class_243 goal = target != null ? target.method_73189().method_1031(0, 3.5, 0) : method_73189().method_1031(0, Math.sin(field_6012 / 20.0) * 0.1, 0);
            class_243 d = goal.method_1020(method_73189());
            if (d.method_1033() > 1) d = d.method_1029().method_1021(kind.speed);
            method_18799(method_18798().method_1021(0.6).method_1019(d.method_1021(0.4)));
            if (target != null) method_5988().method_35111(target);
        }
        if (laserCooldown > 0) { laserCooldown--; return; }
        if (target == null || !target.method_5805() || method_5739(target) > 20 || method_5739(target) < 2.5 && !kind.flying || !method_6057(target)) return;
        laserCooldown = kind.laserCooldown;
        class_243 from = method_33571(), to = target.method_33571();
        int n = (int) (from.method_1022(to) * 3);
        for (int i = 0; i < n; i++) { class_243 at = from.method_1019(to.method_1020(from).method_1021(i / (double) n)); level.method_65096(class_2398.field_29644, at.field_1352, at.field_1351, at.field_1350, 1, 0, 0, 0, 0); }
        float mult = (float) Math.min(2.0, Difficulty.multiplierNear(level, method_24515()));
        target.method_64397(level, level.method_48963().method_48812(this), kind.laser * mult);
        level.method_8396(null, method_24515(), class_3417.field_19344, class_3419.field_15251, 1f, 2f);
    }

    @Override
    public boolean method_5747(double distance, float multiplier, class_1282 source) {
        return !kind.flying && super.method_5747(distance, multiplier, source);
    }

    @Override
    public void method_6078(class_1282 source) {
        super.method_6078(source);
        if (!(method_73183() instanceof class_3218 level)) return;
        if (isAlly()) { var p = ownerPlayer(); if (p != null) p.method_64398(net.minecraft.class_2561.method_43470(method_5477().getString() + " was destroyed.").method_27692(net.minecraft.class_124.field_1079)); return; }
        drop(level, new class_1799(class_1802.field_8620, 1 + field_5974.method_43048(kind == RobotKind.ROBOT_HEAVY ? 4 : 2)));
        if (field_5974.method_43057() < 0.6f) drop(level, new class_1799(class_7923.field_41178.method_63535(com.kiyamet.Kiyamet.id("circuit")), 1 + field_5974.method_43048(2)));
        if (field_5974.method_43057() < 0.25f) drop(level, new class_1799(class_7923.field_41178.method_63535(com.kiyamet.Kiyamet.id("energy_cell"))));
        if (kind == RobotKind.ROBOT_HEAVY && field_5974.method_43057() < 0.3f) drop(level, new class_1799(class_7923.field_41178.method_63535(com.kiyamet.Kiyamet.id("tech_core"))));
        level.method_65096(class_2398.field_29644, method_23317(), method_23318() + 1, method_23321(), 40, 0.5, 0.5, 0.5, 0.3);
    }

    private void drop(class_3218 level, class_1799 s) {
        level.method_8649(new class_1542(level, method_23317(), method_23318() + 0.5, method_23321(), s));
    }
}
