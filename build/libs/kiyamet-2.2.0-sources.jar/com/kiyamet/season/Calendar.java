package com.kiyamet.season;

import com.kiyamet.Kiyamet;
import com.mojang.serialization.Codec;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_1937;

/**
 * 1.7 calendar: the apocalypse starts on 1 January 2027 and every Minecraft day is one calendar day.
 * Seasons follow the months: Mar-May spring, Jun-Aug summer, Sep-Nov autumn, Dec-Feb winter.
 */
public final class Calendar {
    public static final LocalDate START = LocalDate.of(2027, 1, 1);
    /** days added on top of the world clock (/twd date set) */
    public static final AttachmentType<Integer> OFFSET = AttachmentRegistry.create(Kiyamet.id("date_offset"), b -> b.initializer(() -> 0).persistent(Codec.INT));

    public static long dayIndex(class_1937 level) {
        var ow = level.method_8503() == null ? level : level.method_8503().method_30002();
        return ow.method_8532() / 24000 + ow.getAttachedOrElse(OFFSET, 0);
    }

    public static LocalDate date(class_1937 level) { return START.plusDays(dayIndex(level)); }
    public static LocalDate dateAt(class_1937 level, long gameTime) {
        var ow = level.method_8503() == null ? level : level.method_8503().method_30002();
        long dayTimeThen = ow.method_8532() + (gameTime - ow.method_75260());
        return START.plusDays(dayTimeThen / 24000 + ow.getAttachedOrElse(OFFSET, 0));
    }

    public static Seasons.Season seasonOf(LocalDate d) {
        return switch (d.getMonthValue()) { case 3, 4, 5 -> Seasons.Season.SPRING; case 6, 7, 8 -> Seasons.Season.SUMMER; case 9, 10, 11 -> Seasons.Season.AUTUMN; default -> Seasons.Season.WINTER; };
    }

    public static String format(LocalDate d) {
        return d.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.ENGLISH) + ", " + d.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH) + " " + d.getDayOfMonth() + ", " + d.getYear();
    }

    public static String shortFormat(LocalDate d) {
        return d.getMonth().getDisplayName(TextStyle.SHORT, Locale.ENGLISH) + " " + d.getDayOfMonth() + ", " + d.getYear();
    }

    public static void init() {
        net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback.EVENT.register((d, ctx, env) -> d.register(net.minecraft.class_2170.method_9247("twd")
                .then(net.minecraft.class_2170.method_9247("date").executes(c -> {
                    var p = c.getSource().method_9207();
                    p.method_64398(net.minecraft.class_2561.method_43470("📅 " + format(date(p.method_51469())) + " · " + Seasons.season(p.method_51469()).title
                            + (SeasonEvents.today != SeasonEvents.Event.NONE ? " · " + SeasonEvents.today.title : "")).method_27692(net.minecraft.class_124.field_1068));
                    return 1;
                }).then(net.minecraft.class_2170.method_9247("set")
                        .then(net.minecraft.class_2170.method_9244("yyyy-mm-dd", com.mojang.brigadier.arguments.StringArgumentType.word()).executes(c -> {
                            var p = c.getSource().method_9207();
                            if (!p.method_68878()) return 0;
                            LocalDate want = LocalDate.parse(com.mojang.brigadier.arguments.StringArgumentType.getString(c, "yyyy-mm-dd"));
                            var ow = p.method_51469().method_8503().method_30002();
                            long now = ow.method_8532() / 24000;
                            ow.setAttached(OFFSET, (int) (java.time.temporal.ChronoUnit.DAYS.between(START, want) - now));
                            p.method_64398(net.minecraft.class_2561.method_43470("Date set: " + format(date(p.method_51469()))));
                            return 1;
                        }))))));
    }

    private Calendar() {}
}
