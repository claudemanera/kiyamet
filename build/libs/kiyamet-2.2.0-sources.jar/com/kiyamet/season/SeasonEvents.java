package com.kiyamet.season;

import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5819;
import net.minecraft.server.MinecraftServer;

/**
 * 1.7 daily date line in chat + a weather event for the day, different in every season:
 * winter blizzards and freezing lakes, spring rains and blooming meadows, summer heat waves, droughts and storms,
 * autumn fog, falling leaves, storms and the harvest moon.
 */
public final class SeasonEvents {
    public enum Event {
        NONE("", ""), BLIZZARD("Blizzard", "Heavy snow and wind. Stay inside - the cold bites twice as hard."), DEEP_FREEZE("Deep Freeze", "Lakes and rivers freeze over."),
        SPRING_RAIN("Spring Rain", "Steady rain all day. Crops grow faster."), BLOOM("Bloom", "Flowers everywhere. Bees and peace - for a day."),
        HEAT_WAVE("Heat Wave", "Scorching heat. Drink, find shade, stay out of the noon sun."), DROUGHT("Drought", "Not a cloud in the sky. Fields dry out."),
        SUMMER_STORM("Summer Storm", "Thunder and lightning. Walkers are restless."), FOG("Autumn Fog", "Thick fog. You won't see them coming."),
        LEAF_FALL("Leaf Fall", "Leaves come down in gold and red."), AUTUMN_STORM("Autumn Storm", "Cold rain and wind."), HARVEST("Harvest Moon", "Crops ripen faster today.");
        public final String title, desc;
        Event(String t, String d) { title = t; desc = d; }
    }

    public static Event today = Event.NONE;

    public static void newDay(MinecraftServer server, class_3218 ow, Seasons.Season s) {
        class_5819 r = ow.field_9229;
        Event[] pool = switch (s) {
            case WINTER -> new Event[]{Event.NONE, Event.NONE, Event.BLIZZARD, Event.DEEP_FREEZE, Event.BLIZZARD};
            case SPRING -> new Event[]{Event.NONE, Event.SPRING_RAIN, Event.SPRING_RAIN, Event.BLOOM};
            case SUMMER -> new Event[]{Event.NONE, Event.NONE, Event.HEAT_WAVE, Event.DROUGHT, Event.SUMMER_STORM};
            case AUTUMN -> new Event[]{Event.NONE, Event.FOG, Event.LEAF_FALL, Event.AUTUMN_STORM, Event.HARVEST};
        };
        today = pool[r.method_43048(pool.length)];
        switch (today) {
            case BLIZZARD, AUTUMN_STORM, SPRING_RAIN -> ow.method_27910(0, 24000, true, false);
            case SUMMER_STORM -> ow.method_27910(0, 12000, true, true);
            case DROUGHT, HEAT_WAVE, BLOOM -> ow.method_27910(24000, 0, false, false);
            default -> {}
        }
        var d = Calendar.date(ow);
        class_2561 line = class_2561.method_43470("📅 " + Calendar.format(d)).method_27695(class_124.field_1068, class_124.field_1067)
                .method_10852(class_2561.method_43470("  ·  " + s.title + ", day " + Seasons.dayOfSeason(ow)).method_27692(s.color))
                .method_10852(class_2561.method_43470("  ·  Day " + (Calendar.dayIndex(ow) + 1) + " of the apocalypse").method_27692(class_124.field_1063));
        for (class_3222 p : server.method_3760().method_14571()) {
            p.method_64398(line);
            if (today != Event.NONE) p.method_64398(class_2561.method_43470("   ⚠ " + today.title + ": " + today.desc).method_27692(s.color));
        }
    }

    /** Extra degrees from today's event (used by the temperature model). */
    public static float tempShift() {
        return switch (today) { case BLIZZARD -> -9; case DEEP_FREEZE -> -5; case HEAT_WAVE -> 9; case DROUGHT -> 4; case FOG -> -2; case AUTUMN_STORM -> -3; default -> 0; };
    }

    public static float cropBoost() { return today == Event.SPRING_RAIN || today == Event.HARVEST ? 0.2f : today == Event.DROUGHT ? -0.15f : 0; }

    public static void tick(MinecraftServer server, class_3218 ow, Seasons.Season s, int t) {
        if (today == Event.NONE || t % 20 != 0) return;
        class_5819 r = ow.field_9229;
        for (class_3222 p : server.method_3760().method_14571()) {
            if (p.method_51469() != ow || p.method_7325()) continue;
            boolean sky = ow.method_8311(p.method_24515().method_10084());
            switch (today) {
                case BLIZZARD -> {
                    ow.method_65096(class_2398.field_28013, p.method_23317(), p.method_23318() + 4, p.method_23321(), 200, 10, 3, 10, 0.3);
                    if (sky) { p.method_6092(new class_1293(class_1294.field_5909, 40, 0, true, false)); if (r.method_43048(6) == 0) p.method_6092(new class_1293(class_1294.field_38092, 60, 0, true, false)); }
                }
                case DEEP_FREEZE -> freeze(ow, p, r, 12);
                case BLOOM -> { if (r.method_43048(3) == 0) bloom(ow, p, r); }
                case HEAT_WAVE -> { if (sky && ow.method_8530()) ow.method_65096(class_2398.field_23956, p.method_23317(), p.method_23318() + 2, p.method_23321(), 10, 6, 2, 6, 0.01); }
                case FOG -> { ow.method_65096(class_2398.field_17430, p.method_23317(), p.method_23318() + 1, p.method_23321(), 6, 8, 1, 8, 0.001); if (sky && r.method_43048(8) == 0) p.method_6092(new class_1293(class_1294.field_5919, 30, 0, true, false)); }
                case LEAF_FALL -> leaves(ow, p, r);
                case AUTUMN_STORM, SPRING_RAIN -> { if (today == Event.SPRING_RAIN && r.method_43048(4) == 0) bloom(ow, p, r); }
                default -> {}
            }
        }
    }

    static class_2338 surface(class_3218 l, class_3222 p, class_5819 r, int rad) {
        class_2338 c = p.method_24515().method_10069(r.method_43048(rad * 2 + 1) - rad, 0, r.method_43048(rad * 2 + 1) - rad);
        return l.method_8477(c) ? l.method_8598(class_2902.class_2903.field_13197, c) : null;
    }

    static void freeze(class_3218 l, class_3222 p, class_5819 r, int n) {
        for (int i = 0; i < n; i++) {
            class_2338 top = surface(l, p, r, 32);
            if (top == null) continue;
            class_2680 w = l.method_8320(top.method_10074());
            if (w.method_27852(class_2246.field_10382) && w.method_26227().method_15771() && l.method_8311(top)) l.method_8501(top.method_10074(), class_2246.field_10295.method_9564());
        }
    }

    static void bloom(class_3218 l, class_3222 p, class_5819 r) {
        class_2338 top = surface(l, p, r, 24);
        if (top == null || !l.method_8320(top).method_26215() || !l.method_8320(top.method_10074()).method_27852(class_2246.field_10219)) return;
        class_2680[] f = {class_2246.field_10449.method_9564(), class_2246.field_10182.method_9564(), class_2246.field_9995.method_9564(), class_2246.field_10554.method_9564(), class_2246.field_10226.method_9564()};
        l.method_8501(top, f[r.method_43048(f.length)]);
    }

    static void leaves(class_3218 l, class_3222 p, class_5819 r) {
        for (int i = 0; i < 4; i++) {
            class_2338 c = p.method_24515().method_10069(r.method_43048(25) - 12, r.method_43048(10), r.method_43048(25) - 12);
            if (l.method_8320(c).method_26164(net.minecraft.class_3481.field_15503) && l.method_8320(c.method_10074()).method_26215())
                l.method_65096(r.method_43056() ? class_2398.field_43379 : class_2398.field_55169, c.method_10263() + 0.5, c.method_10264() - 0.2, c.method_10260() + 0.5, 3, 0.4, 0.1, 0.4, 0.01);
        }
    }

    private SeasonEvents() {}
}
