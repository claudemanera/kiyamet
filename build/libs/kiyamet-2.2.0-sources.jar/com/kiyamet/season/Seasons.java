package com.kiyamet.season;

import com.kiyamet.Kiyamet;
import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2170;
import net.minecraft.class_2246;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2344;
import net.minecraft.class_2363;
import net.minecraft.class_2397;
import net.minecraft.class_2398;
import net.minecraft.class_2488;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3922;
import net.minecraft.class_5819;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.block.*;

/**
 * TWD 1.5 seasons and body temperature.
 * A year is 4 seasons of 7 days. Winter: snow piles up to 1.5 blocks, crops barely grow and rot in the open,
 * walkers slow down in the cold. Summer: heat waves, dry fields wither. Spring melts the snow, autumn ripens the harvest.
 * Your body temperature follows the weather, the biome, day and night, shade, water, fire and your clothes.
 * Too cold: you freeze (frost vignette, slowness, damage). Too hot: hunger, blurred vision, poison, even burning.
 * The temperature is written in chat whenever it changes, coloured from navy (freezing) to red (burning).
 */
public final class Seasons {
    public enum Season {
        SPRING("Spring", class_124.field_1060, 13), SUMMER("Summer", class_124.field_1065, 29), AUTUMN("Autumn", class_124.field_1061, 11), WINTER("Winter", class_124.field_1075, -7);
        public final String title; public final class_124 color; public final float base;
        Season(String t, class_124 c, float b) { title = t; color = c; base = b; }
    }

    public static final int DAYS = 7;
    public static final AttachmentType<Float> BODY = AttachmentRegistry.create(Kiyamet.id("body_temp"), b -> b.initializer(() -> 20f).persistent(Codec.FLOAT));
    private static final java.util.Map<java.util.UUID, int[]> SHOWN = new java.util.HashMap<>();   // last shown temp, last state, tick
    private static int lastSeason = -1;
    private static int forced = -1;

    public static Season season(class_1937 level) {
        if (forced >= 0) return Season.values()[forced];
        if (level.method_8503() == null) return Season.SPRING;
        return Calendar.seasonOf(Calendar.date(level));
    }

    public static int dayOfSeason(class_1937 level) {
        java.time.LocalDate d = Calendar.date(level);
        java.time.LocalDate first = java.time.LocalDate.of(d.getMonthValue() == 12 ? d.getYear() : d.getMonthValue() <= 2 ? d.getYear() - 1 : d.getYear(), switch (Calendar.seasonOf(d)) { case SPRING -> 3; case SUMMER -> 6; case AUTUMN -> 9; case WINTER -> 12; }, 1);
        return (int) java.time.temporal.ChronoUnit.DAYS.between(first, d) + 1;
    }
    private static long lastDay = Long.MIN_VALUE;

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int t = server.method_3780();
            class_3218 ow = server.method_30002();
            Season s = season(ow);
            if (t % 100 == 0 && s.ordinal() != lastSeason) { if (lastSeason >= 0) announce(server, s); lastSeason = s.ordinal(); weather(ow, s); }
            if (t % 20 == 0) {
                long day = Calendar.dayIndex(ow);
                if (day != lastDay) { boolean first = lastDay == Long.MIN_VALUE; lastDay = day; if (!first || ow.method_8532() % 24000 < 200) SeasonEvents.newDay(server, ow, s); }
            }
            SeasonEvents.tick(server, ow, s, t);
            if (t % 20 != 0) return;
            for (class_3222 p : server.method_3760().method_14571()) {
                if (p.method_7325()) continue;
                class_3218 level = p.method_51469();
                if (level == ow) { snow(level, p, s); if (t % 40 == 0) crops(level, p, s); }
                temperature(level, p, s);
            }
        });
        CommandRegistrationCallback.EVENT.register((d, ctx, env) -> d.register(class_2170.method_9247("twd")
                .then(class_2170.method_9247("season").executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    Season s = season(p.method_51469());
                    p.method_64398(class_2561.method_43470(Calendar.format(Calendar.date(p.method_51469())) + " · " + s.title + ", day " + dayOfSeason(p.method_51469()) + ". ").method_27695(s.color, class_124.field_1067)
                            .method_10852(tempText(p.getAttachedOrElse(BODY, 20f))));
                    return 1;
                }).then(class_2170.method_9244("set", com.mojang.brigadier.arguments.IntegerArgumentType.integer(-1, 3)).executes(c -> {
                    class_3222 p = c.getSource().method_9207();
                    if (!p.method_68878()) return 0;
                    forced = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "set");
                    p.method_64398(class_2561.method_43470(forced < 0 ? "Seasons follow the calendar again." : "Season forced: " + Season.values()[forced].title));
                    return 1;
                })))));
    }

    private static void announce(MinecraftServer server, Season s) {
        String sub = switch (s) {
            case SPRING -> "The snow melts. Plant your fields.";
            case SUMMER -> "Heat waves. Stay in the shade, keep water close.";
            case AUTUMN -> "Harvest time. Prepare for the cold.";
            case WINTER -> "Snow, cold, and empty bellies. Stay warm.";
        };
        for (class_3222 p : server.method_3760().method_14571()) {
            p.field_13987.method_14364(new class_5905(20, 80, 30));
            p.field_13987.method_14364(new class_5903(class_2561.method_43470(sub).method_27692(class_124.field_1080)));
            p.field_13987.method_14364(new class_5904(class_2561.method_43470(s.title.toUpperCase()).method_27695(s.color, class_124.field_1067)));
            p.method_64398(class_2561.method_43470("❖ " + s.title + " has come. " + sub).method_27692(s.color));
        }
    }

    private static void weather(class_3218 ow, Season s) {
        if (s == Season.WINTER) ow.method_27910(0, 12000 + ow.field_9229.method_43048(12000), true, false);
        if (s == Season.SUMMER) ow.method_27910(24000 * 3, 0, false, false);
    }

    // ------------------------------------------------------------------ snow

    static boolean snowing(class_3218 l, Season s) { return s == Season.WINTER && l.method_8419(); }

    private static void snow(class_3218 level, class_3222 p, Season s) {
        class_5819 r = level.field_9229;
        if (snowing(level, s)) level.method_65096(class_2398.field_28013, p.method_23317(), p.method_23318() + 10, p.method_23321(), 80, 14, 5, 14, 0.01);
        int tries = s == Season.WINTER ? (level.method_8419() ? 40 : 3) : s == Season.SPRING ? 30 : s == Season.SUMMER ? 50 : 0;
        for (int i = 0; i < tries; i++) {
            class_2338 col = p.method_24515().method_10069(r.method_43048(81) - 40, 0, r.method_43048(81) - 40);
            if (!level.method_8477(col)) continue;
            class_2338 top = level.method_8598(class_2902.class_2903.field_13197, col);   // first free block above the surface
            class_2680 below = level.method_8320(top.method_10074());
            if (s == Season.WINTER) addSnow(level, top, below);
            else meltSnow(level, top, below);
        }
    }

    /** Snow layers pile up to 12 (one full snow block + 4 layers = 1.5 blocks). */
    private static void addSnow(class_3218 level, class_2338 top, class_2680 below) {
        if (!level.method_8311(top) || !level.method_8320(top).method_26215()) return;
        if (below.method_27852(class_2246.field_10477)) {
            int layers = below.method_11654(class_2488.field_11518);
            class_2338 at = top.method_10074();
            boolean onSnowBlock = level.method_8320(at.method_10074()).method_27852(class_2246.field_10491);
            if (layers < 8) level.method_8652(at, below.method_11657(class_2488.field_11518, layers + 1), 3);
            else if (!onSnowBlock) level.method_8652(at, class_2246.field_10491.method_9564(), 3);
            return;
        }
        if (below.method_27852(class_2246.field_10491)) {
            if (!level.method_8320(top.method_10087(2)).method_27852(class_2246.field_10491)) level.method_8652(top, class_2246.field_10477.method_9564(), 3);   // max 1 block + layers
            return;
        }
        if (below.method_26204() instanceof class_2302 || below.method_26204() instanceof class_2344 || below.method_26204() instanceof class_2397 || below.method_26227().method_15771()) return;
        if (class_2246.field_10477.method_9564().method_26184(level, top)) level.method_8652(top, class_2246.field_10477.method_9564(), 3);
    }

    private static void meltSnow(class_3218 level, class_2338 top, class_2680 below) {
        class_2338 at = top.method_10074();
        if (below.method_27852(class_2246.field_10477)) {
            int layers = below.method_11654(class_2488.field_11518);
            level.method_8652(at, layers > 1 ? below.method_11657(class_2488.field_11518, layers - 1) : class_2246.field_10124.method_9564(), 3);
        } else if (below.method_27852(class_2246.field_10491) && level.method_8320(at.method_10074()).method_51367()) {
            level.method_8652(at, class_2246.field_10477.method_9564().method_11657(class_2488.field_11518, 7), 3);
        }
    }

    // ------------------------------------------------------------------ crops

    private static void crops(class_3218 level, class_3222 p, Season s) {
        class_5819 r = level.field_9229;
        for (int i = 0; i < 40; i++) {
            class_2338 pos = p.method_24515().method_10069(r.method_43048(49) - 24, r.method_43048(9) - 4, r.method_43048(49) - 24);
            class_2680 st = level.method_8320(pos);
            if (!(st.method_26204() instanceof class_2302 crop)) continue;
            boolean sheltered = !level.method_8311(pos) || warmNear(level, pos, 4);   // greenhouses and heated fields are safe
            int age = crop.method_9829(st);
            switch (s) {
                case WINTER -> {
                    if (sheltered) break;
                    if (r.method_43057() < 0.07f) {           // rots in the frozen field
                        level.method_8652(pos, class_2246.field_10124.method_9564(), 3);
                        level.method_65096(class_2398.field_11251, pos.method_10263() + 0.5, pos.method_10264() + 0.3, pos.method_10260() + 0.5, 6, 0.2, 0.1, 0.2, 0.01);
                    } else if (age > 0 && r.method_43057() < 0.6f) level.method_8652(pos, crop.method_9828(age - 1), 2);   // almost no growth
                }
                case SUMMER -> {
                    class_2680 soil = level.method_8320(pos.method_10074());
                    boolean dry = soil.method_28498(class_2344.field_11009) && soil.method_11654(class_2344.field_11009) == 0;
                    float heat = level.method_23753(pos).comp_349().method_8712() > 1.5f ? 2f : 1f;
                    if (dry && !sheltered && r.method_43057() < 0.08f * heat) {   // dries out
                        level.method_8652(pos, class_2246.field_10124.method_9564(), 3);
                        level.method_65096(class_2398.field_23956, pos.method_10263() + 0.5, pos.method_10264() + 0.3, pos.method_10260() + 0.5, 8, 0.2, 0.1, 0.2, 0.01);
                    }
                }
                case AUTUMN -> { if (!crop.method_9825(st) && r.method_43057() < 0.3f) level.method_8652(pos, crop.method_9828(age + 1), 2); }
                case SPRING -> { if (!crop.method_9825(st) && r.method_43057() < 0.15f) level.method_8652(pos, crop.method_9828(age + 1), 2); }
            }
            float boost = SeasonEvents.cropBoost();
            st = level.method_8320(pos);
            if (boost > 0 && st.method_26204() instanceof class_2302 c2 && !c2.method_9825(st) && r.method_43057() < boost) level.method_8652(pos, c2.method_9828(c2.method_9829(st) + 1), 2);
        }
    }

    // ------------------------------------------------------------------ temperature

    public static boolean heatBlock(class_2680 b) {
        if (b.method_27852(class_2246.field_10036) || b.method_27852(class_2246.field_22089) || b.method_27852(class_2246.field_10164) || b.method_27852(class_2246.field_10092)) return true;
        if ((b.method_26204() instanceof class_3922 || b.method_26204() instanceof class_2363) && b.method_28498(class_2741.field_12548)) return b.method_11654(class_2741.field_12548);
        return b.method_26204() instanceof com.kiyamet.defense.GeneratorBlock && b.method_11654(class_2741.field_12548);
    }

    public static boolean warmNear(class_3218 level, class_2338 c, int r) {
        for (class_2338 q : class_2338.method_10097(c.method_10069(-r, -2, -r), c.method_10069(r, 2, r))) if (heatBlock(level.method_8320(q))) return true;
        return false;
    }

    static boolean coldNear(class_3218 level, class_2338 c) {
        for (class_2338 q : class_2338.method_10097(c.method_10069(-2, -1, -2), c.method_10069(2, 1, 2))) {
            class_2680 b = level.method_8320(q);
            if (b.method_27852(class_2246.field_10295) || b.method_27852(class_2246.field_10225) || b.method_27852(class_2246.field_10384)) return true;
        }
        return false;
    }

    /** The air temperature where the player stands, in °C. */
    public static float ambient(class_3218 level, class_3222 p, Season s) {
        class_2338 pos = p.method_24515();
        float t = level.method_27983() == class_1937.field_25180 ? 45 : level.method_27983() == class_1937.field_25181 ? 5 : s.base + SeasonEvents.tempShift();
        if (level.method_27983() == class_1937.field_25179) {
            float biome = level.method_23753(pos).comp_349().method_8712();
            t += (biome - 0.8f) * 18;
            long tod = level.method_8532() % 24000;
            boolean day = tod < 12500 || tod > 23500;
            t += day ? (tod > 4000 && tod < 9000 ? 6 : 3) : -7;
            if (pos.method_10264() > 95) t -= (pos.method_10264() - 95) / 8f;
            if (level.method_8419()) t -= s == Season.WINTER ? 5 : 3;
            boolean sky = level.method_8311(pos.method_10084());
            if (!sky) t = t + (17 - t) * 0.5f;                 // indoors / underground evens things out
            else if (day && s == Season.SUMMER) t += 4;        // direct summer sun
        }
        if (p.method_5799()) t -= 9;
        if (warmNear(level, pos, 4)) t += s == Season.SUMMER ? 6 : 16;
        if (coldNear(level, pos)) t -= 10;
        // clothes: leather keeps you warm, metal cooks you in summer
        int leather = 0, metal = 0;
        for (class_1304 es : new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166}) {
            class_1799 a = p.method_6118(es);
            if (a.method_31574(class_1802.field_8267) || a.method_31574(class_1802.field_8577) || a.method_31574(class_1802.field_8570) || a.method_31574(class_1802.field_8370)) leather++;
            else if (!a.method_7960()) metal++;
        }
        float fur = com.kiyamet.farm.Fur.warmth(p) + com.kiyamet.wild.WildAnimal.petWarmth(p);
        if (t < 15) t += leather * 3.5f + metal * 1f + fur;
        else if (t > 24) t += leather * 1.5f + metal * 1.2f + com.kiyamet.farm.Fur.pieces(p) * 2.5f;   // fur in summer = sweating
        else t += fur * 0.3f;
        if (p.method_5854() instanceof com.kiyamet.vehicle.VehicleEntity v && v.kind != com.kiyamet.vehicle.VehicleKind.ATV && v.kind != com.kiyamet.vehicle.VehicleKind.MOTORCYCLE)
            t = t + (20 - t) * 0.4f;                           // cars have heaters and shade
        return t;
    }

    private static void temperature(class_3218 level, class_3222 p, Season s) {
        float body = p.getAttachedOrElse(BODY, 20f);
        float amb = ambient(level, p, s);
        if (p.method_68878()) amb = 20;
        body += (amb - body) * 0.08f;
        p.setAttached(BODY, body);
        int state = state(body);
        class_5819 r = level.field_9229;
        switch (state) {
            case -3 -> {   // freezing
                p.method_32317(Math.min(p.method_32315() + 20, p.method_32312() + 60));
                p.method_6092(new class_1293(class_1294.field_5909, 40, 1, true, false, true));
                p.method_6092(new class_1293(class_1294.field_5901, 40, 0, true, false, true));
                p.method_7322(0.6f);
            }
            case -2 -> {   // cold
                p.method_32317(Math.min(p.method_32315() - 10, p.method_32312() + 30));
                p.method_6092(new class_1293(class_1294.field_5909, 40, 0, true, false, true));
                p.method_7322(0.3f);
            }
            case 2 -> p.method_7322(0.25f);   // warm: thirsty work
            case 3 -> {    // hot
                p.method_6092(new class_1293(class_1294.field_5903, 60, 0, true, false, true));
                p.method_6092(new class_1293(class_1294.field_5911, 60, 0, true, false, true));
            }
            case 4 -> {    // heatstroke
                p.method_6092(new class_1293(class_1294.field_5903, 60, 1, true, false, true));
                p.method_6092(new class_1293(class_1294.field_5916, 160, 0, true, false, true));
                if (r.method_43048(5) == 0) p.method_6092(new class_1293(class_1294.field_5899, 50, 0, true, false, true));
                if (body >= 48 && level.method_8311(p.method_24515().method_10084()) && level.method_8530() && r.method_43048(4) == 0) p.method_5639(2);
            }
            default -> {}
        }
        // chat report: when the temperature moves 3 °C or the state changes (at most every 15 s)
        int[] last = SHOWN.computeIfAbsent(p.method_5667(), k -> new int[]{Integer.MIN_VALUE, 99, 0});
        int shown = Math.round(body);
        int now = p.method_51469().method_8503().method_3780();
        if ((state != last[1] || Math.abs(shown - last[0]) >= 3) && now - last[2] >= 300) {
            last[0] = shown; last[1] = state; last[2] = now;
            p.method_64398(tempText(body));
        }
    }

    public static int state(float t) {
        if (t < -2) return -3;
        if (t < 5) return -2;
        if (t < 30) return t < 10 ? -1 : 0;
        if (t < 38) return 2;
        if (t < 44) return 3;
        return 4;
    }

    public static class_124 color(float t) {
        if (t < -2) return class_124.field_1058;     // navy
        if (t < 3) return class_124.field_1078;
        if (t < 8) return class_124.field_1068;
        if (t < 14) return class_124.field_1075;          // light blue
        if (t < 26) return class_124.field_1060;
        if (t < 32) return class_124.field_1054;
        if (t < 40) return class_124.field_1065;          // orange
        if (t < 46) return class_124.field_1061;
        return class_124.field_1079;
    }

    public static class_2561 tempText(float t) {
        String label = switch (state(t)) {
            case -3 -> "Freezing! Find fire or shelter"; case -2 -> "Cold"; case -1 -> "Chilly"; case 2 -> "Warm"; case 3 -> "Hot - get into the shade";
            case 4 -> "Heatstroke! Water, shade, now"; default -> "Comfortable";
        };
        return class_2561.method_43470("🌡 " + Math.round(t) + "°C  ").method_27695(color(t), class_124.field_1067)
                .method_10852(class_2561.method_43470(label).method_27692(color(t)));
    }

    private Seasons() {}
}
