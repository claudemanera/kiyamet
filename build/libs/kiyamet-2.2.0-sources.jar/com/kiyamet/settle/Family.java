package com.kiyamet.settle;

import com.kiyamet.npc.Faction;
import com.kiyamet.npc.HumanEntity;
import com.kiyamet.npc.Role;
import com.kiyamet.season.Calendar;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.EntitySleepEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_2170;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_5134;

/**
 * 1.9 family. A companion with high morale can become your partner. Sleep near your partner and one night she may
 * get pregnant; nine months later (calendar) your child is born. Children grow up with the calendar:
 * baby (first month) → toddler → child → teenager → adult (one year). Babies and children don't fight;
 * teenagers start to; adults are full companions.
 */
public final class Family {
    public static final int PREGNANCY_DAYS = 270;
    public enum Stage { BABY(0, 0.35f, "Baby"), TODDLER(30, 0.45f, "Toddler"), CHILD(120, 0.6f, "Child"), TEEN(240, 0.82f, "Teenager"), ADULT(365, 1f, "Adult");
        public final int from; public final float scale; public final String title;
        Stage(int from, float scale, String title) { this.from = from; this.scale = scale; this.title = title; }
        public static Stage of(long ageDays) { Stage s = BABY; for (Stage t : values()) if (ageDays >= t.from) s = t; return s; }
    }

    public static Stage stage(class_3218 l, HumanEntity h) { return h.bornDay < 0 ? Stage.ADULT : Stage.of(Calendar.dayIndex(l) - h.bornDay); }

    public static boolean canPartner(HumanEntity h) { return h.appearance().female() && h.bornDay < 0 && !h.partner; }

    public static void propose(class_3222 p, HumanEntity h) {
        class_3218 l = (class_3218) p.method_51469();
        if (h.partner) {
            long due = h.pregnantDay >= 0 ? PREGNANCY_DAYS - (Calendar.dayIndex(l) - h.pregnantDay) : -1;
            p.method_7353(class_2561.method_43470(h.pregnantDay >= 0 ? h.method_5477().getString() + " is expecting - " + Math.max(0, due) + " days to go."
                    : "You're together. Sleep in a bed near " + h.method_5477().getString() + " at night.").method_27692(class_124.field_1076), true);
            return;
        }
        if (!canPartner(h)) { p.method_7353(class_2561.method_43470("That's not possible.").method_27692(class_124.field_1080), true); return; }
        boolean taken = !l.method_8390(HumanEntity.class, p.method_5829().method_1014(256), o -> o.partner && o.isOwnedBy(p)).isEmpty();
        if (taken) { p.method_7353(class_2561.method_43470("You already have a partner.").method_27692(class_124.field_1061), true); return; }
        if (h.morale < 60) { p.method_64398(class_2561.method_43470(h.method_5477().getString() + ": \"Not now... I need to feel safe first.\" (morale 60+)").method_27692(class_124.field_1080)); return; }
        h.partner = true;
        l.method_65096(class_2398.field_11201, h.method_23317(), h.method_23318() + 2, h.method_23321(), 8, 0.4, 0.3, 0.4, 0);
        l.method_8396(null, h.method_24515(), class_3417.field_14725.comp_349(), class_3419.field_15254, 1f, 1.2f);
        p.method_64398(class_2561.method_43470("♥ " + h.method_5477().getString() + " is your partner now.").method_27695(class_124.field_1076, class_124.field_1067));
    }

    public static void init() {
        EntitySleepEvents.STOP_SLEEPING.register((e, pos) -> {
            if (!(e instanceof class_3222 p) || !(p.method_51469() instanceof class_3218 l) || l.method_23886()) return;
            for (HumanEntity h : l.method_8390(HumanEntity.class, p.method_5829().method_1014(12), o -> o.partner && o.isOwnedBy(p) && o.pregnantDay < 0))
                if (l.field_9229.method_43057() < 0.35f) {
                    h.pregnantDay = Calendar.dayIndex(l);
                    p.method_64398(class_2561.method_43470("♥ " + h.method_5477().getString() + " has news: you're going to be a parent! (due in 9 months)").method_27695(class_124.field_1076, class_124.field_1067));
                }
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.method_3780() % 100 == 0)
                for (class_3222 p : server.method_3760().method_14571())
                    if (p.getAttachedOrElse(CARRIED, 0) > 0 && p.method_51469().method_8390(HumanEntity.class, p.method_5829().method_1014(4), o -> o.method_5752().contains(CARRY_TAG) && o.isOwnedBy(p)).isEmpty())
                        p.setAttached(CARRIED, 0);
            if (server.method_3780() % 200 != 0) return;
            for (class_3218 l : server.method_3738())
                for (HumanEntity h : l.method_18198(net.minecraft.class_5575.method_31795(HumanEntity.class), o -> o.pregnantDay >= 0))
                    if (Calendar.dayIndex(l) - h.pregnantDay >= PREGNANCY_DAYS) birth(l, h);
        });
        CommandRegistrationCallback.EVENT.register((d, ctx, env) -> d.register(class_2170.method_9247("twd").then(class_2170.method_9247("family")
                .executes(c -> { status(c.getSource().method_9207()); return 1; })
                .then(class_2170.method_9247("birth").executes(c -> {          // creative testing: skip the nine months
                    class_3222 p = c.getSource().method_9207();
                    if (!p.method_68878()) return 0;
                    for (HumanEntity h : p.method_51469().method_8390(HumanEntity.class, p.method_5829().method_1014(32), o -> o.partner && o.isOwnedBy(p))) { h.pregnantDay = Calendar.dayIndex(p.method_51469()) - PREGNANCY_DAYS; }
                    return 1;
                })))));
    }

    static void status(class_3222 p) {
        class_3218 l = (class_3218) p.method_51469();
        var fam = l.method_8390(HumanEntity.class, p.method_5829().method_1014(512), o -> o.isOwnedBy(p) && (o.partner || o.bornDay >= 0));
        if (fam.isEmpty()) { p.method_64398(class_2561.method_43470("No family yet. A companion with high morale might become your partner (companion panel).").method_27692(class_124.field_1080)); return; }
        for (HumanEntity h : fam) {
            if (h.partner) p.method_64398(class_2561.method_43470("♥ Partner: " + h.method_5477().getString() + (h.pregnantDay >= 0 ? " - expecting, " + Math.max(0, PREGNANCY_DAYS - (Calendar.dayIndex(l) - h.pregnantDay)) + " days to go" : "")).method_27692(class_124.field_1076));
            else p.method_64398(class_2561.method_43470("★ " + h.method_5477().getString() + " - " + stage(l, h).title + ", " + (Calendar.dayIndex(l) - h.bornDay) + " days old").method_27692(class_124.field_1075));
        }
    }

    static void birth(class_3218 l, HumanEntity mother) {
        mother.pregnantDay = -1;
        class_3222 owner = mother.ownerPlayer();
        HumanEntity baby = com.kiyamet.npc.ModHumans.HUMAN.method_5883(l, class_3730.field_16466);
        if (baby == null) return;
        baby.setup(Faction.COMPANION, Role.MEMBER, 1, null);
        baby.method_5808(mother.method_23317(), mother.method_23318(), mother.method_23321(), mother.method_36454(), 0);
        baby.bornDay = Calendar.dayIndex(l);
        baby.method_5673(class_1304.field_6173, class_1799.field_8037);
        l.method_8649(baby);
        if (owner != null) {
            com.kiyamet.skill.SkillManager.addXp(owner, com.kiyamet.skill.Skill.SURVIVAL, 1500);
            baby.setOwner(owner);
            baby.setOrder(HumanEntity.Order.STAY);
            owner.method_64398(class_2561.method_43470("★ " + mother.method_5477().getString() + " gave birth! Say hello to " + baby.method_5477().getString() + ".").method_27695(class_124.field_1065, class_124.field_1067));
        }
        l.method_65096(class_2398.field_11201, mother.method_23317(), mother.method_23318() + 1.5, mother.method_23321(), 12, 0.5, 0.5, 0.5, 0);
        l.method_8396(null, mother.method_24515(), class_3417.field_14709, class_3419.field_15254, 1f, 1.4f);
        grow(l, baby);
    }

    /** 2.2: babies ride with their parent, wrapped in white, beside the backpack. Synced so every client can draw the bundle. */
    public static final net.fabricmc.fabric.api.attachment.v1.AttachmentType<Integer> CARRIED = net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry.create(
            com.kiyamet.Kiyamet.id("carried_baby"), b -> b.initializer(() -> 0).persistent(com.mojang.serialization.Codec.INT)
                    .syncWith(net.minecraft.class_9135.field_48550, net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate.all()));
    public static final String CARRY_TAG = "carried_baby";

    static void carry(HumanEntity h, class_3222 o) {
        if (!h.method_5752().contains(CARRY_TAG)) {
            h.method_5780(CARRY_TAG);
            o.method_64398(class_2561.method_43470("★ " + h.method_5477().getString() + " is wrapped up and rides with you, beside your backpack.").method_27692(class_124.field_1075));
        }
        h.method_5648(true); h.method_5684(true); h.method_5977(true); h.method_5875(true); h.method_5803(true);
        h.method_5942().method_6340();
        if (o.getAttachedOrElse(CARRIED, 0) == 0) o.setAttached(CARRIED, 1);
    }

    static void release(class_3218 l, HumanEntity h, String why) {
        if (!h.method_5752().contains(CARRY_TAG)) return;
        h.method_5738(CARRY_TAG);
        h.method_5648(false); h.method_5684(false); h.method_5977(false); h.method_5875(false); h.method_5803(false);
        if (h.ownerPlayer() instanceof class_3222 o) {
            o.setAttached(CARRIED, 0);
            if (why != null) o.method_64398(class_2561.method_43470("★ " + h.method_5477().getString() + " " + why).method_27692(class_124.field_1075));
        }
    }

    /** every tick while carried: stay right with the parent */
    public static void follow(class_3218 l, HumanEntity h) {
        class_3222 o = h.ownerPlayer();
        if (o == null || o.method_51469() != l || !o.method_5805()) { release(l, h, null); return; }
        h.method_5808(o.method_23317(), o.method_23318(), o.method_23321(), o.method_36454(), 0);
        h.method_18799(net.minecraft.class_243.field_1353);
        h.field_6017 = 0;
    }

    /** called every 2 seconds for children */
    public static void grow(class_3218 l, HumanEntity h) {
        Stage s = stage(l, h);
        var scale = h.method_5996(class_5134.field_47760);
        if (scale != null && scale.method_6201() != s.scale) {
            boolean first = scale.method_6201() != 1.0 || s != Stage.BABY;
            scale.method_6192(s.scale);
            if (first && h.ownerPlayer() instanceof class_3222 o && s != Stage.BABY)
                o.method_64398(class_2561.method_43470("★ " + h.method_5477().getString() + " is a " + s.title.toLowerCase() + " now!").method_27692(class_124.field_1075));
            if (s == Stage.ADULT) { h.bornDay = -1; h.applyStats(true); }
        }
        if (s.ordinal() <= Stage.CHILD.ordinal()) {
            h.method_5980(null);
            if (!h.method_6047().method_7960()) h.method_5673(class_1304.field_6173, class_1799.field_8037);
            if (s == Stage.BABY && h.order() != HumanEntity.Order.STAY) h.setOrder(HumanEntity.Order.STAY);
        }
        if (s == Stage.BABY && h.ownerPlayer() instanceof class_3222 o && o.method_51469() == l && o.method_5805()) carry(h, o);
        else if (s != Stage.BABY) release(l, h, "has grown - time to walk on their own!");
    }

    private Family() {}
}
