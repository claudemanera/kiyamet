package com.kiyamet.settle;

import com.kiyamet.Kiyamet;
import com.kiyamet.npc.HumanEntity;
import com.kiyamet.registry.ModItems;
import com.kiyamet.ui.PanelMenu;
import com.kiyamet.ui.Ui;
import java.util.*;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1263;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_747;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9334;

/**
 * 1.9 your own settlement. Place a Settlement Bell, then open a companion's panel and choose "Settle here".
 * Settlers live around the bell and work every minute: farmers harvest and replant, smiths turn iron into plates and
 * ammo, doctors heal, guards watch for walkers, cooks cook raw food. Everything goes into (and comes out of) the chests
 * within 12 blocks of the bell. Every morning each settler eats one food from those chests and needs a bed nearby -
 * fed and rested settlers stay happy, hungry or bedless ones lose morale (and a broken settler may leave... or worse).
 */
public final class Settlement {
    public static final String[] JOBS = {"FARMER", "SMITH", "DOCTOR", "GUARD", "COOK"};
    public static final class_1792[] JOB_ICONS = {class_1802.field_8609, class_1802.field_8782, class_1802.field_8463, class_1802.field_8255, class_1802.field_16309};
    public static final String[] JOB_DESC = {"Harvests ripe crops near the bell and replants them", "Turns iron into metal plates and makes ammo",
            "Heals you and the settlers, makes bandages", "Watches the walls, marks walkers that come close", "Cooks raw meat and fish from the chests"};
    public static final int RADIUS = 24, CHEST_RANGE = 12;
    public static class_2248 BELL;
    static final Map<UUID, Map<String, Integer>> MADE = new HashMap<>();

    public static class BellBlock extends class_2248 {
        static final class_265 SHAPE = class_2248.method_9541(4, 0, 4, 12, 16, 12);
        public BellBlock(class_2251 p) { super(p); }
        @Override protected class_265 method_9530(class_2680 s, class_1922 l, class_2338 p, class_3726 c) { return SHAPE; }
        @Override
        protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
            if (player instanceof class_3222 sp) {
                level.method_8396(null, pos, class_3417.field_17265, class_3419.field_15245, 1f, 1f);
                Panel.open(sp, pos.method_10062());
            }
            return class_1269.field_5812;
        }
    }

    public static void init() {
        class_5321<class_2248> key = class_5321.method_29179(class_7924.field_41254, Kiyamet.id("settlement_bell"));
        BELL = class_2378.method_39197(class_7923.field_41175, key, new BellBlock(class_4970.class_2251.method_9630(class_2246.field_16332).method_22488().method_63500(key)));
        ModItems.custom("settlement_bell", ip -> new class_1747(BELL, ip.method_63685()));
        // the morning: food and beds
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            class_3218 ow = server.method_30002();
            if (ow.method_8532() % 24000 != 1000) return;
            Map<UUID, List<HumanEntity>> byOwner = new HashMap<>();
            for (class_3218 l : server.method_3738())
                for (HumanEntity h : l.method_18198(net.minecraft.class_5575.method_31795(HumanEntity.class), h -> !h.work.isEmpty() && h.settleAt != null && h.ownerPlayer() != null))
                    byOwner.computeIfAbsent(h.ownerPlayer().method_5667(), k -> new ArrayList<>()).add(h);
            byOwner.forEach((id, list) -> morning(server.method_3760().method_14602(id), list));
        });
    }

    public static List<class_1263> chests(class_3218 l, class_2338 bell) {
        List<class_1263> out = new ArrayList<>();
        for (class_2338 p : class_2338.method_10097(bell.method_10069(-CHEST_RANGE, -4, -CHEST_RANGE), bell.method_10069(CHEST_RANGE, 4, CHEST_RANGE))) {
            class_2586 be = l.method_8321(p);
            if (be instanceof class_1263 c && !(be instanceof net.minecraft.class_2609) && c.method_5439() >= 9) out.add(c);
        }
        return out;
    }

    static boolean store(List<class_1263> cs, class_1799 s) {
        for (class_1263 c : cs) {
            for (int i = 0; i < c.method_5439() && !s.method_7960(); i++) {
                class_1799 in = c.method_5438(i);
                if (in.method_7960()) { c.method_5447(i, s.method_7972()); s.method_7939(0); }
                else if (class_1799.method_31577(in, s) && in.method_7947() < in.method_7914()) { int m = Math.min(s.method_7947(), in.method_7914() - in.method_7947()); in.method_7933(m); s.method_7934(m); }
            }
            c.method_5431();
            if (s.method_7960()) return true;
        }
        return s.method_7960();
    }

    static class_1799 takeOne(List<class_1263> cs, java.util.function.Predicate<class_1799> what) {
        for (class_1263 c : cs) for (int i = 0; i < c.method_5439(); i++) {
            class_1799 in = c.method_5438(i);
            if (!in.method_7960() && what.test(in)) { class_1799 one = in.method_7971(1); c.method_5431(); return one; }
        }
        return class_1799.field_8037;
    }

    static int count(List<class_1263> cs, java.util.function.Predicate<class_1799> what) {
        int n = 0;
        for (class_1263 c : cs) for (int i = 0; i < c.method_5439(); i++) { class_1799 in = c.method_5438(i); if (!in.method_7960() && what.test(in)) n += in.method_7947(); }
        return n;
    }

    static boolean isFood(class_1799 s) { return s.method_57826(class_9334.field_50075) && !s.method_31574(class_1802.field_8511) && !s.method_31574(class_1802.field_8680) && !s.method_31574(class_1802.field_8635); }

    public static int beds(class_3218 l, class_2338 bell) {
        int n = 0;
        for (class_2338 p : class_2338.method_10097(bell.method_10069(-RADIUS, -6, -RADIUS), bell.method_10069(RADIUS, 6, RADIUS))) {
            class_2680 s = l.method_8320(p);
            if (s.method_26204() instanceof com.kiyamet.furniture.FurnitureBed) n++;
            else if (s.method_26204() instanceof class_2244 && s.method_28498(class_2244.field_9967) && s.method_11654(class_2244.field_9967) == net.minecraft.class_2742.field_12560) n++;
        }
        return n;
    }

    static void made(HumanEntity h, String what, int n) {
        if (h.ownerPlayer() == null || n <= 0) return;
        if (h.ownerPlayer() instanceof class_3222 o) com.kiyamet.skill.SkillManager.addXp(o, switch (h.work) { case "FARMER" -> com.kiyamet.skill.Skill.FARMING; case "SMITH" -> com.kiyamet.skill.Skill.ENGINEERING; case "DOCTOR" -> com.kiyamet.skill.Skill.MEDICINE; case "COOK" -> com.kiyamet.skill.Skill.SURVIVAL; default -> com.kiyamet.skill.Skill.DEFENSE; }, 2 * n);
        MADE.computeIfAbsent(h.ownerPlayer().method_5667(), k -> new LinkedHashMap<>()).merge(what, n, Integer::sum);
    }

    static class_1792 cooked(class_1792 raw) {
        String id = class_7923.field_41178.method_10221(raw).toString();
        String c = switch (id) {
            case "minecraft:beef" -> "minecraft:cooked_beef"; case "minecraft:porkchop" -> "minecraft:cooked_porkchop"; case "minecraft:chicken" -> "minecraft:cooked_chicken";
            case "minecraft:mutton" -> "minecraft:cooked_mutton"; case "minecraft:rabbit" -> "minecraft:cooked_rabbit"; case "minecraft:cod" -> "minecraft:cooked_cod";
            case "minecraft:salmon" -> "minecraft:cooked_salmon"; case "minecraft:potato" -> "minecraft:baked_potato";
            default -> id.startsWith("kiyamet:") && !id.contains("cooked") && class_7923.field_41178.method_10250(net.minecraft.class_2960.method_60654("kiyamet:cooked_" + id.substring(8))) ? "kiyamet:cooked_" + id.substring(8) : null;
        };
        return c == null ? null : Ui.item(c);
    }

    /** one minute of work */
    public static void work(class_3218 l, HumanEntity h) {
        if (h.work.isEmpty() || h.settleAt == null || !l.method_8477(h.settleAt) || !(l.method_8320(h.settleAt).method_26204() instanceof BellBlock)) return;
        if (h.morale < 25 && h.method_59922().method_43056()) return;           // unhappy settlers slack off
        List<class_1263> cs = chests(l, h.settleAt);
        switch (h.work) {
            case "FARMER" -> {
                int n = 0;
                for (class_2338 p : class_2338.method_10097(h.settleAt.method_10069(-RADIUS, -4, -RADIUS), h.settleAt.method_10069(RADIUS, 4, RADIUS))) {
                    if (n >= 8) break;
                    class_2680 s = l.method_8320(p);
                    if (s.method_26204() instanceof class_2302 crop && crop.method_9825(s)) {
                        for (class_1799 d : class_2248.method_9562(s, l, p, null)) if (!store(cs, d)) class_2248.method_9577(l, h.settleAt.method_10084(), d);
                        l.method_8652(p, crop.method_9828(0), 2);
                        l.method_65096(class_2398.field_11211, p.method_10263() + 0.5, p.method_10264() + 0.5, p.method_10260() + 0.5, 3, 0.3, 0.3, 0.3, 0);
                        n++;
                    }
                }
                made(h, "crops harvested", n);
            }
            case "SMITH" -> {
                class_1799 iron = takeOne(cs, s -> s.method_31574(class_1802.field_8620));
                if (!iron.method_7960()) { store(cs, h.method_59922().method_43056() ? new class_1799(Ui.item("kiyamet:metal_plate")) : new class_1799(Ui.item("kiyamet:pistol_ammo"), 12)); made(h, "smithing jobs", 1); }
                else if (h.method_59922().method_43048(3) == 0) { store(cs, new class_1799(Ui.item("kiyamet:pistol_ammo"), 3)); made(h, "rounds of scrap ammo", 3); }
                l.method_8396(null, h.method_24515(), class_3417.field_14559, class_3419.field_15254, 0.4f, 1.2f);
            }
            case "DOCTOR" -> {
                int healed = 0;
                for (class_1309 e : l.method_8390(class_1309.class, h.method_5829().method_1014(RADIUS), e -> (e instanceof class_1657 || e instanceof HumanEntity o && o.ownerPlayer() == h.ownerPlayer()) && e.method_6032() < e.method_6063())) {
                    e.method_6025(6); e.method_6092(new class_1293(class_1294.field_5924, 200, 0)); healed++;
                }
                made(h, "patients treated", healed);
                if (h.method_59922().method_43048(4) == 0) { store(cs, new class_1799(Ui.item("kiyamet:bandage"))); made(h, "bandages", 1); }
            }
            case "GUARD" -> {
                int seen = 0;
                for (class_1309 e : l.method_8390(class_1309.class, h.method_5829().method_1014(RADIUS + 16), e -> e instanceof class_1569 && e.method_5805())) { e.method_6092(new class_1293(class_1294.field_5912, 1200, 0, false, false)); seen++; }
                if (seen > 0 && h.ownerPlayer() instanceof class_3222 o && o.method_24515().method_19771(h.settleAt, 64))
                    o.method_7353(class_2561.method_43470("Guard " + h.method_5477().getString() + ": " + seen + " walker" + (seen > 1 ? "s" : "") + " near the settlement!").method_27692(class_124.field_1065), true);
            }
            case "COOK" -> {
                int n = 0;
                for (int i = 0; i < 6; i++) {
                    class_1799 raw = takeOne(cs, s -> cooked(s.method_7909()) != null);
                    if (raw.method_7960()) break;
                    store(cs, new class_1799(cooked(raw.method_7909()))); n++;
                }
                if (n > 0) l.method_65096(class_2398.field_17430, h.method_23317(), h.method_23318() + 2, h.method_23321(), 2, 0.1, 0.1, 0.1, 0.01);
                made(h, "meals cooked", n);
            }
            default -> {}
        }
    }

    static void morning(class_3222 owner, List<HumanEntity> settlers) {
        if (settlers.isEmpty()) return;
        class_3218 l = (class_3218) settlers.get(0).method_73183();
        class_2338 bell = settlers.get(0).settleAt;
        List<class_1263> cs = chests(l, bell);
        int beds = beds(l, bell), fed = 0;
        for (HumanEntity h : settlers) {
            class_1799 f = takeOne(cs, Settlement::isFood);
            if (!f.method_7960()) { fed++; h.morale = Math.min(100, h.morale + 6); h.method_6025(4); }
            else h.morale = Math.max(0, h.morale - 15);
        }
        if (beds < settlers.size()) for (HumanEntity h : settlers) h.morale = Math.max(0, h.morale - 8);
        else for (HumanEntity h : settlers) h.morale = Math.min(100, h.morale + 3);
        if (owner == null) return;
        float avg = 0; for (HumanEntity h : settlers) avg += h.morale; avg /= settlers.size();
        owner.method_64398(class_2561.method_43470("🏘 Settlement report: " + settlers.size() + " settlers · fed " + fed + "/" + settlers.size() + " · beds " + beds + "/" + settlers.size()
                + " · morale " + Math.round(avg) + " · food left " + count(cs, Settlement::isFood)).method_27692(class_124.field_1060));
        Map<String, Integer> m = MADE.remove(owner.method_5667());
        if (m != null && !m.isEmpty()) {
            StringBuilder b = new StringBuilder("   Yesterday: ");
            m.forEach((k, v) -> b.append(v).append(' ').append(k).append(", "));
            owner.method_64398(class_2561.method_43470(b.substring(0, b.length() - 2)).method_27692(class_124.field_1080));
        }
        if (fed < settlers.size()) owner.method_64398(class_2561.method_43470("   Not enough food in the settlement chests!").method_27692(class_124.field_1061));
        if (beds < settlers.size()) owner.method_64398(class_2561.method_43470("   Your people need more beds.").method_27692(class_124.field_1061));
    }

    /** Companion panel button: settle at the nearest bell, or leave the settlement */
    public static void toggle(class_3222 p, HumanEntity h) {
        if (!h.work.isEmpty()) {
            h.work = ""; h.settleAt = null; h.setOrder(HumanEntity.Order.FOLLOW);
            p.method_7353(class_2561.method_43470(h.method_5477().getString() + " left the settlement and follows you again.").method_27692(class_124.field_1054), true);
            return;
        }
        class_2338 bell = null; double best = 1e9;
        for (class_2338 q : class_2338.method_10097(h.method_24515().method_10069(-48, -12, -48), h.method_24515().method_10069(48, 12, 48)))
            if (h.method_73183().method_8320(q).method_26204() instanceof BellBlock) { double d = q.method_10262(h.method_24515()); if (d < best) { best = d; bell = q.method_10062(); } }
        if (bell == null) { p.method_7353(class_2561.method_43470("No Settlement Bell within 48 blocks. Build one at the Main Table.").method_27692(class_124.field_1061), true); return; }
        h.settleAt = bell; h.work = "FARMER";
        h.setHome(bell); h.setOrder(HumanEntity.Order.GUARD); h.setHome(bell);
        p.method_64398(class_2561.method_43470(h.method_5477().getString() + " settled at your settlement as a Farmer. Change their job at the bell.").method_27692(class_124.field_1060));
    }

    /** the bell panel: overview + every settler; click a settler to change their job */
    public static class Panel extends PanelMenu {
        final class_2338 bell;
        List<HumanEntity> people = List.of();
        static void open(class_3222 p, class_2338 bell) { p.method_17355(new class_747((id, inv, pl) -> new Panel(id, inv, p, bell), class_2561.method_43470("Settlement"))); }
        Panel(int id, class_1661 inv, class_3222 p, class_2338 bell) { super(id, inv, p); this.bell = bell; redraw(); }

        @Override
        protected void draw() {
            class_3218 l = (class_3218) player.method_51469();
            people = l.method_8390(HumanEntity.class, new net.minecraft.class_238(bell).method_1014(96), h -> bell.equals(h.settleAt) && h.isOwnedBy(player));
            List<class_1263> cs = chests(l, bell);
            int beds = beds(l, bell), food = count(cs, Settlement::isFood);
            float avg = 0; for (HumanEntity h : people) avg += h.morale; if (!people.isEmpty()) avg /= people.size();
            c.method_5447(4, Ui.glint(Ui.icon(BELL.method_8389(), Ui.text("Your Settlement", class_124.field_1065, class_124.field_1067),
                    Ui.text("Settlers: " + people.size(), class_124.field_1068),
                    Ui.text("Beds: " + beds + (beds < people.size() ? "  (need " + (people.size() - beds) + " more!)" : ""), beds < people.size() ? class_124.field_1061 : class_124.field_1060),
                    Ui.text("Food in chests: " + food + (food < people.size() * 3 ? "  (running low)" : ""), food < people.size() * 3 ? class_124.field_1061 : class_124.field_1060),
                    Ui.text("Chests linked: " + cs.size() + " (within " + CHEST_RANGE + " blocks)", class_124.field_1080),
                    Ui.text("Morale: " + Math.round(avg) + "/100", avg >= 60 ? class_124.field_1060 : avg >= 35 ? class_124.field_1054 : class_124.field_1061),
                    Ui.text("Add settlers: companion panel → Settle here", class_124.field_1063)), true));
            for (int i = 0; i < people.size() && i < 36; i++) {
                HumanEntity h = people.get(i);
                int j = Math.max(0, Arrays.asList(JOBS).indexOf(h.work));
                c.method_5447(9 + i, Ui.icon(JOB_ICONS[j], Ui.text(h.method_5477().getString() + " - " + title(JOBS[j]), class_124.field_1075, class_124.field_1067),
                        Ui.text(JOB_DESC[j], class_124.field_1080), Ui.text("Morale " + Math.round(h.morale) + " · Health " + (int) h.method_6032(), class_124.field_1068),
                        Ui.text("Click: next job", class_124.field_1054)));
            }
            c.method_5447(49, Ui.icon(class_1802.field_8077, Ui.text("Close", class_124.field_1061)));
        }

        @Override
        protected boolean click(int slot, class_1713 type) {
            if (slot == 49) { player.method_7346(); return false; }
            int i = slot - 9;
            if (i < 0 || i >= people.size()) return false;
            HumanEntity h = people.get(i);
            int j = Math.max(0, Arrays.asList(JOBS).indexOf(h.work));
            h.work = JOBS[(j + 1) % JOBS.length];
            player.method_51469().method_8396(null, bell, class_3417.field_20680, class_3419.field_15245, 0.7f, 1f);
            return true;
        }
    }

    public static String title(String job) { return job.charAt(0) + job.substring(1).toLowerCase(); }

    private Settlement() {}
}
