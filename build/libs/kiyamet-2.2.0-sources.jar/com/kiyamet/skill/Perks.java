package com.kiyamet.skill;

import com.kiyamet.Kiyamet;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import java.util.ArrayList;
import java.util.List;

/**
 * Skill roads: every skill raises several attributes in small steps all the way to level 999
 * (e.g. Athletics: +0.05% move speed every 3 levels = +17% at 999). Each line has its own step size,
 * so you gain something almost every level. Bonuses are refreshed every 5 seconds.
 */
public final class Perks {
    /** One road line: grows by max/steps every {@code every} levels, reaching {@code max} at 999. */
    public record Perk(Skill skill, class_6880<class_1320> attribute, double max, int every, class_1322.class_1323 op, String label, boolean percent) {
        public int totalSteps() { return Skill.MAX_LEVEL / every; }
        public double perStep() { return max / totalSteps(); }
        public double value(int level) { return perStep() * Math.min(totalSteps(), Math.max(0, level) / every); }
        public int nextLevel(int level) { return level >= Skill.MAX_LEVEL ? -1 : Math.min(Skill.MAX_LEVEL, (level / every + 1) * every); }
        public String fmt(double v) {
            if (percent) return (v >= 0 ? "+" : "") + (Math.abs(v * 100) < 1 ? String.format("%.2f%%", v * 100) : String.format("%.1f%%", v * 100));
            return (v >= 0 ? "+" : "") + (Math.abs(v) < 1 ? String.format("%.2f", v) : String.format("%.1f", v));
        }
        public String describe(int level) { return label + " " + fmt(value(level)); }
        public String stepText() { return fmt(perStep()) + " every " + every + " lv"; }
    }

    private static final class_1322.class_1323 ADD = class_1322.class_1323.field_6328, PCT = class_1322.class_1323.field_6330;
    public static final List<Perk> ALL = new ArrayList<>();

    static {
        p(Skill.HEALTH, class_5134.field_23725, 2, 10, ADD, "Armor toughness", false);
        p(Skill.HEALTH, class_5134.field_45124, 4, 20, ADD, "Max absorption", false);
        p(Skill.HEALTH, class_5134.field_23718, 0.1, 10, ADD, "Knockback resistance", true);
        p(Skill.ATHLETICS, class_5134.field_23719, 0.17, 3, PCT, "Move speed", true);
        p(Skill.ATHLETICS, class_5134.field_23728, 0.10, 5, PCT, "Jump height", true);
        p(Skill.ATHLETICS, class_5134.field_51582, 0.4, 10, ADD, "Mud/soul sand speed", true);
        p(Skill.MINING, class_5134.field_49076, 0.60, 3, PCT, "Mining speed", true);
        p(Skill.MINING, class_5134.field_51581, 10, 10, ADD, "Tool efficiency", false);
        p(Skill.MINING, class_5134.field_51576, 1.0, 10, PCT, "Underwater mining", true);
        p(Skill.MINING, class_5134.field_47758, 1.0, 20, ADD, "Reach (blocks)", false);
        p(Skill.SWORDS, class_5134.field_23721, 6, 3, ADD, "Melee damage", false);
        p(Skill.SWORDS, class_5134.field_23723, 0.20, 5, PCT, "Attack speed", true);
        p(Skill.SWORDS, class_5134.field_51577, 0.5, 10, ADD, "Sweep damage", true);
        p(Skill.SWORDS, class_5134.field_47759, 0.75, 25, ADD, "Attack reach", false);
        p(Skill.ARCHERY, class_5134.field_23726, 2, 10, ADD, "Luck", false);
        p(Skill.ARCHERY, class_5134.field_23719, 0.03, 10, PCT, "Move speed", true);
        p(Skill.ARCHERY, class_5134.field_51584, 0.15, 20, ADD, "Sneak speed", true);
        p(Skill.DEFENSE, class_5134.field_23724, 10, 3, ADD, "Armor", false);
        p(Skill.DEFENSE, class_5134.field_23725, 6, 5, ADD, "Armor toughness", false);
        p(Skill.DEFENSE, class_5134.field_23718, 0.4, 10, ADD, "Knockback resistance", true);
        p(Skill.DEFENSE, class_5134.field_51580, 0.5, 20, ADD, "Blast knockback resistance", true);
        p(Skill.ACROBATICS, class_5134.field_49079, 12, 3, ADD, "Safe fall (blocks)", false);
        p(Skill.ACROBATICS, class_5134.field_23728, 0.25, 5, PCT, "Jump height", true);
        p(Skill.ACROBATICS, class_5134.field_49077, -0.5, 10, ADD, "Fall damage", true);
        p(Skill.ACROBATICS, class_5134.field_23719, 0.03, 10, PCT, "Move speed", true);
        p(Skill.SWIMMING, class_5134.field_51578, 1.0, 3, ADD, "Swim speed", true);
        p(Skill.SWIMMING, class_5134.field_51583, 12, 5, ADD, "Breath", false);
        p(Skill.SWIMMING, class_5134.field_51576, 0.5, 10, PCT, "Underwater mining", true);
        p(Skill.FARMING, class_5134.field_23726, 2, 5, ADD, "Luck", false);
        p(Skill.FARMING, class_5134.field_49076, 0.10, 10, PCT, "Harvest speed", true);
        p(Skill.FARMING, class_5134.field_23719, 0.02, 20, PCT, "Move speed", true);
        p(Skill.WOODCUTTING, class_5134.field_49076, 0.30, 3, PCT, "Chopping speed", true);
        p(Skill.WOODCUTTING, class_5134.field_23721, 2, 10, ADD, "Melee damage", false);
        p(Skill.WOODCUTTING, class_5134.field_47758, 0.5, 25, ADD, "Reach (blocks)", false);
        p(Skill.HUNTING, class_5134.field_23721, 3, 5, ADD, "Melee damage", false);
        p(Skill.HUNTING, class_5134.field_23719, 0.04, 10, PCT, "Move speed", true);
        p(Skill.HUNTING, class_5134.field_23726, 1, 20, ADD, "Luck", false);
        p(Skill.HUNTING, class_5134.field_51584, 0.2, 20, ADD, "Sneak speed", true);
        p(Skill.ENCHANTING, class_5134.field_23726, 4, 5, ADD, "Luck", false);
        p(Skill.ENCHANTING, class_5134.field_23725, 1, 25, ADD, "Armor toughness", false);
        p(Skill.ALCHEMY, class_5134.field_51579, -0.6, 5, PCT, "Burn time", true);
        p(Skill.ALCHEMY, class_5134.field_51583, 4, 20, ADD, "Breath", false);
        p(Skill.ALCHEMY, class_5134.field_45124, 4, 25, ADD, "Max absorption", false);
        p(Skill.EXPLORATION, class_5134.field_23719, 0.06, 5, PCT, "Move speed", true);
        p(Skill.EXPLORATION, class_5134.field_47761, 0.5, 10, ADD, "Step height", false);
        p(Skill.EXPLORATION, class_5134.field_49079, 3, 20, ADD, "Safe fall (blocks)", false);
        p(Skill.EXPLORATION, class_5134.field_23726, 1, 25, ADD, "Luck", false);
        p(Skill.ENGINEERING, class_5134.field_47758, 2.5, 5, ADD, "Reach (blocks)", false);
        p(Skill.ENGINEERING, class_5134.field_49076, 0.15, 10, PCT, "Mining speed", true);
        p(Skill.ENGINEERING, class_5134.field_23724, 2, 25, ADD, "Armor", false);
        p(Skill.SURVIVAL, class_5134.field_51579, -0.4, 5, PCT, "Burn time", true);
        p(Skill.SURVIVAL, class_5134.field_23718, 0.2, 10, ADD, "Knockback resistance", true);
        p(Skill.SURVIVAL, class_5134.field_51582, 0.5, 10, ADD, "Mud/soul sand speed", true);
        p(Skill.SURVIVAL, class_5134.field_23716, 4, 50, ADD, "Max health", false);
        p(Skill.STEALTH, class_5134.field_51584, 0.6, 3, ADD, "Sneak speed", true);
        p(Skill.STEALTH, class_5134.field_23719, 0.03, 10, PCT, "Move speed", true);
        p(Skill.STEALTH, class_5134.field_49079, 4, 20, ADD, "Safe fall (blocks)", false);
        p(Skill.MEDICINE, class_5134.field_23725, 3, 10, ADD, "Armor toughness", false);
        p(Skill.MEDICINE, class_5134.field_45124, 6, 20, ADD, "Max absorption", false);
        p(Skill.MEDICINE, class_5134.field_23716, 4, 50, ADD, "Max health", false);
        p(Skill.HEAVY_WEAPONS, class_5134.field_23721, 4, 5, ADD, "Melee damage", false);
        p(Skill.HEAVY_WEAPONS, class_5134.field_23722, 2, 5, ADD, "Knockback", false);
        p(Skill.HEAVY_WEAPONS, class_5134.field_23718, 0.2, 10, ADD, "Knockback resistance", true);
        p(Skill.BUILDING, class_5134.field_47758, 3, 3, ADD, "Reach (blocks)", false);
        p(Skill.BUILDING, class_5134.field_49076, 0.20, 5, PCT, "Breaking speed", true);
        p(Skill.BUILDING, class_5134.field_47759, 1, 10, ADD, "Attack reach", false);
        p(Skill.BUILDING, class_5134.field_49079, 6, 20, ADD, "Safe fall (blocks)", false);
    }

    private static void p(Skill s, class_6880<class_1320> a, double max, int every, class_1322.class_1323 op, String label, boolean pct) {
        ALL.add(new Perk(s, a, max, every, op, label, pct));
    }

    public static List<Perk> of(Skill s) { return ALL.stream().filter(x -> x.skill == s).toList(); }

    private static class_2960 id(Perk p) {
        return Kiyamet.id("perk/" + p.skill.name().toLowerCase() + "/" + p.attribute.method_40230().map(k -> k.method_29177().method_12832()).orElse("x"));
    }

    public static void apply(class_3222 p) {
        SkillData d = SkillManager.get(p);
        for (Perk perk : ALL) {
            class_1324 inst = p.method_5996(perk.attribute);
            if (inst == null) continue;
            class_2960 id = id(perk);
            double v = perk.value(d.level(perk.skill));
            if (v == 0) { inst.method_6200(id); continue; }
            class_1322 cur = inst.method_6199(id);
            if (cur == null || cur.comp_2449() != v) inst.method_55696(new class_1322(id, v, perk.op));
        }
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.method_3780() % 100 != 0) return;
            for (class_3222 p : server.method_3760().method_14571()) apply(p);
        });
    }

    private Perks() {}
}
