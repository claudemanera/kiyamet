package com.kiyamet.skill;

import com.kiyamet.Kiyamet;
import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Super powers: every useful /effect becomes a permanent power unlocked by skill levels. Each can be switched on/off
 * in the Powers panel (/skills -> Powers). Kıyamet 1.2 will add stronger tiers on top of these.
 */
public final class Powers {
    public enum Power {
        NIGHT_VISION("Night Vision", class_1294.field_5925, 0, Skill.EXPLORATION, 50, class_1802.field_8071),
        SPEED_1("Speed I", class_1294.field_5904, 0, Skill.ATHLETICS, 50, class_1802.field_8479),
        SPEED_2("Speed II", class_1294.field_5904, 1, Skill.ATHLETICS, 250, class_1802.field_8479),
        SPEED_3("Speed III", class_1294.field_5904, 2, Skill.ATHLETICS, 750, class_1802.field_8479),
        SPEED_4("Speed IV (1.2)", class_1294.field_5904, 3, Skill.ATHLETICS, 999, class_1802.field_8479),
        JUMP_1("Jump Boost I", class_1294.field_5913, 0, Skill.ACROBATICS, 50, class_1802.field_8073),
        JUMP_2("Jump Boost II", class_1294.field_5913, 1, Skill.ACROBATICS, 250, class_1802.field_8073),
        JUMP_3("Jump Boost III (1.2)", class_1294.field_5913, 2, Skill.ACROBATICS, 750, class_1802.field_8073),
        SLOW_FALL("Slow Falling", class_1294.field_5906, 0, Skill.ACROBATICS, 500, class_1802.field_8614),
        HASTE_1("Haste I", class_1294.field_5917, 0, Skill.MINING, 50, class_1802.field_8335),
        HASTE_2("Haste II", class_1294.field_5917, 1, Skill.MINING, 250, class_1802.field_8335),
        HASTE_3("Haste III", class_1294.field_5917, 2, Skill.MINING, 750, class_1802.field_22024),
        HASTE_4("Haste IV (1.2)", class_1294.field_5917, 3, Skill.MINING, 999, class_1802.field_22024),
        BUILDER_HASTE("Builder's Haste", class_1294.field_5917, 0, Skill.BUILDING, 100, class_1802.field_20390),
        STRENGTH_1("Strength I", class_1294.field_5910, 0, Skill.SWORDS, 100, class_1802.field_8183),
        STRENGTH_2("Strength II", class_1294.field_5910, 1, Skill.SWORDS, 500, class_1802.field_8183),
        STRENGTH_3("Strength III", class_1294.field_5910, 2, Skill.SWORDS, 750, class_1802.field_22022),
        STRENGTH_4("Strength IV (1.2)", class_1294.field_5910, 3, Skill.SWORDS, 999, class_1802.field_22022),
        HEAVY_STRENGTH_2("Titan Force (1.2)", class_1294.field_5910, 1, Skill.HEAVY_WEAPONS, 750, class_1802.field_8782),
        HEAVY_STRENGTH("Brute Force", class_1294.field_5910, 0, Skill.HEAVY_WEAPONS, 250, class_1802.field_8782),
        RESIST_1("Resistance I", class_1294.field_5907, 0, Skill.DEFENSE, 100, class_1802.field_8523),
        RESIST_2("Resistance II", class_1294.field_5907, 1, Skill.DEFENSE, 500, class_1802.field_8058),
        RESIST_3("Resistance III", class_1294.field_5907, 2, Skill.DEFENSE, 999, class_1802.field_22028),
        ABSORPTION("Absorption", class_1294.field_5898, 0, Skill.DEFENSE, 250, class_1802.field_8463),
        ABSORPTION_2("Absorption III (1.2)", class_1294.field_5898, 2, Skill.DEFENSE, 750, class_1802.field_8367),
        REGEN_1("Regeneration I", class_1294.field_5924, 0, Skill.HEALTH, 100, class_1802.field_8070),
        REGEN_2("Regeneration II", class_1294.field_5924, 1, Skill.HEALTH, 500, class_1802.field_8070),
        REGEN_3("Regeneration III (1.2)", class_1294.field_5924, 2, Skill.HEALTH, 999, class_1802.field_8137),
        MEDIC_REGEN_2("Field Surgeon (1.2)", class_1294.field_5924, 1, Skill.MEDICINE, 750, class_1802.field_8597),
        MEDIC_REGEN("Field Medic", class_1294.field_5924, 0, Skill.MEDICINE, 100, class_1802.field_8597),
        FIRE_RES("Fire Resistance", class_1294.field_5918, 0, Skill.SURVIVAL, 250, class_1802.field_8135),
        SATURATION("Saturation", class_1294.field_5922, 0, Skill.SURVIVAL, 750, class_1802.field_8176),
        FARMER_SATURATION("Harvest Feast", class_1294.field_5922, 0, Skill.FARMING, 500, class_1802.field_8229),
        WATER_BREATH("Water Breathing", class_1294.field_5923, 0, Skill.SWIMMING, 50, class_1802.field_8323),
        DOLPHIN("Dolphin's Grace", class_1294.field_5900, 0, Skill.SWIMMING, 250, class_1802.field_8207),
        ARCHER_HASTE("Steady Hands (1.2)", class_1294.field_5917, 1, Skill.ARCHERY, 750, class_1802.field_8399),
        STEALTH_SPEED("Ghost Walk (1.2)", class_1294.field_5904, 1, Skill.STEALTH, 750, class_1802.field_8614),
        BUILDER_JUMP("Scaffold Legs (1.2)", class_1294.field_5913, 0, Skill.BUILDING, 250, class_1802.field_16482),
        ENGINEER_RESIST("Exo Frame (1.2)", class_1294.field_5907, 0, Skill.ENGINEERING, 750, class_1802.field_8773),
        EXPLORER_NIGHT("Pathfinder (1.2)", class_1294.field_5904, 0, Skill.EXPLORATION, 500, class_1802.field_8251),
        CONDUIT("Conduit Power", class_1294.field_5927, 0, Skill.SWIMMING, 500, class_1802.field_8140),
        INVISIBLE("Shadow Step (invisible while sneaking)", class_1294.field_5905, 0, Skill.STEALTH, 250, class_1802.field_8711),
        LUCK_1("Luck I", class_1294.field_5926, 0, Skill.HUNTING, 100, class_1802.field_8245),
        LUCK_2("Luck II", class_1294.field_5926, 1, Skill.HUNTING, 500, class_1802.field_8687),
        LUCK_3("Luck III (1.2)", class_1294.field_5926, 2, Skill.HUNTING, 999, class_1802.field_8733),
        TREASURE_LUCK("Treasure Sense", class_1294.field_5926, 0, Skill.EXPLORATION, 250, class_1802.field_8895),
        HERO("Hero of the Village", class_1294.field_18980, 0, Skill.FARMING, 250, class_1802.field_8733),
        ENCHANT_LUCK("Arcane Luck", class_1294.field_5926, 0, Skill.ENCHANTING, 250, class_1802.field_8759),
        ALCHEMY_RESIST("Iron Stomach", class_1294.field_5907, 0, Skill.ALCHEMY, 250, class_1802.field_8740),
        ENGINEER_HASTE("Tinkerer", class_1294.field_5917, 0, Skill.ENGINEERING, 250, class_1802.field_8725),
        WOOD_HASTE("Lumberjack", class_1294.field_5917, 0, Skill.WOODCUTTING, 100, class_1802.field_8825),
        ARCHER_SPEED("Ranger's Stride", class_1294.field_5904, 0, Skill.ARCHERY, 250, class_1802.field_8399),
        EMERGENCY_HEAL("Second Wind (instant heal at low HP, 2 min cooldown)", class_1294.field_5915, 1, Skill.MEDICINE, 250, class_1802.field_8288);

        public final String title;
        public final class_6880<class_1291> effect;
        public final int amp, level;
        public final Skill skill;
        public final class_1792 icon;

        Power(String title, class_6880<class_1291> effect, int amp, Skill skill, int level, class_1792 icon) {
            this.title = title; this.effect = effect; this.amp = amp; this.skill = skill; this.level = level; this.icon = icon;
        }

        public boolean unlocked(SkillData d) { return d.level(skill) >= level; }
    }

    public static final AttachmentType<List<String>> DISABLED = AttachmentRegistry.create(Kiyamet.id("powers_off"),
            b -> b.initializer(List::of).persistent(Codec.STRING.listOf()).copyOnDeath());
    public static final AttachmentType<Long> HEAL_COOLDOWN = AttachmentRegistry.create(Kiyamet.id("second_wind"),
            b -> b.initializer(() -> 0L).persistent(Codec.LONG));

    public static boolean enabled(class_3222 p, Power pw) {
        return !p.getAttachedOrElse(DISABLED, List.of()).contains(pw.name());
    }

    public static void toggle(class_3222 p, Power pw) {
        List<String> l = new ArrayList<>(p.getAttachedOrElse(DISABLED, List.of()));
        if (!l.remove(pw.name())) {
            l.add(pw.name());
            class_1293 cur = p.method_6112(pw.effect);
            if (cur != null && cur.method_5591()) p.method_6016(pw.effect);
        }
        p.setAttached(DISABLED, List.copyOf(l));
    }

    private static void apply(class_3222 p) {
        SkillData d = SkillManager.get(p);
        Map<class_6880<class_1291>, Integer> best = new HashMap<>();
        for (Power pw : Power.values()) {
            if (!pw.unlocked(d) || !enabled(p, pw)) continue;
            if (pw == Power.EMERGENCY_HEAL) continue;
            if (pw == Power.INVISIBLE && !p.method_5715()) continue;
            if ((pw == Power.SATURATION || pw == Power.FARMER_SATURATION) && p.method_7344().method_7586() >= 18) continue;
            best.merge(pw.effect, pw.amp, Math::max);
        }
        best.forEach((eff, amp) -> {
            class_1293 cur = p.method_6112(eff);
            if (cur != null && !cur.method_5591() && cur.method_5578() >= amp) return;           // a stronger potion is active
            if (eff == class_1294.field_5898 && cur != null) return;                            // only refills once it ran out
            int dur = eff == class_1294.field_5898 ? 2400 : eff == class_1294.field_5922 ? 1 : eff == class_1294.field_5905 ? 30 : 300;
            p.method_6092(new class_1293(eff, dur, amp, true, false, true));
        });
        if (Power.EMERGENCY_HEAL.unlocked(d) && enabled(p, Power.EMERGENCY_HEAL) && p.method_6032() < p.method_6063() * 0.3f) {
            long now = p.method_51469().method_75260();
            if (now >= p.getAttachedOrElse(HEAL_COOLDOWN, 0L)) {
                p.setAttached(HEAL_COOLDOWN, now + 2400);
                p.method_6092(new class_1293(class_1294.field_5915, 1, 1));
                p.method_6092(new class_1293(class_1294.field_5924, 100, 1));
                p.method_64398(class_2561.method_43470("Second Wind!").method_27695(class_124.field_1076, class_124.field_1067));
            }
        }
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int t = server.method_3780();
            for (class_3222 p : server.method_3760().method_14571()) {
                if (p.method_7325()) continue;
                if (t % 20 == p.method_5628() % 20) apply(p);
            }
        });
    }

    private Powers() {}
}
