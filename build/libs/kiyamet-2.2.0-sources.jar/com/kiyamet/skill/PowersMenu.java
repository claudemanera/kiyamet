package com.kiyamet.skill;

import com.kiyamet.ui.Ui;
import net.minecraft.class_124;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3917;
import net.minecraft.class_747;

/** Lists every super power: unlocked ones glow when active and can be switched on/off with a click. */
public class PowersMenu extends class_1707 {
    private final class_1277 shown;
    private final class_3222 player;
    private int page;

    public static void open(class_3222 p) {
        p.method_17355(new class_747((id, inv, pl) -> new PowersMenu(id, inv, p), class_2561.method_43470("Super Powers")));
    }

    private PowersMenu(int id, class_1661 inv, class_3222 p) { this(id, inv, new class_1277(54), p); }

    private PowersMenu(int id, class_1661 inv, class_1277 c, class_3222 p) {
        super(class_3917.field_17327, id, inv, c, 6);
        this.shown = c;
        this.player = p;
        refresh();
    }

    private void refresh() {
        shown.method_5448();
        SkillData d = SkillManager.get(player);
        Powers.Power[] all = Powers.Power.values();
        int unlocked = 0;
        for (Powers.Power pw : all) if (pw.unlocked(d)) unlocked++;
        for (int i = 0; i < 45 && page * 45 + i < all.length; i++) {
            Powers.Power pw = all[page * 45 + i];
            boolean un = pw.unlocked(d), on = un && Powers.enabled(player, pw);
            class_1799 s = (un ? Ui.logo("power_" + pw.name().toLowerCase(), Ui.text(pw.title, on ? class_124.field_1060 : class_124.field_1061, class_124.field_1067)) : Ui.icon(class_1802.field_8298, Ui.text(pw.title, class_124.field_1063, class_124.field_1067)));
            Ui.lore(s, java.util.List.of(
                    Ui.text(un ? (on ? "● Active" : "● Switched off") : "✘ Locked", !un ? class_124.field_1063 : on ? class_124.field_1060 : class_124.field_1061),
                    class_2561.method_43470("Unlock: ").method_27692(class_124.field_1080).method_10852(class_2561.method_43471(pw.skill.key())).method_10852(class_2561.method_43470(" " + pw.level + "  (you: " + d.level(pw.skill) + ")")),
                    un ? Ui.text("Click to switch " + (on ? "off" : "on"), class_124.field_1054) : Ui.bar(d.level(pw.skill) / (double) pw.level, 16)));
            shown.method_5447(i, Ui.glint(s, on));
        }
        for (int i = 45; i < 54; i++) shown.method_5447(i, Ui.dark());
        shown.method_5447(45, Ui.icon(class_1802.field_8107, Ui.text("Back to skills", class_124.field_1054)));
        shown.method_5447(49, Ui.glint(Ui.icon(class_1802.field_8137, Ui.text("Powers unlocked: " + unlocked + " / " + all.length, class_124.field_1065, class_124.field_1067),
                Ui.bar(unlocked / (double) all.length, 20), Ui.text("Level up skills to earn more powers.", class_124.field_1080)), true));
        shown.method_5447(53, Ui.icon(class_1802.field_8077, Ui.text("Close", class_124.field_1061)));
        int pages = (all.length + 44) / 45;
        if (page > 0) shown.method_5447(47, Ui.icon(class_1802.field_8236, Ui.text("< Previous page", class_124.field_1075)));
        if (page < pages - 1) shown.method_5447(51, Ui.icon(class_1802.field_8236, Ui.text("Next page > (" + (page + 2) + "/" + pages + ")", class_124.field_1075)));
    }

    @Override
    public void method_7593(int slot, int button, class_1713 type, class_1657 p) {
        if (slot < 0 || slot >= 54) { if (type != class_1713.field_7794) super.method_7593(slot, button, type, p); return; }
        if (slot == 45) { SkillsMenu.open(player); return; }
        if (slot == 53) { player.method_7346(); return; }
        Powers.Power[] all = Powers.Power.values();
        if (slot == 47 && page > 0) { page--; refresh(); return; }
        if (slot == 51 && (page + 1) * 45 < all.length) { page++; refresh(); return; }
        int idx = page * 45 + slot;
        if (slot < 45 && idx < all.length && all[idx].unlocked(SkillManager.get(player))) {
            Powers.toggle(player, all[idx]);
            player.method_51469().method_8396(null, player.method_24515(), class_3417.field_15015.comp_349(), class_3419.field_15248, 0.5f, 1.3f);
            refresh();
        }
    }

    @Override
    public class_1799 method_7601(class_1657 p, int index) { return class_1799.field_8037; }

    @Override
    public boolean method_7597(class_1657 p) { return true; }
}
