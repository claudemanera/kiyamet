package com.kiyamet.skill;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5250;

/** /skills — lists all 20 skills, their level and progress, plus Total Power. */
public final class SkillCommand {
    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, env) ->
                dispatcher.register(class_2170.method_9247("skills").executes(ctx -> { SkillsMenu.open(ctx.getSource().method_9207()); return 1; })
                        .then(class_2170.method_9247("text").executes(ctx -> {
                    class_3222 p = ctx.getSource().method_9207();
                    SkillData d = SkillManager.get(p);
                    class_5250 out = class_2561.method_43469("kiyamet.msg.skills_title", d.totalPower()).method_27695(class_124.field_1065, class_124.field_1067);
                    for (Skill s : Skill.values()) {
                        int lv = d.level(s);
                        int pct = lv >= Skill.MAX_LEVEL ? 100 : (int) (100 * d.xp(s) / XpCurve.toNext(lv));
                        out.method_10852(class_2561.method_43470("\n "))
                                .method_10852(class_2561.method_43471(s.key()).method_27692(class_124.field_1068))
                                .method_10852(class_2561.method_43470("  " + lv).method_27692(class_124.field_1054))
                                .method_10852(class_2561.method_43470("  (" + pct + "%)").method_27692(class_124.field_1080));
                    }
                    ctx.getSource().method_9226(() -> out, false);
                    return 1;
                }))));
    }
    private SkillCommand() {}
}
