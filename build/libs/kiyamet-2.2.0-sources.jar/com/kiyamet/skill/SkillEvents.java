package com.kiyamet.skill;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags;
import net.minecraft.class_1297;
import net.minecraft.class_2302;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3481;
import net.minecraft.class_3483;
import net.minecraft.class_3489;
import net.minecraft.class_8103;

/**
 * XP sources tuned for ~3,140 XP per hour per skill while actively doing that thing.
 * Engineering, alchemy, enchanting, medicine, building and exploration get their sources in later phases
 * (lab table crafting, brewing, healing items, block placing, structure discovery).
 */
public final class SkillEvents {
    private static final Map<UUID, class_243> LAST_POS = new HashMap<>();
    private static int tick;

    public static void init() {
        PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, be) -> {
            if (!(player instanceof class_3222 p)) return;
            if (level instanceof net.minecraft.class_3218 sl) com.kiyamet.world.NoiseSystem.make(sl, pos, 10, 4);
            if (state.method_26164(class_3481.field_15475)) SkillManager.addXp(p, Skill.WOODCUTTING, 7);
            else if (state.method_26204() instanceof class_2302 crop) { if (crop.method_9825(state)) SkillManager.addXp(p, Skill.FARMING, 9); }
            else if (state.method_26164(ConventionalBlockTags.ORES)) SkillManager.addXp(p, Skill.MINING, 14);
            else if (state.method_26164(class_3481.field_33715)) SkillManager.addXp(p, Skill.MINING, 2);
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (!(source.method_5529() instanceof class_3222 p) || entity == p) return;
            double base = Math.max(4, entity.method_6063() * 1.5);
            class_1297 direct = source.method_5526();
            if ((direct != null && direct.method_5864().method_20210(class_3483.field_21508)) || p.method_6047().method_7909() instanceof com.kiyamet.item.GunItem) SkillManager.addXp(p, Skill.ARCHERY, base);
            else if (p.method_6047().method_31573(class_3489.field_42611) || p.method_6047().method_7909() instanceof com.kiyamet.element.ElementWeapon || p.method_6047().method_31574(com.kiyamet.element.ElementItems.ROD)) SkillManager.addXp(p, Skill.SWORDS, base);
            if (entity instanceof com.kiyamet.element.TempleGuardian) { SkillManager.addXp(p, Skill.DEFENSE, 80); SkillManager.addXp(p, Skill.EXPLORATION, 60); }
            if (entity instanceof com.kiyamet.wild.WildAnimal w && w.kind != null && (w.kind.predator || w.kind.zombie)) SkillManager.addXp(p, Skill.HUNTING, w.kind.zombie ? 120 : 60);
            else if (p.method_6047().method_31573(class_3489.field_42612)) SkillManager.addXp(p, Skill.HEAVY_WEAPONS, base);
            SkillManager.addXp(p, Skill.HUNTING, base * 0.6);
            if (p.method_5715()) SkillManager.addXp(p, Skill.STEALTH, base * 0.5);
        });

        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseTaken, taken, blocked) -> {
            if (!(entity instanceof class_3222 p)) return;
            if (source.method_48789(class_8103.field_42250)) SkillManager.addXp(p, Skill.ACROBATICS, taken * 6);
            else if (blocked) SkillManager.addXp(p, Skill.DEFENSE, baseTaken * 4);
            else {
                if (taken > 0) SkillManager.addXp(p, Skill.HEALTH, taken * 4);
                if (baseTaken > taken) SkillManager.addXp(p, Skill.DEFENSE, (baseTaken - taken) * 4);
            }
        });

        ServerPlayerEvents.AFTER_RESPAWN.register((oldP, newP, alive) -> SkillManager.applyHealth(newP));
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> SkillManager.applyHealth(handler.field_14140));

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (++tick % 20 != 0) return;
            for (class_3222 p : server.method_3760().method_14571()) {
                if (p.method_7325() || p.method_68878() || !p.method_5805()) continue;
                SkillManager.tickRest(p);
                com.kiyamet.world.Infection.tick(p);
                class_243 now = p.method_73189(), last = LAST_POS.put(p.method_5667(), now);
                boolean moved = last != null && last.method_1025(now) > 1.0;
                if (p.method_5624() && moved) SkillManager.addXp(p, Skill.ATHLETICS, 1.2);
                if ((p.method_5681() || p.method_5869()) && moved) SkillManager.addXp(p, Skill.SWIMMING, 1.5);
                if (p.method_5715() && moved && p.method_24828()) SkillManager.addXp(p, Skill.STEALTH, 1.0);
                if (tick % 1200 == 0) SkillManager.addXp(p, Skill.SURVIVAL, 25);
            }
        });
    }

    private SkillEvents() {}
}
