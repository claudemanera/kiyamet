package com.kiyamet.skill;

import com.kiyamet.Kiyamet;
import java.time.LocalDate;
import net.minecraft.class_124;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5134;
import net.minecraft.class_5894;

public final class SkillManager {
    /** First 2 real hours of play each day give +50% XP. */
    public static final int RESTED_TICKS = 2 * 60 * 60 * 20;
    private static final class_2960 HEALTH_MOD = Kiyamet.id("skill_health");

    public static SkillData get(class_3222 p) {
        return p.getAttachedOrSet(ModAttachments.SKILLS, SkillData.empty());
    }

    public static void set(class_3222 p, SkillData d) {
        p.setAttached(ModAttachments.SKILLS, d);
    }

    /** Adds XP to one skill; handles rested bonus, level ups, milestone messages and the health bonus. */
    public static void addXp(class_3222 p, Skill skill, double base) {
        if (base <= 0 || p.method_68878() || p.method_7325()) return;
        SkillData d = get(p);
        int level = d.level(skill);
        if (level >= Skill.MAX_LEVEL) return;
        boolean rested = d.restTicks() < RESTED_TICKS && d.restDay() == LocalDate.now().toEpochDay();
        long gain = Math.max(1, Math.round(base * (rested ? 1.5 : 1.0)));
        long xp = d.xp(skill) + gain;
        int startLevel = level;
        while (level < Skill.MAX_LEVEL && xp >= XpCurve.toNext(level)) {
            xp -= XpCurve.toNext(level);
            level++;
        }
        if (level >= Skill.MAX_LEVEL) xp = 0;
        set(p, d.with(skill, level, xp));

        class_2561 bar = class_2561.method_43470("+" + gain + " ").method_27692(rested ? class_124.field_1075 : class_124.field_1060)
                .method_10852(class_2561.method_43471(skill.key()).method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("  " + level + "  ").method_27692(class_124.field_1065))
                .method_10852(class_2561.method_43470(xp + "/" + XpCurve.toNext(level)).method_27692(class_124.field_1080));
        p.field_13987.method_14364(new class_5894(bar));

        if (level > startLevel) onLevelUp(p, skill, startLevel, level);
    }

    private static void onLevelUp(class_3222 p, Skill skill, int from, int to) {
        p.method_51469().method_8396(null, p.method_24515(), class_3417.field_14709, class_3419.field_15248, 0.5f, 1.3f);
        p.method_64398(class_2561.method_43469("kiyamet.msg.level_up", class_2561.method_43471(skill.key()), to).method_27692(class_124.field_1065));
        for (int m = from + 1; m <= to; m++) {
            if (m == 250 || m == 500 || m == 750 || m == 999)
                p.method_64398(class_2561.method_43469("kiyamet.msg.big_perk", class_2561.method_43471(skill.key()), m).method_27695(class_124.field_1076, class_124.field_1067));
            else if (m % 50 == 0)
                p.method_64398(class_2561.method_43469("kiyamet.msg.perk", class_2561.method_43471(skill.key()), m).method_27692(class_124.field_1054));
        }
        if (skill == Skill.HEALTH) applyHealth(p);
    }

    /** Health skill: +1 HP (half heart) every 33 levels → +30 HP at 999 = 25 hearts total. */
    public static void applyHealth(class_3222 p) {
        class_1324 inst = p.method_5996(class_5134.field_23716);
        if (inst == null) return;
        int bonus = Math.min(30, get(p).level(Skill.HEALTH) / 33);
        inst.method_6200(HEALTH_MOD);
        if (bonus > 0) inst.method_26837(new class_1322(HEALTH_MOD, bonus, class_1322.class_1323.field_6328));
    }

    /** Called every second for every online player: counts the daily rested window. */
    public static void tickRest(class_3222 p) {
        SkillData d = get(p);
        long today = LocalDate.now().toEpochDay();
        if (d.restDay() != today) set(p, d.withRest(today, 20));
        else if (d.restTicks() < RESTED_TICKS) set(p, d.withRest(today, d.restTicks() + 20));
    }

    private SkillManager() {}
}
