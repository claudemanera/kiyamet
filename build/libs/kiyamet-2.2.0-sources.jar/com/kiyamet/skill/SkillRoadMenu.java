package com.kiyamet.skill;

import com.kiyamet.ui.PanelMenu;
import com.kiyamet.ui.Ui;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_747;

/**
 * The road of one skill from level 1 to 999: 72 stops over two pages, laid out as a winding path.
 * Every stop shows what you have at that level and which super powers unlock there.
 */
public class SkillRoadMenu extends PanelMenu {
    private static final int NODES = 72, PER_PAGE = 36;
    private final Skill skill;
    private int page;

    public static void open(class_3222 p, Skill s, int page) {
        int lv = SkillManager.get(p).level(s);
        int pg = page >= 0 ? page : (nodeIndexFor(lv) >= PER_PAGE ? 1 : 0);
        p.method_17355(new class_747((id, inv, pl) -> new SkillRoadMenu(id, inv, p, s, pg),
                class_2561.method_43471(s.key()).method_10852(class_2561.method_43470(" - road to 999"))));
    }

    private SkillRoadMenu(int id, class_1661 inv, class_3222 p, Skill s, int page) {
        super(id, inv, p);
        this.skill = s;
        this.page = page;
        redraw();
    }

    static int nodeLevel(int i) { return Math.max(1, (int) Math.round(Skill.MAX_LEVEL * (i + 1) / (double) NODES)); }

    static int nodeIndexFor(int lv) {
        for (int i = 0; i < NODES; i++) if (nodeLevel(i) > lv) return i;
        return NODES - 1;
    }

    /** Slot of the i-th stop on a page, snaking left-right / right-left across 4 rows. */
    private static int slot(int i) {
        int row = i / 9, col = i % 9;
        if (row % 2 == 1) col = 8 - col;
        return 9 + row * 9 + col;
    }

    @Override
    protected void draw() {
        int lv = SkillManager.get(player).level(skill);
        List<Perks.Perk> perks = Perks.of(skill);
        // header
        List<class_2561> head = new ArrayList<>();
        head.add(Ui.text("Level " + lv + " / " + Skill.MAX_LEVEL, class_124.field_1054));
        head.add(Ui.bar(lv / (double) Skill.MAX_LEVEL, 30).method_27661().method_10852(class_2561.method_43470(" " + (lv * 100 / Skill.MAX_LEVEL) + "%").method_27692(class_124.field_1080)));
        for (Perks.Perk pk : perks) {
            int nx = pk.nextLevel(lv);
            head.add(Ui.text("✦ " + pk.describe(lv) + (nx > 0 ? "  → next at lv " + nx + ": " + pk.fmt(pk.perStep()) : "  (max)"), class_124.field_1060));
        }
        for (Perks.Perk pk : perks) head.add(Ui.text("   at 999: " + pk.describe(Skill.MAX_LEVEL), class_124.field_1062));
        class_1799 h = Ui.logo("skill_" + skill.name().toLowerCase(), class_2561.method_43471(skill.key()).method_27695(class_124.field_1065, class_124.field_1067));
        Ui.lore(h, head);
        c.method_5447(4, Ui.glint(h, lv >= Skill.MAX_LEVEL));

        int cur = nodeIndexFor(lv);
        for (int k = 0; k < PER_PAGE; k++) {
            int i = page * PER_PAGE + k;
            int at = nodeLevel(i), prev = i == 0 ? 0 : nodeLevel(i - 1);
            boolean reached = lv >= at, current = i == cur && !reached;
            List<Powers.Power> unlocks = new ArrayList<>();
            for (Powers.Power pw : Powers.Power.values()) if (pw.skill == skill && pw.level > prev && pw.level <= at) unlocks.add(pw);
            List<class_2561> lore = new ArrayList<>();
            lore.add(Ui.text(reached ? "✔ Reached" : current ? "► You are here (" + lv + ")" : "Locked", reached ? class_124.field_1060 : current ? class_124.field_1054 : class_124.field_1063));
            class_124[] col = {class_124.field_1075, class_124.field_1060, class_124.field_1065, class_124.field_1076};
            for (int L0 = prev + 1; L0 <= at; L0++) {
                final int L = L0;
                net.minecraft.class_5250 row = null;
                for (int pi = 0; pi < perks.size(); pi++) {
                    Perks.Perk pk = perks.get(pi);
                    if (L % pk.every() != 0 || L / pk.every() > pk.totalSteps()) continue;
                    class_2561 part = class_2561.method_43470(pk.label() + " " + pk.fmt(pk.perStep())).method_27692(lv >= L ? col[pi % col.length] : class_124.field_1063);
                    if (row == null) row = class_2561.method_43470("Lv " + L + ": ").method_27694(st -> st.method_10978(false).method_10977(lv >= L ? class_124.field_1068 : class_124.field_1080));
                    else row.method_10852(class_2561.method_43470(" · ").method_27692(class_124.field_1063));
                    row.method_10852(part);
                }
                if (row != null) lore.add(row);
            }
            for (com.kiyamet.enchant.Enchants.Unlock u : com.kiyamet.enchant.Enchants.unlocksBetween(skill, prev, at))
                lore.add(Ui.text("✧ Lv " + u.at() + ": " + com.kiyamet.enchant.Enchants.title(u.id()) + " " + com.kiyamet.enchant.Enchants.roman(u.level()), lv >= u.at() ? class_124.field_1076 : class_124.field_1064));
            lore.add(Ui.text("Total at " + at + ":", class_124.field_1068));
            for (int pi = 0; pi < perks.size(); pi++) lore.add(Ui.text("  " + perks.get(pi).describe(at), col[pi % col.length]));
            for (Powers.Power pw : unlocks) lore.add(Ui.text("★ Super power: " + pw.title + " (lv " + pw.level + ")", class_124.field_1076));
            if (at == 250 || at == 500 || at == 750 || at == Skill.MAX_LEVEL) lore.add(Ui.text("★ Big milestone", class_124.field_1065));
            class_1799 node;
            class_2561 name = Ui.text("Level " + at, reached ? class_124.field_1060 : current ? class_124.field_1054 : class_124.field_1068, class_124.field_1067);
            if (!unlocks.isEmpty()) node = Ui.logo("power_" + unlocks.get(0).name().toLowerCase(), name);
            else if (current) node = Ui.icon(class_1802.field_8287, name);
            else if (at % 100 < (Skill.MAX_LEVEL / NODES) && at >= 100 || at == Skill.MAX_LEVEL) node = Ui.icon(reached ? class_1802.field_8494 : class_1802.field_8385, name);
            else node = Ui.icon(reached ? class_1802.field_8839 : class_1802.field_8333, name);
            Ui.lore(node, lore);
            node.method_7939(Math.max(1, Math.min(64, at / 16)));
            c.method_5447(slot(k), Ui.glint(node, current || reached && !unlocks.isEmpty()));
        }
        c.method_5447(45, Ui.icon(class_1802.field_8107, Ui.text("Back to skills", class_124.field_1054)));
        if (page > 0) c.method_5447(48, Ui.icon(class_1802.field_8236, Ui.text("< Levels 1-" + nodeLevel(PER_PAGE - 1), class_124.field_1075)));
        if (page == 0) c.method_5447(50, Ui.icon(class_1802.field_8236, Ui.text("Levels " + nodeLevel(PER_PAGE) + "-999 >", class_124.field_1075)));
        c.method_5447(49, Ui.icon(class_1802.field_8895, Ui.text("Page " + (page + 1) + " / 2", class_124.field_1068), Ui.text("Green = reached · bottle = you are here", class_124.field_1080),
                Ui.text("Icons = super powers · gold = every 100 levels", class_124.field_1080)));
        c.method_5447(53, Ui.icon(class_1802.field_8077, Ui.text("Close", class_124.field_1061)));
    }

    @Override
    protected boolean click(int slot, class_1713 type) {
        if (slot == 45) { SkillsMenu.open(player); return false; }
        if (slot == 53) { player.method_7346(); return false; }
        if (slot == 48 && page > 0) { page = 0; return true; }
        if (slot == 50 && page == 0) { page = 1; return true; }
        return false;
    }
}
