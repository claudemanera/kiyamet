package com.kiyamet.skill;

import com.kiyamet.boss.BossRewards;
import com.kiyamet.ui.Ui;
import com.kiyamet.world.Difficulty;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_747;

/** /skills panel: 20 skill icons with level, progress bar and next milestone, plus Total Power and threat level. */
public class SkillsMenu extends class_1707 {
    private static final int[] SLOTS = {11, 12, 13, 14, 15, 20, 21, 22, 23, 24, 29, 30, 31, 32, 33, 38, 39, 40, 41, 42};

    public static void open(class_3222 p) {
        p.method_17355(new class_747((id, inv, pl) -> new SkillsMenu(id, inv, p), class_2561.method_43470("Skills")));
    }

    private SkillsMenu(int id, class_1661 inv, class_3222 p) {
        this(id, inv, new class_1277(54), p);
    }

    private SkillsMenu(int id, class_1661 inv, class_1277 c, class_3222 p) {
        super(class_3917.field_17327, id, inv, c, 6);
        fill(c, p);
    }

    private static class_1792 icon(Skill s) {
        return switch (s) {
            case HEALTH -> class_1802.field_8463; case ATHLETICS -> class_1802.field_8370; case MINING -> class_1802.field_8403;
            case SWORDS -> class_1802.field_8371; case ARCHERY -> com.kiyamet.ui.Ui.item("kiyamet:ak47"); case DEFENSE -> class_1802.field_8255; case ACROBATICS -> class_1802.field_8153;
            case SWIMMING -> class_1802.field_8662; case FARMING -> class_1802.field_8861; case WOODCUTTING -> class_1802.field_8475;
            case HUNTING -> class_1802.field_8176; case ENCHANTING -> class_1802.field_8657; case ALCHEMY -> class_1802.field_8740;
            case EXPLORATION -> class_1802.field_8251; case ENGINEERING -> class_1802.field_8725; case SURVIVAL -> class_1802.field_17346;
            case STEALTH -> class_1802.field_8449; case MEDICINE -> Ui.item("kiyamet:medkit"); case HEAVY_WEAPONS -> Ui.item("kiyamet:arrow_gatling");
            case BUILDING -> class_1802.field_20390;
        };
    }

    private static int nextMilestone(int lv) {
        for (int m : new int[]{250, 500, 750, 999}) if (lv < m && m - lv <= 50) return m;
        return Math.min(Skill.MAX_LEVEL, (lv / 50 + 1) * 50);
    }

    private static void fill(class_1277 c, class_3222 p) {
        SkillData d = SkillManager.get(p);
        for (int i = 0; i < 54; i++) c.method_5447(i, i < 9 || i >= 45 || i % 9 == 0 || i % 9 == 8 ? Ui.dark() : Ui.frame());
        int power = d.totalPower();
        int threat = (int) Math.round(100.0 * Math.min(power, Difficulty.CAP) / Difficulty.CAP);
        c.method_5447(4, Ui.glint(Ui.icon(class_1802.field_8137, Ui.text("Total Power: " + power, class_124.field_1065, class_124.field_1067),
                Ui.text("Sum of all 20 skill levels (max " + 20 * Skill.MAX_LEVEL + ")", class_124.field_1080),
                Ui.bar(power / (20.0 * Skill.MAX_LEVEL), 20),
                Ui.text("Zombie threat: " + threat + "%", threat > 66 ? class_124.field_1061 : threat > 33 ? class_124.field_1054 : class_124.field_1060),
                Ui.text("(zombies stop getting stronger at " + Difficulty.CAP + ")", class_124.field_1063)), true));
        int bosses = p.getAttachedOrElse(BossRewards.KILLED, List.of()).size();
        c.method_5447(2, Ui.icon(class_1802.field_8791, Ui.text("Bosses defeated: " + bosses + " / 15", class_124.field_1079, class_124.field_1067), Ui.bar(bosses / 15.0, 15)));
        boolean rested = d.restTicks() < SkillManager.RESTED_TICKS;
        c.method_5447(6, Ui.icon(rested ? class_1802.field_28659 : class_1802.field_16998, Ui.text(rested ? "Rested: +50% XP" : "Rested bonus used up today", rested ? class_124.field_1075 : class_124.field_1080),
                Ui.text("First 2 hours of play each day give +50% XP", class_124.field_1080)));
        Skill[] all = Skill.values();
        for (int i = 0; i < all.length; i++) {
            Skill s = all[i];
            int lv = d.level(s);
            boolean max = lv >= Skill.MAX_LEVEL;
            double frac = max ? 1 : d.xp(s) / (double) XpCurve.toNext(lv);
            List<class_2561> lore = new ArrayList<>();
            lore.add(Ui.text("Level " + lv + " / " + Skill.MAX_LEVEL, class_124.field_1054));
            lore.add(Ui.bar(frac, 20).method_27661().method_10852(class_2561.method_43470(" " + (int) (frac * 100) + "%").method_27692(class_124.field_1080)));
            if (!max) {
                lore.add(Ui.text(d.xp(s) + " / " + XpCurve.toNext(lv) + " XP", class_124.field_1063));
                int m = nextMilestone(lv);
                boolean big = m == 250 || m == 500 || m == 750 || m == 999;
                lore.add(Ui.text((big ? "★ Big power at level " : "Next perk at level ") + m, big ? class_124.field_1076 : class_124.field_1075));
            } else lore.add(Ui.text("★ MASTERED", class_124.field_1076, class_124.field_1067));
            for (Perks.Perk pk : Perks.of(s))
                lore.add(Ui.text("✦ " + pk.describe(lv) + "  (" + pk.stepText() + ")", pk.value(lv) == 0 ? class_124.field_1063 : class_124.field_1060));
            lore.add(Ui.text("Click: open the road to 999", class_124.field_1054));
            class_1799 st = Ui.logo("skill_" + s.name().toLowerCase(), class_2561.method_43471(s.key()).method_27695(max ? class_124.field_1076 : class_124.field_1068, class_124.field_1067));
            Ui.lore(st, lore);
            st.method_7939(Math.max(1, Math.min(64, lv / 16 + 1)));
            c.method_5447(SLOTS[i], Ui.glint(st, lv >= 250));
        }
        c.method_5447(49, Ui.icon(class_1802.field_8077, Ui.text("Close", class_124.field_1061)));
        long un = java.util.Arrays.stream(Powers.Power.values()).filter(pw -> pw.unlocked(d)).count();
        c.method_5447(47, Ui.glint(Ui.icon(class_1802.field_8668, Ui.text("Super Powers", class_124.field_1076, class_124.field_1067),
                Ui.text(un + " / " + Powers.Power.values().length + " unlocked", class_124.field_1080), Ui.text("Click to open", class_124.field_1054)), true));
    }

    @Override
    public void method_7593(int slot, int button, class_1713 type, class_1657 player) {
        if (slot == 49 && player instanceof class_3222 sp) sp.method_7346();
        if (slot == 47 && player instanceof class_3222 sp) { PowersMenu.open(sp); return; }
        for (int i = 0; i < SLOTS.length; i++) if (SLOTS[i] == slot && player instanceof class_3222 sp) { SkillRoadMenu.open(sp, Skill.values()[i], -1); return; }
        if (slot < 0 || slot >= 54) { if (type != class_1713.field_7794) super.method_7593(slot, button, type, player); }
    }

    @Override
    public class_1799 method_7601(class_1657 player, int index) { return class_1799.field_8037; }

    @Override
    public boolean method_7597(class_1657 player) { return true; }
}
