package com.kiyamet.stone;

import com.kiyamet.Kiyamet;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2378;
import net.minecraft.class_7923;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9331;

/** Stones socketed into the Stone Gauntlet and which one is selected for the active ability. */
public record GauntletData(List<String> stones, int selected) {
    public static final GauntletData EMPTY = new GauntletData(List.of(), 0);
    public static final Codec<GauntletData> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.STRING.listOf().fieldOf("stones").forGetter(GauntletData::stones),
            Codec.INT.optionalFieldOf("selected", 0).forGetter(GauntletData::selected)).apply(i, GauntletData::new));
    public static final class_9139<ByteBuf, GauntletData> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48554.method_56433(class_9135.method_56363()), GauntletData::stones,
            class_9135.field_48550, GauntletData::selected, GauntletData::new);

    public static final class_9331<GauntletData> TYPE = class_2378.method_10230(class_7923.field_49658, Kiyamet.id("gauntlet"),
            class_9331.<GauntletData>method_57873().method_57881(CODEC).method_57882(STREAM_CODEC).method_57880());

    public static void init() {}

    public GauntletData add(String id) { List<String> l = new ArrayList<>(stones); l.add(id); return new GauntletData(List.copyOf(l), l.size() - 1); }
    public GauntletData cycle() { return stones.isEmpty() ? this : new GauntletData(stones, (selected + 1) % stones.size()); }
    public StoneKind current() { return stones.isEmpty() ? null : StoneKind.byId(stones.get(Math.min(selected, stones.size() - 1))); }
}
