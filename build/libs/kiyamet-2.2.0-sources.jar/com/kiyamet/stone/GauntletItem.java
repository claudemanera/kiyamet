package com.kiyamet.stone;

import com.kiyamet.skill.SkillManager;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * Stone Gauntlet. Slots open at Total Power 200 / 1000 / 3000 / 6000 / 10000 (tier I–V).
 * Stone in offhand + right click: socket it. Sneak + right click: select next stone. Right click: use selected stone. Left click: gauntlet panel.
 */
public class GauntletItem extends class_1792 {
    public static final int[] SLOT_POWER = {200, 1000, 3000, 6000, 10000};

    public GauntletItem(class_1793 p) { super(p); }

    public static int slots(int power) {
        int n = 0;
        for (int t : SLOT_POWER) if (power >= t) n++;
        return n;
    }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (!(player instanceof class_3222 p) || hand != class_1268.field_5808) return class_1269.field_5812;
        GauntletData d = stack.method_58695(GauntletData.TYPE, GauntletData.EMPTY);
        class_1799 off = p.method_6079();
        if (off.method_7909() instanceof StoneItem si) {
            int slots = slots(SkillManager.get(p).totalPower());
            if (d.stones().contains(si.kind.id)) { p.method_64398(class_2561.method_43471("kiyamet.msg.gauntlet_has").method_27692(class_124.field_1080)); return class_1269.field_5814; }
            if (d.stones().size() >= slots) {
                int next = d.stones().size() < SLOT_POWER.length ? SLOT_POWER[d.stones().size()] : -1;
                p.method_64398(class_2561.method_43469("kiyamet.msg.gauntlet_full", next).method_27692(class_124.field_1061));
                return class_1269.field_5814;
            }
            stack.method_57379(GauntletData.TYPE, d.add(si.kind.id));
            if (!p.method_68878()) off.method_7934(1);
            p.method_64398(class_2561.method_43469("kiyamet.msg.gauntlet_socket", class_2561.method_43471("item.kiyamet." + si.kind.id)).method_27692(class_124.field_1076));
            return class_1269.field_21466;
        }
        if (p.method_5715()) {
            GauntletData c = d.cycle();
            stack.method_57379(GauntletData.TYPE, c);
            if (c.current() != null) p.method_64398(class_2561.method_43469("kiyamet.msg.gauntlet_select", class_2561.method_43471("item.kiyamet." + c.current().id)).method_27692(class_124.field_1075));
            return class_1269.field_21466;
        }
        StoneKind k = d.current();
        if (k == null) { p.method_64398(class_2561.method_43471("kiyamet.msg.gauntlet_empty").method_27692(class_124.field_1080)); return class_1269.field_5814; }
        if (StonePowers.activate(p, k)) p.method_7357().method_62835(stack, StonePowers.cooldown(p, k));
        return class_1269.field_21466;
    }
}
