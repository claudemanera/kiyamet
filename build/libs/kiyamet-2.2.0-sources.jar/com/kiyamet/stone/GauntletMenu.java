package com.kiyamet.stone;

import com.kiyamet.skill.SkillManager;
import com.kiyamet.ui.PanelMenu;
import com.kiyamet.ui.Ui;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_747;

/**
 * Stone Gauntlet panel (left-click with the gauntlet in hand): 5 sockets that open with Total Power.
 * Click a socketed stone to select it, sneak-click to take it out; click a stone from your inventory to socket it.
 */
public class GauntletMenu extends PanelMenu {
    static final int[] SOCKETS = {20, 21, 22, 23, 24};
    private final List<Integer> invSlots = new ArrayList<>();

    public static void open(class_3222 p) {
        p.method_17355(new class_747((id, inv, pl) -> new GauntletMenu(id, inv, p), class_2561.method_43470("Stone Gauntlet")));
    }

    private GauntletMenu(int id, class_1661 inv, class_3222 p) { super(id, inv, p); redraw(); }

    class_1799 gauntlet() {
        class_1799 m = player.method_6047();
        return m.method_7909() instanceof GauntletItem ? m : class_1799.field_8037;
    }

    @Override
    protected void draw() {
        class_1799 g = gauntlet();
        if (g.method_7960()) return;
        GauntletData d = g.method_58695(GauntletData.TYPE, GauntletData.EMPTY);
        int power = SkillManager.get(player).totalPower(), open = GauntletItem.slots(power);
        c.method_5447(4, Ui.glint(Ui.icon(g.method_7909(), Ui.text("Stone Gauntlet", class_124.field_1076, class_124.field_1067),
                Ui.text("Sockets: " + d.stones().size() + " used · " + open + " / 5 open", class_124.field_1080),
                Ui.text("Total Power: " + power, class_124.field_1065),
                Ui.text("Right-click: use the selected stone", class_124.field_1063)), true));
        for (int i = 0; i < 5; i++) {
            int slot = SOCKETS[i];
            if (i < d.stones().size()) {
                StoneKind k = StoneKind.byId(d.stones().get(i));
                boolean sel = i == Math.min(d.selected(), d.stones().size() - 1);
                c.method_5447(slot, Ui.glint(Ui.icon(Ui.item("kiyamet:" + k.id), class_2561.method_43471("item.kiyamet." + k.id).method_27695(sel ? class_124.field_1060 : class_124.field_1068, class_124.field_1067),
                        Ui.text(sel ? "★ Selected" : "Click: select", sel ? class_124.field_1060 : class_124.field_1054),
                        Ui.text("Sneak + click: take it out", class_124.field_1080),
                        Ui.text("Cooldown: " + (k.cooldown / 20) + " s", class_124.field_1063)), sel));
            } else if (i < open) {
                c.method_5447(slot, Ui.icon(class_1802.field_8581, Ui.text("Empty socket " + (i + 1), class_124.field_1060), Ui.text("Click a stone below to put it in", class_124.field_1080)));
            } else {
                c.method_5447(slot, Ui.icon(class_1802.field_8879, Ui.text("Locked socket " + (i + 1), class_124.field_1061),
                        Ui.text("Opens at Total Power " + GauntletItem.SLOT_POWER[i], class_124.field_1080), Ui.bar(Math.min(1, power / (double) GauntletItem.SLOT_POWER[i]), 16)));
            }
        }
        for (int i = 9; i < 45; i++) if (i < 18 || i > 26) c.method_5447(i, i >= 27 ? class_1799.field_8037 : Ui.frame());
        c.method_5447(19, Ui.frame()); c.method_5447(25, Ui.frame());
        c.method_5447(31, Ui.icon(class_1802.field_8529, Ui.text("Stones in your inventory", class_124.field_1075), Ui.text("Click one to socket it", class_124.field_1080)));
        invSlots.clear();
        int at = 36;
        class_1661 inv = player.method_31548();
        for (int i = 0; i < inv.method_5439() && at < 45; i++) {
            class_1799 s = inv.method_5438(i);
            if (s.method_7909() instanceof StoneItem si) {
                boolean has = d.stones().contains(si.kind.id);
                c.method_5447(at, Ui.icon(s.method_7909(), s.method_7964().method_27661().method_27692(class_124.field_1076),
                        Ui.text(has ? "Already in the gauntlet" : "Click: put in the gauntlet", has ? class_124.field_1080 : class_124.field_1054)));
                invSlots.add(i);
                at++;
            }
        }
        if (invSlots.isEmpty()) c.method_5447(40, Ui.icon(class_1802.field_8077, Ui.text("No stones in your inventory", class_124.field_1080)));
        c.method_5447(49, Ui.icon(class_1802.field_8077, Ui.text("Close", class_124.field_1061)));
    }

    @Override
    protected boolean click(int slot, class_1713 type) {
        class_1799 g = gauntlet();
        if (g.method_7960() || slot == 49) { player.method_7346(); return false; }
        GauntletData d = g.method_58695(GauntletData.TYPE, GauntletData.EMPTY);
        for (int i = 0; i < 5; i++) {
            if (slot != SOCKETS[i] || i >= d.stones().size()) continue;
            if (type == class_1713.field_7794) {                 // take the stone out
                List<String> l = new ArrayList<>(d.stones());
                String id = l.remove(i);
                g.method_57379(GauntletData.TYPE, new GauntletData(List.copyOf(l), 0));
                class_1799 back = new class_1799(Ui.item("kiyamet:" + id));
                if (!player.method_31548().method_7394(back)) player.method_7328(back, false);
            } else g.method_57379(GauntletData.TYPE, new GauntletData(d.stones(), i));
            return true;
        }
        if (slot >= 36 && slot < 36 + invSlots.size()) {
            class_1799 s = player.method_31548().method_5438(invSlots.get(slot - 36));
            if (!(s.method_7909() instanceof StoneItem si) || d.stones().contains(si.kind.id)) return false;
            if (d.stones().size() >= GauntletItem.slots(SkillManager.get(player).totalPower())) {
                player.method_7353(Ui.text("No free socket - raise your Total Power.", class_124.field_1061), true);
                return false;
            }
            g.method_57379(GauntletData.TYPE, d.add(si.kind.id));
            if (!player.method_68878()) s.method_7934(1);
            return true;
        }
        return false;
    }
}
