package com.kiyamet.stone;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class StoneEvents {
    private static final Map<UUID, List<class_1799>> SOUL_KEEP = new HashMap<>();
    private static int tick;

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3218 l : server.method_3738()) StonePowers.tickHoles(l);
            if (++tick % 20 != 0) return;
            for (class_3222 p : server.method_3760().method_14571()) if (p.method_5805()) StonePowers.tickPassives(p);
            for (class_3218 l : server.method_3738()) { StonePowers.tickSpirits(l); com.kiyamet.item.GadgetItem.tick(l); }
        });
        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, base, taken, blocked) -> {
            if (source.method_5529() instanceof class_3222 p && entity != p && taken > 0) StonePowers.onPlayerHit(p, entity, taken);
        });
        // Soul Stone: keep the whole inventory on death.
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
            if (entity instanceof class_3222 p && StonePowers.active(p).contains(StoneKind.SOUL)) {
                List<class_1799> saved = new ArrayList<>();
                for (int i = 0; i < p.method_31548().method_5439(); i++) saved.add(p.method_31548().method_5438(i).method_7972());
                p.method_31548().method_5448();
                SOUL_KEEP.put(p.method_5667(), saved);
            }
            return true;
        });
        ServerPlayerEvents.COPY_FROM.register((oldP, newP, alive) -> {
            List<class_1799> saved = SOUL_KEEP.remove(oldP.method_5667());
            if (saved == null || alive) return;
            for (int i = 0; i < saved.size() && i < newP.method_31548().method_5439(); i++) newP.method_31548().method_5447(i, saved.get(i));
        });
    }

    private StoneEvents() {}
}
