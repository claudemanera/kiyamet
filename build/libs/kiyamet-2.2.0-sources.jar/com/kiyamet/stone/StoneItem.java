package com.kiyamet.stone;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3222;

/** A loose power stone: right click uses its active power; in the offhand its passive works. */
public class StoneItem extends class_1792 {
    public final StoneKind kind;
    public StoneItem(class_1793 p, StoneKind kind) { super(p); this.kind = kind; }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (player instanceof class_3222 p && StonePowers.activate(p, kind))
            p.method_7357().method_62835(stack, StonePowers.cooldown(p, kind));
        return class_1269.field_5812;
    }
}
