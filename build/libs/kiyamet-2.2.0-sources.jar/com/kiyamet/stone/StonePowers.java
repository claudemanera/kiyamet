package com.kiyamet.stone;

import com.kiyamet.skill.SkillManager;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1439;
import net.minecraft.class_1538;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2400;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_5134;

/** Passive and active effects of the 10 power stones. */
public final class StonePowers {
    private static final class_2960 EARTH_KB = com.kiyamet.Kiyamet.id("earth_stone");
    private static final Map<UUID, Long> SPIRITS = new HashMap<>();

    /** Stones whose passive is active: socketed in a gauntlet anywhere in the inventory, or a loose stone in the offhand. */
    public static Set<StoneKind> active(class_1657 p) {
        Set<StoneKind> set = EnumSet.noneOf(StoneKind.class);
        for (int i = 0; i < p.method_31548().method_5439(); i++) {
            class_1799 s = p.method_31548().method_5438(i);
            GauntletData d = s.method_58694(GauntletData.TYPE);
            if (d != null) for (String id : d.stones()) { StoneKind k = StoneKind.byId(id); if (k != null) set.add(k); }
        }
        if (p.method_6079().method_7909() instanceof StoneItem si) set.add(si.kind);
        return set;
    }

    /** Every second. */
    public static void tickPassives(class_3222 p) {
        Set<StoneKind> s = active(p);
        if (s.isEmpty() && !p.method_6127().method_45330(class_5134.field_23718, EARTH_KB)) return;
        if (s.contains(StoneKind.FIRE)) { p.method_6092(new class_1293(class_1294.field_5918, 80, 0, true, false)); p.method_6092(new class_1293(class_1294.field_5910, 80, 0, true, false)); }
        if (s.contains(StoneKind.STORM)) { p.method_6092(new class_1293(class_1294.field_5904, 80, 1, true, false)); p.method_6092(new class_1293(class_1294.field_5913, 80, 1, true, false)); }
        if (s.contains(StoneKind.NATURE)) { p.method_6092(new class_1293(class_1294.field_5924, 80, 0, true, false)); if (p.field_6012 % 60 < 20) p.method_7344().method_7585(1, 0.3f); }
        if (s.contains(StoneKind.SHADOW)) { p.method_6092(new class_1293(class_1294.field_5925, 260, 0, true, false)); if (p.method_5715()) p.method_6092(new class_1293(class_1294.field_5905, 40, 0, true, false)); }
        if (s.contains(StoneKind.EARTH)) p.method_6092(new class_1293(class_1294.field_5907, 80, 0, true, false));
        if (s.contains(StoneKind.TIME)) p.method_6092(new class_1293(class_1294.field_5917, 80, 1, true, false));
        if (s.contains(StoneKind.SOUL) && p.field_6012 % 200 < 20) p.method_6092(new class_1293(class_1294.field_5898, 400, 1, true, false));
        if (s.contains(StoneKind.VOID)) p.method_6092(new class_1293(class_1294.field_5906, 80, 0, true, false));
        if (s.contains(StoneKind.BLOOD)) p.method_6092(new class_1293(class_1294.field_5910, 80, 0, true, false));
        if (s.contains(StoneKind.STAR)) { p.method_6092(new class_1293(class_1294.field_5926, 80, 1, true, false)); p.method_6092(new class_1293(class_1294.field_5906, 80, 0, true, false)); }
        if (s.contains(StoneKind.DRAGON)) { p.method_6092(new class_1293(class_1294.field_5907, 80, 1, true, false)); p.method_6092(new class_1293(class_1294.field_5918, 80, 0, true, false)); }
        class_1324 kb = p.method_5996(class_5134.field_23718);
        if (kb != null) {
            kb.method_6200(EARTH_KB);
            if (s.contains(StoneKind.EARTH)) kb.method_26835(new class_1322(EARTH_KB, 1.0, class_1322.class_1323.field_6328));
        }
    }

    /** Called when a player damages a living entity. */
    public static void onPlayerHit(class_3222 p, class_1309 target, float damage) {
        Set<StoneKind> s = active(p);
        if (s.contains(StoneKind.FROST)) { target.method_6092(new class_1293(class_1294.field_5909, 100, 2)); target.method_32317(Math.min(300, target.method_32312() + 60)); }
        if (s.contains(StoneKind.BLOOD)) p.method_6025(damage * 0.25f);
        if (s.contains(StoneKind.FIRE)) target.method_5639(4);
        if (s.contains(StoneKind.STAR) && p.method_51469() instanceof class_3218 sl0) { target.method_64397(sl0, sl0.method_48963().method_48831(), 2f); sl0.method_65096(class_2398.field_11207, target.method_23317(), target.method_23318() + 1, target.method_23321(), 6, 0.3, 0.5, 0.3, 0.05); }
        if (s.contains(StoneKind.DRAGON) && p.method_59922().method_43057() < 0.2f) target.method_6092(new class_1293(class_1294.field_5920, 60, 1));
        if (s.contains(StoneKind.STORM) && p.method_59922().method_43057() < 0.12f && p.method_51469() instanceof class_3218 sl) {
            class_1538 b = class_1299.field_6112.method_5883(sl, class_3730.field_16461);
            if (b != null) { b.method_5814(target.method_23317(), target.method_23318(), target.method_23321()); b.method_6961(p); sl.method_8649(b); }
        }
    }

    public static int cooldown(class_1657 p, StoneKind k) {
        return (int) (k.cooldown * 0.5 * (active(p).contains(StoneKind.TIME) ? 0.75 : 1));
    }

    private static List<class_1309> enemies(class_3218 level, class_1657 p, double r) {
        List<class_1309> out = new ArrayList<>();
        for (class_1309 e : level.method_18467(class_1309.class, new class_238(p.method_24515()).method_1014(r)))
            if (e != p && e instanceof class_1569 && e.method_5805()) out.add(e);
        return out;
    }

    private static void burst(class_3218 level, class_1657 p, class_2400 type, int n, double spread) {
        level.method_65096(type, p.method_23317(), p.method_23318() + 1, p.method_23321(), n, spread, 0.6, spread, 0.05);
    }

    private static void hurt(class_3218 level, class_1657 p, class_1309 e, float amount) {
        e.method_64397(level, level.method_48963().method_48802(p), amount);
    }

    /** Active ability. Returns false if nothing happened. */
    public static boolean activate(class_3222 p, StoneKind k) {
        class_3218 level = p.method_51469();
        float power = 2f + SkillManager.get(p).totalPower() / 2500f;
        switch (k) {
            case STAR -> {   // starfall: shooting stars crash on every enemy around
                List<class_1309> es = enemies(level, p, 20);
                for (class_1309 e : es) {
                    hurt(level, p, e, 12 * power);
                    e.method_6092(new class_1293(class_1294.field_5902, 30, 1)); e.method_6092(new class_1293(class_1294.field_5912, 300, 0));
                    level.method_65096(class_2398.field_11207, e.method_23317(), e.method_23318() + 6, e.method_23321(), 40, 0.2, 3, 0.2, 0.02);
                    level.method_65096(net.minecraft.class_9381.method_58256(class_2398.field_17909, 0xFFFFFFFF), e.method_23317(), e.method_23318() + 1, e.method_23321(), 1, 0, 0, 0, 0);
                }
                level.method_8396(null, p.method_24515(), class_3417.field_15188, class_3419.field_15248, 1.5f, 0.7f);
                burst(level, p, class_2398.field_11207, 300, 10);
            }
            case DRAGON -> {  // dragon's breath: a lingering cloud of dragon fire where you look, and a dragon fireball
                class_243 dir = p.method_5828(1f);
                net.minecraft.class_1670 f = new net.minecraft.class_1670(level, p, dir.method_1029());
                f.method_5814(p.method_23317() + dir.field_1352 * 1.5, p.method_23320() + dir.field_1351 * 1.5, p.method_23321() + dir.field_1350 * 1.5);
                level.method_8649(f);
                for (class_1309 e : enemies(level, p, 8)) { hurt(level, p, e, 10 * power); e.method_6005(1.5, p.method_23317() - e.method_23317(), p.method_23321() - e.method_23321()); }
                level.method_8396(null, p.method_24515(), class_3417.field_14671, class_3419.field_15248, 1f, 1.2f);
                burst(level, p, class_2398.field_23190, 300, 4);
            }
            case FIRE -> {   // inferno: big fire ring, burning for 12 s, fire resistance + strength for you
                for (class_1309 e : enemies(level, p, 12)) { e.method_5639(12); hurt(level, p, e, 9 * power); e.method_6005(0.8, p.method_23317() - e.method_23317(), p.method_23321() - e.method_23321()); }
                p.method_6092(new class_1293(class_1294.field_5910, 400, 1)); burst(level, p, class_2398.field_11240, 400, 8); burst(level, p, class_2398.field_11239, 60, 5);
            }
            case FROST -> {  // blizzard: everything around frozen solid for 10 s
                for (class_1309 e : enemies(level, p, 14)) { e.method_6092(new class_1293(class_1294.field_5909, 200, 6)); e.method_6092(new class_1293(class_1294.field_5911, 200, 2)); e.method_32317(400); hurt(level, p, e, 6 * power); }
                burst(level, p, class_2398.field_28013, 500, 10);
            }
            case STORM -> {  // chain storm: up to 6 bolts on the closest enemies
                List<class_1309> es = enemies(level, p, 24);
                es.sort(java.util.Comparator.comparingDouble(e -> e.method_5858(p)));
                int n = 0;
                for (class_1309 e : es) {
                    if (n++ >= 6) break;
                    class_1538 bolt = class_1299.field_6112.method_5883(level, class_3730.field_16461);
                    if (bolt != null) { bolt.method_5814(e.method_23317(), e.method_23318(), e.method_23321()); bolt.method_6961(p); level.method_8649(bolt); }
                    hurt(level, p, e, 14 * power);
                }
                if (n == 0) {
                    class_243 at = p.method_33571().method_1019(p.method_5828(1f).method_1021(20));
                    class_1538 bolt = class_1299.field_6112.method_5883(level, class_3730.field_16461);
                    if (bolt != null) { bolt.method_5814(at.field_1352, at.field_1351, at.field_1350); bolt.method_6961(p); level.method_8649(bolt); }
                }
                p.method_6092(new class_1293(class_1294.field_5904, 400, 2));
            }
            case NATURE -> {  // full heal, regeneration III, roots everyone around
                p.method_6025(20 * power); p.method_6092(new class_1293(class_1294.field_5924, 300, 2)); p.method_6016(class_1294.field_5899); p.method_6016(class_1294.field_5920);
                for (class_1309 e : enemies(level, p, 12)) { e.method_6092(new class_1293(class_1294.field_5909, 240, 9)); e.method_6092(new class_1293(class_1294.field_5899, 200, 1)); }
                burst(level, p, class_2398.field_11211, 300, 8);
            }
            case BLOOD -> {  // blood drain: heavy damage to all around, half comes back as health
                float total = 0;
                for (class_1309 e : enemies(level, p, 12)) { hurt(level, p, e, 10 * power); total += 10 * power; e.method_6092(new class_1293(class_1294.field_5920, 160, 1)); }
                p.method_6025(total * 0.5f); p.method_6092(new class_1293(class_1294.field_5898, 600, 3));
                burst(level, p, class_2398.field_11209, 200, 6);
            }
            case SHADOW -> {  // 30 s invisible, faster, every enemy forgets you
                p.method_6092(new class_1293(class_1294.field_5905, 600, 0)); p.method_6092(new class_1293(class_1294.field_5904, 600, 1));
                p.method_6092(new class_1293(class_1294.field_5910, 600, 1));
                for (class_1309 e : enemies(level, p, 40)) { if (e instanceof net.minecraft.class_1308 m && m.method_5968() == p) m.method_5980(null); e.method_6092(new class_1293(class_1294.field_5919, 200, 0)); }
                burst(level, p, class_2398.field_11237, 200, 2);
            }
            case SOUL -> {   // 3 spirit golems for 3 minutes, stronger with power
                for (int i = 0; i < 3; i++) {
                    class_1439 g = class_1299.field_6147.method_5883(level, class_3730.field_16461);
                    if (g == null) continue;
                    g.method_5814(p.method_23317() + (i - 1) * 2.5, p.method_23318(), p.method_23321() + (i == 1 ? 2 : 0));
                    g.method_6499(true);
                    g.method_6092(new class_1293(class_1294.field_5910, 3600, Math.min(4, (int) power - 1)));
                    g.method_6092(new class_1293(class_1294.field_5907, 3600, 1));
                    level.method_8649(g);
                    SPIRITS.put(g.method_5667(), level.method_75260() + 3600);
                }
                burst(level, p, class_2398.field_23114, 200, 3);
            }
            case TIME -> {   // time stop: enemies frozen for 12 s, you get speed + haste
                for (class_1309 e : enemies(level, p, 24)) {
                    e.method_6092(new class_1293(class_1294.field_5909, 240, 255)); e.method_6092(new class_1293(class_1294.field_5911, 240, 4));
                    if (e instanceof net.minecraft.class_1308 m) { m.method_5977(true); FROZEN.put(m.method_5667(), level.method_75260() + 240); }
                }
                p.method_6092(new class_1293(class_1294.field_5904, 240, 3)); p.method_6092(new class_1293(class_1294.field_5917, 240, 2));
                burst(level, p, class_2398.field_11215, 400, 10);
            }
            case VOID -> {   // black hole: pulls in everything for 4 seconds, crushes it
                class_243 c = p.method_33571().method_1019(p.method_5828(1f).method_1021(10));
                HOLES.add(new Object[]{p.method_5667(), c, level.method_75260() + 80, power});
                level.method_65096(class_2398.field_23190, c.field_1352, c.field_1351, c.field_1350, 400, 2, 2, 2, 0.3);
            }
            case EARTH -> {   // quake: everything around launched, slowed and battered
                for (class_1309 e : enemies(level, p, 12)) { e.method_18799(e.method_18798().method_1031(0, 1.4, 0)); e.field_6037 = true; hurt(level, p, e, 12 * power); e.method_6092(new class_1293(class_1294.field_5909, 200, 3)); }
                p.method_6092(new class_1293(class_1294.field_5907, 400, 2));
                burst(level, p, class_2398.field_17430, 200, 8); burst(level, p, class_2398.field_11236, 12, 6);
            }
        }
        level.method_8396(null, p.method_24515(), class_3417.field_43154, class_3419.field_15248, 1.5f, 0.8f);
        return true;
    }

    private static final Map<UUID, Long> FROZEN = new HashMap<>();
    private static final List<Object[]> HOLES = new ArrayList<>();

    /** Spirit golems vanish after one minute. */
    /** Every tick: black holes from the Void stone. */
    public static void tickHoles(class_3218 level) {
        if (HOLES.isEmpty()) return;
        long t = level.method_75260();
        HOLES.removeIf(h -> {
            class_243 c = (class_243) h[1];
            class_3222 owner = level.method_8503().method_3760().method_14602((UUID) h[0]);
            for (class_1309 e : level.method_18467(class_1309.class, new class_238(c, c).method_1014(14))) {
                if (e == owner || !(e instanceof class_1569)) continue;
                class_243 pull = c.method_1020(e.method_73189()).method_1029().method_1021(0.6);
                e.method_18800(pull.field_1352, pull.field_1351 + 0.08, pull.field_1350); e.field_6037 = true;
                if (t % 10 == 0 && owner != null) hurt(level, owner, e, 3 * (Float) h[3]);
            }
            level.method_65096(class_2398.field_11214, c.field_1352, c.field_1351, c.field_1350, 30, 1, 1, 1, 0.5);
            return t >= (Long) h[2];
        });
    }

    public static void tickSpirits(class_3218 level) {
        long t = level.method_75260();
        FROZEN.entrySet().removeIf(en -> {
            if (en.getValue() > t) return false;
            if (level.method_66347(en.getKey()) instanceof net.minecraft.class_1308 m) m.method_5977(false);
            return true;
        });
        if (SPIRITS.isEmpty()) return;
        long now = level.method_75260();
        SPIRITS.entrySet().removeIf(en -> {
            if (en.getValue() > now) return false;
            class_1297 e = level.method_66347(en.getKey());
            if (e != null) e.method_31472();
            return e != null;
        });
    }

    private StonePowers() {}
}
