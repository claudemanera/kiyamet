package com.kiyamet.twd;

import com.kiyamet.Kiyamet;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1291;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_4081;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

/** Walker-blood camouflage: zombies ignore you until you attack them, get wet, or it wears off. */
public final class Camouflage {
    public static class Effect extends class_1291 {
        public Effect() { super(class_4081.field_18271, 0x5a2a1a); }
    }

    public static final class_6880<class_1291> EFFECT = class_2378.method_47985(class_7923.field_41174, Kiyamet.id("walker_camouflage"), new Effect());

    public static boolean hides(class_1309 target, class_1308 zombie) {
        return target.method_6059(EFFECT) && zombie.method_6065() != target;
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.method_3780() % 20 != 0) return;
            for (class_3222 p : server.method_3760().method_14571()) {
                if (p.method_6059(EFFECT) && p.method_5721()) {
                    p.method_6016(EFFECT);
                    p.method_64398(class_2561.method_43470("The water washed the walker blood off you!").method_27692(class_124.field_1061));
                }
            }
        });
    }

    private Camouflage() {}
}
