package com.kiyamet.twd;

import com.kiyamet.npc.Talk;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_2183;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;

/**
 * Story cut-scenes, made from what the game can do without a camera mod: fade to black, title cards,
 * a slow-down "freeze", the camera turning toward where you have to go, sound and particles.
 */
public final class Cinema {
    public static final String[] BOOKS = {"BOOK I: THE LONG ROAD", "BOOK II: ACROSS THE WATER", "BOOK III: THE BURNING CITIES", "BOOK IV: LEGACY"};
    static final int[] BOOK_START = {1, 60, 101, 151};

    static void title(class_3222 p, int in, int stay, int out, class_2561 t, class_2561 sub) {
        p.field_13987.method_14364(new class_5905(in, stay, out));
        p.field_13987.method_14364(new class_5903(sub));
        p.field_13987.method_14364(new class_5904(t));
    }

    static void freeze(class_3222 p, int ticks) {
        p.method_6092(new class_1293(class_1294.field_5909, ticks, 4, true, false, false));
        p.method_6092(new class_1293(class_1294.field_5901, ticks, 4, true, false, false));
    }

    static void fadeBlack(class_3222 p, int ticks) { p.method_6092(new class_1293(class_1294.field_5919, ticks, 0, true, false, false)); }

    /** Opening of a chapter: black screen, (book card), chapter card, then the camera turns toward the objective. */
    public static void chapter(class_3222 p, int ch, String name, String tagline, class_2338 target) {
        class_3218 level = p.method_51469();
        int book = -1;
        for (int i = 0; i < BOOK_START.length; i++) if (BOOK_START[i] == ch) book = i;
        int d = 0;
        fadeBlack(p, book >= 0 ? 120 : 60);
        freeze(p, book >= 0 ? 160 : 100);
        level.method_8396(null, p.method_24515(), class_3417.field_19167, class_3419.field_15250, 0.8f, 0.6f);
        if (book >= 0) {
            final int b = book;
            Talk.later(p, 10, () -> {
                title(p, 30, 60, 20, class_2561.method_43470(BOOKS[b]).method_27695(class_124.field_1065, class_124.field_1067), class_2561.method_43470("The Long Road").method_27695(class_124.field_1080, class_124.field_1056));
                level.method_8396(null, p.method_24515(), class_3417.field_14981, class_3419.field_15250, 0.35f, 0.7f);
            });
            d = 100;
        }
        Talk.later(p, d + 20, () -> {
            title(p, 15, 70, 25, class_2561.method_43470("CHAPTER " + ch).method_27695(class_124.field_1068, class_124.field_1067),
                    class_2561.method_43470(name + " - " + tagline).method_27695(class_124.field_1080, class_124.field_1056));
            level.method_8396(null, p.method_24515(), class_3417.field_14624.comp_349(), class_3419.field_15250, 1f, 0.5f);
        });
        if (target != null) Talk.later(p, d + 55, () -> {
            p.method_5702(class_2183.class_2184.field_9851, class_243.method_24953(target).method_1031(0, 1, 0));
            class_243 dir = class_243.method_24953(target).method_1020(p.method_73189()).method_1029();
            for (int i = 2; i < 14; i++) {
                class_243 q = p.method_33571().method_1019(dir.method_1021(i));
                level.method_65096(class_2398.field_11207, q.field_1352, q.field_1351, q.field_1350, 1, 0, 0, 0, 0);
            }
            level.method_8396(null, p.method_24515(), class_3417.field_26980, class_3419.field_15250, 1f, 0.8f);
        });
    }

    /** A boss or named enemy comes into view. */
    public static void boss(class_3222 p, class_1297 e, String name) {
        freeze(p, 50);
        p.method_5702(class_2183.class_2184.field_9851, e.method_33571());
        title(p, 5, 50, 20, class_2561.method_43470("★ " + name.toUpperCase() + " ★").method_27695(class_124.field_1079, class_124.field_1067), class_2561.method_43470("Story enemy").method_27692(class_124.field_1080));
        p.method_51469().method_8396(null, p.method_24515(), class_3417.field_14792, class_3419.field_15251, 0.5f, 0.8f);
    }

    public static void passed(class_3222 p, int reward, boolean finale) {
        class_3218 level = p.method_51469();
        freeze(p, 40);
        title(p, 10, 60, 20, class_2561.method_43470(finale ? "THE END" : "MISSION PASSED").method_27695(class_124.field_1065, class_124.field_1067),
                class_2561.method_43470("+" + com.kiyamet.money.Money.fmt(reward * com.kiyamet.money.Money.RATE)).method_27692(class_124.field_1060));
        level.method_8396(null, p.method_24515(), class_3417.field_15195, class_3419.field_15250, 1f, 1f);
        for (int i = 0; i < (finale ? 6 : 2); i++) {
            final int k = i;
            Talk.later(p, 10 + i * 12, () -> {
                double a = k * 1.3;
                level.method_65096(class_2398.field_11248, p.method_23317() + Math.cos(a) * 3, p.method_23318() + 4, p.method_23321() + Math.sin(a) * 3, 60, 0.4, 0.4, 0.4, 0.15);
                level.method_8396(null, p.method_24515(), class_3417.field_15188, class_3419.field_15250, 0.8f, 1f);
            });
        }
    }

    public static void failed(class_3222 p, String why) {
        p.method_6092(new class_1293(class_1294.field_38092, 80, 0, true, false, false));
        title(p, 5, 60, 25, class_2561.method_43470("MISSION FAILED").method_27695(class_124.field_1079, class_124.field_1067), class_2561.method_43470(why).method_27692(class_124.field_1080));
        p.method_51469().method_8396(null, p.method_24515(), class_3417.field_38068, class_3419.field_15250, 1f, 0.6f);
    }

    private Cinema() {}
}
