package com.kiyamet.twd;

import java.util.Optional;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/** Walking Dead rule: aim for the head. Hits in the top ~22% of the body deal double damage. */
public final class Headshot {
    public static final float MULT = 2.0f;

    /** Returns the damage multiplier for this hit (2.0 for a headshot) and plays the effect. */
    public static float multiplier(class_3218 level, class_1309 target, class_1282 src) {
        class_1297 direct = src.method_5526(), attacker = src.method_5529();
        double hitY;
        if (direct != null && direct != attacker) hitY = direct.method_23318() + direct.method_17682() / 2;     // arrow / projectile
        else if (attacker instanceof class_1309 a) {                                                 // melee or hitscan gun
            class_243 eye = a.method_33571(), end = eye.method_1019(a.method_5720().method_1021(64));
            class_238 box = target.method_5829().method_1014(0.15);
            Optional<class_243> hit = box.method_992(eye, end);
            if (box.method_1006(eye)) return 1f;
            if (hit.isEmpty()) return 1f;
            hitY = hit.get().field_1351;
        } else return 1f;
        double headStart = target.method_23318() + target.method_17682() * 0.78;
        if (hitY < headStart) return 1f;
        level.method_65096(class_2398.field_11205, target.method_23317(), target.method_23320() + 0.1, target.method_23321(), 12, 0.2, 0.15, 0.2, 0.2);
        level.method_8396(null, target.method_24515(), class_3417.field_15016, class_3419.field_15248, 0.9f, 0.7f);
        return MULT;
    }

    private Headshot() {}
}
