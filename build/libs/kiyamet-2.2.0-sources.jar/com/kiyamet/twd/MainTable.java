package com.kiyamet.twd;

import com.kiyamet.Kiyamet;
import com.kiyamet.npc.Shop;
import com.kiyamet.registry.ModItems;
import com.kiyamet.ui.PanelMenu;
import com.kiyamet.ui.Ui;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_747;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * 1.9 Main Table: the one table that builds all the other TWD stations - furniture, cooking, guns, lab, vehicles,
 * power, the mission board and everything for your own settlement. Those stations can't be crafted anywhere else.
 */
public class MainTable extends class_2248 {
    public static class_2248 BLOCK;
    public static class_1792 MISSION_BOARD_ITEM;

    /** item id, short description, cost (item, n, ...) */
    public record Station(String id, String what, Object... cost) {}
    public static final List<Station> STATIONS = new ArrayList<>(List.of(
            new Station("kiyamet:furniture_table", "Build beds, sofas, wardrobes, fridges...", "minecraft:oak_planks", 12, "minecraft:shears", 1, "minecraft:crafting_table", 1),
            new Station("kiyamet:cooking_table", "Cook all 30 meals", "minecraft:oak_planks", 8, "minecraft:iron_ingot", 2, "minecraft:furnace", 1, "minecraft:bowl", 1),
            new Station("kiyamet:gun_bench", "Build guns, fit parts, repair", "minecraft:iron_ingot", 6, "minecraft:oak_planks", 6, "minecraft:crafting_table", 1),
            new Station("kiyamet:lab_table", "Research and the vaccine", "minecraft:iron_ingot", 6, "minecraft:copper_ingot", 2, "minecraft:redstone", 4, "minecraft:crafting_table", 1),
            new Station("kiyamet:vehicle_workshop", "Build cars and bikes", "minecraft:iron_block", 6, "minecraft:anvil", 1, "minecraft:crafting_table", 1),
            new Station("kiyamet:generator", "Powers turrets, fences and electric tools", "minecraft:iron_ingot", 8, "minecraft:redstone", 6, "minecraft:furnace", 1),
            new Station("kiyamet:settlement_bell", "Found your own settlement - settlers live and work here", "minecraft:gold_ingot", 4, "minecraft:iron_ingot", 4, "minecraft:oak_planks", 8, "minecraft:bell", 1),
            new Station("kiyamet:solar_panel", "Free power while the sun shines (8 blocks)", "minecraft:glass_pane", 6, "minecraft:iron_ingot", 3, "minecraft:redstone", 4, "minecraft:lapis_lazuli", 2),
            new Station("kiyamet:wind_turbine", "Free power day and night - best up high", "minecraft:iron_ingot", 8, "minecraft:redstone", 4, "minecraft:white_wool", 3),
            new Station("kiyamet:electric_drill", "Mines 3x3 - charges in power", "minecraft:iron_ingot", 6, "minecraft:diamond", 2, "minecraft:redstone", 8),
            new Station("kiyamet:chainsaw", "Fells a whole tree - charges in power", "minecraft:iron_ingot", 6, "minecraft:diamond", 1, "minecraft:redstone", 6),
            new Station("kiyamet:mission_board", "Your own mission board: 3 new jobs every day", "minecraft:oak_planks", 10, "minecraft:paper", 6, "minecraft:stick", 4)));

    public MainTable(class_2251 p) { super(p); }

    public static void init() {
        class_5321<class_2248> key = class_5321.method_29179(class_7924.field_41254, Kiyamet.id("main_table"));
        BLOCK = class_2378.method_39197(class_7923.field_41175, key, new MainTable(class_4970.class_2251.method_9630(class_2246.field_9980).method_9632(3f).method_63500(key)));
        ModItems.custom("main_table", ip -> new class_1747(BLOCK, ip.method_63685()));
        MISSION_BOARD_ITEM = ModItems.custom("mission_board", p -> new BoardItem(p.method_7889(4)));
    }

    /** places a mission board where you click, facing you */
    public static class BoardItem extends class_1792 {
        public BoardItem(class_1793 p) { super(p); }
        @Override
        public class_1269 method_7884(class_1838 ctx) {
            if (!(ctx.method_8045() instanceof class_3218 sl)) return class_1269.field_5812;
            class_2338 at = ctx.method_8037().method_10093(ctx.method_8038());
            MissionBoard b = ModTwd.MISSION_BOARD.method_5883(sl, class_3730.field_16465);
            if (b == null) return class_1269.field_5814;
            float yaw = ctx.method_8036() == null ? 0 : ctx.method_8036().method_36454() + 180;
            b.method_5808(at.method_10263() + 0.5, at.method_10264(), at.method_10260() + 0.5, yaw, 0);
            b.method_5847(yaw); b.method_5636(yaw);
            sl.method_8649(b);
            ctx.method_8041().method_57008(1, ctx.method_8036());
            sl.method_8396(null, at, class_3417.field_14718, class_3419.field_15245, 1f, 1f);
            return class_1269.field_5812;
        }
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (player instanceof class_3222 sp) Menu.open(sp);
        return class_1269.field_5812;
    }

    static boolean has(class_3222 p, Station s) {
        if (p.method_68878()) return true;
        for (int i = 0; i < s.cost().length; i += 2) if (Shop.count(p, (String) s.cost()[i]) < (Integer) s.cost()[i + 1]) return false;
        return true;
    }

    public static class Menu extends PanelMenu {
        static final int[] SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};

        static void open(class_3222 p) { p.method_17355(new class_747((id, inv, pl) -> new Menu(id, inv, p), class_2561.method_43470("Main Table"))); }

        private Menu(int id, class_1661 inv, class_3222 p) { super(id, inv, p); redraw(); }

        @Override
        protected void draw() {
            c.method_5447(4, Ui.icon(BLOCK.method_8389(), Ui.text("Main Table", class_124.field_1065, class_124.field_1067), Ui.text("Every TWD station and settlement block is built here", class_124.field_1080)));
            for (int i = 0; i < STATIONS.size() && i < SLOTS.length; i++) {
                Station s = STATIONS.get(i);
                boolean ok = has(player, s);
                List<class_2561> lore = new ArrayList<>();
                lore.add(Ui.text(s.what(), class_124.field_1075));
                for (int j = 0; j < s.cost().length; j += 2) {
                    String id = (String) s.cost()[j]; int n = (Integer) s.cost()[j + 1], have = Shop.count(player, id);
                    lore.add(class_2561.method_43470((have >= n ? "✔ " : "✘ ") + n + "× ").method_10852(new class_1799(Ui.item(id)).method_7964()).method_27692(have >= n ? class_124.field_1060 : class_124.field_1080));
                }
                lore.add(Ui.text(ok ? "Click to build!" : "Missing materials", ok ? class_124.field_1054 : class_124.field_1063));
                c.method_5447(SLOTS[i], Ui.glint(Ui.lore(new class_1799(Ui.item(s.id())), lore), ok));
            }
            c.method_5447(49, Ui.icon(class_1802.field_8077, Ui.text("Close", class_124.field_1061)));
        }

        @Override
        protected boolean click(int slot, class_1713 type) {
            if (slot == 49) { player.method_7346(); return false; }
            for (int i = 0; i < STATIONS.size() && i < SLOTS.length; i++) {
                if (SLOTS[i] != slot) continue;
                Station s = STATIONS.get(i);
                if (!has(player, s)) return false;
                if (!player.method_68878()) for (int j = 0; j < s.cost().length; j += 2) Shop.take(player, (String) s.cost()[j], (Integer) s.cost()[j + 1]);
                Shop.give(player, new class_1799(Ui.item(s.id())));
                com.kiyamet.skill.SkillManager.addXp(player, com.kiyamet.skill.Skill.BUILDING, 60);
                player.method_51469().method_8396(null, player.method_24515(), class_3417.field_22463, class_3419.field_15245, 0.8f, 1f);
                return true;
            }
            return false;
        }
    }
}
