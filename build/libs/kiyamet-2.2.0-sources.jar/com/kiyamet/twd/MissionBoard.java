package com.kiyamet.twd;

import com.kiyamet.Kiyamet;
import com.kiyamet.entity.KZombie;
import com.kiyamet.npc.Communities;
import com.kiyamet.npc.Faction;
import com.kiyamet.npc.HumanEntity;
import com.kiyamet.registry.ModItems;
import com.kiyamet.skill.Skill;
import com.kiyamet.skill.SkillManager;
import com.kiyamet.ui.PanelMenu;
import com.kiyamet.ui.Ui;
import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1314;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_747;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Mission board next to every settlement leader: 3 jobs a day per player (kill walkers, kill raiders, bring supplies).
 * Rewards: rubies, XP and reputation with that settlement.
 */
public class MissionBoard extends class_1314 implements GeoEntity {
    /** "day|type,item,need,have,reward,done|..." */
    public static final AttachmentType<String> MISSIONS = AttachmentRegistry.create(Kiyamet.id("missions"),
            b -> b.initializer(() -> "").persistent(Codec.STRING).copyOnDeath());
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("misc.idle");
    private static final String[][] BRING = {{"minecraft:bread", "16"}, {"minecraft:arrow", "32"}, {"minecraft:iron_ingot", "12"}, {"minecraft:leather", "10"},
            {"minecraft:cooked_beef", "12"}, {"kiyamet:bandage", "4"}, {"minecraft:wheat", "32"}, {"minecraft:oak_log", "32"}, {"kiyamet:walker_guts", "6"}, {"minecraft:coal", "16"}};
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    public String community = "";

    public MissionBoard(class_1299<? extends MissionBoard> type, class_1937 level) {
        super(type, level);
        method_5971();
    }

    public static void init() {
        ServerLivingEntityEvents.AFTER_DEATH.register((e, src) -> {
            if (!(src.method_5529() instanceof class_3222 p)) return;
            int type = e instanceof KZombie ? 0 : e instanceof HumanEntity h && (h.faction() == Faction.RAIDER || h.faction() == Faction.WHISPERER) ? 1 : -1;
            if (type < 0) return;
            List<int[]> ms = load(p);
            boolean changed = false;
            for (int[] m : ms) if (m[0] == type && m[5] == 0 && m[3] < m[2]) {
                m[3]++; changed = true;
                if (m[3] == m[2]) p.method_7353(class_2561.method_43470("Mission complete! Turn it in at a mission board.").method_27692(class_124.field_1060), true);
            }
            if (changed) save(p, ms);
        });
    }

    private static int day(class_3222 p) { return (int) (p.method_51469().method_8503().method_30002().method_8532() / 24000); }

    /** Today's 3 missions (rolled once per day). */
    static List<int[]> load(class_3222 p) {
        String s = p.getAttachedOrElse(MISSIONS, "");
        int today = day(p);
        List<int[]> out = new ArrayList<>();
        String[] parts = s.split("\\|");
        if (parts.length > 1 && parts[0].equals(String.valueOf(today))) {
            for (int i = 1; i < parts.length; i++) {
                String[] f = parts[i].split(",");
                int[] m = new int[6];
                for (int j = 0; j < 6 && j < f.length; j++) m[j] = Integer.parseInt(f[j]);
                out.add(m);
            }
            return out;
        }
        Random r = new Random(p.method_5667().getLeastSignificantBits() ^ today * 31L);
        int power = SkillManager.get(p).totalPower();
        int walkers = 15 + r.nextInt(25) + power / 200;
        out.add(new int[]{0, 0, walkers, 0, 3 + walkers / 6, 0});
        int raiders = 2 + r.nextInt(5) + power / 1500;
        out.add(new int[]{power >= 300 ? 1 : 0, 0, power >= 300 ? raiders : walkers + 10, 0, power >= 300 ? raiders * 3 : 5 + walkers / 6, 0});
        int item = r.nextInt(BRING.length);
        out.add(new int[]{2, item, Integer.parseInt(BRING[item][1]), 0, 4 + r.nextInt(6), 0});
        save(p, out);
        return out;
    }

    static void save(class_3222 p, List<int[]> ms) {
        StringBuilder sb = new StringBuilder().append(day(p));
        for (int[] m : ms) { sb.append('|'); for (int j = 0; j < 6; j++) { if (j > 0) sb.append(','); sb.append(m[j]); } }
        p.setAttached(MISSIONS, sb.toString());
    }

    @Override
    public void method_5773() {
        super.method_5773();
        method_18800(0, method_18798().field_1351, 0);
    }

    @Override
    protected class_1269 method_5992(class_1657 player, class_1268 hand) {
        if (hand == class_1268.field_5808 && player instanceof class_3222 sp) {
            String key = community;
            sp.method_17355(new class_747((id, inv, pl) -> new Menu(id, inv, sp, key), class_2561.method_43470("Mission Board")));
        }
        return class_1269.field_5812;
    }

    @Override public boolean method_64397(class_3218 level, class_1282 source, float amount) {
        return source.method_5529() instanceof class_1657 p && p.method_68878() && super.method_64397(level, source, amount);
    }
    @Override public boolean method_5974(double d) { return false; }
    @Override public boolean method_6094() { return true; }
    @Override public boolean method_5810() { return false; }
    @Override protected boolean method_27071(class_3218 level) { return false; }
    @Override public boolean method_5931() { return false; }

    @Override protected void method_5652(class_11372 out) { super.method_5652(out); out.method_71469("Community", community); }
    @Override protected void method_5749(class_11368 in) { super.method_5749(in); community = in.method_71428("Community", ""); }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar c) {
        c.add(new AnimationController<MissionBoard>("main", 0, t -> t.setAndContinue(IDLE)));
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    static class Menu extends PanelMenu {
        private final String community;
        private static final int[] SLOTS = {20, 22, 24};

        Menu(int id, class_1661 inv, class_3222 p, String community) { super(id, inv, p); this.community = community; redraw(); }

        @Override
        protected void draw() {
            List<int[]> ms = load(player);
            c.method_5447(4, Ui.glint(Ui.icon(class_1802.field_8674, Ui.text("Mission Board", class_124.field_1065, class_124.field_1067),
                    Ui.text("3 new jobs every day", class_124.field_1080), Ui.text("Rewards: cash, XP" + (community.isEmpty() ? "" : ", reputation"), class_124.field_1080)), true));
            for (int i = 0; i < ms.size() && i < 3; i++) {
                int[] m = ms.get(i);
                boolean done = m[5] == 1;
                String title; class_1792 icon;
                if (m[0] == 0) { title = "Kill " + m[2] + " walkers"; icon = class_1802.field_8511; }
                else if (m[0] == 1) { title = "Kill " + m[2] + " raiders"; icon = class_1802.field_8399; }
                else { class_1792 it = Ui.item(BRING[m[1]][0]); title = "Bring " + m[2] + "× " + new class_1799(it).method_7964().getString(); icon = it; }
                int have = m[0] == 2 ? Math.min(m[2], player.method_31548().method_18861(Ui.item(BRING[m[1]][0]))) : m[3];
                boolean ready = !done && have >= m[2];
                c.method_5447(SLOTS[i], Ui.glint(Ui.icon(done ? class_1802.field_8131 : icon, Ui.text(title, done ? class_124.field_1077 : ready ? class_124.field_1060 : class_124.field_1068, class_124.field_1067),
                        Ui.bar(have / (double) m[2], 20), Ui.text(have + " / " + m[2], class_124.field_1080),
                        Ui.text("Reward: " + com.kiyamet.money.Money.fmt(m[4] * com.kiyamet.money.Money.RATE) + " + XP", class_124.field_1065),
                        Ui.text(done ? "✔ Done for today" : ready ? "Click to turn in!" : "In progress", done ? class_124.field_1077 : ready ? class_124.field_1054 : class_124.field_1080)), ready));
            }
            c.method_5447(49, Ui.icon(class_1802.field_8077, Ui.text("Close", class_124.field_1061)));
            int ch = Story.chapter(player), st = Story.stage(player);
            if (ch <= Story.CHAPTERS.length) {
                StoryChapters.Chapter sc = Story.CHAPTERS[ch - 1];
                c.method_5447(40, Ui.glint(Ui.icon(class_1802.field_8204, Ui.text("★ STORY - Chapter " + ch + "/" + Story.CHAPTERS.length + ": " + sc.title(), class_124.field_1065, class_124.field_1067),
                        Ui.text("\"" + sc.tagline() + "\"", class_124.field_1080), Ui.text("The Long Road", class_124.field_1063),
                        Ui.text("Reward: " + com.kiyamet.money.Money.fmt(Story.reward(ch) * com.kiyamet.money.Money.RATE) + " + XP", class_124.field_1060),
                        Ui.text(st > 0 ? "In progress - follow the arrow on screen" : "Click: talk to Marcus", class_124.field_1054)), st == 0));
            } else c.method_5447(40, Ui.icon(class_1802.field_8895, Ui.text("★ The Long Road - complete", class_124.field_1065), Ui.text("Thank you, hero.", class_124.field_1080)));
        }

        @Override
        protected boolean click(int slot, class_1713 type) {
            if (slot == 49) { player.method_7346(); return false; }
            if (slot == 40) {
                player.method_7346();
                for (MissionBoard b : player.method_51469().method_18467(MissionBoard.class, player.method_5829().method_1014(10))) { Story.offer(player, b); break; }
                return false;
            }
            for (int i = 0; i < 3; i++) if (SLOTS[i] == slot) {
                List<int[]> ms = load(player);
                int[] m = ms.get(i);
                if (m[5] == 1) return false;
                if (m[0] == 2) {
                    class_1792 it = Ui.item(BRING[m[1]][0]);
                    if (player.method_31548().method_18861(it) < m[2]) return false;
                    int left = m[2];
                    for (int s = 0; s < player.method_31548().method_5439() && left > 0; s++) {
                        class_1799 st = player.method_31548().method_5438(s);
                        if (st.method_31574(it)) { int take = Math.min(left, st.method_7947()); st.method_7934(take); left -= take; }
                    }
                } else if (m[3] < m[2]) return false;
                m[5] = 1;
                save(player, ms);
                com.kiyamet.money.Money.give(player, m[4] * com.kiyamet.money.Money.RATE);
                SkillManager.addXp(player, m[0] == 2 ? Skill.SURVIVAL : Skill.SWORDS, 60 + m[4] * 8);
                if (!community.isEmpty()) Communities.change(player, community, 5);
                player.method_51469().method_8396(null, player.method_24515(), class_3417.field_14709, class_3419.field_15248, 0.6f, 1.2f);
                for (HumanEntity h : player.method_51469().method_8390(HumanEntity.class, player.method_5829().method_1014(16), h -> h.faction() == Faction.COMMUNITY)) {
                    String[] thanks = {"Thank you. That'll keep us going another week.", "You did good out there.", "We won't forget this.", "Here, you earned it.", "Fewer of them, more of us. Good work."};
                    com.kiyamet.npc.Talk.say(player, h, thanks[player.method_59922().method_43048(thanks.length)]);
                    break;
                }
                player.method_64398(class_2561.method_43470("Mission done: +" + com.kiyamet.money.Money.fmt(m[4] * com.kiyamet.money.Money.RATE) + (community.isEmpty() ? "" : ", +5 reputation")).method_27692(class_124.field_1060));
                return true;
            }
            return false;
        }
    }
}
