package com.kiyamet.twd;

import com.kiyamet.Kiyamet;
import com.kiyamet.registry.ModItems;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1311;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/** Shelter Core, Mission Board and Lost Notes. */
public final class ModTwd {
    private static final class_5321<class_1299<?>> CORE_KEY = class_5321.method_29179(class_7924.field_41266, Kiyamet.id("shelter_core"));
    private static final class_5321<class_1299<?>> BOARD_KEY = class_5321.method_29179(class_7924.field_41266, Kiyamet.id("mission_board"));
    public static final class_1299<ShelterCore> SHELTER_CORE = class_2378.method_39197(class_7923.field_41177, CORE_KEY,
            class_1299.class_1300.<ShelterCore>method_5903(ShelterCore::new, class_1311.field_17715).method_17687(0.9f, 1.0f).method_27299(10).method_19947().method_5905(CORE_KEY));
    public static final class_1299<MissionBoard> MISSION_BOARD = class_2378.method_39197(class_7923.field_41177, BOARD_KEY,
            class_1299.class_1300.<MissionBoard>method_5903(MissionBoard::new, class_1311.field_17715).method_17687(2.0f, 2.2f).method_27299(10).method_19947().method_5905(BOARD_KEY));
    public static final class_1792 SHELTER_CORE_ITEM = ModItems.custom("shelter_core", p -> new ShelterCore.CoreItem(p.method_7889(1).method_7894(net.minecraft.class_1814.field_8904)));
    public static final class_1792 QUEST_ITEM = ModItems.custom("quest_item", p -> new class_1792(p.method_7889(1).method_7894(net.minecraft.class_1814.field_8903)));
    public static final class_1792 LOST_NOTE = ModItems.custom("lost_note", p -> new com.kiyamet.item.LostNoteItem(p.method_7889(1)));

    public static void init() {
        FabricDefaultAttributeRegistry.register(SHELTER_CORE, class_1308.method_26828().method_26868(class_5134.field_23716, 300).method_26868(class_5134.field_23724, 10).method_26868(class_5134.field_23718, 1).method_26868(class_5134.field_23719, 0));
        FabricDefaultAttributeRegistry.register(MISSION_BOARD, class_1308.method_26828().method_26868(class_5134.field_23716, 100).method_26868(class_5134.field_23718, 1).method_26868(class_5134.field_23719, 0));
        MissionBoard.init();
        Story.init();
    }

    private ModTwd() {}
}
