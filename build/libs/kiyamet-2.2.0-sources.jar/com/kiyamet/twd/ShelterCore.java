package com.kiyamet.twd;

import com.kiyamet.npc.BaseRaids;
import com.kiyamet.npc.HumanEntity;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.*;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1314;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_5321;

/**
 * Shelter Core: the heart of your base. Within 24 blocks walkers don't spawn on their own, you and your
 * companions slowly heal, and it becomes your base for raids. One per player; sneak + right-click to pick it up.
 */
public class ShelterCore extends class_1314 implements GeoEntity {
    public static final int RADIUS = 24;
    private static final Map<class_5321<class_1937>, Map<UUID, class_2338>> CORES = new HashMap<>();
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("misc.idle");
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private UUID owner;

    public ShelterCore(class_1299<? extends ShelterCore> type, class_1937 level) {
        super(type, level);
        method_5971();
    }

    public UUID owner() { return owner; }

    public static boolean protects(class_3218 level, class_2338 pos) {
        Map<UUID, class_2338> m = CORES.get(level.method_27983());
        if (m == null) return false;
        for (class_2338 c : m.values()) if (c.method_10262(pos) <= RADIUS * RADIUS) return true;
        return false;
    }

    @Override
    public void method_5773() {
        super.method_5773();
        method_18800(0, method_18798().field_1351, 0);
        if (!(method_73183() instanceof class_3218 sl)) return;
        CORES.computeIfAbsent(sl.method_27983(), k -> new HashMap<>()).put(method_5667(), method_24515());
        if (field_6012 % 100 == 0) {
            for (class_1657 p : sl.method_18467(class_1657.class, method_5829().method_1014(RADIUS)))
                p.method_6092(new class_1293(class_1294.field_5924, 120, 0, true, true));
            for (HumanEntity h : sl.method_8390(HumanEntity.class, method_5829().method_1014(RADIUS), h -> owner != null && owner.equals(h.owner())))
                h.method_6025(2);
            sl.method_65096(class_2398.field_11207, method_23317(), method_23318() + 1.2, method_23321(), 6, 0.2, 0.4, 0.2, 0.02);
        }
    }

    @Override
    public void method_5650(class_5529 reason) {
        if (method_73183() instanceof class_3218 sl) { Map<UUID, class_2338> m = CORES.get(sl.method_27983()); if (m != null) m.remove(method_5667()); }
        super.method_5650(reason);
    }

    @Override
    protected class_1269 method_5992(class_1657 player, class_1268 hand) {
        if (hand != class_1268.field_5808 || !(player instanceof class_3222 sp)) return class_1269.field_5812;
        if (sp.method_5715() && (owner == null || owner.equals(sp.method_5667()))) {
            class_1799 item = new class_1799(ModTwd.SHELTER_CORE_ITEM);
            if (!sp.method_31548().method_7394(item)) sp.method_7328(item, false);
            method_31472();
            sp.method_7353(class_2561.method_43470("Shelter Core packed up.").method_27692(class_124.field_1080), true);
            return class_1269.field_5812;
        }
        sp.method_64398(class_2561.method_43470("Shelter Core  ").method_27695(class_124.field_1075, class_124.field_1067)
                .method_10852(class_2561.method_43470("HP " + (int) method_6032() + "/" + (int) method_6063() + " · walkers don't spawn within " + RADIUS + " blocks · healing aura · raid target. Sneak + right-click to pack up. Iron block: repair.").method_27692(class_124.field_1080)));
        if (player.method_5998(hand).method_31574(net.minecraft.class_1802.field_8773) && method_6032() < method_6063()) {
            method_6025(60); if (!sp.method_68878()) player.method_5998(hand).method_7934(1);
        }
        return class_1269.field_5812;
    }

    @Override
    public boolean method_64397(class_3218 level, class_1282 source, float amount) {
        if (source.method_5529() instanceof class_1657 p && owner != null && owner.equals(p.method_5667())) return false;
        return super.method_64397(level, source, amount);
    }

    @Override
    public void method_6078(class_1282 source) {
        if (method_73183() instanceof class_3218 sl) {
            sl.method_65096(class_2398.field_11236, method_23317(), method_23318() + 0.5, method_23321(), 3, 0.3, 0.3, 0.3, 0);
            sl.method_8649(new class_1542(sl, method_23317(), method_23318() + 0.5, method_23321(), new class_1799(com.kiyamet.registry.ModItems.get("tech_core"))));
            class_3222 p = owner == null ? null : sl.method_8503().method_3760().method_14602(owner);
            if (p != null) p.method_64398(class_2561.method_43470("Your Shelter Core was destroyed!").method_27695(class_124.field_1079, class_124.field_1067));
        }
        super.method_6078(source);
    }

    @Override public boolean method_5974(double d) { return false; }
    @Override public boolean method_6094() { return true; }
    @Override public boolean method_5810() { return false; }
    @Override protected boolean method_27071(class_3218 level) { return false; }
    @Override public boolean method_5931() { return false; }

    @Override
    protected void method_5652(class_11372 out) {
        super.method_5652(out);
        if (owner != null) out.method_71469("Owner", owner.toString());
    }

    @Override
    protected void method_5749(class_11368 in) {
        super.method_5749(in);
        String o = in.method_71428("Owner", "");
        if (!o.isEmpty()) try { owner = UUID.fromString(o); } catch (IllegalArgumentException ignored) {}
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar c) {
        c.add(new AnimationController<ShelterCore>("main", 0, t -> t.setAndContinue(IDLE)));
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    public static class CoreItem extends class_1792 {
        public CoreItem(class_1793 p) { super(p); }

        @Override
        public class_1269 method_7884(class_1838 ctx) {
            if (!(ctx.method_8045() instanceof class_3218 level) || !(ctx.method_8036() instanceof class_3222 p)) return class_1269.field_5812;
            for (ShelterCore c : level.method_8390(ShelterCore.class, p.method_5829().method_1014(512), c -> p.method_5667().equals(c.owner))) {
                p.method_7353(class_2561.method_43470("You already have a Shelter Core at " + c.method_24515().method_23854() + ".").method_27692(class_124.field_1061), true);
                return class_1269.field_5814;
            }
            ShelterCore c = ModTwd.SHELTER_CORE.method_5883(level, class_3730.field_16471);
            if (c == null) return class_1269.field_5814;
            class_2338 at = ctx.method_8037().method_10093(ctx.method_8038());
            c.method_5814(at.method_10263() + 0.5, at.method_10264(), at.method_10260() + 0.5);
            c.owner = p.method_5667();
            level.method_8649(c);
            p.setAttached(BaseRaids.BASE, at);
            level.method_8396(null, at, class_3417.field_14703, class_3419.field_15245, 1f, 1.2f);
            p.method_64398(class_2561.method_43470("Shelter Core online. This is your base now: no walkers spawn within " + RADIUS + " blocks, everyone nearby heals. Raiders will come here.").method_27692(class_124.field_1075));
            if (!p.method_68878()) ctx.method_8041().method_7934(1);
            return class_1269.field_5812;
        }
    }
}
