package com.kiyamet.twd;

import com.kiyamet.Kiyamet;
import com.kiyamet.entity.KZombie;
import com.kiyamet.entity.ZombieKind;
import com.kiyamet.npc.*;
import com.kiyamet.registry.ModItems;
import com.kiyamet.skill.Skill;
import com.kiyamet.skill.SkillManager;
import com.kiyamet.vehicle.ModVehicles;
import com.kiyamet.vehicle.VehicleEntity;
import com.kiyamet.vehicle.VehicleKind;
import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2595;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3730;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import java.util.*;

/**
 * "The Long Road": a 200-chapter story in four books told at the mission boards, GTA-style. Marcus, who runs the settlement,
 * sends you out: medicine runs, a missing scout, a raider camp, a truck, a siege, a herd, a heist, and the
 * Commander himself. Objectives show on the action bar with an arrow and distance; dying fails the mission
 * (just start it again from any board).
 */
public final class Story {
    /** "chapter;stage;x;y;z;bx;by;bz;targetUuid;count;deadline" */
    public static final AttachmentType<String> STATE = AttachmentRegistry.create(Kiyamet.id("story"),
            b -> b.initializer(() -> "1;0").persistent(Codec.STRING).copyOnDeath());

    static final String MARCUS = "Marcus", ELENA = "Elena", DANI = "Dani", RADIO = "Radio";
    static final class_124 MC = class_124.field_1060, EC = class_124.field_1076, DC = class_124.field_1075, RC = class_124.field_1061;

    public static final StoryChapters.Chapter[] CHAPTERS = StoryChapters.ALL;
    public static int total() { return CHAPTERS.length; }
    public static int reward(int ch) { return 15 + ch * 4 + (ch % 10 == 0 ? 40 : 0); }

    // stages: 0 = not started, 1 = go to target, 2 = do the thing there, 3 = return to the board, 4+ = special
    private static final Map<UUID, Set<UUID>> TRACKED = new HashMap<>();
    private static final Map<UUID, Integer> KILLS = new HashMap<>();

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.method_3780() % 10 != 0) return;
            for (class_3222 p : server.method_3760().method_14571()) tick(p);
        });
        ServerLivingEntityEvents.AFTER_DEATH.register((e, src) -> {
            if (e instanceof class_3222 p && stage(p) > 0) fail(p, "You died");
            for (Map.Entry<UUID, Set<UUID>> en : TRACKED.entrySet()) if (en.getValue().contains(e.method_5667())) {
                KILLS.merge(en.getKey(), 1, Integer::sum);
                class_3222 p = ((class_3218) e.method_73183()).method_8503().method_3760().method_14602(en.getKey());
                if (p == null) continue;
                String[] st = state(p);
                if (e.method_5667().toString().equals(st[8])) onTargetDeath(p, (class_1309) e);
            }
        });
    }

    // ------------------------------------------------------------------ state

    static String[] state(class_3222 p) {
        String[] s = p.getAttachedOrElse(STATE, "1;0").split(";");
        String[] out = new String[11];
        Arrays.fill(out, "0");
        out[8] = "";
        System.arraycopy(s, 0, out, 0, Math.min(s.length, 11));
        return out;
    }
    static void save(class_3222 p, String[] s) { p.setAttached(STATE, String.join(";", s)); }
    public static int chapter(class_3222 p) { return Integer.parseInt(state(p)[0]); }
    public static int stage(class_3222 p) { return Integer.parseInt(state(p)[1]); }
    static class_2338 target(String[] s) { return new class_2338(Integer.parseInt(s[2]), Integer.parseInt(s[3]), Integer.parseInt(s[4])); }
    static class_2338 board(String[] s) { return new class_2338(Integer.parseInt(s[5]), Integer.parseInt(s[6]), Integer.parseInt(s[7])); }
    static void setStage(class_3222 p, int stage) { String[] s = state(p); s[1] = String.valueOf(stage); save(p, s); }

    // ------------------------------------------------------------------ starting

    /** Called from a mission board. */
    public static void offer(class_3222 p, MissionBoard board) {
        int ch = chapter(p);
        if (ch > CHAPTERS.length) { Talk.sayAs(p, MARCUS, MC, "You've done more than anyone could ask. The road is yours now."); return; }
        if (stage(p) > 0) { Talk.sayAs(p, MARCUS, MC, "You're already on a job. Finish it first."); return; }
        StoryChapters.Chapter c = CHAPTERS[ch - 1];
        int d = 0;
        for (String line : c.intro()) { speak(p, d, line); d += Math.min(60, 20 + line.length() / 2); }
        Talk.askAs(p, board, MARCUS, MC, d, "", null,
                new Talk.Option(c.accept(), pl -> start(pl, board, ch)),
                new Talk.Option("Not now.", pl -> Talk.sayAs(pl, MARCUS, MC, "Don't take too long.")));
    }

    static void speak(class_3222 p, int delay, String line) {
        String[] kv = line.contains("|") ? line.split("\\|", 2) : new String[]{MARCUS, line};
        class_124 col = kv[0].equals(ELENA) ? EC : kv[0].equals(DANI) ? DC : kv[0].equals(MARCUS) ? MC : class_124.field_1054;
        Talk.sayAsLater(p, delay, kv[0], col, kv[1]);
    }

    static StoryChapters.Chapter ch(class_3222 p) { return CHAPTERS[Math.min(CHAPTERS.length, chapter(p)) - 1]; }

    static void start(class_3222 p, MissionBoard board, int ch) {
        class_3218 level = (class_3218) p.method_51469();
        StoryChapters.Chapter c = CHAPTERS[ch - 1];
        class_2338 b = board.method_24515();
        boolean defend = c.type() == StoryChapters.Type.DEFEND;
        int dist = defend ? 0 : Math.min(600, 110 + ch * 3);
        class_2338 t = b;
        if (!defend) {
            double a = level.field_9229.method_43058() * Math.PI * 2;
            class_2338 raw = b.method_10069((int) (Math.cos(a) * dist), 0, (int) (Math.sin(a) * dist));
            t = level.method_8598(net.minecraft.class_2902.class_2903.field_13203, raw);
        }
        String[] s = {String.valueOf(ch), defend ? "4" : "1", "" + t.method_10263(), "" + t.method_10264(), "" + t.method_10260(), "" + b.method_10263(), "" + b.method_10264(), "" + b.method_10260(), "", "0", "0"};
        save(p, s);
        TRACKED.put(p.method_5667(), new HashSet<>());
        KILLS.put(p.method_5667(), 0);
        Cinema.chapter(p, ch, c.title(), c.tagline(), defend ? null : t);
        if (defend) siegeWave(p, level, b, 0);
    }

    // ------------------------------------------------------------------ ticking

    private static void tick(class_3222 p) {
        String[] s = state(p);
        int chn = Integer.parseInt(s[0]), stage = Integer.parseInt(s[1]);
        if (stage == 0 || chn > CHAPTERS.length) return;
        StoryChapters.Chapter c = CHAPTERS[chn - 1];
        class_3218 level = (class_3218) p.method_51469();
        class_2338 t = target(s), b = board(s);
        Set<UUID> tracked = TRACKED.computeIfAbsent(p.method_5667(), k -> new HashSet<>());
        class_1297 tgt = s[8].isEmpty() ? null : level.method_66347(UUID.fromString(s[8]));
        switch (stage) {
            case 1 -> {
                hud(p, goal(c), t);
                if (p.method_24515().method_10262(t) < 28 * 28) arrive(p, level, chn, t);
            }
            case 2 -> {
                switch (c.type()) {
                    case FETCH -> {
                        hud(p, "Take the " + c.item() + " from the crate", t);
                        if (hasQuestItem(p, c.item())) { setStage(p, 3); Talk.sayAs(p, RADIO, RC, pick(level, "Got it? Get back here, fast.", "Good. Now get out of there!", "That's it. Come home.")); }
                    }
                    case RESCUE -> {
                        if (tgt instanceof HumanEntity d && d.method_5805()) {
                            if (d.isOwnedBy(p)) { setStage(p, 3); Talk.say(p, d, "Let's go. I'll stay close."); }
                            else hud(p, "Reach " + name(c) + " and talk to them", d.method_24515());
                        } else if (tgt == null && level.method_8477(t) && p.method_24515().method_10262(t) < 48 * 48 && !s[8].isEmpty()) fail(p, name(c) + " didn't make it");
                    }
                    case KILL -> hud(p, "Kill " + name(c), tgt != null ? tgt.method_24515() : t);
                    case DRIVE -> {
                        if (tgt instanceof VehicleEntity v && v.method_5805()) {
                            hud(p, v.method_5626(p) ? "Drive it back to the settlement" : "Get in the vehicle", v.method_5626(p) ? b : v.method_24515());
                            if (v.method_5626(p) && v.method_24515().method_10262(b) < 18 * 18) complete(p, level);
                        } else if (tgt == null && level.method_8477(t) && p.method_24515().method_10262(t) < 64 * 64 && !s[8].isEmpty()) fail(p, "The vehicle was destroyed");
                    }
                    case HERD -> {
                        int k = KILLS.getOrDefault(p.method_5667(), 0);
                        long left = Long.parseLong(s[10]) - level.method_75260();
                        p.method_7353(class_2561.method_43470("▶ Thin the herd: " + k + " / " + c.count() + "   ⏱ " + Math.max(0, left / 20) + "s").method_27692(class_124.field_1065), true);
                        if (k >= c.count()) complete(p, level);
                        else if (left <= 0) fail(p, "The herd got through");
                    }
                    default -> {}
                }
            }
            case 3 -> {
                if (c.type() == StoryChapters.Type.RESCUE && tgt != null && !tgt.method_5805()) { fail(p, name(c) + " didn't make it"); return; }
                hud(p, c.type() == StoryChapters.Type.RESCUE ? "Bring " + name(c) + " home" : !c.item().isEmpty() ? "Bring the " + c.item() + " to Marcus" : "Return to Marcus", b);
                if (p.method_24515().method_10262(b) < 10 * 10) {
                    if (c.type() == StoryChapters.Type.RESCUE && tgt instanceof HumanEntity d && d.method_5739(p) > 16) {
                        p.method_7353(class_2561.method_43470("Wait for " + name(c) + "!").method_27692(class_124.field_1054), true);
                    } else if (c.item().isEmpty() || takeQuestItem(p, c.item())) complete(p, level);
                    else p.method_7353(class_2561.method_43470("You lost the " + c.item() + "! Go back for it.").method_27692(class_124.field_1061), true);
                }
            }
            default -> { // 4.. : defend waves
                int wave = stage - 4;
                tracked.removeIf(u -> !(level.method_66347(u) instanceof class_1309 l) || !l.method_5805());
                p.method_7353(class_2561.method_43470("▶ Defend the settlement - wave " + (wave + 1) + "/" + c.count() + " · " + tracked.size() + " left").method_27692(class_124.field_1065), true);
                if (tracked.isEmpty() && level.method_75260() > Long.parseLong(s[10])) {
                    if (wave + 1 >= c.count()) complete(p, level);
                    else { setStage(p, stage + 1); siegeWave(p, level, b, wave + 1); }
                }
            }
        }
    }

    static String pick(class_3218 l, String... o) { return o[l.field_9229.method_43048(o.length)]; }

    static String name(StoryChapters.Chapter c) {
        String n = c.target().replace("+", "").replace("!", "").replace("&truck", "");
        if (n.startsWith("boss:")) { try { return com.kiyamet.boss.BossKind.valueOf(n.substring(5).toUpperCase()).title; } catch (IllegalArgumentException e) { return "the beast"; } }
        return n;
    }

    static String goal(StoryChapters.Chapter c) {
        return switch (c.type()) {
            case FETCH -> "Find the " + c.item();
            case RESCUE -> "Find " + name(c);
            case KILL -> "Hunt down " + name(c);
            case DRIVE -> "Find the vehicle";
            case HERD -> "Meet the herd";
            default -> "Go";
        };
    }

    private static final String[] ARROWS = {"↑", "↗", "→", "↘", "↓", "↙", "←", "↖"};

    static void hud(class_3222 p, String text, class_2338 to) {
        double dx = to.method_10263() + 0.5 - p.method_23317(), dz = to.method_10260() + 0.5 - p.method_23321();
        int dist = (int) Math.sqrt(dx * dx + dz * dz);
        float yawTo = (float) (class_3532.method_15349(dz, dx) * class_3532.field_29848) - 90f;
        float rel = class_3532.method_15393(yawTo - p.method_36454());
        String arrow = ARROWS[Math.floorMod(Math.round(rel / 45f), 8)];
        p.method_7353(class_2561.method_43470("▶ " + text + "   ").method_27692(class_124.field_1065)
                .method_10852(class_2561.method_43470(arrow + " " + dist + " m").method_27695(class_124.field_1054, class_124.field_1067)), true);
    }

    // ------------------------------------------------------------------ encounters

    private static final ZombieKind[] WALKERS = {ZombieKind.FARMER, ZombieKind.WOMAN, ZombieKind.NURSE, ZombieKind.DOCTOR, ZombieKind.POLICE, ZombieKind.CRAWLER, ZombieKind.TOXIC};

    private static void walkers(class_3222 p, class_3218 level, class_2338 at, int n) {
        for (int i = 0; i < n; i++) {
            class_2338 q = level.method_8598(net.minecraft.class_2902.class_2903.field_13203, at.method_10069(level.field_9229.method_43048(17) - 8, 0, level.field_9229.method_43048(17) - 8));
            KZombie z = ModEntities_walker(level, q, WALKERS[level.field_9229.method_43048(WALKERS.length)]);
            if (z != null) track(p, z);
        }
    }

    private static KZombie ModEntities_walker(class_3218 level, class_2338 at, ZombieKind k) {
        KZombie z = com.kiyamet.entity.ModEntities.ZOMBIES.get(k).method_5883(level, class_3730.field_16467);
        if (z == null) return null;
        z.method_5814(at.method_10263() + 0.5, at.method_10264(), at.method_10260() + 0.5);
        z.method_5943(level, level.method_8404(at), class_3730.field_16467, null);
        z.method_5971();
        level.method_8649(z);
        return z;
    }

    private static HumanEntity human(class_3222 p, class_3218 level, class_2338 at, Faction f, Role r, int lv, String name) {
        class_2338 q = level.method_8598(net.minecraft.class_2902.class_2903.field_13203, at.method_10069(level.field_9229.method_43048(9) - 4, 0, level.field_9229.method_43048(9) - 4));
        HumanEntity h = ModHumans.spawn(level, q, f, r, lv, null);
        if (h == null) return null;
        if (name != null) h.method_5665(class_2561.method_43470(name));
        h.method_5971();
        track(p, h);
        return h;
    }

    private static void track(class_3222 p, class_1297 e) { TRACKED.computeIfAbsent(p.method_5667(), k -> new HashSet<>()).add(e.method_5667()); }

    /** Enemy level: grows with the chapter and with your power. */
    private static int lv(class_3222 p, int ch) { return class_3532.method_15340(8 + Math.round(ch * 1.4f) + SkillManager.get(p).totalPower() / 40, 5, 290); }

    /** How many guards: the chapter's base count, growing with each chapter. */
    private static int scale(int base, int ch) { return Math.min(40, Math.round(base * Math.min(2.2f, 1 + ch / 60f))); }

    private static void guards(class_3222 p, class_3218 level, class_2338 at, char g, int n, int ch) {
        for (int i = 0; i < n; i++) {
            char k = g == 'X' ? "WWRMB".charAt(level.field_9229.method_43048(ch >= 29 ? 5 : 4)) : g;
            switch (k) {
                case 'R' -> human(p, level, at, Faction.RAIDER, i == 0 ? Role.LEADER : Role.MEMBER, lv(p, ch), null);
                case 'M' -> human(p, level, at, Faction.WHISPERER, Role.MEMBER, lv(p, ch), null);
                case 'B' -> robot(p, level, at, ch);
                default -> walkers(p, level, at, 1);
            }
        }
        if (g == 'M') walkers(p, level, at, n / 2);   // the masked always bring walkers
    }

    private static void robot(class_3222 p, class_3218 level, class_2338 at, int ch) {
        com.kiyamet.robot.RobotKind k = ch >= 36 && level.field_9229.method_43057() < 0.3f ? com.kiyamet.robot.RobotKind.ROBOT_HEAVY
                : level.field_9229.method_43057() < 0.25f ? com.kiyamet.robot.RobotKind.SCOUT_DRONE : com.kiyamet.robot.RobotKind.ROBOT_TROOPER;
        var r = com.kiyamet.robot.ModRobots.TYPES.get(k).method_5883(level, class_3730.field_16467);
        if (r == null) return;
        class_2338 q = level.method_8598(net.minecraft.class_2902.class_2903.field_13203, at.method_10069(level.field_9229.method_43048(11) - 5, 0, level.field_9229.method_43048(11) - 5));
        r.method_5814(q.method_10263() + 0.5, q.method_10264(), q.method_10260() + 0.5);
        r.method_5971();
        level.method_8649(r);
        track(p, r);
    }

    private static void arrive(class_3222 p, class_3218 level, int chn, class_2338 t) {
        StoryChapters.Chapter c = CHAPTERS[chn - 1];
        String[] s = state(p);
        s[1] = "2";
        int n = scale(c.count(), chn);
        switch (c.type()) {
            case FETCH -> {
                class_2338 at = level.method_8598(net.minecraft.class_2902.class_2903.field_13203, t);
                level.method_8652(at, class_2246.field_10034.method_9564(), 3);
                if (level.method_8321(at) instanceof class_2595 chest) {
                    chest.method_5447(13, questItem(c.item()));
                    chest.method_5447(11, new class_1799(ModItems.get("medkit"), 1 + level.field_9229.method_43048(2)));
                    chest.method_5447(15, com.kiyamet.money.Money.stack((3 + chn / 4) * com.kiyamet.money.Money.RATE));
                }
                s[2] = "" + at.method_10263(); s[3] = "" + at.method_10264(); s[4] = "" + at.method_10260();
                guards(p, level, at, c.guards(), n, chn);
                Talk.sayAs(p, RADIO, RC, pick(level, "Careful. You won't be alone out there.", "Eyes open. Something's guarding it.", "Stay low. Grab it and go."));
            }
            case RESCUE -> {
                HumanEntity d = human(p, level, t, Faction.SURVIVOR, Role.MEMBER, lv(p, chn), name(c));
                if (d != null) { d.method_6033(d.method_6063() * 0.35f); s[8] = d.method_5667().toString(); TRACKED.get(p.method_5667()).remove(d.method_5667()); }
                guards(p, level, t, c.guards(), n, chn);
                if (d != null) Talk.say(p, d, pick(level, "Over here! Help me!", "Please - they've got me pinned!", "Is someone there?! I'm hurt!"));
            }
            case KILL -> {
                class_1309 target;
                String tn = c.target();
                if (tn.startsWith("boss:")) {
                    target = null;
                    try {
                        var kind = com.kiyamet.boss.BossKind.valueOf(tn.substring(5).toUpperCase());
                        var boss = com.kiyamet.boss.ModBosses.TYPES.get(kind).method_5883(level, class_3730.field_16467);
                        if (boss != null) { boss.method_5814(t.method_10263() + 0.5, t.method_10264(), t.method_10260() + 0.5); boss.method_5971(); level.method_8649(boss); target = boss; track(p, boss); }
                    } catch (IllegalArgumentException ignored) {}
                } else {
                    boolean cmd = tn.startsWith("!");
                    target = human(p, level, t, c.guards() == 'M' ? Faction.WHISPERER : Faction.RAIDER, cmd ? Role.COMMANDER : Role.LEADER, cmd ? 300 : Math.min(290, lv(p, chn) + 20), name(c));
                }
                if (target != null) { s[8] = target.method_5667().toString(); Cinema.boss(p, target, name(c)); }
                if (c.target().contains("&truck")) {
                    List<HumanEntity> crew = new ArrayList<>();
                    for (int i = 0; i < 5; i++) { HumanEntity h = human(p, level, t, Faction.RAIDER, Role.MEMBER, lv(p, chn), null); if (h != null) crew.add(h); }
                    ModVehicles.raiderRide(level, t, crew, true, 9999);
                }
                guards(p, level, t, c.guards(), n, chn);
                Talk.sayAs(p, name(c), RC, pick(level, "You shouldn't have come here.", "So you're the one everyone talks about. Let's see.", "Nobody leaves this place alive.", "..."));
            }
            case DRIVE -> {
                VehicleKind k;
                try { k = VehicleKind.valueOf(c.target()); } catch (IllegalArgumentException e) { k = VehicleKind.PICKUP; }
                VehicleEntity v = ModVehicles.spawn(level, k, t.method_10263() + 0.5, t.method_10264(), t.method_10260() + 0.5, level.field_9229.method_43057() * 360, 0.5f, 0.7f);
                if (v != null) s[8] = v.method_5667().toString();
                guards(p, level, t, c.guards(), n, chn);
                Talk.sayAs(p, RADIO, RC, "There it is. Keys should still be in it.");
            }
            case HERD -> {
                walkers(p, level, t, c.count() + 10);
                s[10] = String.valueOf(level.method_75260() + 20L * Math.max(240, 480 - chn));
                KILLS.put(p.method_5667(), 0);
                Talk.sayAs(p, RADIO, RC, "There they are. Thin them out before they reach us!");
            }
            default -> {}
        }
        save(p, s);
    }

    private static void onTargetDeath(class_3222 p, class_1309 e) {
        StoryChapters.Chapter c = ch(p);
        if (c.type() != StoryChapters.Type.KILL || stage(p) != 2) return;
        class_3218 level = (class_3218) e.method_73183();
        if (!c.item().isEmpty()) level.method_8649(new class_1542(level, e.method_23317(), e.method_23318() + 0.5, e.method_23321(), questItem(c.item())));
        Talk.sayAs(p, RADIO, RC, c.item().isEmpty() ? "Is it done? ...Come home." : "Grab the " + c.item() + " and come home.");
        setStage(p, 3);
    }

    private static void siegeWave(class_3222 p, class_3218 level, class_2338 b, int wave) {
        StoryChapters.Chapter c = ch(p);
        int chn = chapter(p);
        String[] s = state(p);
        s[10] = String.valueOf(level.method_75260() + 100);
        save(p, s);
        double a = level.field_9229.method_43058() * Math.PI * 2;
        class_2338 at = level.method_8598(net.minecraft.class_2902.class_2903.field_13203, b.method_10069((int) (Math.cos(a) * 32), 0, (int) (Math.sin(a) * 32)));
        int n = Math.min(35, scale(4 + wave * 3, chn));
        guards(p, level, at, c.guards(), n, chn);
        if (c.guards() != 'W') walkers(p, level, at, 2 + wave * 2);
        for (UUID u : TRACKED.getOrDefault(p.method_5667(), Set.of())) if (level.method_66347(u) instanceof net.minecraft.class_1308 m && m.method_5968() == null) m.method_5980(p);
        level.method_8396(null, b, class_3417.field_17266.comp_349(), class_3419.field_15251, 3f, 1f);
        Talk.sayAs(p, MARCUS, MC, wave == 0 ? "Here they come! Everyone to the walls!" : wave + 1 == c.count() ? "Last push - they're throwing everything at us!" : "More of them! Hold!");
    }

    // ------------------------------------------------------------------ end

    static void complete(class_3222 p, class_3218 level) {
        int chn = chapter(p);
        StoryChapters.Chapter c = CHAPTERS[chn - 1];
        String[] st = state(p);
        class_1297 tgt = st[8].isEmpty() ? null : level.method_66347(UUID.fromString(st[8]));
        if (c.type() == StoryChapters.Type.RESCUE && tgt instanceof HumanEntity h && !c.target().startsWith("+")) {
            Talk.say(p, h, "Thank you. I'll be safe here now.");
            h.method_31472();
        }
        save(p, new String[]{String.valueOf(chn + 1), "0"});
        TRACKED.remove(p.method_5667());
        int reward = reward(chn);
        Cinema.passed(p, reward, chn == CHAPTERS.length);
        com.kiyamet.money.Money.give(p, reward * com.kiyamet.money.Money.RATE);
        SkillManager.addXp(p, Skill.SURVIVAL, 150 + chn * 40);
        SkillManager.addXp(p, Skill.SWORDS, 100 + chn * 30);
        if (chn % 10 == 0) Shop.give(p, new class_1799(ModItems.get("tech_core"), 1 + chn / 20));
        if (chn % 5 == 0) { Shop.give(p, com.kiyamet.enchant.EnchantLoot.weapon(level, SkillManager.get(p).totalPower())); Shop.give(p, com.kiyamet.enchant.GunTomeItem.random(level.field_9229)); }
        if (chn == 8) Shop.give(p, new class_1799(net.minecraft.class_7923.field_41178.method_63535(Kiyamet.id("armored_truck_keys"))));
        int d = 20;
        for (String o : c.outro()) { speak(p, d, o); d += 50; }
        if (chn == CHAPTERS.length)
            Talk.later(p, d + 20, () -> p.method_64398(class_2561.method_43470("★ THE LONG ROAD - COMPLETE. Thank you for playing the story.").method_27695(class_124.field_1065, class_124.field_1067)));
        else Talk.later(p, d + 20, () -> p.method_64398(class_2561.method_43470("Chapter " + (chn + 1) + " is waiting at any mission board.").method_27692(class_124.field_1080)));
    }

    static void fail(class_3222 p, String why) {
        String[] s = state(p);
        s[1] = "0";
        save(p, new String[]{s[0], "0"});
        Set<UUID> t = TRACKED.remove(p.method_5667());
        if (t != null) for (UUID u : t) {
            class_1297 e = ((class_3218) p.method_51469()).method_66347(u);
            if (e instanceof HumanEntity h && h.faction() == Faction.RAIDER && !h.method_16914()) h.method_31472();
        }
        Cinema.failed(p, why + " - try again from a mission board");
    }

    // ------------------------------------------------------------------ quest items

    static class_1799 questItem(String name) {
        class_1799 s = new class_1799(ModTwd.QUEST_ITEM);
        class_2487 tag = new class_2487();
        tag.method_10582("Quest", name);
        s.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
        s.method_57379(class_9334.field_49631, class_2561.method_43470(name).method_27694(st -> st.method_10978(false).method_10977(class_124.field_1065)));
        return s;
    }

    static boolean isQuest(class_1799 s, String name) {
        return s.method_31574(ModTwd.QUEST_ITEM) && s.method_58695(class_9334.field_49628, class_9279.field_49302).method_57461().method_68564("Quest", "").equals(name);
    }

    static boolean hasQuestItem(class_3222 p, String name) {
        for (int i = 0; i < p.method_31548().method_5439(); i++) if (isQuest(p.method_31548().method_5438(i), name)) return true;
        return false;
    }

    static boolean takeQuestItem(class_3222 p, String name) {
        for (int i = 0; i < p.method_31548().method_5439(); i++) if (isQuest(p.method_31548().method_5438(i), name)) { p.method_31548().method_5438(i).method_7934(1); return true; }
        return false;
    }

    /** The person you came to rescue: talk to them (a medkit or bandage in hand heals them) and they follow you. */
    public static boolean interact(class_3222 p, HumanEntity h) {
        String[] s = state(p);
        if (!"2".equals(s[1]) || !h.method_5667().toString().equals(s[8])) return false;
        class_1799 held = p.method_6047();
        if (held.method_31574(ModItems.get("medkit")) || held.method_31574(ModItems.get("bandage"))) { held.method_7934(1); h.method_6025(12); Talk.say(p, h, "Oh god, that's better. Thank you."); }
        else Talk.say(p, h, "Marcus sent you? ...Okay. Get me out of here.");
        h.setOwner(p);
        return true;
    }

    static void title(class_3222 p, class_2561 t, class_2561 sub) {
        p.field_13987.method_14364(new class_5905(10, 70, 20));
        p.field_13987.method_14364(new class_5903(sub));
        p.field_13987.method_14364(new class_5904(t));
    }

    private Story() {}
}
