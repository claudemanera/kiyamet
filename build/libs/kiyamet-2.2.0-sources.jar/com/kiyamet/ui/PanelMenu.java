package com.kiyamet.ui;

import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3917;

/** Base for 6-row button panels: subclasses draw into {@link #c} in {@link #draw()} and react in {@link #click}. */
public abstract class PanelMenu extends class_1707 {
    protected final class_1277 c;
    protected final class_3222 player;

    protected PanelMenu(int id, class_1661 inv, class_3222 player) {
        this(id, inv, new class_1277(54), player);
    }

    private PanelMenu(int id, class_1661 inv, class_1277 c, class_3222 player) {
        super(class_3917.field_17327, id, inv, c, 6);
        this.c = c;
        this.player = player;
    }

    protected abstract void draw();

    /** @return true if something changed (redraw + click sound). */
    protected abstract boolean click(int slot, class_1713 type);

    protected void redraw() {
        c.method_5448();
        for (int i = 0; i < 54; i++) c.method_5447(i, i < 9 || i >= 45 ? Ui.dark() : class_1799.field_8037);
        draw();
    }

    @Override
    public void method_7593(int slot, int button, class_1713 type, class_1657 p) {
        if (slot < 0 || slot >= 54) { if (type != class_1713.field_7794) super.method_7593(slot, button, type, p); return; }
        if (click(slot, type)) {
            player.method_51469().method_8396(null, player.method_24515(), class_3417.field_15015.comp_349(), class_3419.field_15248, 0.4f, 1.2f);
            if (player.field_7512 == this) redraw();
        }
    }

    @Override
    public class_1799 method_7601(class_1657 p, int index) { return class_1799.field_8037; }

    @Override
    public void method_7595(class_1657 p) {
        c.method_5448();
        super.method_7595(p);
    }

    @Override
    public boolean method_7597(class_1657 p) { return true; }

    public static class_2561 title(String s) { return class_2561.method_43470(s); }
}
