package com.kiyamet.ui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

/** Small helpers for the chest-style menus (named icons, lore, glint, frame panes, progress bars). */
public final class Ui {
    public static class_1792 item(String id) { return class_7923.field_41178.method_63535(class_2960.method_60654(id)); }

    public static class_1799 icon(class_1792 item, class_2561 name, class_2561... lore) {
        class_1799 s = new class_1799(item);
        s.method_57379(class_9334.field_49631, name.method_27661().method_27694(st -> st.method_10978(false)));
        if (lore.length > 0) lore(s, List.of(lore));
        return s;
    }

    /** A custom logo (assets/kiyamet/items/icon/<name>.json) drawn on a plain item. */
    public static class_1799 logo(String name, class_2561 title, class_2561... lore) {
        class_1799 s = icon(class_1802.field_8407, title, lore);
        s.method_57379(net.minecraft.class_9334.field_54199, class_2960.method_60655("kiyamet", "icon/" + name));
        return s;
    }

    public static class_1799 lore(class_1799 s, List<class_2561> lines) {
        List<class_2561> out = new ArrayList<>();
        for (class_2561 c : lines) out.add(c.method_27661().method_27694(st -> st.method_10978(false)));
        s.method_57379(class_9334.field_49632, new class_9290(out));
        return s;
    }

    public static class_1799 glint(class_1799 s, boolean on) {
        s.method_57379(class_9334.field_49641, on);
        return s;
    }

    public static class_1799 pane(class_1792 pane) {
        class_1799 s = new class_1799(pane);
        s.method_57379(class_9334.field_49631, class_2561.method_43470(" "));
        return s;
    }

    public static class_1799 frame() { return pane(class_1802.field_8871); }
    public static class_1799 dark() { return pane(class_1802.field_8157); }

    public static class_2561 text(String s, class_124... f) { return class_2561.method_43470(s).method_27695(f); }

    /** ■■■■■□□□□□ style bar, green filled part. */
    public static class_2561 bar(double frac, int width) {
        int n = (int) Math.round(Math.max(0, Math.min(1, frac)) * width);
        return class_2561.method_43470("■".repeat(n)).method_27692(class_124.field_1060)
                .method_10852(class_2561.method_43470("■".repeat(width - n)).method_27692(class_124.field_1063));
    }

    private Ui() {}
}
