package com.kiyamet.vehicle;

import com.kiyamet.Kiyamet;
import com.kiyamet.npc.HumanEntity;
import io.netty.buffer.ByteBuf;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_2170;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import com.mojang.brigadier.arguments.IntegerArgumentType;

/**
 * 1.6 autopilot: a companion drives your vehicle to a spot. The Autopilot key (Y) sends your newest Xaero's map waypoint;
 * without Xaero's, use /twd drive <x> <z>.
 */
public final class Autopilot {
    public record Drive(int x, int z, String name) implements class_8710 {
        public static final class_9154<Drive> TYPE = new class_9154<>(Kiyamet.id("autopilot"));
        public static final class_9139<ByteBuf, Drive> CODEC = class_9139.method_56436(class_9135.field_48550, Drive::x, class_9135.field_48550, Drive::z, class_9135.field_48554, Drive::name, Drive::new);
        @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
    }

    public static void init() {
        PayloadTypeRegistry.playC2S().register(Drive.TYPE, Drive.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(Drive.TYPE, (d, ctx) -> ctx.server().execute(() -> {
            if (d.name().equals("?")) { ctx.player().method_7353(class_2561.method_43470("No Xaero's waypoint found. Make one on the map, or use /twd drive <x> <z>.").method_27692(class_124.field_1054), false); return; }
            go(ctx.player(), d.x(), d.z(), d.name());
        }));
        CommandRegistrationCallback.EVENT.register((disp, ctx, env) -> disp.register(class_2170.method_9247("twd").then(class_2170.method_9247("drive")
                .then(class_2170.method_9244("x", IntegerArgumentType.integer()).then(class_2170.method_9244("z", IntegerArgumentType.integer()).executes(c -> {
                    go(c.getSource().method_9207(), IntegerArgumentType.getInteger(c, "x"), IntegerArgumentType.getInteger(c, "z"), "");
                    return 1;
                }))))));
    }

    static void go(class_3222 p, int x, int z, String name) {
        class_3218 level = p.method_51469();
        VehicleEntity v = p.method_5854() instanceof VehicleEntity ve ? ve
                : level.method_8390(VehicleEntity.class, p.method_5829().method_1014(10), e -> e.method_31483() == null || e.method_31483() == p).stream().findFirst().orElse(null);
        if (v == null) { p.method_7353(class_2561.method_43470("Get in a vehicle (or stand next to one) first.").method_27692(class_124.field_1061), false); return; }
        HumanEntity driver = v.method_31483() instanceof HumanEntity h && h.isOwnedBy(p) ? h : null;
        if (driver == null) for (var e : v.method_5685()) if (e instanceof HumanEntity h && h.isOwnedBy(p)) { driver = h; break; }
        if (driver == null) driver = level.method_8390(HumanEntity.class, p.method_5829().method_1014(24), h -> h.isOwnedBy(p) && !h.isAway()).stream()
                .min(java.util.Comparator.comparingDouble(h -> h.method_5858(p))).orElse(null);
        if (driver == null) { p.method_7353(class_2561.method_43470("You need a companion nearby to drive.").method_27692(class_124.field_1061), false); return; }
        if (!name.isEmpty()) p.method_64398(class_2561.method_43470("Waypoint: " + name).method_27692(class_124.field_1080));
        v.driveTo(p, driver, new class_243(x + 0.5, v.method_23318(), z + 0.5));
    }

    private Autopilot() {}
}
