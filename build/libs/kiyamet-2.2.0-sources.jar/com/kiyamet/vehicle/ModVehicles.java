package com.kiyamet.vehicle;

import com.kiyamet.Kiyamet;
import com.kiyamet.entity.KZombie;
import com.kiyamet.npc.HumanEntity;
import com.kiyamet.registry.ModItems;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1311;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public final class ModVehicles {
    public static final Map<VehicleKind, class_1299<VehicleEntity>> TYPES = new EnumMap<>(VehicleKind.class);

    static {
        for (VehicleKind k : VehicleKind.values()) {
            class_5321<class_1299<?>> key = class_5321.method_29179(class_7924.field_41266, Kiyamet.id(k.id));
            class_1299<VehicleEntity> type = class_1299.class_1300.<VehicleEntity>method_5903((t, l) -> new VehicleEntity(t, l, k), class_1311.field_17715)
                    .method_17687(k.width, k.height).method_55687(k.height * 0.8f).method_27299(10).method_19947().method_5905(key);
            TYPES.put(k, class_2378.method_39197(class_7923.field_41177, key, type));
        }
        for (VehicleKind k : VehicleKind.values())
            ModItems.custom(k.kitId(), p -> new KeyItem(p.method_7889(1).method_7894(k.armored ? net.minecraft.class_1814.field_8904 : net.minecraft.class_1814.field_8903), k));
    }

    public static void init() {
        TYPES.forEach((k, type) -> FabricDefaultAttributeRegistry.register(type, class_1308.method_26828()
                .method_26868(class_5134.field_23716, k.health)
                .method_26868(class_5134.field_23719, k.speed)
                .method_26868(class_5134.field_23724, k.armor)
                .method_26868(class_5134.field_23725, k.armored ? 8 : 0)
                .method_26868(class_5134.field_47761, k == VehicleKind.MOTORCYCLE ? 1.0 : k.scale > 2 ? 1.6 : 1.25)
                .method_26868(class_5134.field_23718, 1.0)
                .method_26868(class_5134.field_23717, 96)
                .method_26868(class_5134.field_49079, 6)));

        // inside a car the dead can't reach you as easily; inside armored vehicles not at all
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((e, src, amount) -> {
            if (!(e.method_5854() instanceof VehicleEntity v) || !(src.method_5529() instanceof KZombie)) return true;
            if (v.kind.armored) return false;
            if (v.kind == VehicleKind.ATV || v.kind == VehicleKind.MOTORCYCLE) return true;
            return e.method_59922().method_43057() < 0.4f;
        });
    }

    public static VehicleEntity spawn(class_3218 level, VehicleKind k, double x, double y, double z, float yaw, float fuelFrac, float hpFrac) {
        VehicleEntity v = TYPES.get(k).method_5883(level, class_3730.field_16467);
        if (v == null) return null;
        v.method_5814(x, y, z);
        v.method_36456(yaw); v.field_6283 = yaw; v.field_6241 = yaw;
        v.setFuel((int) (k.fuel * fuelFrac));
        v.method_6033((float) (k.health * hpFrac));
        level.method_8649(v);
        return v;
    }

    private static final VehicleKind[] WRECKS = {VehicleKind.SEDAN, VehicleKind.SEDAN, VehicleKind.PICKUP, VehicleKind.POLICE, VehicleKind.AMBULANCE, VehicleKind.ATV, VehicleKind.MOTORCYCLE, VehicleKind.ARMORED_SUV};

    /** An abandoned vehicle by the road: little fuel, banged up, sometimes something in the trunk. */
    public static void abandoned(class_3218 level, class_2338 at) {
        VehicleKind k = WRECKS[level.field_9229.method_43048(WRECKS.length)];
        VehicleEntity v = spawn(level, k, at.method_10263() + 0.5, at.method_10264(), at.method_10260() + 0.5, level.field_9229.method_43057() * 360, 0.05f + level.field_9229.method_43057() * 0.3f, 0.4f + level.field_9229.method_43057() * 0.4f);
        if (v == null || k.trunk == 0) return;
        String[][] loot = {{"minecraft:bread", "4"}, {"kiyamet:bandage", "2"}, {"minecraft:arrow", "16"}, {"kiyamet:fuel_canister", "1"}, {"kiyamet:circuit", "1"}, {"kiyamet:medkit", "1"}, {"kiyamet:dollar_20", "2"}, {"minecraft:iron_ingot", "3"}};
        if (level.field_9229.method_43057() < 0.2f) v.trunk().method_5447(0, com.kiyamet.enchant.EnchantLoot.weapon(level, 0));
        if (level.field_9229.method_43057() < 0.15f) v.trunk().method_5447(1, com.kiyamet.enchant.GunTomeItem.random(level.field_9229));
        int n = level.field_9229.method_43048(4);
        for (int i = 0; i < n; i++) {
            String[] l = loot[level.field_9229.method_43048(loot.length)];
            v.trunk().method_5447(level.field_9229.method_43048(v.trunk().method_5439()), new class_1799(com.kiyamet.ui.Ui.item(l[0]), Integer.parseInt(l[1])));
        }
    }

    /** Puts a raider group into a vehicle (rest walk). */
    public static VehicleEntity raiderRide(class_3218 level, class_2338 at, List<HumanEntity> raiders, boolean commander, int power) {
        VehicleKind k = commander ? VehicleKind.ARMORED_TRUCK : power >= 2500 && level.field_9229.method_43056() ? VehicleKind.ARMORED_SUV
                : new VehicleKind[]{VehicleKind.PICKUP, VehicleKind.PICKUP, VehicleKind.SEDAN, VehicleKind.MOTORCYCLE, VehicleKind.ATV}[level.field_9229.method_43048(5)];
        VehicleEntity v = spawn(level, k, at.method_10263() + 0.5, at.method_10264(), at.method_10260() + 0.5, level.field_9229.method_43057() * 360, 0.3f + level.field_9229.method_43057() * 0.4f, 1f);
        if (v == null) return null;
        int seat = 0;
        for (HumanEntity h : raiders) {
            if (seat >= k.seats.length) break;
            if (h.method_5873(v, true, true)) seat++;
        }
        return v;
    }

    /** Car keys: use on the ground to bring out the vehicle (half a tank). */
    public static class KeyItem extends class_1792 {
        final VehicleKind kind;
        public KeyItem(class_1793 p, VehicleKind kind) { super(p); this.kind = kind; }

        @Override
        public class_1269 method_7884(class_1838 ctx) {
            if (!(ctx.method_8045() instanceof class_3218 level) || !(ctx.method_8036() instanceof class_3222 p)) return class_1269.field_5812;
            class_2338 at = ctx.method_8037().method_10093(ctx.method_8038());
            if (!level.method_18026(TYPES.get(kind).method_58629(at.method_10263() + 0.5, at.method_10264(), at.method_10260() + 0.5))) {
                p.method_7353(class_2561.method_43470("Not enough room here.").method_27692(class_124.field_1061), true);
                return class_1269.field_5814;
            }
            spawn(level, kind, at.method_10263() + 0.5, at.method_10264(), at.method_10260() + 0.5, p.method_36454(), 0.5f, 1f);
            p.method_64398(class_2561.method_43470(kind.title + " ready. Right-click: get in · W/S: gas/brake · A/D: steer · sneak: get out · sneak + right-click: trunk · Fuel Canister / coal: refuel · iron / metal plate / repair kit: repair").method_27692(class_124.field_1065));
            if (!p.method_68878()) ctx.method_8041().method_7934(1);
            return class_1269.field_5812;
        }
    }

    private ModVehicles() {}
}
