package com.kiyamet.vehicle;

import com.kiyamet.entity.KZombie;
import com.kiyamet.npc.Faction;
import com.kiyamet.npc.HumanEntity;
import com.kiyamet.registry.ModItems;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1277;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3917;
import net.minecraft.class_4048;
import net.minecraft.class_747;

/**
 * A drivable car / ATV / motorcycle / armored truck.
 * W/S throttle and brake, A/D steer, sneak to get out. Runs on fuel (Fuel Canister / coal), repaired with iron ingots
 * or a Repair Kit, runs over walkers, has a trunk (sneak + right-click). Raiders drive them straight at you.
 */
public class VehicleEntity extends class_1314 implements GeoEntity {
    private static final class_2940<Integer> FUEL = class_2945.method_12791(VehicleEntity.class, class_2943.field_13327);
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("misc.idle");
    private static final RawAnimation DRIVE = RawAnimation.begin().thenLoop("move.drive");

    public final VehicleKind kind;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final class_1277 trunk;
    private float throttle;
    private int turretCooldown;

    public VehicleEntity(class_1299<? extends VehicleEntity> type, class_1937 level, VehicleKind kind) {
        super(type, level);
        this.kind = kind;
        this.trunk = new class_1277(Math.max(1, kind.trunk));
        method_5971();
    }

    @Override
    protected void method_5693(class_2945.class_9222 b) {
        super.method_5693(b);
        b.method_56912(FUEL, 0);
    }

    public int fuel() { return field_6011.method_12789(FUEL); }
    public void setFuel(int f) { field_6011.method_12778(FUEL, class_3532.method_15340(f, 0, kind.fuel)); }
    public class_1277 trunk() { return trunk; }

    // ------------------------------------------------------------------ riding

    @Override
    public class_1309 method_5642() {
        return method_31483() instanceof class_1657 p ? p : null;
    }

    @Override
    protected boolean method_5818(class_1297 e) { return method_5685().size() < kind.seats.length; }

    @Override
    protected class_243 method_52533(class_1297 e, class_4048 dims, float scale) {
        int i = Math.max(0, method_5685().indexOf(e));
        float[] s = kind.seats[Math.min(i, kind.seats.length - 1)];
        return new class_243(s[0], s[1], s[2]).method_1024(-method_36454() * class_3532.field_29847);   // seats turn with the car
    }

    @Override
    public class_243 method_24829(class_1309 passenger) {
        class_243 side = new class_243(kind.width * 0.5 + 0.7, 0, 0).method_1024(-method_36454() * class_3532.field_29847);
        class_243 at = method_73189().method_1019(side);
        return method_73183().method_8587(passenger, passenger.method_5829().method_997(at.method_1020(passenger.method_73189()))) ? at : method_73189().method_1031(0, kind.height + 0.2, 0);
    }

    @Override
    protected void method_49481(class_1657 p, class_243 in) {
        super.method_49481(p, in);
        float target = fuel() <= 0 ? 0 : p.field_6250 > 0 ? 1f : p.field_6250 < 0 ? -0.4f : 0f;
        throttle += (target - throttle) * (target == 0 ? 0.07f : 0.045f);
        if (Math.abs(throttle) < 0.01f) throttle = 0;
        float grip = class_3532.method_15363(Math.abs(throttle) * 2.5f, 0, 1) * Math.signum(throttle);
        float yaw = method_36454() - p.field_6212 * kind.turn * grip;
        method_5710(yaw, 0);
        field_6283 = field_6241 = yaw;
    }

    @Override
    protected class_243 method_49482(class_1657 p, class_243 in) { return new class_243(0, 0, throttle); }

    @Override
    protected float method_49485(class_1657 p) { return (float) kind.speed; }

    // ------------------------------------------------------------------ ticking

    @Override
    public void method_5773() {
        super.method_5773();
        if (!(method_73183() instanceof class_3218 sl)) return;
        double speed = Math.sqrt(class_3532.method_33723(method_23317() - field_6014) + class_3532.method_33723(method_23321() - field_5969));
        class_1309 driver = method_5642();
        if (driver instanceof class_3222 sp) {
            if (speed > 0.02 && fuel() > 0 && !sp.method_68878()) setFuel(fuel() - 1);
            if (field_6012 % 10 == 0) hud(sp, speed);
            if (speed > 0.22) ram(sl, speed);
            if (field_6012 % 40 == 0 && speed > 0.05 && fuel() > 0) sl.method_8396(null, method_24515(), class_3417.field_14784, class_3419.field_15254, 0.25f, kind == VehicleKind.MOTORCYCLE ? 1.6f : 0.6f);
        }
        if (kind == VehicleKind.AMBULANCE && field_6012 % 100 == 0)
            for (class_1297 e : method_5685()) if (e instanceof class_1309 le) le.method_6092(new class_1293(class_1294.field_5924, 110, 0, true, false));
        if (method_31483() instanceof HumanEntity h && h.faction() == Faction.RAIDER) raiderDrive(sl);
        else if (method_31483() instanceof HumanEntity h && h.faction() == Faction.COMPANION) autopilot(sl, h, speed);
        if (method_6032() < method_6063() * 0.3f && field_6012 % 10 == 0)
            sl.method_65096(class_2398.field_11237, method_23317(), method_23318() + kind.height, method_23321(), 2, 0.3, 0.1, 0.3, 0.01);
    }

    private void hud(class_3222 p, double speed) {
        int pct = (int) Math.round(100.0 * fuel() / kind.fuel);
        StringBuilder bar = new StringBuilder();
        for (int i = 0; i < 10; i++) bar.append(i < pct / 10 ? '|' : '.');
        p.method_7353(class_2561.method_43470(kind.title + "   ").method_27692(class_124.field_1065)
                .method_10852(class_2561.method_43470("Fuel [" + bar + "] " + pct + "%   ").method_27692(pct < 15 ? class_124.field_1061 : class_124.field_1054))
                .method_10852(class_2561.method_43470("HP " + (int) method_6032() + "/" + (int) method_6063() + "   ").method_27692(class_124.field_1060))
                .method_10852(class_2561.method_43470((int) Math.round(speed * 20 * 3.6) + " km/h").method_27692(class_124.field_1075)), true);
    }

    /** Running over things: walkers fly, the car takes a little damage. */
    private void ram(class_3218 sl, double speed) {
        class_243 dir = new class_243(method_23317() - field_6014, 0, method_23321() - field_5969).method_1029();
        for (class_1309 e : sl.method_8390(class_1309.class, method_5829().method_1014(0.4).method_997(dir.method_1021(0.6)),
                e -> e != this && !method_5626(e) && !(e instanceof VehicleEntity) && e.method_5805() && !(e instanceof class_1657 pl && (pl.method_68878() || pl.method_7325())))) {
            if (e instanceof HumanEntity h && h.faction() == Faction.COMPANION) continue;
            float dmg = (float) (speed * 20 * kind.ram * 1.4);
            if (e.method_64397(sl, sl.method_48963().method_48812(method_5642() != null ? method_5642() : this), dmg)) {
                e.method_6005(1.2 + speed * 3, -dir.field_1352, -dir.field_1350);
                method_64397(sl, sl.method_48963().method_48830(), kind.armored ? 0.2f : 1f);
                sl.method_8396(null, e.method_24515(), class_3417.field_14670, class_3419.field_15254, 0.6f, 1.2f);
                if (e instanceof KZombie) sl.method_65096(class_2398.field_11209, e.method_23317(), e.method_23318() + 1, e.method_23321(), 4, 0.3, 0.3, 0.3, 0.1);
            }
        }
    }

    /** Raiders drive at the nearest player, jump out 12 blocks away; the armored truck's turret shoots while manned. */
    // ------------------------------------------------------------------ companion driver (1.6)
    public class_243 autoDest;
    private int autoStuck;

    /** A companion takes the wheel and drives you to the spot (an Xaero's map waypoint, or coordinates). */
    public void driveTo(class_3222 p, HumanEntity driver, class_243 dest) {
        List<class_1297> others = new java.util.ArrayList<>(method_5685());
        method_5772();
        driver.method_5873(this, true, true);
        p.method_5873(this, true, true);
        for (class_1297 e : others) if (e != driver && e != p && method_5818(e)) e.method_5873(this, true, true);
        autoDest = dest;
        p.method_64398(class_2561.method_43470("<" + driver.method_5477().getString() + "> ").method_27692(class_124.field_1075)
                .method_10852(class_2561.method_43470("Hold on. Driving to " + (int) dest.field_1352 + ", " + (int) dest.field_1350 + " (" + (int) Math.sqrt(method_5649(dest.field_1352, method_23318(), dest.field_1350)) + " blocks).").method_27692(class_124.field_1068)));
    }

    private void autopilot(class_3218 sl, HumanEntity h, double speed) {
        if (autoDest == null) { method_5942().method_6340(); return; }
        double dx = autoDest.field_1352 - method_23317(), dz = autoDest.field_1350 - method_23321(), d = Math.sqrt(dx * dx + dz * dz);
        class_3222 owner = h.ownerPlayer();
        if (d < 6 || fuel() <= 0) {
            autoDest = null; method_5942().method_6340();
            if (owner != null) owner.method_64398(class_2561.method_43470("<" + h.method_5477().getString() + "> ").method_27692(class_124.field_1075)
                    .method_10852(class_2561.method_43470(fuel() <= 0 ? "We're out of fuel." : "We're here.").method_27692(class_124.field_1068)));
            return;
        }
        if (speed > 0.02 && fuel() > 0) setFuel(fuel() - 1);
        if (speed > 0.22) ram(sl, speed);
        if (owner != null && field_6012 % 10 == 0) hud(owner, speed);
        if (field_6012 % 5 == 0) {
            double step = Math.min(d, 24);
            double tx = method_23317() + dx / d * step, tz = method_23321() + dz / d * step;
            if (field_5976 && speed < 0.05) {               // blocked: steer around
                if (++autoStuck > 8) { float a = (field_5974.method_43056() ? 70 : -70) * class_3532.field_29847; double rx = dx / d * Math.cos(a) - dz / d * Math.sin(a), rz = dx / d * Math.sin(a) + dz / d * Math.cos(a); tx = method_23317() + rx * 10; tz = method_23321() + rz * 10; }
            } else autoStuck = 0;
            int ty = sl.method_8624(net.minecraft.class_2902.class_2903.field_13203, (int) tx, (int) tz);
            method_5962().method_6239(tx, ty, tz, 1.0);
        }
    }

    private void raiderDrive(class_3218 sl) {
        class_1657 target = sl.method_18460(this, 96);
        if (target == null || target.method_68878() || target.method_7325()) { method_5942().method_6340(); return; }
        double d = method_5739(target);
        if (kind == VehicleKind.ARMORED_TRUCK && d < 32 && --turretCooldown <= 0 && method_6057(target)) {
            turretCooldown = 25;
            target.method_64397(sl, sl.method_48963().method_48803(null, this), 5f);
            class_243 from = method_73189().method_1031(0, kind.height + 0.4, 0), to = target.method_33571();
            for (int i = 0; i < 12; i++) { class_243 p = from.method_35590(to, i / 12.0); sl.method_65096(class_2398.field_11205, p.field_1352, p.field_1351, p.field_1350, 1, 0, 0, 0, 0); }
            sl.method_8396(null, method_24515(), class_3417.field_15187, class_3419.field_15251, 1.2f, 0.6f);
        }
        if (d < 12 || method_6032() < method_6063() * 0.4f) {
            boolean keepGunner = kind == VehicleKind.ARMORED_TRUCK && method_6032() >= method_6063() * 0.4f;
            List<class_1297> riders = List.copyOf(method_5685());
            for (int i = 0; i < riders.size(); i++) if (!(keepGunner && i == 0)) riders.get(i).method_5848();
            method_5942().method_6340();
        } else if (field_6012 % 10 == 0) {
            method_5962().method_6239(target.method_23317(), target.method_23318(), target.method_23321(), 1.0);
        }
    }

    // ------------------------------------------------------------------ interaction

    @Override
    protected class_1269 method_5992(class_1657 player, class_1268 hand) {
        if (hand != class_1268.field_5808) return class_1269.field_5811;
        if (method_31483() instanceof HumanEntity h && h.faction() == Faction.RAIDER) return class_1269.field_5814;
        class_1799 held = player.method_5998(hand);
        if (method_73183().method_8608()) return class_1269.field_5812;
        class_3222 sp = (class_3222) player;
        if (held.method_31574(ModItems.get("fuel_canister")) || held.method_31574(class_1802.field_8713) || held.method_31574(class_1802.field_8665) || held.method_31574(class_1802.field_8187)) {
            if (fuel() >= kind.fuel) { sp.method_7353(class_2561.method_43470("The tank is full.").method_27692(class_124.field_1080), true); return class_1269.field_5812; }
            int add = held.method_31574(class_1802.field_8187) ? kind.fuel : held.method_31574(ModItems.get("fuel_canister")) ? kind.fuel / 2 : kind.fuel / 10;
            setFuel(fuel() + add);
            if (!sp.method_68878()) { if (held.method_31574(class_1802.field_8187)) sp.method_6122(hand, new class_1799(class_1802.field_8550)); else held.method_7934(1); }
            method_73183().method_8396(null, method_24515(), class_3417.field_14834, class_3419.field_15248, 0.8f, 0.8f);
            sp.method_7353(class_2561.method_43470("Fuel: " + (100 * fuel() / kind.fuel) + "%").method_27692(class_124.field_1054), true);
            return class_1269.field_5812;
        }
        if ((held.method_31574(class_1802.field_8620) || held.method_31574(ModItems.get("repair_kit")) || held.method_31574(ModItems.get("metal_plate"))) && method_6032() < method_6063()) {
            float frac = held.method_31574(ModItems.get("repair_kit")) ? 0.5f : held.method_31574(ModItems.get("metal_plate")) ? 0.25f : 0.1f;
            method_6025(method_6063() * frac);
            if (!sp.method_68878()) held.method_7934(1);
            method_73183().method_8396(null, method_24515(), class_3417.field_14559, class_3419.field_15248, 0.5f, 1.3f);
            sp.method_7353(class_2561.method_43470("Repaired: " + (int) method_6032() + "/" + (int) method_6063()).method_27692(class_124.field_1060), true);
            return class_1269.field_5812;
        }
        if (player.method_5715()) {
            if (kind.trunk == 0) { sp.method_7353(class_2561.method_43470("No trunk on this one.").method_27692(class_124.field_1080), true); return class_1269.field_5812; }
            int rows = kind.trunk / 9;
            class_3917<class_1707> t = rows >= 3 ? class_3917.field_17326 : rows == 2 ? class_3917.field_18665 : class_3917.field_18664;
            sp.method_17355(new class_747((id, inv, pl) -> new class_1707(t, id, inv, trunk, rows), class_2561.method_43470(kind.title + " - Trunk")));
            return class_1269.field_5812;
        }
        if (method_5818(player)) {
            player.method_5873(this, false, true);
            if (fuel() <= 0) sp.method_7353(class_2561.method_43470("Out of fuel! Use a Fuel Canister or coal on it.").method_27692(class_124.field_1061), true);
            return class_1269.field_5812;
        }
        return class_1269.field_5811;
    }

    @Override
    public boolean method_64397(class_3218 level, class_1282 source, float amount) {
        class_1297 src = source.method_5529();
        if (src != null && method_5626(src)) return false;
        if (source.method_48789(net.minecraft.class_8103.field_42250)) amount *= 0.3f;
        return super.method_64397(level, source, amount);
    }

    @Override
    public void method_6078(class_1282 source) {
        if (method_73183() instanceof class_3218 sl) {
            for (int i = 0; i < trunk.method_5439(); i++) if (!trunk.method_5438(i).method_7960()) sl.method_8649(new class_1542(sl, method_23317(), method_23318() + 1, method_23321(), trunk.method_5441(i)));
            sl.method_8649(new class_1542(sl, method_23317(), method_23318() + 1, method_23321(), new class_1799(ModItems.get("metal_plate"), 2 + field_5974.method_43048(4))));
            if (field_5974.method_43056()) sl.method_8649(new class_1542(sl, method_23317(), method_23318() + 1, method_23321(), new class_1799(ModItems.get("circuit"), 1 + field_5974.method_43048(2))));
            sl.method_65096(class_2398.field_11221, method_23317(), method_23318() + 1, method_23321(), 1, 0, 0, 0, 0);
            sl.method_8396(null, method_24515(), class_3417.field_15152.comp_349(), class_3419.field_15254, 1.5f, 0.9f);
            method_5772();
        }
        super.method_6078(source);
    }

    // ------------------------------------------------------------------ misc

    @Override public boolean method_5974(double d) { return false; }
    @Override public boolean method_6094() { return true; }
    @Override public boolean method_5810() { return false; }
    @Override public boolean method_30948(class_1297 other) { return true; }
    @Override public boolean method_5863() { return !method_31481(); }
    @Override protected boolean method_27071(class_3218 level) { return false; }
    @Override public boolean method_5931() { return false; }

    @Override
    protected void method_5652(class_11372 out) {
        super.method_5652(out);
        out.method_71465("Fuel", fuel());
        java.util.List<class_1799> items = new java.util.ArrayList<>();
        for (int i = 0; i < trunk.method_5439(); i++) items.add(trunk.method_5438(i));
        out.method_71468("Trunk", class_1799.field_49266.listOf(), items);
    }

    @Override
    protected void method_5749(class_11368 in) {
        super.method_5749(in);
        setFuel(in.method_71424("Fuel", 0));
        in.method_71426("Trunk", class_1799.field_49266.listOf()).ifPresent(l -> { for (int i = 0; i < l.size() && i < trunk.method_5439(); i++) trunk.method_5447(i, l.get(i)); });
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar c) {
        c.add(new AnimationController<VehicleEntity>("main", 3, t -> t.setAndContinue(t.isMoving() ? DRIVE : IDLE)));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
