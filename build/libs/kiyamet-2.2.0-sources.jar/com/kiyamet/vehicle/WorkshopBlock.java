package com.kiyamet.vehicle;

import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3965;

public class WorkshopBlock extends class_2248 {
    public WorkshopBlock(class_2251 p) { super(p); }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (player instanceof class_3222 sp) WorkshopMenu.open(sp);
        return class_1269.field_5812;
    }
}
