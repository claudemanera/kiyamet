package com.kiyamet.water;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3486;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_9279;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

/**
 * Canteens (1.9): right-click water to fill (river water is dirty - boil it by right-clicking a lit campfire or furnace),
 * hold right-click to drink a sip. In winter you can fill them from snow; in the cold they can freeze - warm them by a fire.
 */
public class CanteenItem extends class_1792 {
    public final int sips;
    public CanteenItem(class_1793 p, int sips) { super(p); this.sips = sips; }

    static class_2487 tag(class_1799 s) { return s.method_58695(class_9334.field_49628, class_9279.field_49302).method_57461(); }
    public static int water(class_1799 s) { return tag(s).method_68083("Water", 0); }
    public static boolean dirty(class_1799 s) { return tag(s).method_68566("Dirty", false); }
    public static boolean frozen(class_1799 s) { return tag(s).method_68566("Frozen", false); }

    public static void set(class_1799 s, int water, boolean dirty, boolean frozen) {
        class_2487 t = tag(s);
        t.method_10569("Water", water); t.method_10556("Dirty", dirty && water > 0); t.method_10556("Frozen", frozen && water > 0);
        s.method_57379(class_9334.field_49628, class_9279.method_57456(t));
        int max = s.method_7909() instanceof CanteenItem c ? c.sips : 0;
        s.method_57379(class_9334.field_49632, new class_9290(List.of(
                class_2561.method_43470("Water: " + water + " / " + max + " sips" + (water == 0 ? "" : frozen ? " · FROZEN" : dirty ? " · dirty" : " · clean"))
                        .method_27694(st -> st.method_10978(false).method_10977(water == 0 ? class_124.field_1080 : frozen ? class_124.field_1068 : dirty ? class_124.field_1077 : class_124.field_1075)),
                class_2561.method_43470("Right-click water/snow: fill · campfire: boil · hold: drink").method_27694(st -> st.method_10978(false).method_10977(class_124.field_1063)))));
    }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 s = player.method_5998(hand);
        class_3965 hit = method_7872(level, player, class_3959.class_242.field_1345);
        if (hit.method_17783() == class_239.class_240.field_1332) {
            class_2338 pos = hit.method_17777();
            var st = level.method_8320(pos);
            boolean water = level.method_8316(pos).method_15767(class_3486.field_15517);
            boolean snow = st.method_27852(class_2246.field_10491) || st.method_27852(class_2246.field_10477) || st.method_27852(class_2246.field_27879) || st.method_27852(class_2246.field_10295);
            boolean fire = st.method_27852(class_2246.field_17350) && st.method_11654(net.minecraft.class_3922.field_17352) || st.method_27852(class_2246.field_10181) && st.method_11654(net.minecraft.class_3865.field_11105);
            if (!level.method_8608()) {
                if (fire && water(s) > 0) {
                    set(s, water(s), false, false);
                    level.method_8396(null, pos, class_3417.field_15161, class_3419.field_15248, 1f, 1f);
                    player.method_7353(class_2561.method_43470("Boiled: the water is clean.").method_27692(class_124.field_1075), true);
                    return class_1269.field_21466;
                }
                if ((water || snow) && water(s) < sips) {
                    boolean dirtyNow = water && !(level.method_8419() && level.method_8311(player.method_24515()));
                    set(s, sips, water(s) > 0 ? dirty(s) || dirtyNow : dirtyNow, false);
                    level.method_8396(null, player.method_24515(), class_3417.field_14779, class_3419.field_15248, 1f, snow ? 0.7f : 1f);
                    player.method_7353(class_2561.method_43470(snow ? "Packed with snow - it melts into clean water." : dirtyNow ? "Filled - river water, boil it first!" : "Filled.").method_27692(class_124.field_1075), true);
                    return class_1269.field_21466;
                }
            } else if (fire || water || snow) return class_1269.field_5812;
        }
        if (water(s) <= 0) return class_1269.field_5814;
        if (frozen(s)) { if (!level.method_8608()) player.method_7353(class_2561.method_43470("Frozen solid. Warm it near a fire.").method_27692(class_124.field_1068), true); return class_1269.field_5814; }
        player.method_6019(hand);
        return class_1269.field_21466;
    }

    @Override public int method_7881(class_1799 s, class_1309 e) { return 24; }
    @Override public class_1839 method_7853(class_1799 s) { return class_1839.field_8946; }

    @Override
    public class_1799 method_7861(class_1799 s, class_1937 level, class_1309 e) {
        if (e instanceof class_3222 p && water(s) > 0) {
            Thirst.add(p, 4);
            if (dirty(s) && p.method_59922().method_43057() < 0.35f) { p.method_6092(new class_1293(class_1294.field_5899, 100, 0)); p.method_6092(new class_1293(class_1294.field_5916, 160, 0)); }
            set(s, water(s) - 1, dirty(s), false);
            level.method_8396(null, p.method_24515(), class_3417.field_20613.comp_349(), class_3419.field_15248, 0.8f, 1f);
        }
        return s;
    }

    public static final String[][] TIERS = {{"waterskin", "Leather Waterskin", "4"}, {"tin_canteen", "Tin Canteen", "6"}, {"army_canteen", "Army Canteen", "9"},
            {"steel_thermos", "Steel Thermos", "13"}, {"hydration_pack", "Tactical Hydration Pack", "20"}};

    /** seasons: rain fills canteens outside, frost freezes them, fire thaws them */
    public static void seasonTick(class_3222 p) {
        boolean rainOut = p.method_51469().method_8419() && p.method_51469().method_8311(p.method_24515());
        int bodyState = com.kiyamet.season.Seasons.state(p.getAttachedOrElse(com.kiyamet.season.Seasons.BODY, 20f));
        boolean warm = com.kiyamet.season.Seasons.warmNear(p.method_51469(), p.method_24515(), 4);
        var inv = p.method_31548();
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 s = inv.method_5438(i);
            if (!(s.method_7909() instanceof CanteenItem c)) continue;
            if (rainOut && i < 9 && water(s) < c.sips && p.method_59922().method_43048(3) == 0) set(s, water(s) + 1, dirty(s) && water(s) > 0, frozen(s));
            if (water(s) > 0 && !frozen(s) && bodyState <= -3 && !warm && p.method_59922().method_43048(4) == 0) { set(s, water(s), dirty(s), true); p.method_7353(class_2561.method_43470("Your water froze!").method_27692(class_124.field_1068), true); }
            if (frozen(s) && (warm || bodyState >= 0)) set(s, water(s), dirty(s), false);
        }
    }
}
