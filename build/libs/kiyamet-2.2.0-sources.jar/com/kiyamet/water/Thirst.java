package com.kiyamet.water;

import com.kiyamet.Kiyamet;
import com.kiyamet.season.SeasonEvents;
import com.kiyamet.season.Seasons;
import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_1847;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import net.minecraft.class_9135;
import net.minecraft.class_9334;

/**
 * 1.9 thirst: a water bar (0-20) next to hunger. Summer, heat waves, heat and sprinting dry you out faster; winter slower.
 * Drink from canteens, water bottles, milk, soups and juicy fruit. At zero you start to die of thirst.
 */
public final class Thirst {
    public static final AttachmentType<Float> WATER = AttachmentRegistry.create(Kiyamet.id("thirst"),
            b -> b.initializer(() -> 20f).persistent(Codec.FLOAT).syncWith(class_9135.field_48552, AttachmentSyncPredicate.targetOnly()));

    public static float get(class_3222 p) { return p.getAttachedOrElse(WATER, 20f); }
    public static void add(class_3222 p, float v) { p.setAttached(WATER, Math.max(0, Math.min(20, get(p) + v))); }

    /** how much water a drink / food gives back */
    static float drinkValue(class_1799 s) {
        if (s.method_31574(class_1802.field_8574)) { class_1844 pc = s.method_58694(class_9334.field_49651); return pc != null && pc.method_57401(class_1847.field_8991) ? 6 : 3; }
        if (s.method_31574(class_1802.field_8103)) return 8;
        if (s.method_31574(class_1802.field_20417)) return 2;
        if (s.method_31574(class_1802.field_8497)) return 3;
        String id = class_7923.field_41178.method_10221(s.method_7909()).method_12832();
        return switch (id) {
            case "orange", "peach", "cucumber", "tomato", "strawberry", "apple", "sweet_berries", "glow_berries" -> 2;
            case "mushroom_stew", "beetroot_soup", "rabbit_stew", "vegetable_stew", "tomato_soup", "chicken_soup", "fruit_salad", "cabbage_salad" -> 5;
            default -> 0;
        };
    }

    static float drain(class_3222 p) {
        Seasons.Season s = Seasons.season(p.method_51469());
        float d = 0.011f;
        d *= switch (s) { case SUMMER -> 1.6f; case SPRING -> 1.0f; case AUTUMN -> 0.9f; case WINTER -> 0.75f; };
        if (SeasonEvents.today == SeasonEvents.Event.HEAT_WAVE) d *= 1.6f;
        if (SeasonEvents.today == SeasonEvents.Event.DROUGHT) d *= 1.3f;
        int state = Seasons.state(p.getAttachedOrElse(Seasons.BODY, 20f));
        if (state >= 2) d *= state == 2 ? 1.3f : state == 3 ? 1.8f : 2.6f;
        if (p.method_5624()) d *= 1.8f;
        if (p.method_51469().method_23753(p.method_24515()).comp_349().method_8712() > 1.5f) d *= 1.3f;
        if (p.method_51469().method_27983() == net.minecraft.class_1937.field_25180) d *= 2.5f;
        d *= 1f - Math.min(0.5f, com.kiyamet.skill.SkillManager.get(p).level(com.kiyamet.skill.Skill.SURVIVAL) / 2000f);   // survivors need less
        return d;
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int t = server.method_3780();
            for (class_3222 p : server.method_3760().method_14571()) {
                if (p.method_68878() || p.method_7325() || !p.method_5805()) continue;
                // drinking anything that finishes this tick
                if (p.method_6115() && p.method_6014() == 1) {
                    float v = drinkValue(p.method_6030());
                    if (v > 0) { add(p, v); com.kiyamet.skill.SkillManager.addXp(p, com.kiyamet.skill.Skill.SURVIVAL, 2); }
                }
                if (t % 20 != 0) continue;
                if (t % 600 == 0) CanteenItem.seasonTick(p);
                add(p, -drain(p));
                float w = get(p);
                if (w <= 6) p.method_6092(new class_1293(class_1294.field_5909, 40, 0, true, false, true));
                if (w <= 3) { p.method_6092(new class_1293(class_1294.field_5911, 40, 0, true, false, true)); if (t % 200 == 0) p.method_6092(new class_1293(class_1294.field_5916, 120, 0, true, false, true)); }
                if (w <= 0 && t % 80 == 0) p.method_64397(p.method_51469(), p.method_48923().method_48834(), 1.5f);
                if ((w <= 6 && t % 1200 == 0) || (w <= 3 && t % 400 == 0))
                    p.method_7353(class_2561.method_43470(w <= 3 ? "You're dying of thirst - drink something!" : "You're thirsty.").method_27692(w <= 3 ? class_124.field_1061 : class_124.field_1075), true);
            }
        });
        for (String[] c : CanteenItem.TIERS) { int n = Integer.parseInt(c[2]); com.kiyamet.registry.ModItems.custom(c[0], p -> new CanteenItem(p.method_7889(1), n)); }
        net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents.AFTER_RESPAWN.register((oldP, newP, alive) -> newP.setAttached(WATER, 20f));
    }

    private Thirst() {}
}
