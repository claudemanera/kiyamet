package com.kiyamet.wild;

import com.kiyamet.Kiyamet;
import com.kiyamet.registry.ModItems;
import java.util.EnumMap;
import java.util.Map;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1311;
import net.minecraft.class_1792;
import net.minecraft.class_1972;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import net.minecraft.class_4174;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/** Registers the wild animals, their meat, and spawning (ice bears roam in winter). */
public final class ModWild {
    public static final Map<WildKind, class_1299<WildAnimal>> TYPES = new EnumMap<>(WildKind.class);
    public static final String[][] MEATS = {{"venison", "Venison", "3", "8"}, {"bear_meat", "Bear Meat", "4", "10"}, {"boar_meat", "Boar Meat", "3", "9"},
            {"moose_meat", "Moose Meat", "4", "11"}, {"big_cat_meat", "Big Cat Meat", "3", "8"}, {"croc_meat", "Crocodile Meat", "3", "8"}};

    static {
        for (WildKind k : WildKind.values()) {
            class_5321<class_1299<?>> key = class_5321.method_29179(class_7924.field_41266, Kiyamet.id(k.id));
            class_1299<WildAnimal> t = class_1299.class_1300.<WildAnimal>method_5903((type, l) -> new WildAnimal(type, l, k), k.zombie ? class_1311.field_6302 : class_1311.field_6294)
                    .method_17687(k.width, k.height).method_27299(10).method_5905(key);
            TYPES.put(k, class_2378.method_39197(class_7923.field_41177, key, t));
        }
    }

    public static void init() {
        TYPES.forEach((k, t) -> FabricDefaultAttributeRegistry.register(t, class_1308.method_26828()
                .method_26868(class_5134.field_23716, k.hp).method_26868(class_5134.field_23721, k.damage).method_26868(class_5134.field_23719, k.speed)
                .method_26868(class_5134.field_23717, k.zombie ? 40 : 32).method_26868(class_5134.field_23718, k.hp >= 50 ? 0.7 : 0.3).method_26868(class_5134.field_23722, k.predator ? 1.2 : 0.5)
                .method_26868(class_5134.field_52450, 10).method_26868(class_5134.field_23724, k == WildKind.CROCODILE ? 8 : k.hp >= 60 ? 4 : 0)));
        for (String[] m : MEATS) {
            int n = Integer.parseInt(m[2]), c = Integer.parseInt(m[3]);
            ModItems.custom(m[0], p -> new class_1792(p.method_19265(new class_4174(n, 0.3f, false))));
            ModItems.custom("cooked_" + m[0], p -> new class_1792(p.method_19265(new class_4174(c, 0.9f, false))));
        }
        spawn(WildKind.LION, BiomeSelectors.includeByKey(class_1972.field_9449, class_1972.field_9430, class_1972.field_35114), 6, 1, 3);
        spawn(WildKind.TIGER, BiomeSelectors.includeByKey(class_1972.field_9417, class_1972.field_9440, class_1972.field_35118), 6, 1, 1);
        spawn(WildKind.BROWN_BEAR, BiomeSelectors.includeByKey(class_1972.field_9409, class_1972.field_9420, class_1972.field_35119, class_1972.field_35113, class_1972.field_9475), 5, 1, 2);
        spawn(WildKind.ICE_BEAR, BiomeSelectors.includeByKey(class_1972.field_35117, class_1972.field_9453, class_1972.field_9454, class_1972.field_35115, class_1972.field_34472, class_1972.field_34471), 5, 1, 2);
        spawn(WildKind.CROCODILE, BiomeSelectors.includeByKey(class_1972.field_9471, class_1972.field_38748), 8, 1, 2);
        spawn(WildKind.WILD_BOAR, BiomeSelectors.includeByKey(class_1972.field_9409, class_1972.field_9475, class_1972.field_9449, class_1972.field_9412, class_1972.field_9420), 8, 2, 4);
        spawn(WildKind.DEER, BiomeSelectors.includeByKey(class_1972.field_9409, class_1972.field_9412, class_1972.field_9420, class_1972.field_34470, class_1972.field_9451, class_1972.field_9414, class_1972.field_35112), 12, 2, 4);
        spawn(WildKind.MOOSE, BiomeSelectors.includeByKey(class_1972.field_9420, class_1972.field_9454, class_1972.field_35113, class_1972.field_9471), 5, 1, 2);
        spawn(WildKind.SHEPHERD, BiomeSelectors.includeByKey(class_1972.field_9451, class_1972.field_34470, class_1972.field_9409), 3, 1, 2);
        spawn(WildKind.HUSKY, BiomeSelectors.includeByKey(class_1972.field_35117, class_1972.field_9454, class_1972.field_34471), 4, 1, 3);
        spawn(WildKind.ROTTWEILER, BiomeSelectors.includeByKey(class_1972.field_9451, class_1972.field_9449, class_1972.field_9455), 2, 1, 2);
        spawn(WildKind.CAT, BiomeSelectors.includeByKey(class_1972.field_9451, class_1972.field_9409, class_1972.field_9412, class_1972.field_34470, class_1972.field_9455), 3, 1, 1);
        spawn(WildKind.PITBULL, BiomeSelectors.includeByKey(class_1972.field_9451, class_1972.field_9455, class_1972.field_9449), 2, 1, 1);
        // walker animals: rare - a little more common deep in big forests, jungles and swamps
        for (WildKind k : new WildKind[]{WildKind.ZOMBIE_LION, WildKind.ZOMBIE_TIGER, WildKind.ZOMBIE_BEAR, WildKind.ZOMBIE_DEER, WildKind.ZOMBIE_WOLF, WildKind.ZOMBIE_CROC})
            if (k != WildKind.ZOMBIE_CROC) BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), class_1311.field_6302, TYPES.get(k), 1, 1, 1);
        var deep = BiomeSelectors.includeByKey(class_1972.field_9475, class_1972.field_35119, class_1972.field_35113, class_1972.field_35112, class_1972.field_9417, class_1972.field_9440, class_1972.field_9420, class_1972.field_9454);
        for (WildKind k : new WildKind[]{WildKind.ZOMBIE_BEAR, WildKind.ZOMBIE_DEER, WildKind.ZOMBIE_WOLF}) BiomeModifications.addSpawn(deep, class_1311.field_6302, TYPES.get(k), 3, 1, k == WildKind.ZOMBIE_WOLF ? 3 : 1);
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(class_1972.field_9417, class_1972.field_9440), class_1311.field_6302, TYPES.get(WildKind.ZOMBIE_TIGER), 3, 1, 1);
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(class_1972.field_9449, class_1972.field_9430), class_1311.field_6302, TYPES.get(WildKind.ZOMBIE_LION), 3, 1, 1);
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(class_1972.field_9471, class_1972.field_38748), class_1311.field_6302, TYPES.get(WildKind.ZOMBIE_CROC), 3, 1, 1);
        // the dead don't stay dead: wild animals and wolves rise as walkers a few seconds after they die
        net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents.AFTER_DEATH.register((e, src) -> {
            if (!(e.method_73183() instanceof class_3218 sl)) return;
            WildKind to = null;
            if (e instanceof WildAnimal w && !w.method_6181()) to = w.kind.risesAs();
            else if (e instanceof net.minecraft.class_1493 wf && !wf.method_6181()) to = WildKind.ZOMBIE_WOLF;
            if (to == null || e.method_5809()) return;
            RISING.add(new Rising(sl, e.method_73189(), e.method_36454(), to, sl.method_75260() + 140));
            sl.method_65096(net.minecraft.class_2398.field_11233, e.method_23317(), e.method_23318() + 0.5, e.method_23321(), 12, 0.4, 0.2, 0.4, 0.01);
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (RISING.isEmpty()) return;
            RISING.removeIf(r -> {
                if (r.level.method_75260() < r.at) return false;
                if (!r.level.method_8477(class_2338.method_49638(r.pos))) return true;
                WildAnimal z = TYPES.get(r.kind).method_5883(r.level, class_3730.field_16468);
                if (z == null) return true;
                z.method_5808(r.pos.field_1352, r.pos.field_1351, r.pos.field_1350, r.yaw, 0);
                r.level.method_8649(z);
                r.level.method_65096(net.minecraft.class_2398.field_11237, r.pos.field_1352, r.pos.field_1351 + 0.6, r.pos.field_1350, 20, 0.5, 0.4, 0.5, 0.02);
                z.method_5783(net.minecraft.class_3417.field_15168, 1.2f, 0.6f);
                return true;
            });
        });
        // winter: ice bears come down from the mountains
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.method_3780() % 2400 != 1200) return;
            class_3218 ow = server.method_30002();
            if (com.kiyamet.season.Seasons.season(ow) != com.kiyamet.season.Seasons.Season.WINTER) return;
            for (class_3222 p : server.method_3760().method_14571()) {
                if (p.method_51469() != ow || ow.field_9229.method_43057() > 0.3f) continue;
                if (!ow.method_8390(WildAnimal.class, p.method_5829().method_1014(64), w -> w.kind == WildKind.ICE_BEAR).isEmpty()) continue;
                double a = ow.field_9229.method_43058() * Math.PI * 2;
                class_2338 at = ow.method_8598(class_2902.class_2903.field_13203, p.method_24515().method_10069((int) (Math.cos(a) * 36), 0, (int) (Math.sin(a) * 36)));
                if (!ow.method_8477(at) || !(ow.method_8320(at).method_27852(class_2246.field_10477) || ow.method_8320(at.method_10074()).method_27852(class_2246.field_10491) || ow.method_8320(at.method_10074()).method_27852(class_2246.field_10219))) continue;
                WildAnimal b = TYPES.get(WildKind.ICE_BEAR).method_5883(ow, class_3730.field_16467);
                if (b == null) continue;
                b.method_5814(at.method_10263() + 0.5, at.method_10264(), at.method_10260() + 0.5);
                ow.method_8649(b);
            }
        });
    }

    record Rising(class_3218 level, net.minecraft.class_243 pos, float yaw, WildKind kind, long at) {}
    static final java.util.List<Rising> RISING = new java.util.ArrayList<>();

    static void spawn(WildKind k, java.util.function.Predicate<net.fabricmc.fabric.api.biome.v1.BiomeSelectionContext> where, int weight, int min, int max) {
        BiomeModifications.addSpawn(where, class_1311.field_6294, TYPES.get(k), weight, min, max);
    }

    private ModWild() {}
}
