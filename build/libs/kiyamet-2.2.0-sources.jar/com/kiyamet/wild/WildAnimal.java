package com.kiyamet.wild;

import com.kiyamet.registry.ModItems;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1338;
import net.minecraft.class_1347;
import net.minecraft.class_1350;
import net.minecraft.class_1361;
import net.minecraft.class_1366;
import net.minecraft.class_1374;
import net.minecraft.class_1376;
import net.minecraft.class_1386;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1403;
import net.minecraft.class_1406;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Wild animals (1.9). Predators don't attack on sight - they watch you, and the longer you stay near them the more likely
 * they are to charge (as fast as you sprint, and they hit hard). Lions and tigers can be tamed with about 20 pieces of venison
 * - or they lose patience and attack. Walker forms attack at once.
 */
public class WildAnimal extends class_1321 implements GeoEntity {
    static final RawAnimation IDLE = RawAnimation.begin().thenLoop("misc.idle"), WALK = RawAnimation.begin().thenLoop("move.walk"),
            RUN = RawAnimation.begin().thenLoop("move.run"), ATTACK = RawAnimation.begin().thenPlay("attack.swing"), SIT = RawAnimation.begin().thenLoop("misc.sit");
    public final WildKind kind;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private int stalk, trust;
    private class_3222 watched;

    public WildAnimal(class_1299<? extends class_1321> type, class_1937 level, WildKind kind) {
        super(type, level);
        this.kind = kind;
        field_6194 = kind.predator ? 10 : 3;
    }

    @Override
    protected void method_5959() {
        WildKind k = kindSafe();
        field_6201.method_6277(0, new class_1347(this));
        field_6201.method_6277(1, new class_1386(this));
        if (k == null) return;
        if (k.predator || k == WildKind.WILD_BOAR || k == WildKind.MOOSE || k.dog()) field_6201.method_6277(2, new class_1366(this, 1.25, true));
        if (k == WildKind.DEER) { field_6201.method_6277(2, new class_1338<>(this, class_1657.class, 14f, 1.3, 1.6)); field_6201.method_6277(3, new class_1374(this, 1.7)); }
        field_6201.method_6277(4, new class_1350(this, 1.2, 10f, 3f));
        field_6201.method_6277(6, new class_1394(this, 0.8));
        field_6201.method_6277(7, new class_1361(this, class_1657.class, 12f));
        field_6201.method_6277(8, new class_1376(this));
        field_6185.method_6277(1, new class_1403(this));
        field_6185.method_6277(2, new class_1406(this));
        field_6185.method_6277(3, new class_1399(this));
        if (k.dog()) field_6185.method_6277(4, new class_1400<>(this, net.minecraft.class_1308.class, 5, true, false,
                (e, l) -> method_6181() && e instanceof net.minecraft.class_1569 && !(e instanceof net.minecraft.class_1548)));
        if (k == WildKind.CAT) field_6201.method_6277(3, new class_1338<>(this, net.minecraft.class_1308.class, 8f, 1.2, 1.5, e -> e instanceof net.minecraft.class_1569));
        if (k.zombie) { field_6185.method_6277(4, new class_1400<>(this, class_1657.class, false));
            field_6185.method_6277(5, new class_1400<>(this, com.kiyamet.npc.HumanEntity.class, false)); }
        if (k.predator && !k.zombie) field_6185.method_6277(5, new class_1400<>(this, WildAnimal.class, 10, true, false,
                (e, l) -> e instanceof WildAnimal w && (w.kind == WildKind.DEER || w.kind == WildKind.WILD_BOAR) && !method_6181()));
    }

    /** registerGoals runs inside the super constructor, before kind is set */
    WildKind kindSafe() {
        if (kind != null) return kind;
        for (WildKind k : WildKind.values()) if (ModWild.TYPES.get(k) == method_5864()) return k;
        return null;
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (!(method_73183() instanceof class_3218 sl) || kind == null) return;
        if (kind == WildKind.ICE_BEAR && field_6012 % 20 == 0) sl.method_65096(class_2398.field_28013, method_23317(), method_23318() + 1, method_23321(), 2, 0.4, 0.4, 0.4, 0.01);
        if (kind.pet() && method_6181()) petTick(sl);
        if (!kind.predator || kind.zombie || method_6181() || method_5968() != null || field_6012 % 10 != 0) return;
        // stalking: the longer you hang around, the closer it gets to charging
        class_1657 p = sl.method_18460(this, 18);
        if (p == null || p.method_68878() || p.method_7325() || !method_6057(p)) { stalk = Math.max(0, stalk - 2); return; }
        method_5988().method_6226(p, 30f, 30f);
        if (method_5739(p) > 9) method_5942().method_6335(p, 0.6);
        else method_5942().method_6340();
        stalk += sl.method_23886() ? 2 : 1;
        if (p.method_18276()) stalk--;
        if (p instanceof class_3222 sp0 && field_5974.method_43048(1000) < com.kiyamet.skill.SkillManager.get(sp0).level(com.kiyamet.skill.Skill.STEALTH)) stalk--;   // skilled sneakers go unnoticed longer
        if (stalk == 6 && p instanceof class_3222 sp) { method_5783(class_3417.field_14937, 1f, kind == WildKind.LION || kind == WildKind.TIGER ? 0.6f : 0.9f);
            sp.method_7353(class_2561.method_43470("The " + kind.title.toLowerCase() + " is watching you...").method_27692(class_124.field_1065), true); }
        if (stalk > 14 + field_5974.method_43048(8)) { method_5980(p); stalk = 0; method_5783(class_3417.field_14733, 1.2f, 1.4f); }
    }

    /** dogs smell walkers and bark (marks them), huskies keep you warm, cats bring you little gifts at dawn */
    void petTick(class_3218 sl) {
        if (!(method_35057() instanceof class_3222 owner) || owner.method_51469() != sl) return;
        if (kind.dog() && field_6012 % 100 == 0) {
            var foes = sl.method_8390(net.minecraft.class_1308.class, method_5829().method_1014(kind == WildKind.SHEPHERD ? 28 : 20), e -> e instanceof net.minecraft.class_1569 && e.method_5805());
            if (!foes.isEmpty()) {
                method_5783(class_3417.field_57074.get(net.minecraft.class_10824.class_10825.field_57087).comp_3781().comp_349(), 1.4f, 1f);
                for (var f : foes) f.method_6092(new net.minecraft.class_1293(net.minecraft.class_1294.field_5912, 110, 0, false, false));
                if (field_6012 % 600 == 0) owner.method_7353(class_2561.method_43470((method_16914() ? method_5797().getString() : kind.title) + " smells " + foes.size() + " walker" + (foes.size() > 1 ? "s" : "") + " nearby!").method_27692(class_124.field_1065), true);
            }
        }
        if (kind == WildKind.CAT && sl.method_8532() % 24000 == 0 && method_5739(owner) < 20) {
            net.minecraft.class_1792[] gifts = {net.minecraft.class_1802.field_8276, net.minecraft.class_1802.field_8153, net.minecraft.class_1802.field_8245, net.minecraft.class_1802.field_8675, net.minecraft.class_1802.field_8429, net.minecraft.class_1802.field_8614};
            method_5775(sl, new class_1799(gifts[field_5974.method_43048(gifts.length)]));
            owner.method_7353(class_2561.method_43470("Your cat brought you a gift.").method_27692(class_124.field_1076), true);
        }
    }

    /** a tamed husky lying next to you is like a small campfire */
    public static float petWarmth(class_1657 p) {
        return p.method_73183().method_8390(WildAnimal.class, p.method_5829().method_1014(4), w -> w.kind == WildKind.HUSKY && w.method_6181() && w.method_6171(p)).isEmpty() ? 0 : 4f;
    }

    @Override
    public boolean method_6121(class_3218 level, net.minecraft.class_1297 target) {
        boolean hit = super.method_6121(level, target);
        if (hit && target instanceof class_1309 le) {
            le.method_6005(0.8, method_23317() - le.method_23317(), method_23321() - le.method_23321());
            triggerAnim("main", "attack");
            if (kind != null && kind.zombie) le.method_6092(new net.minecraft.class_1293(net.minecraft.class_1294.field_5899, 80, 0));
        }
        return hit;
    }

    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        class_1799 s = player.method_5998(hand);
        if (kind == null) return super.method_5992(player, hand);
        if (method_6181() && method_6171(player)) {
            if (s.method_31574(ModItems.get("venison")) || s.method_31574(ModItems.get("cooked_venison")) || (kind.dog() && isMeat(s)) || (kind == WildKind.CAT && s.method_31574(net.minecraft.class_1802.field_8429))) { if (!method_73183().method_8608()) { method_6025(10); s.method_57008(1, player); } return class_1269.field_5812; }
            if (!method_73183().method_8608()) { method_24346(!method_24345()); method_6179(method_24345()); method_5942().method_6340(); method_5980(null); }
            return class_1269.field_5812;
        }
        if (kind.pet() && !method_6181() && (kind.dog() ? (s.method_31574(net.minecraft.class_1802.field_8606) || s.method_57826(net.minecraft.class_9334.field_50075) && s.method_7909() != net.minecraft.class_1802.field_8511 && isMeat(s))
                : (s.method_31574(net.minecraft.class_1802.field_8429) || s.method_31574(net.minecraft.class_1802.field_8209) || s.method_31574(net.minecraft.class_1802.field_8373)))) {
            if (!(player instanceof class_3222 sp)) return class_1269.field_5812;
            s.method_57008(1, player);
            if (field_5974.method_43048(3) == 0) {
                method_6170(sp); method_24346(false); method_73183().method_8421(this, (byte) 7);
                com.kiyamet.skill.SkillManager.addXp(sp, com.kiyamet.skill.Skill.HUNTING, 80);
                sp.method_64398(class_2561.method_43470("The " + kind.title.toLowerCase() + " is your pet now! Right-click to make it sit or follow. Use a name tag to name it.").method_27692(class_124.field_1060));
            } else method_73183().method_8421(this, (byte) 6);
            return class_1269.field_21466;
        }
        if (kind.tameable && !kind.pet() && !method_6181() && s.method_31574(ModItems.get("venison"))) {
            if (!(player instanceof class_3222 sp)) return class_1269.field_5812;
            s.method_57008(1, player);
            trust++; stalk = 0;
            ((class_3218) method_73183()).method_65096(class_2398.field_11201, method_23317(), method_23318() + 1.2, method_23321(), 1, 0.3, 0.3, 0.3, 0);
            if (trust >= 20) {
                if (field_5974.method_43057() < Math.min(0.95f, 0.65f + com.kiyamet.skill.SkillManager.get(sp).level(com.kiyamet.skill.Skill.HUNTING) / 3000f)) {
                    com.kiyamet.skill.SkillManager.addXp(sp, com.kiyamet.skill.Skill.HUNTING, 400);
                    method_6170(sp); method_24346(false);
                    method_73183().method_8421(this, (byte) 7);
                    sp.method_64398(class_2561.method_43470("The " + kind.title.toLowerCase() + " trusts you now. It's yours.").method_27695(class_124.field_1060, class_124.field_1067));
                } else {
                    trust = 0; method_5980(sp);
                    method_5783(class_3417.field_14733, 1.2f, 1.2f);
                    sp.method_64398(class_2561.method_43470("It lost its patience!").method_27695(class_124.field_1061, class_124.field_1067));
                }
            } else sp.method_7353(class_2561.method_43470("Trust: " + trust + " / 20").method_27692(class_124.field_1054), true);
            return class_1269.field_21466;
        }
        return super.method_5992(player, hand);
    }

    @Override
    protected void method_6099(class_3218 level, class_1282 src, boolean byPlayer) {
        super.method_6099(level, src, byPlayer);
        if (kind == null) return;
        if (!kind.meat.isEmpty()) method_5775(level, new class_1799(ModItems.get(method_5809() ? "cooked_" + kind.meat : kind.meat), 1 + field_5974.method_43048(kind.predator ? 3 : 2)));
        if (kind.zombie) method_5775(level, new class_1799(net.minecraft.class_1802.field_8511, 1 + field_5974.method_43048(3)));
        if (!kind.pelt.isEmpty() && field_5974.method_43057() < (kind.zombie ? 0.25f : 0.8f)) method_5775(level, new class_1799(ModItems.get(kind.pelt)));
        if (kind == WildKind.DEER || kind == WildKind.MOOSE || kind == WildKind.WILD_BOAR) method_5775(level, new class_1799(net.minecraft.class_1802.field_8745, 1 + field_5974.method_43048(2)));
    }

    static boolean isMeat(class_1799 s) {
        String n = net.minecraft.class_7923.field_41178.method_10221(s.method_7909()).method_12832();
        return n.contains("beef") || n.contains("pork") || n.contains("chicken") || n.contains("mutton") || n.contains("rabbit") || n.contains("meat") || n.contains("venison");
    }

    // ---- sounds: each animal gets its own voice (vanilla sounds re-pitched), walkers sound rotten and deep
    private net.minecraft.class_10823 wolf() { return class_3417.field_57074.get(net.minecraft.class_10824.class_10825.field_57087); }
    @Override protected net.minecraft.class_3414 method_5994() {
        if (kind == null) return null;
        return switch (kind) {
            case LION, TIGER, ZOMBIE_LION, ZOMBIE_TIGER -> method_5968() != null || field_5974.method_43048(4) == 0 ? class_3417.field_14639 : class_3417.field_14741;
            case BROWN_BEAR, ICE_BEAR, ZOMBIE_BEAR -> class_3417.field_15078;
            case CROCODILE, ZOMBIE_CROC -> class_3417.field_22256;
            case WILD_BOAR -> class_3417.field_22256;
            case DEER, ZOMBIE_DEER -> class_3417.field_29809;
            case MOOSE -> class_3417.field_14780;
            case SHEPHERD, HUSKY, ROTTWEILER, PITBULL, ZOMBIE_WOLF -> method_5968() != null ? wolf().comp_3781().comp_349() : method_6181() && method_6032() < method_6063() * 0.4f ? wolf().comp_3784().comp_349() : wolf().comp_3779().comp_349();
            case CAT -> method_6181() ? class_3417.field_14589 : class_3417.field_16440;
        };
    }
    @Override protected net.minecraft.class_3414 method_6011(class_1282 src) {
        if (kind == null) return null;
        return switch (kind) {
            case LION, TIGER, ZOMBIE_LION, ZOMBIE_TIGER, CAT -> class_3417.field_14867;
            case BROWN_BEAR, ICE_BEAR, ZOMBIE_BEAR -> class_3417.field_15107;
            case CROCODILE, ZOMBIE_CROC -> class_3417.field_15183;
            case WILD_BOAR -> class_3417.field_22260;
            case DEER, ZOMBIE_DEER -> class_3417.field_29811;
            case MOOSE -> class_3417.field_14597;
            default -> wolf().comp_3782().comp_349();
        };
    }
    @Override protected net.minecraft.class_3414 method_6002() {
        if (kind == null) return null;
        return switch (kind) {
            case LION, TIGER, ZOMBIE_LION, ZOMBIE_TIGER, CAT -> class_3417.field_14971;
            case BROWN_BEAR, ICE_BEAR, ZOMBIE_BEAR -> class_3417.field_15209;
            case CROCODILE, ZOMBIE_CROC -> class_3417.field_14856;
            case WILD_BOAR -> class_3417.field_22259;
            case DEER, ZOMBIE_DEER -> class_3417.field_29810;
            case MOOSE -> class_3417.field_14857;
            default -> wolf().comp_3780().comp_349();
        };
    }
    @Override public float method_6017() {
        float base = kind == null ? 1f : switch (kind) {
            case LION -> 0.55f; case TIGER -> 0.6f; case BROWN_BEAR -> 0.8f; case ICE_BEAR -> 0.7f; case CROCODILE -> 0.5f; case WILD_BOAR -> 1.2f;
            case DEER -> 1.25f; case MOOSE -> 0.6f; case HUSKY -> 1.1f; case ROTTWEILER, PITBULL -> 0.8f; case SHEPHERD -> 0.95f; case CAT -> 1.1f;
            default -> 0.5f;   // walkers: deep and wrong
        };
        return base + (field_5974.method_43057() - 0.5f) * 0.12f;
    }
    @Override public int method_5970() { return kind != null && kind.zombie ? 140 : 260; }
    @Override protected void method_5712(net.minecraft.class_2338 pos, net.minecraft.class_2680 st) {
        if (kind == null) return;
        method_5783(kind.width >= 1.3f ? class_3417.field_15036 : kind == WildKind.DEER || kind == WildKind.MOOSE || kind == WildKind.WILD_BOAR ? class_3417.field_14613 : class_3417.field_14772, 0.25f, 1f);
    }

    @Override public boolean method_6481(class_1799 s) { return false; }
    @Override public class_1296 method_5613(class_3218 l, class_1296 m) { return null; }
    @Override public boolean method_5974(double d) { return kind != null && kind.zombie && !method_6181() && !method_16914(); }

    @Override
    protected void method_5652(class_11372 out) { super.method_5652(out); out.method_71465("Trust", trust); }
    @Override
    protected void method_5749(class_11368 in) { super.method_5749(in); trust = in.method_71424("Trust", 0); }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar c) {
        c.add(new AnimationController<WildAnimal>("main", 4, t -> t.setAndContinue(method_6172() ? SIT : t.isMoving() ? (method_5968() != null || method_18798().method_37268() > 0.02 ? RUN : WALK) : IDLE))
                .triggerableAnim("attack", ATTACK));
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
