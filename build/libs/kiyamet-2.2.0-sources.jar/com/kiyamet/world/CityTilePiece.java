package com.kiyamet.world;

import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_3341;
import net.minecraft.class_3470;
import net.minecraft.class_3485;
import net.minecraft.class_3492;
import net.minecraft.class_3793;
import net.minecraft.class_5425;
import net.minecraft.class_5819;
import net.minecraft.class_6625;

public class CityTilePiece extends class_3470 {
    public CityTilePiece(class_3485 manager, class_2960 id, class_2338 pos) {
        super(ModStructures.CITY_TILE, 0, manager, id, id.toString(), settings(), pos);
    }

    public CityTilePiece(class_6625 ctx, class_2487 tag) {
        super(ModStructures.CITY_TILE, tag, ctx.comp_135(), id -> settings());
    }

    private static class_3492 settings() {
        return new class_3492()
                .method_15133(false)
                .method_27264(true)
                .method_16184(class_3793.field_16718);
    }

    protected void method_15026(String name, class_2338 pos, class_5425 level, class_5819 random, class_3341 box) {
    }
}
