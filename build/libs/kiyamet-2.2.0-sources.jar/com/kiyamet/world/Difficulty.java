package com.kiyamet.world;

import com.kiyamet.skill.SkillManager;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/** Zombie strength follows the nearest player's Total Power and stops growing at 8000 (x3 health and damage). */
public final class Difficulty {
    public static final int CAP = 8000;

    public static int nearestPower(class_3218 level, class_2338 pos) {
        class_3222 best = null;
        double bd = Double.MAX_VALUE;
        for (class_3222 p : level.method_18456()) {
            double d = p.method_5649(pos.method_10263(), pos.method_10264(), pos.method_10260());
            if (d < bd) { bd = d; best = p; }
        }
        return best == null ? 0 : SkillManager.get(best).totalPower();
    }

    public static double multiplierNear(class_3218 level, class_2338 pos) {
        return 1.0 + 2.0 * Math.min(nearestPower(level, pos), CAP) / CAP;
    }

    private Difficulty() {}
}
