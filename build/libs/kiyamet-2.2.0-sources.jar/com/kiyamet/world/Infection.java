package com.kiyamet.world;

import com.kiyamet.Kiyamet;
import com.kiyamet.entity.ZombieKind;
import com.kiyamet.skill.Skill;
import com.kiyamet.skill.SkillManager;
import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * Zombie hits can infect (base 8%, Survival skill lowers it, immune at Survival 999).
 * Infection counts up in seconds: 5 min hunger, 10 min weakness + nausea, 15 min wither until cured.
 * Cured by a Vaccine (or Medicine perks later).
 */
public final class Infection {
    public static final AttachmentType<Integer> INFECTION = AttachmentRegistry.create(Kiyamet.id("infection"),
            b -> b.initializer(() -> 0).persistent(Codec.INT));

    public static void init() {}

    public static int get(class_3222 p) { return p.getAttachedOrElse(INFECTION, 0); }

    public static void onZombieHit(class_3222 p, ZombieKind kind) {
        if (get(p) > 0 || p.method_68878()) return;
        int survival = SkillManager.get(p).level(Skill.SURVIVAL);
        if (survival >= 999) return;
        double chance = 0.08 * (1.0 - survival / 1100.0) * (kind == ZombieKind.TOXIC ? 2 : 1);
        if (p.method_59922().method_43058() < chance) {
            p.setAttached(INFECTION, 1);
            p.method_64398(class_2561.method_43471("kiyamet.msg.infected").method_27695(class_124.field_1077, class_124.field_1067));
        }
    }

    public static void cure(class_3222 p) {
        p.removeAttached(INFECTION);
        p.method_6016(class_1294.field_5920);
        p.method_6016(class_1294.field_5916);
        p.method_6016(class_1294.field_5911);
        p.method_6016(class_1294.field_5903);
        p.method_64398(class_2561.method_43471("kiyamet.msg.cured").method_27692(class_124.field_1060));
    }

    /** Called once per second per player. */
    public static void tick(class_3222 p) {
        int t = get(p);
        if (t <= 0) return;
        p.setAttached(INFECTION, t + 1);
        if (t >= 300) p.method_6092(new class_1293(class_1294.field_5903, 40, 0, true, false));
        if (t >= 600) { p.method_6092(new class_1293(class_1294.field_5911, 40, 0, true, false)); if (t % 30 == 0) p.method_6092(new class_1293(class_1294.field_5916, 120, 0, true, false)); }
        if (t >= 900) p.method_6092(new class_1293(class_1294.field_5920, 40, 0, true, false));
        if (t % 60 == 0) SkillManager.addXp(p, Skill.SURVIVAL, 10);
    }

    private Infection() {}
}
