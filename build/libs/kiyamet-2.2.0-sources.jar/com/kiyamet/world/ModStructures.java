package com.kiyamet.world;

import com.kiyamet.Kiyamet;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_3773;
import net.minecraft.class_6862;
import net.minecraft.class_7151;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ModStructures {
    public static final class_7151<TiledCityStructure> TILED_CITY =
            class_2378.method_10230(class_7923.field_41147, Kiyamet.id("tiled_city"), () -> TiledCityStructure.CODEC);
    public static final class_3773 CITY_TILE =
            class_2378.method_10230(class_7923.field_41146, Kiyamet.id("city_tile"), (class_3773) CityTilePiece::new);

    public static final class_6862<class_3195> SANCTUARY = class_6862.method_40092(class_7924.field_41246, Kiyamet.id("sanctuary"));

    /** True inside mosques, churches and the peaceful camps/villages — zombies never spawn there. */
    public static boolean inSanctuary(class_3218 level, class_2338 pos) {
        return level.method_27056().method_57560(pos, SANCTUARY).method_16657();
    }

    public static void init() {
    }

    private ModStructures() {
    }
}
