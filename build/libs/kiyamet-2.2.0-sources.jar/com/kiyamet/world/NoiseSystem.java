package com.kiyamet.world;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

/** Loud actions (mining, explosions, guns, car horns, screams) leave short-lived noises that idle zombies walk to. */
public final class NoiseSystem {
    private record Noise(class_3218 level, class_2338 pos, double radius, long until) {}
    private static final List<Noise> NOISES = new ArrayList<>();

    public static void make(class_3218 level, class_2338 pos, double radius, int seconds) {
        if (NOISES.size() > 256) NOISES.remove(0);
        NOISES.add(new Noise(level, pos.method_10062(), radius, level.method_75260() + seconds * 20L));
    }

    public static class_2338 loudestNear(class_3218 level, class_2338 at, double hearing) {
        long now = level.method_75260();
        class_2338 best = null;
        double bestScore = 0;
        for (Iterator<Noise> it = NOISES.iterator(); it.hasNext(); ) {
            Noise n = it.next();
            if (n.until < now) { it.remove(); continue; }
            if (n.level != level) continue;
            double r = n.radius * hearing, d = Math.sqrt(n.pos.method_10262(at));
            if (d < r && r - d > bestScore) { bestScore = r - d; best = n.pos; }
        }
        return best;
    }

    private NoiseSystem() {}
}
