package com.kiyamet.world;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Arrays;
import java.util.Optional;
import net.minecraft.class_2338;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3195;
import net.minecraft.class_6626;
import net.minecraft.class_7151;

/** A giant city assembled from a grid of 64x64 tile templates: cities/&lt;layout&gt;/t_i_j. */
public class TiledCityStructure extends class_3195 {
    public static final MapCodec<TiledCityStructure> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
            method_42697(i),
            Codec.STRING.fieldOf("layout").forGetter(s -> s.layout),
            Codec.INT.fieldOf("cols").forGetter(s -> s.cols),
            Codec.INT.fieldOf("rows").forGetter(s -> s.rows)
    ).apply(i, TiledCityStructure::new));

    public static final int TILE = 64;
    private final String layout;
    private final int cols, rows;

    public TiledCityStructure(class_7302 settings, String layout, int cols, int rows) {
        super(settings);
        this.layout = layout;
        this.cols = cols;
        this.rows = rows;
    }

    @Override
    protected Optional<class_7150> method_38676(class_7149 ctx) {
        int w = cols * TILE, d = rows * TILE;
        // centre the city on the start chunk so every tile stays within reference range
        int x0 = ctx.comp_568().method_8326() - w / 2;
        int z0 = ctx.comp_568().method_8328() - d / 2;
        int[] hs = new int[9];
        int k = 0;
        for (int a = 0; a < 3; a++)
            for (int b = 0; b < 3; b++)
                hs[k++] = ctx.comp_562().method_18028(x0 + a * (w - 1) / 2, z0 + b * (d - 1) / 2,
                        class_2902.class_2903.field_13194, ctx.comp_569(), ctx.comp_564());
        Arrays.sort(hs);
        if (hs[8] - hs[0] > 40) return Optional.empty();       // too rugged for a city
        int y = hs[4];
        if (y < ctx.comp_562().method_16398()) return Optional.empty();
        class_2338 origin = new class_2338(x0, y, z0);
        String[] p = layout.split(":", 2);
        String ns = p.length == 2 ? p[0] : "kiyamet", city = p.length == 2 ? p[1] : p[0];
        return Optional.of(new class_7150(origin, (class_6626 b) -> {
            for (int i = 0; i < cols; i++)
                for (int j = 0; j < rows; j++) {
                    class_2960 id = class_2960.method_60655(ns, "cities/" + city + "/t_" + i + "_" + j);
                    if (ctx.comp_565().method_15094(id).isEmpty()) continue;
                    b.method_35462(new CityTilePiece(ctx.comp_565(), id, origin.method_10069(i * TILE, 0, j * TILE)));
                }
        }));
    }

    @Override
    public class_7151<?> method_41618() {
        return ModStructures.TILED_CITY;
    }
}
